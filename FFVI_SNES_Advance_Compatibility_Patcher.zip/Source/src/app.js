'use strict';
const el = id => document.getElementById(id);
const catalog = JSON.parse(el('catalog').textContent);
const personal = JSON.parse(el('personal').textContent);
// Capture the public page before adding file names, blob URLs or translated controls.
const template = '<!doctype html>\n' + document.documentElement.outerHTML;
// Do not expose an edition until its tested adapter and exact output exist.
const roseEnabled=!!(catalog.rose?.enabled && typeof catalog.rose.plan==='string' && catalog.rose.plan.length>0 &&
    /^[a-f0-9]{64}$/.test(catalog.rose.target||'') &&
    catalog.rose.profiles?.[catalog.rose.target]?.edition==='rose' && catalog.sources.rose?.length);
const options = [
    ...(roseEnabled?[{id:'rose',url:'https://silentenigma.neocities.org/ff6rose/'}]:[]),
    {id:'twue',url:'https://www.romhacking.net/hacks/1386/',mirror:'https://retroachievements.org/game/341/hashes'},
    {id:'vanilla',battle:true},
    {id:'turn',battle:true, url:'https://romhackplaza.org/romhacks/final-fantasy-vi-turn-based-snes/'},
    ...['modern','classic','ctb'].map(id=>({id,battle:true,url:'https://romhackplaza.org/romhacks/ff6-comprehensive-atb-enhancement-snes/'})),
    {id:'dash'},
    {id:'font', url:'https://www.ff6hacking.com/forums/thread-3358.html'},
    {id:'spanish', url:'https://romhackplaza.org/translations/final-fantasy-vi-spanish-translation-snes/',
     mirror:'https://retrohackers.net/translation-details.php?id=5487'},
    {id:'names'},
    {id:'music',url:'https://www.romhacking.net/hacks/1386/'}
];
const labels = {
    "en": {
        "futureWarning": "Warning: a selected patch is newer than the verified release or has unrecognized source bytes. Compatible revisions may proceed, but they have not been playtested. Changes to protected code, data or layout still need an adapter update. Test the resulting game before relying on it.",
        "futureUntested": "Untested patch revision",
        "futureConflict": "This patch changes protected code, data or layout that this adapter cannot merge safely. An adapter update is needed; its version number is not the reason for rejection.",
        "futureAmbiguous": "More than one patch matches this choice. Select only the intended main patch or option.",
        "roseFutureLayout": "ROSE changes protected code, dialogue controls or layout that this adapter cannot merge safely.",
        "rose": "Revised Old Style Edition (ROSE)",
        "roseDesc": "Alternative English edition by SilentEnigma. Verified with the ROSE v2.04 main patch; compatible newer revisions warn and may proceed. Uses the main patch with the native ROSE font, Original ATB, and built-in Cancel dash. Other font, battle-system and ROSE tweak patches are not supported.",
        "roseFile": "Choose the ROSE ZIP, or its main headered/unheadered IPS (verified through v2.04). The main patch is selected automatically.",
        "roseFiles": "Choose the ROSE ZIP or main IPS (verified through v2.04). Broken, Classy, Clunky, ClunkyAndBroken and Square tweaks are not supported.",
        "roseLocked": "Start from the Regular edition without other options. ROSE replaces the English edition and includes Cancel dash.",
        "roseUnsupported": "This ROSE build uses its native font, Original ATB, and built-in Cancel dash. This additional option is not supported.",
        "roseUnavailable": "ROSE is not enabled in this patcher release.",
        "roseIncluded": "Included with ROSE",
        "editionRose": "Revised Old Style Edition",
        "roseCredits": "ROSE v2.04 by SilentEnigma and the contributors credited in its original readme; original main patch required.",
        "roseReadme": "Original ROSE credits, readme and permission notice",
        "roseReadmeDownload": "Download the original ROSE readme",
        "roseRomHint": "Recognized 8 MiB ROSE adapter outputs can also be reopened.",
        "twue": "Ted Woolsey Uncensored Edition",
        "twueDesc": "Alternative English edition by Rodimus Primal. Verified with the six TWUE 3.07 editions; compatible newer revisions warn and may proceed, including Bug Fixes, Add-Ons and Updated Opera. Includes Cancel dash. Earlier base 3.06/3.06a patches remain supported.",
        "twueFile": "Choose the TWUE ZIP, or the IPS for the edition selected below (verified through 3.07). Earlier base IPS/BPS/ZIP files are also supported.",
        "twueFiles": "Choose the original TWUE patch or ZIP matching the selected edition.",
        "twueLocked": "Start from the Regular edition without Spanish, Turn-Based, or legacy font patches. TWUE replaces the English edition and includes dash.",
        "twueFont": "Choose the cartridge font or Multi-Font Selection for TWUE.",
        "editionTwue": "Ted Woolsey Uncensored Edition",
        "battleTitle": "Battle system",
        "battleHint": "Choose one battle system. Other options below can be combined with it.",
        "vanilla": "Original ATB",
        "vanillaDesc": "Keep the standard SNES Advance battle timing.",
        "modern": "Modern ATB Enhanced",
        "modernDesc": "RoSoDude v2.00. Time runs during animations until someone is ready to act. Supports Active and Wait.",
        "classic": "Classic ATB Enhanced",
        "classicDesc": "RoSoDude v2.00. Time pauses during every battle animation. Supports Active and Wait.",
        "ctb": "CTB Wait",
        "ctbDesc": "RoSoDude v2.00. Fully turn-based in Wait mode; Modern ATB in Active mode. Skip turn can advance time.",
        "modernFile": "Choose RoSoDude’s v2.00 ZIP or the Modern 1.1 US IPS.",
        "classicFile": "Choose RoSoDude’s v2.00 ZIP or the Classic Addon 1.1 US IPS. The addon file includes the complete hack.",
        "ctbFile": "Choose RoSoDude’s v2.00 ZIP or the CTB Wait Addon 1.1 US IPS. The addon file includes the complete hack.",
        "battleConflict": "Choose only one battle system. To replace clymax Turn-Based, start from a ROM without that option.",
        "battleLocked": "This ROM has clymax Turn-Based installed. Open a ROM without it to choose a different battle system.",
        "title": "Compatibility patcher",
        "subtitle": "Combine optional patches in a single ROM. Your files stay on this device.",
        "romLabel": "Game ROM",
        "romHint": "Choose an original North American Final Fantasy III ROM (v1.0 or v1.1), or a supported SNES Advance ROM. Original ROMs prompt you to choose Regular or MoleMan. Earlier SNES Advance releases and recognized patcher outputs remain supported.",
        "retailTitle": "Choose your SNES Advance edition",
        "retailHint": "Apply the base edition first, then choose any optional patches below. The matching original-ROM revision is selected automatically.",
        "retailEdition": "Base edition",
        "retailChoose": "Choose an edition…",
        "retailRegular": "Regular — original SNES text",
        "retailMoleman": "MoleMan — GBA translation",
        "retailApply": "Apply base edition",
        "retailApplying": "Applying and verifying the base edition…",
        "retailReady": "Base edition applied. Download it now or choose optional patches below.",
        "retailDetected": "Original Final Fantasy III (USA) v",
        "retailUnknown": "Unrecognized original ROM. Choose an unmodified North American Final Fantasy III v1.0 or v1.1 ROM.",
        "retailMolemanRequired": "Choose MoleMan’s original standard GBA Text BPS or ZIP. Verified with v1.6 and v1.8; newer versions show a warning and must pass compatibility checks. The translation patch is not included.",
        "retailMolemanInvalid": "Choose a valid original MoleMan standard GBA Text BPS or ZIP.",
        "molemanUntested": "Warning: this MoleMan release is newer than v1.8 or unrecognized. Compatibility is verified through v1.8. Compatible dialogue updates can proceed, but other code or layout changes require an adapter update. Test the resulting game before relying on it.",
        "molemanLayout": "This MoleMan patch changes code, data, or a layout that the current adapter cannot safely merge. Its version number is not the restriction; an adapter update is needed for these changes.",
        "molemanAmbiguous": "This ZIP contains more than one standard BPS patch. Extract and select the intended standard BPS file.",
        "retailMolemanAlternate": "Choose MoleMan’s standard patch. The Minus Pop-Culture edition is not supported.",
        "options": "Options",
        "yourBuild": "Your build",
        "build": "Build ROM",
        "download": "Download ROM",
        "credits": "Credits",
        "dashCredits": "Original Cancel Button Dash credits and readme",
        "creditText": "TWUE by Rodimus Primal and its credited contributors. Multi-Font Selection 1.4.1 and Music Player by Madsiur; Advance font artwork by seibaby. Original patches are required. Our proportional font imports glyphs from your U.S. FFVI Advance cartridge. Cancel Button Dash by SilentEnigma, based on Master ZED’s work. Turn-Based by clymax. Comprehensive ATB Enhancement v2.00 by RoSoDude. Spanish translation by Rod Mérida and Traducciones Crackowia.",
        "dash": "Cancel Button Dash",
        "dashDesc": "Hold Cancel to run in the field. Stacks with Sprint Shoes.",
        "turn": "Turn-Based (clymax)",
        "turnDesc": "Includes the Fight targeting fix. Set the battle mode to Wait in Config.",
        "font": "GBA font",
        "fontDesc": "Choose Multi-Font Selection 1.4.1 (default) or our proportional GBA font. Each uses its original source file; you can switch between them when reopening a build made from native fonts.",
        "battleDonor": "Choose the original U.S. GBA ROM again to import its battle HUD digits.",
        "upgradeFile": "Choose your original U.S. .gba file or its ZIP.",
        "updateFont": "Replace the installed legacy font with the cartridge font",
        "legacyFont": "Legacy font pack",
        "cartFont": "Cartridge font",
        "legacyLink": "Legacy font pack",
        "badGba": "Choose an unmodified U.S. Final Fantasy VI Advance ROM (BZ6E).",
        "spanish": "Spanish translation",
        "spanishDesc": "Play the original story and SNES Advance bonus content in Spanish.",
        "spanishLocked": "Spanish uses the Regular edition. Choose a Regular ROM to enable it.",
        "turnFile": "Choose clymax’s Rev 1 v0.01 ZIP or its IPS.",
        "fontFile": "Choose your original U.S. Final Fantasy VI Advance .gba file or its ZIP.",
        "spanishFile": "Choose Crackowia’s NTSC v1.15 ZIP or FF6ESP.IPS.",
        "names": "Longer item and monster names",
        "namesDesc": "Expands abbreviated item and monster names. Requires our proportional cartridge font.",
        "source": "Original patch",
        "mirror": "Alternate download",
        "installed": "Installed",
        "none": "No options selected",
        "chooseRom": "Choose your SNES Advance ROM to begin.",
        "noOptions": "Select an option to build your ROM.",
        "already": "This ROM already has the selected options.",
        "need": "Choose the patch files for",
        "ready": "Ready to build.",
        "working": "Building and verifying your ROM…",
        "checking": "Checking the ROM…",
        "done": "ROM verified and ready to download.",
        "unknown": "Unrecognized ROM. Choose an original U.S. Final Fantasy III v1.0/v1.1 ROM or a supported SNES Advance build.",
        "wrongSize": "Choose an extracted original U.S. Final Fantasy III or supported SNES Advance ROM (.sfc or .smc).",
        "old": "Compatibility updates are available for this ROM. Build once to apply them.",
        "romVerified": "Recognized",
        "editionRegular": "Regular",
        "editionMoleman": "MoleMan",
        "badFiles": "The selected files do not match this release.",
        "badZip": "Could not read this ZIP. Extract the original IPS file(s) and select them instead.",
        "verifyFail": "Output verification failed. Reopen the public patcher and check your input files.",
        "browser": "Open the HTML in a current browser with Web Crypto and DecompressionStream support.",
        "savePersonal": "Save a personal patcher",
        "personalHint": "Includes your verified patch files and option choices for offline reuse. Share the original tool with other players.",
        "bundled": "Patch files included in this personal copy.",
        "badPersonal": "The saved patch files failed verification. Select the original files.",
        "missing": "Missing",
        "duplicate": "Choose each original patch only once.",
        "personalError": "Could not save the personal patcher.",
        "writeError": "Could not read the selected file.",
        "fontImplementation": "GBA font version",
        "fontTimingWarning": "Timing note: Our proportional font can make some menus and battle item/spell lists slightly slower to open or redraw.",
        "fontCartridge": "Our cartridge font — proportional text",
        "fontMultifont": "Multi-Font Selection 1.4.1 — fixed-width menus",
        "fontLegacy": "Older seibaby font pack",
        "multifont": "Multi-Font Selection 1.4.1",
        "multiFontFile": "Choose the original Multi-Font Selection 1.4.1 ZIP or Multi_Fonts_1.4.1_nh.ips. Normal/Advance can be switched in Config; Advance is the default.",
        "legacyFontFile": "Choose the original seibaby font pack ZIP or its two -N.ips files.",
        "nativeFontRequired": "Start from a native-font build to choose native fonts or Multi-Font Selection. The older font pack did not retain the original glyphs.",
        "variantLabel": "TWUE edition",
        "variantLocked": "The TWUE edition is already installed. Start from Regular to choose a different primary TWUE edition.",
        "variant-base": "Base",
        "variant-opera": "Base + Updated Opera",
        "variant-bugfix": "Bug Fixes",
        "variant-bugfix-opera": "Bug Fixes + Updated Opera",
        "variant-addons": "Bug Fixes + Add-Ons",
        "variant-addons-opera": "Bug Fixes + Add-Ons + Updated Opera",
        "music": "Music Player",
        "musicDesc": "TWUE 3.07 music player, including SNES Advance’s added bonus track. Choose its location and optional event/audio fixes.",
        "musicFile": "Choose the original TWUE 3.07 ZIP or the selected music-player IPS and optional fix IPS files. The TWUE ZIP selected above can also supply these files.",
        "musicLocked": "Available with TWUE 3.07.",
        "musicPlacement": "Player location",
        "music-config1": "Config — replace Mono option",
        "music-config2": "Config — add Music row",
        "music-mainA": "Main menu — add Music (Bug Fixes editions)",
        "music-mainB": "Main menu — add Music (Base editions)",
        "fix-sfx": "Restore music volume after event sound effects",
        "fix-lete": "Restore music on Lete River transitions",
        "fix-caves": "Restore music volume in caves and cliffs"
    },
    "es": {
        "futureWarning": "Aviso: un parche seleccionado es posterior a la versión verificada o contiene datos de origen no reconocidos. Las revisiones compatibles pueden continuar, pero no se han probado jugando. Los cambios de código, datos o estructura protegidos todavía necesitan actualizar el adaptador. Prueba el juego resultante antes de depender de él.",
        "futureUntested": "Revisión de parche no probada",
        "futureConflict": "Este parche cambia código, datos o estructura protegidos que el adaptador no puede combinar de forma segura. Es necesario actualizar el adaptador; el rechazo no se debe al número de versión.",
        "futureAmbiguous": "Hay más de un parche para esta opción. Selecciona solo el parche principal o la opción deseada.",
        "roseFutureLayout": "ROSE cambia código, controles de diálogo o estructura protegidos que el adaptador no puede combinar de forma segura.",
        "rose": "Revised Old Style Edition (ROSE)",
        "roseDesc": "Edición alternativa en inglés de SilentEnigma. Usa el parche principal original ROSE v2.04 con su fuente propia, ATB original y carrera mediante Cancelar. No admite otras fuentes, sistemas de combate ni parches de ajustes de ROSE.",
        "roseFile": "Elige el ZIP original ROSE v2.04 o su IPS principal, con o sin cabecera. El parche principal se selecciona automáticamente.",
        "roseFiles": "Elige el ZIP original ROSE v2.04 o el IPS principal. No se admiten los ajustes Broken, Classy, Clunky, ClunkyAndBroken ni Square.",
        "roseLocked": "Empieza con la edición Regular sin otras opciones. ROSE sustituye la edición inglesa e incluye correr con Cancelar.",
        "roseUnsupported": "Esta versión de ROSE usa su fuente propia, ATB original y carrera mediante Cancelar. No admite esta opción adicional.",
        "roseUnavailable": "ROSE no está habilitado en esta versión de la herramienta.",
        "roseIncluded": "Incluido con ROSE",
        "editionRose": "Revised Old Style Edition",
        "roseCredits": "ROSE v2.04 es de SilentEnigma y los colaboradores de sus créditos originales; requiere el parche principal original.",
        "roseReadme": "Créditos, instrucciones y permiso de uso originales de ROSE",
        "roseReadmeDownload": "Descargar las instrucciones originales de ROSE",
        "roseRomHint": "También puedes abrir resultados reconocidos de 8 MiB del adaptador ROSE.",
        "twue": "Ted Woolsey Uncensored Edition",
        "twueDesc": "Edición alternativa en inglés de Rodimus Primal. Elige una de las seis ediciones TWUE 3.07: Bug Fixes, Add-Ons y Updated Opera. Incluye correr con Cancelar. También admite los parches base anteriores 3.06/3.06a.",
        "twueFile": "Elige el ZIP original TWUE 3.07 o el IPS de la edición seleccionada. También admite los IPS/BPS/ZIP de ediciones base anteriores.",
        "twueFiles": "Elige el parche o ZIP original de TWUE que corresponda a la edición seleccionada.",
        "twueLocked": "Empieza con la edición Regular sin español, Turn-Based ni fuente antigua. TWUE sustituye la edición inglesa e incluye correr.",
        "twueFont": "Elige la fuente del cartucho o Multi-Font Selection para TWUE.",
        "editionTwue": "Ted Woolsey Uncensored Edition",
        "battleTitle": "Sistema de combate",
        "battleHint": "Elige un sistema de combate. Puedes combinarlo con las otras opciones.",
        "vanilla": "ATB original",
        "vanillaDesc": "Conserva el ritmo de combate habitual de SNES Advance.",
        "modern": "Modern ATB Enhanced",
        "modernDesc": "RoSoDude v2.00. El tiempo avanza durante las animaciones hasta que alguien esté listo para actuar. Compatible con Activo y Espera.",
        "classic": "Classic ATB Enhanced",
        "classicDesc": "RoSoDude v2.00. El tiempo se detiene durante todas las animaciones de combate. Compatible con Activo y Espera.",
        "ctb": "CTB Wait",
        "ctbDesc": "RoSoDude v2.00. Combate por turnos en modo Espera y Modern ATB en modo Activo. Saltar turno permite avanzar el tiempo.",
        "modernFile": "Elige el ZIP v2.00 de RoSoDude o el IPS Modern para ROM estadounidense 1.1.",
        "classicFile": "Elige el ZIP v2.00 de RoSoDude o el IPS Classic Addon para ROM estadounidense 1.1. Incluye el parche completo.",
        "ctbFile": "Elige el ZIP v2.00 de RoSoDude o el IPS CTB Wait Addon para ROM estadounidense 1.1. Incluye el parche completo.",
        "battleConflict": "Elige un único sistema de combate. Para sustituir Turn-Based de clymax, abre una ROM que no lo tenga instalado.",
        "battleLocked": "Esta ROM ya tiene Turn-Based de clymax. Abre una ROM sin esa opción para cambiar el sistema de combate.",
        "title": "Herramienta de parches",
        "subtitle": "Combina varios parches en una sola ROM. Los archivos se procesan en tu dispositivo.",
        "romLabel": "ROM del juego",
        "romHint": "Elige una ROM original norteamericana de Final Fantasy III (v1.0 o v1.1), o una ROM compatible de SNES Advance. Con una ROM original podrás elegir Regular o MoleMan. También admite versiones anteriores de SNES Advance y resultados reconocidos de esta herramienta.",
        "retailTitle": "Elige tu edición de SNES Advance",
        "retailHint": "Aplica primero la edición base y después elige los parches opcionales. La revisión de la ROM original se selecciona automáticamente.",
        "retailEdition": "Edición base",
        "retailChoose": "Elige una edición…",
        "retailRegular": "Regular — texto original de SNES",
        "retailMoleman": "MoleMan — traducción de GBA",
        "retailApply": "Aplicar edición base",
        "retailApplying": "Aplicando y verificando la edición base…",
        "retailReady": "Edición base aplicada. Descárgala o elige parches opcionales abajo.",
        "retailDetected": "Final Fantasy III original (USA) v",
        "retailUnknown": "ROM original desconocida. Elige una ROM norteamericana de Final Fantasy III v1.0 o v1.1 sin modificar.",
        "retailMolemanRequired": "Elige el BPS o ZIP original de GBA Text de MoleMan, edición estándar. Verificado con v1.6 y v1.8; las versiones nuevas muestran un aviso y deben superar las comprobaciones de compatibilidad. La traducción no está incluida.",
        "retailMolemanInvalid": "Elige un BPS o ZIP original válido de GBA Text de MoleMan, edición estándar.",
        "molemanUntested": "Aviso: esta versión de MoleMan es posterior a v1.8 o no se reconoce. La compatibilidad está verificada hasta v1.8. Los cambios compatibles de diálogo pueden continuar; otros cambios de código o estructura necesitan actualizar el adaptador. Prueba el juego resultante antes de depender de él.",
        "molemanLayout": "Este parche de MoleMan cambia código, datos o una estructura que el adaptador actual no puede combinar de forma segura. La restricción no es el número de versión; estos cambios necesitan actualizar el adaptador.",
        "molemanAmbiguous": "Este ZIP contiene más de un BPS estándar. Extrae y elige el BPS estándar deseado.",
        "retailMolemanAlternate": "Elige la edición estándar de MoleMan. La edición Minus Pop-Culture no es compatible.",
        "options": "Opciones",
        "yourBuild": "Tu versión",
        "build": "Crear ROM",
        "download": "Descargar ROM",
        "credits": "Créditos",
        "dashCredits": "Créditos e instrucciones originales de Cancel Button Dash",
        "creditText": "TWUE es de Rodimus Primal y sus colaboradores. Multi-Font Selection 1.4.1 y Music Player son de Madsiur; fuente Advance de seibaby. Requiere los parches originales. Nuestra fuente proporcional importa glifos del cartucho estadounidense FFVI Advance. Cancel Button Dash es de SilentEnigma, basado en Master ZED. Turn-Based es de clymax. Comprehensive ATB Enhancement v2.00 es de RoSoDude. Traducción española de Rod Mérida y Traducciones Crackowia.",
        "dash": "Correr con Cancelar",
        "dashDesc": "Mantén pulsado Cancelar para correr. Se combina con el efecto de las Botas Veloces (Sprint Shoes).",
        "turn": "Combate por turnos (clymax)",
        "turnDesc": "Incluye la corrección al elegir un objetivo al atacar. Selecciona el modo de espera en la configuración de combate.",
        "font": "Fuente de GBA",
        "fontDesc": "Elige Multi-Font Selection 1.4.1 (predeterminada) o nuestra fuente proporcional de GBA. Cada una requiere su archivo original. Puedes cambiarlas al abrir una ROM creada a partir de las fuentes nativas.",
        "battleDonor": "Selecciona otra vez la ROM original de GBA (USA) para importar los dígitos de la interfaz de batalla.",
        "upgradeFile": "Elige tu archivo .gba estadounidense original o su ZIP.",
        "updateFont": "Sustituir la fuente anterior por la del cartucho",
        "legacyFont": "Fuente anterior",
        "cartFont": "Fuente del cartucho",
        "legacyLink": "Paquete de fuentes anterior",
        "badGba": "Elige una ROM estadounidense original de Final Fantasy VI Advance (BZ6E).",
        "spanish": "Traducción al español",
        "spanishDesc": "Juega en español tanto la historia original como el contenido adicional de SNES Advance.",
        "spanishLocked": "La traducción española requiere la edición Regular. Elige una ROM Regular para activarla.",
        "turnFile": "Elige el ZIP de clymax v0.01 para Rev 1 o su archivo IPS.",
        "fontFile": "Elige tu archivo .gba original estadounidense de Final Fantasy VI Advance o su ZIP.",
        "spanishFile": "Elige el ZIP de Crackowia v1.15 (NTSC) o FF6ESP.IPS.",
        "names": "Nombres largos de objetos y monstruos",
        "namesDesc": "Amplía los nombres abreviados de objetos y monstruos. Requiere nuestra fuente proporcional del cartucho.",
        "source": "Parche original",
        "mirror": "Descarga alternativa",
        "installed": "Instalado",
        "none": "Ninguna opción seleccionada",
        "chooseRom": "Elige tu ROM de SNES Advance para empezar.",
        "noOptions": "Selecciona una opción para crear la ROM.",
        "already": "La ROM ya incluye las opciones seleccionadas.",
        "need": "Selecciona los archivos de",
        "ready": "Todo listo para crear la ROM.",
        "working": "Creando y verificando la ROM…",
        "checking": "Comprobando la ROM…",
        "done": "ROM verificada y lista para descargar.",
        "unknown": "ROM desconocida. Elige una ROM original USA de Final Fantasy III v1.0/v1.1 o una versión compatible de SNES Advance.",
        "wrongSize": "Elige una ROM original USA de Final Fantasy III o una ROM compatible de SNES Advance extraída del archivo comprimido (.sfc o .smc).",
        "old": "Hay actualizaciones de compatibilidad para esta ROM. Crea la ROM para aplicarlas.",
        "romVerified": "ROM reconocida",
        "editionRegular": "Regular",
        "editionMoleman": "MoleMan",
        "badFiles": "Los archivos seleccionados no coinciden con esta versión.",
        "badZip": "No se pudo leer el ZIP. Extrae y selecciona los archivos IPS originales.",
        "verifyFail": "Falló la verificación. Vuelve a abrir la herramienta pública y comprueba los archivos.",
        "browser": "Abre el HTML en un navegador actual que admita Web Crypto y DecompressionStream.",
        "savePersonal": "Guardar una herramienta personal",
        "personalHint": "Incluye tus parches verificados y tus opciones para usarlos sin conexión. Comparte la herramienta original con otros jugadores.",
        "bundled": "Esta copia personal incluye los archivos del parche.",
        "badPersonal": "Los parches guardados no superaron la verificación. Elige los archivos originales.",
        "missing": "Falta",
        "duplicate": "Selecciona cada parche original una sola vez.",
        "personalError": "No se pudo guardar la herramienta personal.",
        "writeError": "No se pudo leer el archivo seleccionado.",
        "fontImplementation": "Versión de la fuente de GBA",
        "fontTimingWarning": "Nota sobre la velocidad: Nuestra fuente proporcional puede hacer que algunos menús y las listas de objetos y hechizos en combate tarden un poco más en abrirse o actualizarse.",
        "fontCartridge": "Nuestra fuente del cartucho — texto proporcional",
        "fontMultifont": "Multi-Font Selection 1.4.1 — menús de ancho fijo",
        "fontLegacy": "Paquete anterior de seibaby",
        "multifont": "Multi-Font Selection 1.4.1",
        "multiFontFile": "Elige el ZIP original Multi-Font Selection 1.4.1 o Multi_Fonts_1.4.1_nh.ips. Puedes elegir Normal/Advance en Config; Advance es la opción predeterminada.",
        "legacyFontFile": "Elige el ZIP original de seibaby o sus dos archivos -N.ips.",
        "nativeFontRequired": "Abre una versión con fuentes nativas para elegir estas o Multi-Font Selection. El paquete anterior no conservó los glifos originales.",
        "variantLabel": "Edición TWUE",
        "variantLocked": "Esta edición TWUE ya está instalada. Empieza con Regular para elegir otra edición principal.",
        "variant-base": "Base",
        "variant-opera": "Base + Updated Opera",
        "variant-bugfix": "Bug Fixes",
        "variant-bugfix-opera": "Bug Fixes + Updated Opera",
        "variant-addons": "Bug Fixes + Add-Ons",
        "variant-addons-opera": "Bug Fixes + Add-Ons + Updated Opera",
        "music": "Reproductor de música",
        "musicDesc": "Reproductor de TWUE 3.07, incluida la pista adicional de SNES Advance. Elige su ubicación y las correcciones opcionales de eventos y audio.",
        "musicFile": "Elige el ZIP original TWUE 3.07 o el IPS del reproductor y los IPS de correcciones seleccionados. También puede usar el ZIP de TWUE seleccionado arriba.",
        "musicLocked": "Disponible con TWUE 3.07.",
        "musicPlacement": "Ubicación del reproductor",
        "music-config1": "Config — sustituir opción Mono",
        "music-config2": "Config — añadir fila Music",
        "music-mainA": "Menú principal — añadir Music (Bug Fixes)",
        "music-mainB": "Menú principal — añadir Music (Base)",
        "fix-sfx": "Restaurar el volumen después de efectos de sonido",
        "fix-lete": "Restaurar la música en transiciones del río Lete",
        "fix-caves": "Restaurar el volumen en cuevas y acantilados"
    }
};
let lang = personal.lang || (navigator.language.toLowerCase().startsWith('es') ? 'es' : 'en');
if (!labels[lang]) lang = 'en';
const t = key => labels[lang][key] || key;
const failure = key => Object.assign(new Error(t(key)),{code:key});
const from64 = str => Uint8Array.from(atob(str), c => c.charCodeAt(0));
function to64(bytes) {
    let binary = '';
    for (let i=0; i<bytes.length; i+=8192) binary += String.fromCharCode(...bytes.subarray(i,i+8192));
    return btoa(binary);
}
async function rawHash(bytes) {
    if (!globalThis.crypto?.subtle) throw failure('browser');
    const result = new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));
    return Array.from(result,x=>x.toString(16).padStart(2,'0')).join('');
}
let knownSourceDigests=null;
async function hash(bytes) {
    const actual=await rawHash(bytes);
    if(![0x400000,0x800000].includes(bytes.length))return actual;
    // Preserve every exact current/historical identity before trying a
    // constrained structural alias for changed translation text.
    if(!knownSourceDigests)knownSourceDigests=new Set((JSON.stringify(catalog)+JSON.stringify(retailBaseData)).match(/[a-f0-9]{64}/g)||[]);
    if(knownSourceDigests.has(actual))return actual;
    const moleman=await molemanDialogueAlias(bytes,actual,retailBaseData.molemanAliases||{},rawHash);
    if(moleman!==actual)return moleman;
    for(const alias of [roseFutureAlias,twueDialogueAlias,spanishFutureAlias]){
        const matched=await alias(bytes,actual,rawHash);if(matched!==actual)return matched;
    }
    return actual;
}
function writeChecksum(bytes) {
    bytes.set([255,255,0,0],0xffdc);
    let sum = 0;
    for (const b of bytes) sum += b;
    const view = new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
    view.setUint16(0xffdc,sum^65535,true);
    view.setUint16(0xffde,sum,true);
}
function applyOverlay(out,base,index) {
    for (const [offset,data] of catalog.overlays[index]) {
        const payload = typeof data==='number' ? base.subarray(offset,offset+data) : from64(data);
        out.set(payload,offset);
    }
}
// Install display tables without changing inventory IDs or the text used in dialogue.
function nameLayout(bytes, layout, undo=false) {
    const out=bytes.slice();
    for (const [src,dst,n] of layout.copies) {
        if (undo) out.fill(255,dst,dst+n);
        else out.set(bytes.subarray(src,src+n),dst);
    }
    if (!undo) {
        for (const [offset,value] of layout.edits) out.set(from64(value),offset);
    }
    for (const [offset,original,replacement] of layout.shared) {
        out.set(from64(undo?original:replacement),offset);
    }
    for (const [slot,code,leading] of layout.spaces) {
        const dest=0x47fc0+16*slot;
        out.fill(0,dest,dest+16);
        if (undo) continue;
        // Fold a word break into the side bearing of the player's own GBA glyph.
        const start=0x47fc0+16*code;
        const tile=bytes.subarray(start,start+16);
        let occupied=0;
        for (let y=0;y<8;y++) occupied|=tile[2*y]&tile[2*y+1];
        const columns=[0,1,2,3,4,5,6,7].filter(x=>occupied&(128>>x));
        const first=columns[0],width=columns.at(-1)-first+1,target=Math.min(5,width);
        for (let x=0;x<target;x++) {
            const oldX=first+Math.round(x*(width-1)/Math.max(1,target-1));
            const newX=(leading?8-target:0)+x;
            for (let row=0;row<16;row++) {
                if (tile[row]&(128>>oldX)) out[dest+row]|=128>>newX;
            }
        }
    }
    writeChecksum(out);
    return out;
}

/* CARTRIDGE_FONT */
const cartridgeInputs=new Map();
for (const [base,targets] of Object.entries(catalog.cartridge.priorMenus || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,priorMenu:true}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.priorEspers || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,priorEsper:true}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.priorShadows || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,priorDialogue:true}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.priorTypography || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,priorDialogue:true}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.priorDialogue || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,priorDialogue:true}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.preBattle || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,legacy:true}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.targets)) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.previous || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,prior:true,legacy:true}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.spaced || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,spaced:true,legacy:true}));
}
for (const [base,targets] of Object.entries(catalog.cartridge.earlierNumbers || {})) {
    targets.forEach((target,names)=>cartridgeInputs.set(target,{base,names:!!names,earlierNumbers:true,legacy:true}));
}
function cartridgeEdition(profile) {
    return profile.options.includes('spanish')?'es':profile.edition;
}
function fontProfile(profile,names) {
    const options=[...new Set([...profile.options,'font',...(names?['names']:[])])];
    return {...profile,options,cartridge:true};
}
async function identifyBase(file) {
    if (![4194304,4194816].includes(file.size)) throw failure('wrongSize');
    const raw = new Uint8Array(await file.arrayBuffer());
    let bytes = raw.slice(raw.length-4194304);
    let id = await hash(bytes);
    if (!catalog.builds[id] && !catalog.aliases[id] && !catalog.nameLayer.toBase[id] && !cartridgeInputs.has(id)) {
        writeChecksum(bytes);
        id = await hash(bytes);
    }
    if (cartridgeInputs.has(id)) {
        const {base,names,prior,spaced,earlierNumbers,legacy,priorDialogue,priorEsper,priorMenu}=cartridgeInputs.get(id),profile=catalog.builds[base];
        const restored=restoreCartridge(bytes,cartridgeEdition(profile),names,prior,spaced,legacy);
        if (await hash(restored.base)!==base || await hash(restored.data)!==(legacy?catalog.cartridge.legacyPortableHash:catalog.cartridge.portableHash)) throw failure('verifyFail');
        return {bytes:restored.base,id:base,directData:legacy?undefined:restored.data,needsBattleDonor:!!legacy,upgrade:!!(legacy||prior||spaced||earlierNumbers||priorDialogue||priorEsper||priorMenu),profile:fontProfile(profile,names)};
    }
    const namesBase=catalog.nameLayer.toBase[id];
    if (namesBase) {
        const [layout]=catalog.nameLayer.fromBase[namesBase];
        bytes=nameLayout(bytes,catalog.nameLayer.layouts[layout],true);
        id=await hash(bytes);
        if (id!==namesBase) throw failure('verifyFail');
    }
    const upgrade = catalog.aliases[id];
    if (upgrade) {
        applyOverlay(bytes,bytes,upgrade.overlay);
        writeChecksum(bytes);
        id = await hash(bytes);
        if (id !== upgrade.target) throw failure('verifyFail');
    }
    if (!catalog.builds[id]) throw failure('unknown');
    const profile=catalog.builds[id];
    return {bytes,id,upgrade:!!upgrade,profile:namesBase?{...profile,options:[...profile.options,'names']}:profile};
}
function applyIPS(out,patch) {
    // All upstream files have an exact SHA-256 match before reaching this decoder.
    let pos=5;
    while (pos<patch.length-3) {
        const dest=patch[pos]*65536+patch[pos+1]*256+patch[pos+2];
        const size=patch[pos+3]*256+patch[pos+4];
        pos+=5;
        if (size) {
            out.set(patch.subarray(pos,pos+size),dest);
            pos+=size;
        } else {
            const count=patch[pos]*256+patch[pos+1];
            out.fill(patch[pos+2],dest,dest+count);
            pos+=3;
        }
    }
}
async function unzip(bytes,specs) {
    const bad=()=>failure('badZip');
    if (bytes.length<22) throw bad();
    const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
    const u16=i=>view.getUint16(i,true),u32=i=>view.getUint32(i,true);
    let end=bytes.length-22;
    const floor=Math.max(0,bytes.length-65557);
    while (end>=floor && (u32(end)!==0x06054b50 || end+22+u16(end+20)!==bytes.length)) end--;
    if (end<floor) throw bad();
    let pos=u32(end+16);
    const result={};
    for (let i=0;i<u16(end+10);i++) {
        if (pos+46>end || u32(pos)!==0x02014b50) throw bad();
        const nameSize=u16(pos+28);
        const next=pos+46+nameSize+u16(pos+30)+u16(pos+32);
        if (next>end) throw bad();
        const fullName=new TextDecoder().decode(bytes.subarray(pos+46,pos+46+nameSize));
        const name=fullName.split('/').pop();
        const spec=specs.find(s=>s.name.toLowerCase()===name.toLowerCase() && (s.format!=='bps' || (u32(pos+24)===s.size && u32(pos+16)===s.crc)));
        if (spec) {
            const loc=u32(pos+42),size=u32(pos+20),method=u16(pos+10);
            if (result[spec.name] || loc+30>end || u32(loc)!==0x04034b50 || (u16(pos+8)&1) ||
                u32(pos+24)!==spec.size || u32(pos+16)!==spec.crc) throw bad();
            const start=loc+30+u16(loc+26)+u16(loc+28);
            if (start+size>end) throw bad();
            const chunk=bytes.subarray(start,start+size);
            if (method===0) result[spec.name]=chunk;
            else if (method===8) {
                if (!globalThis.DecompressionStream) throw failure('browser');
                try {
                    const stream=new Blob([chunk]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
                    const reader=stream.getReader(),unpacked=new Uint8Array(spec.size);
                    let used=0;
                    for (;;) {
                        const {value,done}=await reader.read();
                        if (done) break;
                        if (used+value.length>unpacked.length) {await reader.cancel();throw bad();}
                        unpacked.set(value,used);used+=value.length;
                    }
                    if (used!==unpacked.length) throw bad();
                    result[spec.name]=unpacked;
                } catch { throw bad(); }
            } else throw bad();
        }
        pos=next;
    }
    return result;
}
async function readSource(id,files,saved) {
    if(id==='rose')return readROSE(files,saved);
    if(id==='twue')return readTWUE(files,saved);
    if (id==='font') {
        if (!files.length && saved?.cartridge) {
            const data=from64(saved.cartridge);
            if (await hash(data)!==catalog.cartridge.portableHash) throw failure('badPersonal');
            return {cartridge:data};
        }
        if (files.length===1) {
            const file=files[0];
            if (/\.gba$/i.test(file.name) || file.size>3*1024*1024) {
                if (file.size>16*1024*1024) throw failure('badFiles');
                let bytes=new Uint8Array(await file.arrayBuffer());
                if (bytes[0]===80 && bytes[1]===75) {
                    const members=await unzip(bytes,[gbaFont.spec]);
                    if(members[gbaFont.spec.name])return readCartridge(members[gbaFont.spec.name]);
                }else if(String.fromCharCode(...bytes.subarray(0,5))!=='PATCH'){
                    return readCartridge(bytes);
                }
            }
        }
    }
    return readFutureSourceSet(id,files,saved,catalog.sources[id],
        id==='spanish'?{allowDifferent:validateFutureSpanishPatch}:{});
}

async function applySpanish(out,base,patch,plan) {
    if (!globalThis.DecompressionStream) throw failure('browser');
    const headered=new Uint8Array(base.length+512);
    headered.set(base,512);
    applyFutureIPS(headered,patch);
    const donor=headered.subarray(512);
    const stream=new Blob([from64(catalog.spanishPlans[plan])]).stream().pipeThrough(new DecompressionStream('deflate'));
    const [copies,fixes]=JSON.parse(await new Response(stream).text());
    for (const [dest,src,count] of copies) out.set(donor.subarray(src,src+count),dest);
    for (const [dest,count,fix] of fixes) out.set(fix===null?base.subarray(dest,dest+count):from64(fix),dest);
}
async function combineBase(input,selected,sources,settings) {
    let {bytes,id}=input;
    selected=new Set(selected);
    const longNames=selected.has('names') || input.profile.options.includes('names');
    if (input.needsBattleDonor && !sources.font?.cartridge) throw failure('badGba');
    const cartridge=sources.font?.cartridge || input.directData;
    if (longNames) selected.add('font');
    if (cartridge) selected.delete('font');
    for (const feature of options) {
        const profile=catalog.builds[id],key=feature.id;
        if (key==='names' || !selected.has(key) || profile.options.includes(key)) continue;
        const step=profile.add[key];
        if (!step) throw failure('verifyFail');
        const out=bytes.slice();
        if(key==='twue'){
            bytes=await (settings?.variantSource?applyTWUEVariant(bytes,sources.twue,settings):applyTWUE(bytes,sources.twue));id=await hash(bytes);continue;
        }
        if(profile.edition==='twue' && key==='font')throw failure('twueFont');
        if(step.twueOverlay){for(const [at,data]of step.twueOverlay)out.set(from64(data),at);}
        else if (key==='spanish') await applySpanish(out,bytes,sources[key]['FF6ESP.IPS'],step.plan);
        else {
            for (const spec of catalog.sources[key] || []) applyIPS(out,sources[key][spec.name]);
            applyOverlay(out,bytes,step.overlay);
        }
        writeChecksum(out);
        id=await hash(out);
        if (id!==step.target) throw failure('verifyFail');
        bytes=out;
    }
    const profile=catalog.builds[id];
    if (cartridge) {
        bytes=cartridgeLayout(bytes,cartridge,cartridgeEdition(profile),longNames);
        const target=await hash(bytes);
        if (catalog.cartridge.targets[id]?.[Number(longNames)]!==target) throw failure('verifyFail');
        return {bytes,id:target,profile:fontProfile(profile,longNames)};
    }
    if (longNames) {
        const [layout,expected]=catalog.nameLayer.fromBase[id];
        bytes=nameLayout(bytes,catalog.nameLayer.layouts[layout]);
        id=await hash(bytes);
        if (id!==expected) throw failure('verifyFail');
        return {bytes,id,profile:{...profile,options:[...profile.options,'names']}};
    }
    return {bytes,id,profile};
}
/* FUTURE_INPUTS */
/* TWUE_FUTURE */
/* ROSE_FUTURE */
/* SPANISH_FUTURE */
/* TWUE_LAYER */
/* ROSE_LAYER */
/* ATB_LAYER */
/* SPELL_NAMES */
/* MENU_POLISH */
/* TWUE_VARIANTS */
/* TWUE_MUSIC */
/* MULTI_FONT */
/* COMPOSED_OPTIONS */
/* SPELL_ICONS */
/* MOLEMAN_DIALOGUE */
/* RETAIL_BASE */
/* MOLEMAN_VERSION */
/* FUTURE_SOURCES */
const controls=new Map();
const wanted=new Set((personal.options||[]).filter(id=>options.some(opt=>opt.id===id)||id==='multifont'));
if(wanted.delete('multifont'))wanted.add('font');
let chosenBattle=(personal.options||[]).find(id=>battleKinds.includes(id))||'vanilla';
const cachedLegacyFont=(personal.options||[]).includes('font')&&!personal.sources?.font?.cartridge&&catalog.sources.font.every(spec=>personal.sources?.font?.[spec.name]);
const cachedCartridgeFont=(personal.options||[]).includes('font')&&!!personal.sources?.font?.cartridge;
let chosenFont=['cartridge','multifont','legacy'].includes(personal.settings?.fontStyle)?personal.settings.fontStyle:((personal.options||[]).includes('multifont')?'multifont':cachedLegacyFont?'legacy':cachedCartridgeFont||wanted.has('names')?'cartridge':'multifont');
let chosenVariant=catalog.twueVariants?.variants[personal.settings?.variant]?personal.settings.variant:'base';
let chosenMusic=['config1','config2','mainA','mainB'].includes(personal.settings?.music)?personal.settings.music:'config2';
const chosenFixes=new Set(personal.settings?.fixes||[]);
let current=null,reading=false,building=false,romRevision=0,buildRevision=0;
let romError='',buildError='',result=null,resultUrl=null,verifiedSources={};
let retailInput=null,retailEdition=['regular','moleman'].includes(personal.retailBaseEdition)?personal.retailBaseEdition:'',retailBusy=false,retailError='';
let preparedBase=null,retailPreparedEdition='',retailMolemanPatch=null;
function make(tag,className){const n=document.createElement(tag);if(className)n.className=className;return n;}
function clearResult(){
    buildRevision++;building=false;buildError='';result=null;verifiedSources={};
    if(resultUrl)URL.revokeObjectURL(resultUrl);resultUrl=null;el('download').removeAttribute('href');
    for(const c of controls.values())if(c.issue)c.issue.textContent='';
}
function publishOutput(output){
    if(resultUrl)URL.revokeObjectURL(resultUrl);
    resultUrl=URL.createObjectURL(new Blob([output.bytes],{type:'application/octet-stream'}));
    el('download').href=resultUrl;el('download').download=filename(output.profile);result=output;
}
function acceptCurrent(found){
    current=found;const style=fontStyle(found.profile),battle=found.profile.options.find(x=>battleKinds.includes(x));
    if(battle)chosenBattle=battle;else if(found.profile.edition==='rose')chosenBattle='vanilla';
    if(style!=='native'){chosenFont=style;wanted.add('font');}if(found.profile.options.includes('names'))wanted.add('names');
    if(found.profile.edition==='twue')chosenVariant=found.profile.twueVariant||'base';
    if(found.profile.music){wanted.add('music');chosenMusic=found.profile.music;chosenFixes.clear();for(const f of found.profile.musicFixes)chosenFixes.add(f);}
}
function needsBuild(selected=selectedOptions(),settings=selectedSettings()){
    if(!current)return false;
    const installed=new Set(current.profile.options);
    return current.upgrade||settings.fontStyle!==fontStyle(current.profile)||chosenBattle!==(current.profile.options.find(x=>battleKinds.includes(x))||'vanilla')||selected.has('names')!==installed.has('names')||musicKey(settings.music,settings.fixes)!==musicKey(current.profile.music||'none',current.profile.musicFixes)||[...selected].some(x=>!['vanilla','font','multifont','names','music'].includes(x)&&!installed.has(x));
}
function resetRetailPreparation(){
    romRevision++;retailBusy=false;retailError='';current=null;preparedBase=null;retailPreparedEdition='';clearResult();
}
el('retailEdition').addEventListener('change',()=>{
    if(!retailInput)return;
    resetRetailPreparation();retailEdition=['regular','moleman'].includes(el('retailEdition').value)?el('retailEdition').value:'';render();
});
el('retailMoleFile').addEventListener('change',async()=>{
    if(!retailInput)return;
    resetRetailPreparation();retailMolemanPatch=null;const token=romRevision;render();
    const files=[...el('retailMoleFile').files];
    if(!files.length)return;
    try{
        const patch=await readRetailMoleman(files);
        if(token===romRevision){retailMolemanPatch=patch;render();}
    }catch(error){if(token===romRevision){retailError=error.message;render();}}
});
el('retailApply').addEventListener('click',async()=>{
    if(!retailInput||!['regular','moleman'].includes(retailEdition)||retailBusy||el('retailApply').disabled)return;
    resetRetailPreparation();const token=romRevision,input=retailInput,edition=retailEdition;
    const files=[...el('retailMoleFile').files];retailBusy=true;render();
    try{
        const donor=edition==='moleman'?await readRetailMoleman(files,retailMolemanPatch?to64(retailMolemanPatch):personal.retailMolemanPatch,personal.retailMolemanVersion):null;
        if(token!==romRevision)return;
        const output=await buildRetailBase(input,edition,donor);
        if(token!==romRevision)return;
        const found=await identify(new File([output.bytes],'SNES_Advance_base.sfc'));
        if(token!==romRevision)return;
        if(found.profile.edition!==edition||found.profile.options.length||found.upgrade)throw failure('verifyFail');
        if(edition==='moleman')for(const id of ['rose','twue','spanish','music'])wanted.delete(id);
        acceptCurrent(found);preparedBase={...output,profile:found.profile};retailPreparedEdition=edition;
        if(donor)retailMolemanPatch=donor;
    }catch(error){if(token===romRevision)retailError=error.message||t('verifyFail');}
    finally{if(token===romRevision){retailBusy=false;render();}}
});
function selectControl(row,id,choices,onchange){
    const wrap=make('div','choice'),label=make('label'),select=make('select');
    label.htmlFor=id;select.id=id;wrap.append(label,select);row.append(wrap);
    const entries=choices.map(value=>{const n=make('option');n.value=value;select.append(n);return [value,n];});
    select.addEventListener('change',()=>{onchange(select.value);clearResult();render();});
    return {wrap,label,select,entries};
}
for(const option of options){
    const id=option.id,row=make('div','option'),label=make('label','opt-label'),box=make('input');
    box.type=option.battle?'radio':'checkbox';box.id='opt-'+id;if(option.battle)box.name='battle-mode';
    const copy=make('span'),caption=make('strong'),name=make('span'),installed=make('span','installed'),description=make('small');
    caption.append(name,installed);copy.append(caption,description);label.append(box,copy);row.append(label);
    el(option.battle?'battleOptions':'options').append(row);const c={row,box,name,installed,description};controls.set(id,c);
    box.addEventListener('change',()=>{
        if(option.battle)chosenBattle=id;else if(box.checked)wanted.add(id);else wanted.delete(id);
        if(['rose','twue','spanish'].includes(id)&&box.checked)for(const other of ['rose','twue','spanish'])if(other!==id)wanted.delete(other);
        if(id==='rose'&&box.checked){for(const other of [...wanted])if(other!=='rose'&&!roseProfile().capabilities.includes(other))wanted.delete(other);chosenBattle='vanilla';}
        if(id==='names'&&box.checked){wanted.add('font');chosenFont='cartridge';}
        if(id==='font'&&!box.checked)wanted.delete('names');clearResult();render();
    });
    if(id==='font'){
        c.choice=selectControl(row,'font-style',['multifont','cartridge','legacy'],v=>{chosenFont=v;controls.get('font').files.value='';if(v!=='cartridge')wanted.delete('names');});
        c.timingNote=make('p','font-timing-note');c.timingNote.id='font-timing-warning';c.timingNote.setAttribute('aria-live','polite');
        c.choice.select.setAttribute('aria-describedby','font-timing-warning');row.append(c.timingNote);
    }
    if(id==='twue')c.choice=selectControl(row,'twue-variant',Object.keys(catalog.twueVariants?.variants||{base:{}}),v=>{chosenVariant=v;});
    if(id==='music'){
        c.choice=selectControl(row,'music-placement',['config1','config2','mainA','mainB'],v=>{chosenMusic=v;});
        c.fixes=new Map();const wrap=make('div','choice');c.fixesWrap=wrap;row.append(wrap);
        for(const fix of ['sfx','lete','caves']){
            const lab=make('label','fix-choice'),check=make('input'),text=make('span');check.type='checkbox';check.id='music-fix-'+fix;
            lab.append(check,' ',text);wrap.append(lab);c.fixes.set(fix,{check,text});
            check.addEventListener('change',()=>{if(check.checked)chosenFixes.add(fix);else chosenFixes.delete(fix);clearResult();render();});
        }
    }
    if(!option.url)continue;
    const source=make('div','source'),hint=make('label'),links=make('div'),link=make('a'),files=make('input');
    hint.htmlFor='files-'+id;link.href=option.url;link.target='_blank';link.rel='noopener noreferrer';links.append(link);
    if(option.mirror){const mirror=make('a');mirror.href=option.mirror;mirror.target='_blank';mirror.rel='noopener noreferrer';links.append(' · ',mirror);c.mirror=mirror;}
    files.type='file';files.accept=id==='font'?'.gba,.zip,.ips':id==='twue'?'.zip,.ips,.bps':'.zip,.ips';files.id='files-'+id;files.multiple=['font','twue','music'].includes(id);
    const saved=make('p','reused'),issue=make('p','status error');issue.setAttribute('aria-live','polite');source.append(hint,links,files,saved,issue);row.append(source);
    Object.assign(c,{source,hint,link,files,saved,issue});files.addEventListener('change',()=>{c.sourceRevision=(c.sourceRevision||0)+1;clearResult();render();});
}
function selectedOptions(){
    const selected=new Set(options.filter(({id})=>controls.get(id).box.checked).map(o=>o.id));
    if(selected.has('font')&&chosenFont==='multifont'){selected.delete('font');selected.add('multifont');}
    return selected;
}
function selectedSettings(){return {fontStyle:controls.get('font').box.checked?chosenFont:'native',variant:chosenVariant,music:controls.get('music').box.checked?chosenMusic:'none',fixes:controls.get('music').box.checked?[...chosenFixes].sort():[]};}
function editionLabel(p){
    const suffix=p.futureUntested?' · '+t('futureUntested'):'';
    if(p.edition==='rose')return t('editionRose')+(p.futureUntested?'':' '+p.roseVersion)+suffix;
    if(p.edition==='twue')return t('editionTwue')+(p.futureUntested?'':' '+(p.twueVersion==='307'?'3.07':p.twueVersion==='306a'?'3.06a':'3.06'))+(p.twueVariant&&p.twueVariant!=='base'?' · '+t('variant-'+p.twueVariant):'')+suffix;
    return t(p.edition==='regular'?'editionRegular':'editionMoleman')+(p.edition==='moleman'&&p.molemanVersion?' v'+p.molemanVersion:'')+suffix;
}
function filename(p){
    const names={modern:'ModernATB',classic:'ClassicATB',ctb:'CTBWait',dash:'Dash',turn:'TurnBased',font:p.cartridge?'GBA_Cartridge_Font':'Legacy_Font',multifont:'MultiFont141',spanish:'ES',names:'LongNames',music:'Music_'+p.music};
    const tags=[p.edition==='rose'?'ROSE'+String(p.roseVersion).replace(/[^a-z0-9]/gi,''):p.edition==='twue'?'TWUE'+p.twueVersion+(p.twueVariant&&p.twueVariant!=='base'?'_'+p.twueVariant:''):p.edition==='regular'?'Regular':p.molemanVersion?'MoleMan'+p.molemanVersion.replace('.',''):'MoleMan_Untested',...p.options.filter(o=>!['twue','rose'].includes(o)).map(o=>names[o])];
    if(p.musicFixes?.length)tags.push(p.musicFixes.join('-'));
    if(p.futureUntested)tags.push('UntestedSource');
    return 'FFVI_Advance_v1.5_'+tags.join('_')+'.sfc';
}
function savedSources(id){return personal.sources?.[id];}
function previewFutureSources(id,c){
    const family=id==='font'&&chosenFont==='multifont'?'multifont':id;
    const settings=selectedSettings(),files=[...c.files.files];
    const key=JSON.stringify([c.sourceRevision||0,family,chosenFont,settings.variant,settings.music,settings.fixes]);
    if(c.previewKey===key)return;
    c.previewKey=key;c.previewWarning=false;
    const saved=savedSources(family);
    if(!files.length)c.previewWarning=Object.entries(personal.sourceInfo?.[family]||{}).some(([name,info])=>saved?.[name]&&info.warning);
    if(!files.length&&!saved)return;
    const read=()=>id==='twue'?readTWUEChoice(files,saved,settings):id==='music'?readTWUEMusic(files,saved):readSource(family,files,saved);
    read().then(entries=>{
        if(c.previewKey!==key)return;
        if(id==='music')entries=Object.fromEntries(musicRecipes().filter(r=>entries[r.source]).map(r=>[r.source,entries[r.source]]));
        c.previewWarning=futureWarningsForSources({[family]:entries});render();
    }).catch(()=>{if(c.previewKey===key){c.previewWarning=false;render();}});
}
function musicRecipes(){return [catalog.twueMusic?.[chosenMusic],...[...chosenFixes].map(k=>catalog.twueMusic?.fixes?.[k])].filter(Boolean);}
function hasMusicSources(){
    const sources={...savedSources('twue'),...savedSources('music'),...current?.musicSources};
    const recipes=musicRecipes();return recipes.length>0&&recipes.every(r=>sources[r.source]);
}
function requiresSource(id,installed){
    if(!controls.get(id).box.checked)return false;
    if(id==='font')return chosenFont==='multifont'?!current?.multiFontPatch:chosenFont==='cartridge'?!current?.directData:!installed.has('font');
    if(id==='music')return !hasMusicSources();
    if(atbKinds.includes(id)&&current?.profile.edition!=='twue'&&controls.get('twue').box.checked)return true;
    return !installed.has(id);
}
function render(){
    document.documentElement.lang=lang;document.title='FFVI SNES Advance · '+t('title');
    for(const n of document.querySelectorAll('[data-t]')){n.textContent=t(n.dataset.t);if(roseEnabled&&n.dataset.t==='creditText')n.textContent+=' '+t('roseCredits');if(roseEnabled&&n.dataset.t==='romHint')n.textContent+=' '+t('roseRomHint');}
    const readme=roseEnabled?catalog.rose.readme:'';el('roseReadme').hidden=!readme;
    if(readme){el('roseReadmeText').textContent=readme;const link=el('roseReadmeDownload');if(!link.href)link.href=URL.createObjectURL(new Blob([readme],{type:'text/plain;charset=utf-8'}));link.download='FF6_ROSE_Readme.txt';link.textContent=t('roseReadmeDownload');}
    el('language').textContent=lang==='es'?'English':'Español';el('language').lang=lang==='es'?'en':'es';
    const retailPending=!!retailInput&&!current;
    el('retailPanel').hidden=!retailInput;el('battlePanel').hidden=retailPending;el('optionsPanel').hidden=retailPending;
    el('retailEdition').value=retailEdition;el('retailMoleSource').hidden=retailEdition!=='moleman';
    const retailFiles=el('retailMoleFile').files,retailSaved=!!(retailMolemanPatch||personal.retailMolemanPatch);
    el('retailMoleSaved').hidden=!retailSaved||!!retailFiles.length;
    el('retailApply').disabled=!retailInput||!retailEdition||retailBusy||!!preparedBase||retailEdition==='moleman'&&!retailFiles.length&&!retailSaved;
    el('retailApply').textContent=t(retailBusy?'retailApplying':'retailApply');
    el('molemanWarning').hidden=!(current?.profile.molemanUntested||retailInput&&retailEdition==='moleman'&&retailMolemanPatch&&molemanPatchInfo(retailMolemanPatch).warning);
    el('molemanWarning').textContent=t('molemanUntested');
    el('retailStatus').textContent=retailError||(retailBusy?t('retailApplying'):preparedBase?t('retailReady'):'');
    el('retailStatus').className='status'+(retailError?' error':preparedBase?' ok':'');
    const installed=new Set(current?.profile.options||[]),raw=current&&catalog.builds[current.id],missing=[];
    const roseSelectable=roseEnabled&&(!current||current.profile.edition==='rose'||roseSourceEligible(current));
    const roseMode=roseEnabled&&(current?.profile.edition==='rose'||roseSelectable&&wanted.has('rose'));
    const twueMode=!roseMode&&(current?.profile.edition==='twue'||wanted.has('twue'));
    const capabilities=roseMode?new Set(roseProfile().capabilities):null;
    if(roseMode)chosenBattle='vanilla';
    const legacyBase=raw?.options.includes('font');
    if(legacyBase&&chosenFont==='multifont')chosenFont='cartridge';
    const variant=catalog.twueVariants?.variants?.[chosenVariant];
    if((chosenMusic==='mainA'&&!variant?.bugfix)||(chosenMusic==='mainB'&&variant?.bugfix))chosenMusic=variant?.bugfix?'mainA':'mainB';
    for(const option of options){
        const id=option.id,c=controls.get(id),removable=['font','names','music'].includes(id);
        let supported=option.battle?(!installed.has('turn')||id==='turn'):id==='names'||!current||installed.has(id)||!!current.profile.add[id];
        if(id==='rose')supported=roseSelectable;
        else if(roseMode)supported=capabilities.has(id);
        else if(id==='font')supported=true;
        else if(id==='music')supported=twueMode&&(!current||current.profile.edition!=='twue'||current.profile.twueVersion==='307');
        if(id==='names'&&!roseMode)supported=!wanted.has('font')||chosenFont!=='multifont';
        c.box.checked=option.battle?supported&&chosenBattle===id:roseMode&&id==='dash'||supported&&(removable?wanted.has(id)||id==='font'&&legacyBase:installed.has(id)||wanted.has(id));
        c.box.disabled=option.battle?!supported:!supported||roseMode&&id==='dash'||!removable&&installed.has(id)||id==='font'&&legacyBase;
        c.name.textContent=t(id);c.installed.textContent=roseMode&&id==='dash'?t('roseIncluded'):id==='font'&&current&&fontStyle(current.profile)!=='native'?t(fontStyle(current.profile)==='multifont'?'multifont':current.profile.cartridge?'cartFont':'legacyFont'):installed.has(id)?t('installed'):'';
        c.description.textContent=t(supported?id+'Desc':id==='rose'?'roseLocked':roseMode?'roseUnsupported':option.battle?'battleLocked':id==='twue'?'twueLocked':id==='music'?'musicLocked':'spanishLocked');
        if(id==='font'&&legacyBase)c.description.textContent+=' '+t('nativeFontRequired');
        if(c.choice){
            c.choice.wrap.hidden=!c.box.checked;
            c.choice.label.textContent=t(id==='font'?'fontImplementation':id==='twue'?'variantLabel':'musicPlacement');
            for(const [value,n]of c.choice.entries){
                n.textContent=t(id==='font'?{cartridge:'fontCartridge',multifont:'fontMultifont',legacy:'fontLegacy'}[value]:id==='twue'?'variant-'+value:'music-'+value);
                n.disabled=id==='font'?(value==='multifont'&&legacyBase||value==='legacy'&&twueMode):id==='twue'?!catalog.builds[catalog.twueVariants?.variants[value]?.target]:value==='mainA'&&!variant?.bugfix||value==='mainB'&&variant?.bugfix;
                n.hidden=id==='font'&&value==='legacy'&&fontStyle(current?.profile||{options:[]})!=='legacy'&&chosenFont!=='legacy'||id==='music'&&n.disabled;
            }
            c.choice.select.value=id==='font'?chosenFont:id==='twue'?chosenVariant:chosenMusic;
            c.choice.select.disabled=id==='twue'&&current?.profile.edition==='twue';
            if(id==='twue'&&c.choice.select.disabled)c.description.textContent+=' '+t('variantLocked');
        }
        if(c.timingNote){c.timingNote.hidden=!c.box.checked||chosenFont!=='cartridge';c.timingNote.textContent=t('fontTimingWarning');}
        if(c.fixes){c.fixesWrap.hidden=!c.box.checked;for(const [fix,x]of c.fixes){x.check.checked=chosenFixes.has(fix);x.text.textContent=t('fix-'+fix);}}
        if(!c.source)continue;
        const required=requiresSource(id,installed);c.source.hidden=!required;
        c.hint.textContent=t(id==='font'?(chosenFont==='multifont'?'multiFontFile':chosenFont==='legacy'?'legacyFontFile':'fontFile'):id+'File');
        c.link.textContent=t('source');c.link.hidden=id==='font'&&chosenFont==='cartridge';
        if(id==='font')c.link.href=chosenFont==='multifont'?'https://www.romhacking.net/hacks/3232/':option.url;
        if(c.mirror)c.mirror.textContent=t('mirror');c.saved.textContent=t('bundled');
        let saved=id==='font'?chosenFont==='multifont'?savedSources('multifont'):chosenFont==='cartridge'?savedSources('font')?.cartridge:savedSources('font'):savedSources(id);
        if(id==='twue')saved=saved?.[catalog.twueVariants?.variants[chosenVariant]?.source]||(chosenVariant==='base'&&catalog.sources.twue.some(spec=>saved?.[spec.name]));
        if(id==='music')saved=hasMusicSources();
        c.saved.hidden=!saved||!!c.files.files.length;
        const twueFiles=[...controls.get('twue').files.files];
        const sharedMusic=id==='music'&&(hasMusicSources()||twueFiles.length>1||twueFiles.some(f=>/\.zip$/i.test(f.name)));
        if(required&&!c.files.files.length&&!saved&&!sharedMusic)missing.push(t(id));
    }
    const selected=selectedOptions(),settings=selectedSettings(),items=current?[editionLabel(current.profile)]:retailInput?[t('retailDetected')+retailInput.revision]:[];
    let futureWarning=!!(current?.profile.futureUntested||result?.profile.futureUntested);
    for(const [id,c]of controls)if(c.source&&c.box.checked&&!c.box.disabled&&!retailPending){previewFutureSources(id,c);futureWarning||=!!c.previewWarning;}
    el('futureWarning').hidden=!futureWarning;el('futureWarning').textContent=t('futureWarning');
    for(const id of (retailPending?[]:selected)){if(id==='twue')items.push(t('twue')+' · '+t('variant-'+chosenVariant));else if(id==='font')items.push(t(chosenFont==='cartridge'?'fontCartridge':'fontLegacy'));else if(id==='music')items.push(t('music-'+chosenMusic));else items.push(t(id));}
    if(!items.length)items.push(t('none'));el('selection').replaceChildren(...items.map(text=>{const li=make('li');li.textContent=text;return li;}));
    const status=el('romStatus');status.className='status'+(romError?' error':current||retailInput?' ok':'');status.textContent=romError||(reading?t('checking'):current?t('romVerified')+' · '+editionLabel(current.profile)+(current.upgrade?' · '+t('old'):''):retailInput?t('romVerified')+' · '+t('retailDetected')+retailInput.revision:'');
    const changes=needsBuild(selected,settings);
    if(preparedBase&&current&&!changes&&!result&&!building)publishOutput(preparedBase);
    let message=retailPending?t('retailChoose'):!current?t('chooseRom'):!changes?t(installed.size?'already':'noOptions'):missing.length?t('need')+' '+missing.join(', ')+'.':t('ready');
    if(reading)message=t('checking');if(retailBusy)message=t('retailApplying');if(building)message=t('working');if(result)message=t('done');
    el('status').textContent=buildError||message;el('status').className='status'+(buildError?' error':result?' ok':'');el('build').disabled=!changes||!!missing.length||building;el('build').hidden=!!result||retailPending;
    el('download').hidden=!result;el('outputName').hidden=!result;el('outputName').textContent=result?filename(result.profile):'';
    const canSave=!!result&&(Object.keys(verifiedSources).length>0||retailPreparedEdition==='moleman'&&!!retailMolemanPatch);el('personalButton').hidden=!canSave;el('personalHint').hidden=!canSave;
}
el('rom').addEventListener('change',async()=>{
    const token=++romRevision;clearResult();current=null;retailInput=null;preparedBase=null;retailPreparedEdition='';retailBusy=false;retailError='';romError='';
    retailEdition=['regular','moleman'].includes(personal.retailBaseEdition)?personal.retailBaseEdition:'';
    const file=el('rom').files[0];reading=!!file;render();if(!file)return;
    try{
        const original=await identifyRetailROM(file);
        if(token!==romRevision)return;
        if(original){
            retailInput=original;
            if(!retailMolemanPatch&&!el('retailMoleFile').files.length&&personal.retailMolemanPatch){
                try{
                    const saved=await readRetailMoleman([],personal.retailMolemanPatch,personal.retailMolemanVersion);
                    if(token===romRevision)retailMolemanPatch=saved;
                }catch(error){if(token===romRevision&&retailEdition==='moleman')retailError=error.message;}
            }
        }
        else{const found=await identify(file);if(token===romRevision)acceptCurrent(found);}
    }catch(error){if(token===romRevision)romError=error.message||t('writeError');}finally{if(token===romRevision){reading=false;render();}}
});
async function readTWUEChoice(files,saved,settings){
    try{return await readTWUEVariantSources(files,saved,settings);}catch(error){if(settings.variant!=='base')throw error;return readTWUE(files,saved);}
}
el('build').addEventListener('click',async()=>{
    if(!current||el('build').disabled)return;clearResult();const token=buildRevision,input=current,selected=selectedOptions(),settings=selectedSettings(),sources={};let sourceId=null;building=true;render();
    try{
        for(const {id}of options){
            if(['font','music'].includes(id)||!catalog.sources[id]||!selected.has(id)||(input.profile.options.includes(id)&&!(atbKinds.includes(id)&&input.profile.edition!=='twue'&&selected.has('twue'))))continue;
            sourceId=id;const files=[...controls.get(id).files.files];sources[id]=id==='twue'?await readTWUEChoice(files,savedSources(id),settings):await readSource(id,files,savedSources(id));if(token!==buildRevision)return;
        }
        if(settings.fontStyle==='cartridge'){
            sourceId='font';if(input.directData&&!controls.get('font').files.files.length)sources.font={cartridge:input.directData};else sources.font=await readSource('font',[...controls.get('font').files.files],savedSources('font'));
            if(!sources.font.cartridge)throw failure('badGba');
        }else if(settings.fontStyle==='legacy'&&!catalog.builds[input.id]?.options.includes('font')){sourceId='font';sources.font=await readSource('font',[...controls.get('font').files.files],savedSources('font'));}
        else if(settings.fontStyle==='multifont'){
            sourceId='font';sources.multifont=input.multiFontPatch&&!controls.get('font').files.files.length?{[multiFontSpec.name]:input.multiFontPatch}:await readSource('multifont',[...controls.get('font').files.files],savedSources('multifont'));
        }
        if(selected.has('music')){
            sourceId='music';
            const cached=Object.fromEntries(Object.entries({...savedSources('twue'),...savedSources('music')}).filter(([name])=>catalog.twueVariants.sources.some(spec=>spec.name===name)));
            let m=Object.keys(cached).length?await readTWUEMusic([],cached):{};
            m={...m,...input.musicSources,...sources.twue};
            const files=[...controls.get('music').files.files];
            if(files.length)m={...m,...await readTWUEMusic(files)};
            if(!musicRecipes().every(r=>m[r.source])&&controls.get('twue').files.files.length)
                m={...m,...await readTWUEMusic([...controls.get('twue').files.files])};
            sources.music=Object.fromEntries(musicRecipes().map(r=>[r.source,m[r.source]]));
            if(Object.values(sources.music).some(v=>!v))throw failure('twueFiles');
        }
        if(token!==buildRevision)return;sourceId=null;const output=await combine(input,selected,sources,settings);if(token!==buildRevision)return;
        publishOutput(output);
        // Retain only selected primary/player sources in personal copies.
        if(sources.twue){const spec=catalog.twueVariants?.variants[settings.variant];if(sources.twue[spec?.source])sources.twue={[spec.source]:sources.twue[spec.source]};}
        verifiedSources=sources;
    }catch(error){if(token!==buildRevision)return;buildError=(sourceId?t(sourceId)+' · ':'')+(error.message||t('verifyFail'));if(sourceId){const c=controls.get(sourceId);c.issue.textContent=error.message;c.files.focus();}}
    finally{if(token===buildRevision){building=false;render();}}
});
function personalHTML(){
    const sources={};for(const [id,patches]of Object.entries(verifiedSources)){sources[id]={};for(const [name,bytes]of Object.entries(patches))sources[id][name]=to64(bytes);}
    const payload=JSON.stringify({lang,options:[...selectedOptions()],settings:selectedSettings(),sources,sourceInfo:futureMetadataForSources(verifiedSources),
        ...(retailPreparedEdition?{retailBaseEdition:retailPreparedEdition}:{}),
        ...(retailPreparedEdition==='moleman'&&retailMolemanPatch?{retailMolemanPatch:to64(retailMolemanPatch),retailMolemanVersion:molemanPatchInfo(retailMolemanPatch).declaredVersion}:{})});return template.replace(/(<script type="application\/json" id="personal">)[^<]*/,(_,tag)=>tag+payload);
}
el('personalButton').addEventListener('click',()=>{
    try{const url=URL.createObjectURL(new Blob([personalHTML()],{type:'text/html;charset=utf-8'})),link=make('a');link.href=url;link.download='FFVI_SNES_Advance_Personal_Patcher.html';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}catch{buildError=t('personalError');render();}
});
el('language').addEventListener('click',()=>{lang=lang==='es'?'en':'es';render();});
render();
