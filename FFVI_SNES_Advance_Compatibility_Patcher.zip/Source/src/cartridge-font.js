// The portable font record contains the advances and pixels for printable ASCII.
// Menu rows retain both GBA colors. Dialogue shadows are reconstructed exactly
// from the validated donor's ink and six single-pixel outline exceptions.
const gbaFont = {
    donorHash:'1310f2ad3c13f5446cf6c43d01d48aad640d6b8a4fbba2b92c776f4f6d90e6ff',
    spec:{name:'Final Fantasy VI Advance (USA).gba',size:0x800000,crc:0xd708f5ab},
    record:40, first:32, count:95, small:0x161ff0, large:0x162ccc,
    fontStart:0x47fc0, fontEnd:0x4a4c0, stash:0x3eb000
};
const legacyPortableLength=gbaFont.record*gbaFont.count;
const portableLength=legacyPortableLength+192;
const hudFontOffset=legacyPortableLength;
const alphaNumeric='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
function extractCartridge(rom) {
    const data=new Uint8Array(portableLength);
    const view=new DataView(rom.buffer,rom.byteOffset,rom.byteLength);
    for (let i=0;i<gbaFont.count;i++) {
        const dest=i*gbaFont.record;
        for (const [base,height] of [[gbaFont.small,8],[gbaFont.large,12]]) {
            const index=view.getUint16(base+12+2*(i+32),true);
            const glyph=base+view.getUint32(base+0x10c+4*index,true);
            const stride=rom[glyph+1];
            const large=height===12;
            data[dest+(large?17:0)]=rom[glyph];
            for (let y=0;y<(large?11:8);y++) {
                let ink=0,shade=0;
                for (let x=0;x<Math.min(large?12:8,stride*4);x++) {
                    const packed=rom[glyph+2+y*stride+(x>>2)];
                    const color=(packed>>(2*(x&3)))&3;
                    const bit=1<<((large?11:7)-x);
                    if (color===1) ink|=bit;
                    if (color===2) shade|=bit;
                }
                if (large) {
                    data[dest+18+2*y]=ink&255;
                    data[dest+19+2*y]=ink>>8;
                } else {
                    data[dest+1+2*y]=ink|shade;
                    data[dest+2+2*y]=ink;
                }
            }
        }
    }
    for(let i=0;i<12;i++) for(let y=0;y<8;y++) for(let x=0;x<8;x++) {
        const color=(rom[0x72e078+(i===11?12:i)*32+y*4+(x>>1)]>>(4*(x&1)))&15;
        if(color) data[hudFontOffset+i*16+y*2]|=128>>x;
        if(color===1) data[hudFontOffset+i*16+y*2+1]|=128>>x;
    }
    return data;
}
function cartridgeMenuTile(data,ch) {
    const start=(ch.charCodeAt(0)-32)*gbaFont.record+1;
    return data.slice(start,start+16);
}
function pairTile(data,word,accentTiles) {
    const chars=Array.from(word);
    const letters=chars.map(ch=>accentTiles.get(ch)||cartridgeMenuTile(data,ch));
    const span=tile=>{
        const used=[];
        for (let x=0;x<8;x++)
            if (tile.some((row,i)=>i%2 && (row&(128>>x)))) used.push(x);
        return used.length ? [used[0],used[used.length-1]-used[0]+1] : [0,0];
    };
    const edges=letters.map(span);
    const result=new Uint8Array(16);
    const widths=edges.map(pair=>pair[1]);
    if (widths[0]+widths[1]>8) {
        // Only unusually wide pairs need to share columns. Fold ink rather than dropping strokes.
        const available=Math.round(8*widths[0]/(widths[0]+widths[1]));
        widths[0]=available;widths[1]=8-available;
    }
    const gap=Math.min(1,8-widths[0]-widths[1]);
    const starts=[0,widths[0]+gap];
    if (chars[0]===' ') starts[1]=8-widths[1];
    if (chars[1]===' ') starts[0]=0;
    for (let i=0;i<2;i++) {
        if (!widths[i]) continue;
        const [first,inkWidth]=edges[i];
        for (let x=first;x<8;x++) {
            const column=starts[i]+Math.floor((x-first)*widths[i]/inkWidth);
            if (column>=8) continue;
            for (let row=0;row<16;row++)
                if (letters[i][row]&(128>>x)) result[row]|=128>>column;
        }
    }
    return result;
}
// Use ASCII counterparts for glyphs that also exist in the two SNES encodings.
// Edition-specific accent, symbol and control slots are reserved.
function writeCartridgeFont(out,base,data,edition,names) {
    const spanish=edition==='es';
    const menu=new Map(),dialog=new Map();
    for (const [index,ch] of Array.from(alphaNumeric).entries()) {
        menu.set(0x80+index,ch);dialog.set(0x20+index,ch);
    }
    const punctuation="!?/:\u0022'-.,";
    for (const [index,ch] of Array.from(punctuation).entries()) {
        if (spanish && ch==="'") continue;
        menu.set(0xbe+index,ch);dialog.set(0x5e+index,ch);
    }
    for (const [index,ch] of [[0xcb,'('],[0xcc,')']]) {
        menu.set(index,ch);dialog.set(index-0x60,ch);
    }
    if (!spanish) {
        for (const [index,ch] of [[0xc8,';'],[0xc9,'#'],[0xca,'+'],[0xcd,'%'],[0xce,'~']]) {
            menu.set(index,ch);dialog.set(index-0x60,ch);
        }
        if (edition==='regular') {menu.set(0xd2,'=');dialog.set(0x72,'=');}
    }
    for (const [code,ch] of menu) out.set(cartridgeMenuTile(data,ch),gbaFont.fontStart+16*code);
    for (const [code,ch] of dialog) {
        const ptr=(ch.charCodeAt(0)-32)*gbaFont.record+17;
        out.set(data.subarray(ptr+1,ptr+23),0x490c0+(code-32)*22);
        // Import the advance with each replaced glyph in every edition.
        // Keep translated widths only for untouched accent/symbol slots.
        out[0x48fc0+code]=data[ptr];
    }
    out[0x48fc0+0x7f]=data[17];
    out[0x48fc0+0x9f]=data[17]; // battle dialogue uses a second encoded space
    // SNES encodes an ellipsis as one glyph. GBA renders three full stops:
    // retain their baseline, two-pixel ink and four-pixel dialogue advances.
    const dot=(46-32)*gbaFont.record, smallDots=new Uint8Array(16);
    for(let row=0;row<16;row++) for(let i=0;i<3;i++)
        smallDots[row]|=data[dot+1+row]>>(i*data[dot]);
    out.set(smallDots,gbaFont.fontStart+16*0xc7);
    for(let y=0;y<11;y++) {
        const ink=data[dot+18+2*y]|data[dot+19+2*y]<<8;
        let dots=0;
        for(let i=0;i<3;i++) dots|=ink>>(i*data[dot+17]);
        const dest=0x490c0+(0x67-32)*22+2*y;
        out[dest]=dots&255;out[dest+1]=dots>>8;
    }
    out[0x48fc0+0x67]=3*data[dot+17];
    const accents=new Map();
    if (spanish) {
        for (const [code,ch] of [[195,'í'],[202,'ñ'],[206,'á'],[207,'é'],[208,'ó'],[209,'ú'],[210,'ü']]) {
            accents.set(ch,base.slice(gbaFont.fontStart+16*code,gbaFont.fontStart+16*(code+1)));
        }
    }
    if (names) {
        for (const [slot,word] of catalog.cartridge.pairs[edition])
            out.set(pairTile(data,word,accents),gbaFont.fontStart+16*slot);
    }
}
// Each hook runs with the display blank, after the stock label writer and before
// the stock tilemap upload. Only these two screens use this extra VRAM page.
const menuScreens=[
    {hook:0x33123,original:0x31f4,stub:0x3fca8,code:0x3f4500,atlas:0x3f6000},
    {hook:0x37e60,original:0x0e29,stub:0x3fcb0,code:0x3f4c00,atlas:0x3f6800}
];
function proportionalTiles(data,text) {
    const rows=Array.from({length:8},()=>[]);
    let pen=0;
    for (const ch of text) {
        const glyph=cartridgeMenuTile(data,ch);
        for (let y=0;y<8;y++) for (let x=0;x<8;x++) {
            const mask=128>>x;
            const color=glyph[2*y+1]&mask?3:glyph[2*y]&mask?1:0;
            if (color) rows[y][pen+x]=Math.max(rows[y][pen+x]||0,color);
        }
        pen+=data[(ch.charCodeAt(0)-32)*gbaFont.record];
    }
    const tiles=new Uint8Array(Math.ceil(Math.max(pen,...rows.map(r=>r.length))/8)*16);
    for (let y=0;y<8;y++) rows[y].forEach((color,x)=>{
        const address=(x>>3)*16+2*y,bit=128>>(x&7);
        if (color) tiles[address]|=bit;
        if (color===3) tiles[address+1]|=bit;
    });
    return tiles;
}
function menuRecords(base,screen,edition) {
    const word=ptr=>base[ptr]|base[ptr+1]<<8;
    const list=0x30000+word(0x37e49);
    const addresses=screen===menuScreens[0]
        ?[0x3372a,0x3372c,0x3372e,0x33730,0x3375a,0x3375c,0x3321c,0x33724,0x33726,0x33728,0x3323a]
        :[0x37e3f,list,list+2,list+4];
    const translated={0x7ab9:'Reliquia',0x7c39:'Guardar'};
    return addresses.map(address=>{
        const record=0x30000+word(address),position=word(record);
        const raw=base.subarray(record+2,base.indexOf(0,record+2));
        let text=edition==='es' && translated[position];
        if (!text) text=Array.from(raw,v=>{
            if (v===0xff) return ' ';
            if (v===0xc5) return '.';
            if (v===0xd0 && (edition==='moleman'||edition==='twue')) return 'il';
            if (v<0x80 || v>0xbd) throw failure('verifyFail');
            return alphaNumeric[v-0x80];
        }).join('').trimEnd();
        return {position,text,cells:raw.length};
    });
}
function installMenuLabels(out,base,data,edition) {
    const word=n=>[n&255,(n>>8)&255];
    const far=n=>[...word(n),(n>>16)&255];
    for (const screen of menuScreens) {
        const {hook,original,stub,code,atlas}=screen;
        if (base[hook]!==0x20 || base[hook+1]!== (original&255) || base[hook+2]!==original>>8 ||
            !base.subarray(stub,stub+8).every(b=>b===255) ||
            !base.subarray(code,code+0x600).every(b=>b===255) ||
            !base.subarray(atlas,atlas+0x800).every(b=>b===255)) throw failure('verifyFail');
        const vram=screen===menuScreens[0]?0x7200:0x7780;
        const graphics=[],instructions=[];
        const records=menuRecords(base,screen,edition);
        for (const {position,text,cells} of records) {
            const first=(vram-0x6000)/8+graphics.length/16;  // BG3 base $6000, word-addressed VRAM
            const tiles=proportionalTiles(data,text);
            const count=tiles.length/16;
            graphics.push(...tiles);
            // Read the palette from the stock tilemap to retain enabled and disabled colors.
            const color=[0xaf,...far(0x7e0000+position),0x29,0,0xfc]; // LDA.l / AND #$FC00
            instructions.push(...color,0x09,...word(first));          // ORA #tile
            for (let i=0;i<count;i++) {
                if (i) instructions.push(0x1a);                      // INC A
                instructions.push(0x8f,...far(0x7e0000+position+2*i));
            }
            if (count<cells) {
                instructions.push(...color,0x09,0xff,0);             // stock space tile
                for (let i=count;i<cells;i++) instructions.push(0x8f,...far(0x7e0000+position+2*i));
            }
        }
        const program=[
            0x08,0xc2,0x30,0x48,0xda,0x5a,      // PHP / REP #$30 / PHA / PHX / PHY
            0xa9,...word(vram),0x8f,0x16,0x21,0,        // select this screen's label graphics
            0xa2,0,0,                            // LDX #$0000
            0xbf,...far(atlas|0xc00000),          // LDA.l atlas,X
            0x8f,0x18,0x21,0,0xe8,0xe8,          // STA.l $2118 / INX twice
            0xe0,...word(graphics.length),0xd0,0xf1,
            ...instructions,0x7a,0xfa,0x68,0x28,0x6b];
        if (program.length>0x600 || graphics.length>0x800) throw failure('verifyFail');
        out.set(graphics,atlas);out.set(program,code);
        out.set([0x20,...word(original),0x22,...far(code|0xc00000),0x60],stub);
        out.set(word(stub),hook+1);
    }
}
function clearMenuLabels(bytes) {
    for (const {hook,original,stub,code,atlas} of menuScreens) {
        bytes[hook+1]=original&255;bytes[hook+2]=original>>8;
        bytes.fill(255,stub,stub+8);bytes.fill(255,code,code+0x600);bytes.fill(255,atlas,atlas+0x800);
    }
}

// Each row is composed from the game's own tilemap at draw time. The shifted
// strips are generated locally from the cartridge, including translated tiles.
const shiftedPages=[0x374000,0x378000,0x37c000,0x38c000,0x398000,0x39c000,0x3a8000,0x3ac000];
const battleRenderer='XCjQ/Vzw0P1cgdH9XP7R/Vzn0f1cIXn/XMjS/Vzx0v1ca9P9XJjT/YzA743C74UsBixL9DzQ9CsAXAxkwQjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZButwu8p/wDJBgDwMskHAPAtyQgA8AXJDgDQCq3I7yn/ANBogBnJDwDwFMkRAPAPyRIA8ArJFwCQUskbALBNmDjtwO9KhQfJDgCwQK9TAH4YbcDvhQGtyu8p/wDJBQCQBekFAID2Cq7A7+AUAJABGoUZCgoYZRkKGGkAA4UFqRAAhQmpAPCFCyIhef97GGkoABsrq3r6aChcRGfBjMTvS/T90PQrAFzpZsGySEv0CtH0KwBcYGnBCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG5g47cTvSoUHr0wAfhhtxO+FAaIAAL2A78UB8A/JAADwCujo4AgA0O2iAAClAZ2A74pKhRkKGGUZChhpZAOFBakQAIUJqQDwhQsiIXn/exhpKAAbK6t6+mgoXERnwaUFOOkAA4UZCgoKChhpAPiopRnJZACwGKIAAMkKAJAH6QoA6OiA9IYZqVAAhRWAGjjpZACiFADJBgCQB+kGAOjogPSGGakwAIUVnqDvpgu9AACZAADo6MjIxhXQ8qYZqQEAnaDvawjCMEjaqQAAoj4An4DvfsrKEPj6aChrCMIwSNpardVkKf8A8ANMp9KtEvfwA0yn0q107/AwqXBHjxYhAKkA749yQwCpcACPdUMAqQEYj3BDAOIgqX6PdEMAqYCPFSEAjwtCAMIgogAAvaDvyQEA0Em/rNL9GGkAWI8WIQC/rNL9ChhpAPiPckMAqaAA4BQAkAOpYACPdUMAqQEYj3BDAKkCAJ2g7+IgqX6PdEMAqYCPFSEAjwtCAMIg6OjgHADQqHr6aChrAABQAKAA8ABAAZAB4AEwAoAC0AIgA1ADgAOwA0v00tL0KwBcSEPBCMIgSNqiGgC9oO/wBqkBAJ2g78rKEPH6aCiiABBrrdyIhU5L9ADT9CsAXLNmwQjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBuvTAB+yTFdkDjJd12QFsm9XbAuqZddhQGpBACFB6nxAIUFgA+pUV2FAakDAIUHqe4AhQWpEACFCakA8IULIiF5/3sYaSgAGyurevpoKFxEZ8GlBTjp7gAKCgoKGGkA76imC6UHCgoKhRm9AACZAADo6MjIxhnQ8qkBAI1072u/AOD9hYZr';
const battleRowEntries=[
    [0x14db2,[0x5a,0x0a,0x85,0x40]],
    [0x14d73,[0x5a,0x85,0x40,0xad,0xca,0x62]],
    [0x14cdf,[0x5a,0x0a,0xa8,0x7b]],
    [0x14d05,[0x5a,0x0a,0xa8,0x7b]],
    [0x14d2b,[0x5a,0x0a,0xa8,0x7b]],
    [0x14bf4,[0x5a,0xc2,0x20,0x0a]],
    [0x14c24,[0x5a,0xc2,0x20,0x85,0x40]],
    [0x14c68,[0x5a,0x22,0x5e,0xa1,0xff]]
];
const battleHooks=[
    ...battleRowEntries.map(([at,bytes],i)=>[at,bytes,[0x5c,(0xee00+i*16)&255,(0xee00+i*16)>>8,0xfd,...Array(bytes.length-4).fill(0xea)]]),
    [0x166ae,[0xad,0xdc,0x88,0x85,0x4e],[0x5c,0x1c,0xd0,0xfd,0xea]],
    [0x143b6,[0x20,0x48,0x43,0xa2,0,0x10],[0x22,0x18,0xd0,0xfd,0xea,0xea]],
    [0x140c8,[0xbf,0xc8,0x3f,0xc1],[0x8a,0xea,0xea,0xea]],
    [0x140d5,[0xc0,0x7f],[0x00,0x28]], [0x140e1,[0xc4],[0xfb]],
    [0x14a42,[0xff,0x16,0x17,0x17,0x18,0x17,0x18],[0xff,0x16,0x17,0x18,0x1b,0xff,0xff]],
    [0x14a57,[0,2,2,2,2,2,2],[0,2,2,2,2,0,0]],
    [0x16408,[0x85,0x2c,0x06,0x2c],[0x5c,0x00,0xd0,0xfd]],
    [0x1695b,[0x20,0xe9,0x66,0xb2,0x48],[0x5c,0x04,0xd0,0xfd,0xea]],
    [0x14061,[0xc0,0x7f],[0x00,0x18]], [0x14067,[0xc4],[0xfb]],
    [0x143bf,[0xc0,0x7f],[0x00,0x18]], [0x143c5,[0xc4],[0xfb]],
    [0x16c7a,[0xbd,0x00,0xf8,0x85,0x86],[0x22,0x24,0xd0,0xfd,0xea]]
];
const nameRenderer='TDNwTIhwTKxxTPJxTHtyTJlyTHt1TLV1TJx3TL13TPV3TAZ4TBl4TDl4TPVwTDlxTGdxCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG6+Jnn6FATjpGTmiAADJgAGQBumAAeiA9YoKhQUKZQVpQAKFBSDecKkGAIUHIHRzexhpKAAbK6t6+mgoawjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBuviZ5+GhqFAa/lAH4p/wDJDACQBekMAID2CoUFCgplBWkAAoUFIN5wqQwAhQcgdHN7GGkoABsrq3r6aChrpQUKCgoKGGkAUIUDqSAAhQmpAJaFC2AIwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbr+UAfin/AMkSAJAF6RIAgPYKCqq/ANj/hQW/Atj/hRuvWlXDKf8AhQeAWgjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBupdgKFBakIgIUbr/Y0wyn/AIUHgCwIwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbqW4ChQWpCICFG68hWsMp/wCFB6+Jnn6FASDecCB0c3sYaSgAGyurevpoKGt7S/S3cfQrAFxXTsFL9MJx9CsAXK5mwQjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBup7VqFAamyAIUFqQoAhQepMACFGYBFqQFL9P5x9CsAXFdOwUv0CXL0KwBcrmbBCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG6mjW4UBqdYAhQWpBgCFB6kcAIUZqQQAhRupIPeFC6kQAIUJpQUKCgoYaQBAhQMgdHOlBRhlB6YH4AoA0AE6hQWlARhlGYUBxhvQ2HsYaSgAGyurevpoKGsIwiAp/ABI4iC9llspAwMBnZZb6OjGEtDwwiBoKGuM8PepAY3I70v0q3L0KwBcBE7BS/S2cvQrAFyoY8GcyO8IwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbogAAhhegAADiIL8AzPPZlV7QDMjI6MAaANDvwiCAEMIgpRcYaRAAquDwENDWgFut8PfJGQCQBekZAID2ogAAyQUAkAfpBQDo6ID0v2pz/4UFpRcKCoUVCmUVGp3g96KXXqAAAL0AACkA/AUFhRWYGGUVwAoAkAilFSkA/An/A50AAOjoyMAMANDaexhpKAAbK6t6+mgoa4AAigCUAJ4AqABkDWQPpQcKCgqFHaYBpAe9AAAp/wDJ/wDQBujoiNDwYKUHGhqFFaULqqQJqQAAnQAA6OiIiND3xhXQ7qUPCmUBqr0AACn/AIUXqr8Ab/8p/wCFFaUNKQcACqq/8Xj/hROlFwoKCgoKChh/4Xj/hRGlDUpKSgoKCgqkCcAgANABChhlC6qgAAC3ER0AAJ0AAOjoyMiYKQ8A0O7AMADwD6UJyRAA8OKKGGkQAKqA2qUNGGUVhQ3mD6UPxQfwJKUNxR2QGqYPigoYZQGouQAAKf8Ayf8A0Aro5AfQ6oAETK9zYKUJyRAA0B2lBckAA5AGIoHR/YA9ye4AkAYia9P9gDIgNnWALaUbEBKlB0ilGyn/f4UHIGV4aIUHgBelB8kMANANxgfGByBleOYH5geAAyBleKYBoAAAvQAAKQD8BQWFF5gYZRfapgngEADwLEilGxASKf9/hRVoxBWQWCkA/An/AIBQaKYH4AwA0EjACgCQQykA/An/AIA7pgdIpQXJAANokBBIpQXJZANokArABgCQIoAITBd1wAoAkBgpAPwJ/wOAEOAKANALwAkA0AYpAPwJ/wP6nQAA6OjIxAfwA0yqdGCiAAClBd98d//wBOjogPSeAPeGF6UFOOmyAAoKCgoYaQDzqKYXv4x3/0qFFaYLvQAAmQAA6OjIyMYV0PKmF6kBAJ0A92Ai59H9IhW4/wjCIKkAAKIOAJ8A937KyhD4oggAn+D3fsrKEPipVkaPEPd+qQAAjxL3fiiiAGigAAhrCNqpfkirwiAiD7j/Iv7R/aIIAL2QYikAA8kAAdAJvZBiCQACnZBiysoQ6K0Q98lWRvADTHd3rRL3yRAAkHvJGACwdjjpEADrjRT3GGkA8I9yQwCtFPdKGGkARI8WIQCpAAGPdUMAqQEYj3BDAO4S960S98kYANAGqQMAjRL34iCp0o90QwCpgI8VIQCpgI8LQgDCIK0U9xhpADiPckMArRT3ShhpAGyPFiEAqQABj3VDAOIgqf9MZ3fJIACwGMkAAPBoyQIA0GCti3sp/wDQWKkgAI0S960S9ykHAOuNFPcYaQBYj3JDAK0U90oYaQBsjxYhAKkAAY91QwCpARiPcEMA7hL3rRL3ySgA0AOcEvfiIKn/j3RDAKmAjxUhAKmAjwtCAMIggANMd3eiAAC9APfJAQDwQ+jo4BAA0PGiAAC94PfQCejo4AoA0PSAdDqPckMAnuD3v2pz/woKChhpAECPFiEAqaAAj3VDAKkBGI9wQwDiIKnzgDmeAPe/fHf/CgoKGGkAQI8WIQC/fHf/OOmyAAoKCgoYaQDzj3JDAKkBGI9wQwC/jHf/j3VDAOIgqX6PdEMAqYCPFSEAqYCPC0IA+iipfmuyALsAxADNANYA3ADiAOgAkACQAJAAkABgAGAAYABgAK0S98kD8A3JELAFqRCNEvdcH0rBqQGNEvd7qqlMXMpVwUv0x3f0KwBc+0DBS/TSd/QrAFwbQcEIwiCpAQCiDgCdAPfKyhD5oggAnuD3ysoQ+akCAI0S9yhrkUyp/5FKyKVOCQKRTJFKyGvCIAkAApFTpVUJAAKRUeIgyMhri6kASKuOFiHCIKnuAeAAeJADCQACjRghiND6e+Igq2sIwiBI2qIAAL0/5ykAA8kAAdAJvT/nCQACnT/n6OjggADQ5fpoKKKAAIYQawjiIK8E+n7QGq8SQgAQ+q8/IQCvNyEArz0hAMn2sOrJ3JDmeKIGAL8AQwBIyhD4qYCPFSEAwiClA48WIQCpARiPAEMApQuPAkMApQcKCgoKpgngIADQAQqPBUMA4iCpfo8EQwCpAY8LQgCiAABonwBDAOjgBwDQ9cIgKGAAQACAAMAAwACAAMAAgADA9wD3APcA+AD5APkA+gD6AABwAKAAUACQAMAAIABQAKD7APsA/AD8APwA/QD9AP0AIHRzaw==';
const numberRenderer='TCS4TIC4TL64TCO5TI+5THO+TCK+TFy+TNa/TADATBjATCXAhuupfoXtu6AAALX3l+vIpSmX68jo5ODQ8QjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBuYSoUdr+sAfoUBqQAAhRsgV78geMCwBiA9uiBvwXsYaSgAGyurevpoKGtL9Iq49CsAXK5owbVpS/SXuPQrAFzwZsHo4AQA0O0IwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbqQQAhR2APEv0yLj0KwBcxmjBtWpL9NW49CsAXPBmwejgAwDQ7QjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBupAwCFHZgYb0wAfoUBpR0KhRWlATjlFYUBqQEAhRsgPbp7GGkoABsrq3r6aChrS/QtufQrAFz0Y8FkQLJPOOkKkATmQID3GGkKhUGlQNACqUsYabRL9FO59CsAXPtjwaVBBUDQBKn/gAWlQRhptEv0bbn0KwBc+2PBCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG6kCAIUdTBS6S/SZufQrAFz0Y8FkQGRBsk846WSQBOZAgPcYaWQ46QqQBOZBgPcYaQpIpUDQAqlLGGm0S/TMufQrAFz7Y8GlQQVA0ASp/4AFpUEYabRL9Oa59CsAXPtjwWgYabRL9PW59CsAXPtjwQjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBupAwCFHZgYb1MAfoUBpR0KhRWlATjlFYUBqQEAhRsgPbp7GGkoABsrq3r6aChrZCGlHdABYMkJAJABYKYBpB29AAAp/wDJ/wDwDMm0ALABYMm+AJABYOjoiNDkpR2FH6YBvQAAKf8Ayf8A0Afo6MYf0O9gpR8KGGUfCoUVGGkHAEpKSoUHCgoKOOUVhQ2lHTjlB4UZpRvQY6kgAIUJqQCWhQulHckCAPAFyQMA0CGlAcnJd5AapR0KGGUBqiDbwZAOpR2FB2QZCgoKOOUVhQ2lHckCANAvpQHJyXeQKDo6qiDbwZAgqQIAhSGp//+FGakGAIUNqQMAhQeACqkQAIUJqSD3hQulG/ADTKm7pR3JBADwA0ypu6UBOjqqvQAAKf8DSCn/AMnAAPAfaDjp0AHJUACwZgqqvQD5yQEA0Fy9APgaGsUB0FOAAWilH8kEAJAg5iGp//+FGakGAIUNpR8aChhlHxoKGGkHAEpKSoUHgClkGakDAIUHpR8KGGUfCoUNqRYAOOUNhQ2lATo6qr0AACkA/AnAAJ0AAKUhyQIA0BilATo6qr0AACn/AzjpoAHJoACwBKqeAPgghL2QAWClHTjlH4UPpQcahRWmC6QJqQAAnQAA6OiIiND3xhXQ7qUh8E6mC6AAAFq7pSHJAgDwBr8AcPeABL9AcPd6pgudAADmC+YLyMjAEADQ3KULOOkQAIULpQ8KGGUBqr0AACn/AMn/ANAL5g+lD8Ud0OZMvLylDwoYZQGqvQAAKf8AhRelDSkHAAqqv/F4/4UTpRcKCgoKCgoYf+F4/4URpQ1KSkoKCgoKpAnAIADQAQoYZQuqoAAAtxEdAACdAADo6MjImCkPANDuwCAA8A+lCckQAPDiihhpEACqgNqlDRhpBgCFDeYPpQ/FHfADTEC8pRvQFqUFCgoKChhpAG2FAyAwwPAwIGV4gCuc/u+lBQoKCgoYaQDwqKYLpQcKCgqFFb0AAJkAAOjoyMjGFdDyqQEAjf7vpgG9AAApAPyFFQn/AKQb8AMJAAOkHZ0AAOjoiND4pRkKGGUBhQFkD6UFGGUPqiBivQUVpAGZAACKCqqYpBvQEZ0A+KkAAKQP0AKlIZ0A+YADnQDv5gHmAeYPpQ/FB9DIYKUb0BSlAcnJd5AHigoYaaABYIoYadABYNqKCqq/977/+mBkF6IAAKUb0CatAvrwFq/lAH4p/wDJDACQBekMAID2CoUFGGCtAPrJAQDQA6IYANqKCqqlG9AFvQD4gAO9AO/6yQAA8CGoWtqlAUiYhQEgYr2FA2iFAfp6uQAAKf8DxQPQBGQXgA6lF9AChgXmF6UXxQfwKOilG9AZrQD68A/JAgDwBeAwAIAN4CAAgAjgUACAA+AoANCY7vzvOGAYYCLzzdQiBtn/CMIwSNqpAACi/gGfAPh+ysoQ+I/8736PAPp+jwL6fo8E+n6iLgCfEPp+ysoQ+PpoKGsIwjBI2qkAAKL+A58A737KyhD4+mgoawjCMEjaWq3+7/BWrRL30FGiAADgEADQCK3VZCn/ANBBv9m+/48WIQC/277/j3VDANqKSqq/7b7/+o9yQwCpARiPcEMA4iCpfo90QwCpgI8VIQCPC0IAwiDo6Ojo4BAA0LJ6+mgoa3BHIAFAQIAA0EFgAMBDgAAAWIAAAPAg8aDxAPKA8u4A7wDwAPEA8gDzAPQA9QD2APcA+AD5APoA+wD8AP0A/gD/AAgACQAKAAsADAANAA4ADwA6ADsAPAA9AD4APwB4AHkAegB7AHwAfQB+AH8AAAMBAwIDAwMEAwUDBgMHA68mAH4p/wDJCQDwUMkKAPBLyRoAkAXJHwCQQckzAPA8yTQA8DfJPgDwMskHAPAoyQgA8CPJFwCQGckaAJAZyV4A8BTJZADwD8lxAPAKyXIA8AWpAACACKkBAIADqQIAzQD68BqNAPqi/gGpAACdAPjKyhD5oi4AnRD6ysoQ+WDCILfvqsAEAPAFwAgA0A2lKSn/AOsJwACf/v994iBL9P6/9Ib/XJEEw2upAY8C+n5L9BDA9Ib/XLcEw6kAjwL6fmupAY8E+n6pgI8AIQBrqQCPBPp+qQGFRGtkF6UFCqqkB70A+NAC5hfo6IjQ9KUFCgoKCqqkC6UHhQ+pCACFFbkAAN0A+/AFnQD75hfo6MjIxhXQ65gYaRAAqMYP0NylF2CcBvpkIaUdyQIA8BvJAwDQE6UBycl3kAwYaQYAqiDbwZACGGBMzMGlAcnJd7ADTMzBGGkEAKog28GwFKUBOjqqINvBkAepAgCFIYADTMzB7gb6pQGNOvqqvQAAjTz6vQIAjT76ogAAvRD6xQHQeb0S+s08+tBxvRT6zT760Gm9Fvop/wOkAcDJd5AHOOmgAUqABDjp0AHJUACwTAqopSHJAgDQBqUBOjqAAqUB2QD40DYaGtkC+NAvpSHJAgDQCaUBGhrZBPjQH6QBpSHJAgDQCIiIvUD6mQQAvRb6mQAAvRj6mQIAOGCKGGkKAKrgKADwA0zfwBhgrQb68FeiAAC9EPrNOvrwDooYaQoAquAoANDtrjj6rTr6nRD6qKUhyQIA0AKIiK08+p0S+q0++p0U+rkAAJ0W+rkCAJ0Y+rkEAJ1A+ooYaQoAySgAkAOpAACNOPpgoigAqQAAnRD6ysoQ+RhgvQAAKf8DycEA8B046aAByaAAsBaJAQDQEaiK2QD40Aq5APnJAgDQAjhgGGA=';
const numberHooks=[
    [0x33530,[0xa9,0x80,0x8d,0x00,0x21],[0x22,0x1e,0xb8,0xff,0xea]],
    [0x33542,[0xa9,0x01,0x85,0x44],[0x22,0x21,0xb8,0xff]],
    [0x30d22,[0xc2,0x20,0xb7,0xef,0xaa],[0x22,0x18,0xb8,0xff,0x60]],
    [0x38013,[0x20,0xb7,0x04],[0x20,0xe4,0xfe]],
    [0x3fee4,Array(5).fill(255),[0x22,0x1b,0xb8,0xff,0x60]],
    [0x3ff87,[255],[0x6b]],
    [0x304c8,[0x86,0xeb,0xa9,0x7e,0x85],[0x22,0x00,0xb8,0xff,0x60]],
    [0x36959,[0x22,0xf3,0xcd,0xd4],[0x22,0x12,0xb8,0xff]],
    [0x168f2,[0x20,0xae,0x68,0xb5,0x69],[0x20,0xae,0x68,0xb5,0x69]],
    [0x16901,[0x20,0xc6,0x68,0xb5,0x6a],[0x20,0xc6,0x68,0xb5,0x6a]],
    [0x16491,[0x20,0xf4,0x63,0x64,0x40],[0x20,0xf4,0x63,0x64,0x40]],
    [0x16447,[0x20,0xf4,0x63,0x64,0x40],[0x20,0xf4,0x63,0x64,0x40]]
];
const rowHooks=[
    [0x14903,[0x84],[0x60]],
    [0x143a9,[0xa2,0x80,0,0x86,0x10],[0x22,0x27,0x70,0xff,0xea]],
    [0x17d83,[0x35],[0x37]],[0x17d9b,[0x35],[0x37]],[0x17d45,[0x29],[0x2b]],
    ...Array.from({length:15},(_,i)=>[0x2a860+i,[i<8?0x21:0x25],[i<8?0x23:0x27]]),
    [0x1468e,[1],[3]],
    [0x11205,[0x55],[0x44]],
    [0x166f0,[0x91,0x4c,0xa9,0xff,0x91],[0x22,0x1e,0x70,0xff,0x60]],
    [0x163fb,[0xc2,0x20,0x91,0x53,0xa5],[0x22,0x21,0x70,0xff,0x60]],
    [0x117a5,[0x8b,0xa9,0,0x48,0xab],[0x22,0x24,0x70,0xff,0x60]],
    ...[0x14a6b,0x15a1a].map(at=>[at,[1],[3]]),
    [0x155c6,[0x7b,0xaa,0xa9,0x4c],[0x5c,0x18,0x70,0xff]],
    [0x156b2,[0x20,0xfb,0x40,0x20,0x1b,0x41],[0x22,0x1b,0x70,0xff,0xea,0xea]],
    [0x14cd7,[0x20,0x04,0x4e,0x20,0xa8,0x63,0x7a,0x60],[0x22,0x0f,0x70,0xff,0x7a,0x60,0xea,0xea]],
    [0x110d3,[0xa2,0x00,0x68,0xa0,0x00,0x08],[0x22,0x12,0x70,0xff,0xea,0xea]],
    [0x10bc7,[0xa9,0x7e,0x48,0xab],[0x22,0x15,0x70,0xff]],
    ...[0x33322,0x3336e,0x333ba,0x33406].map(at=>[at,[0x20,0xd0,0x34],[0x20,0xb8,0xfc]]),
    [0x3fcb8,Array(8).fill(255),[0x20,0xd0,0x34,0x22,0x00,0x70,0xff,0x60]],
    [0x3802f,[0x20,0x35,0x80],[0x20,0xc0,0xfc]],
    [0x3fcc0,Array(8).fill(255),[0x20,0x35,0x80,0x22,0x03,0x70,0xff,0x60]],
    [0x14a5e,[0x7b,0x20,0x57,0x4e,0x4c,0xae,0x66],[0x22,0x06,0x70,0xff,0x60,0xea,0xea]],
    [0x14a8c,[0xa9,1,0x20,0x57,0x4e,0x4c,0xae,0x66],[0x22,0x09,0x70,0xff,0x60,0xea,0xea,0xea]],
    [0x1479e,[0x9d,0x96,0x5b,0xe8,0xe8,0xc6,0x12,0xd0,0xf7],[0x22,0x0c,0x70,0xff,0xea,0xea,0xea,0xea,0xea]]
];
function vectorLengthTable(rom) {
    // Expand the input game's delta-coded 32x32 vector table exactly as C1 does.
    const start=0x2cd66,end=start+rom[start]+256*rom[start+1];
    const history=new Uint8Array(2048),deltas=[];
    let p=start+2,write=0x7de;
    const emit=value=>{deltas.push(value);history[write]=value;write=(write+1)&2047;};
    while(p<end) {
        const flags=rom[p++];
        for(let bit=0;bit<8&&p<end;bit++) {
            if(flags&(1<<bit)) emit(rom[p++]);
            else {
                const token=rom[p++]+256*rom[p++];
                for(let i=0;i<(token>>>11)+3;i++) emit(history[((token&2047)+i)&2047]);
            }
        }
    }
    if(deltas.length!==1024) throw failure('verifyFail');
    const table=new Uint8Array(2048);
    for(let row=0;row<32;row++) {
        let sum=0;
        for(let col=0;col<32;col++) {
            const i=row*32+col;sum+=deltas[i];table[i*2]=sum;table[i*2+1]=sum>>>8;
        }
    }
    return table;
}
function installNameSpacing(out,data,edition,names) {
    const ensureFree=(offset,size)=>{
        if (!out.subarray(offset,offset+size).every(v=>v===255)) throw failure('verifyFail');
    };
    for (const address of shiftedPages) ensureFree(address,0x4000);
    ensureFree(0x3b1800,0x1200);
    ensureFree(0x3dd000,0x2000);
    out.set(vectorLengthTable(out),0x3de000);
    out.set(out.subarray(gbaFont.fontStart,gbaFont.fontStart+4096),0x3b1800);
    ensureFree(0x3f6f00,0x1100);
    ensureFree(0x3fb800,0x2000);
    for (const [at,before,after] of [...rowHooks,...numberHooks,...battleHooks]) {
        if (!before.every((v,i)=>out[at+i]===v)) throw failure('verifyFail');
        out.set(after,at);
    }
    const ascii=new Map(Array.from(alphaNumeric,(ch,i)=>[i+128,ch]));
    for (const [i,ch] of Array.from("!?/:\"'-.,").entries())
        if (edition!=='es' || ch!=="'") ascii.set(0xbe+i,ch);
    const components=new Map(names?catalog.cartridge.pairs[edition]:[]);
    if (edition==='es') for(const [i,pair] of catalog.cartridge.pairs.es)
        if ([13,36,37,39,40,65,67,69,71,74,75,76,82,90,92,99,105,108,109,110,111,112,127].includes(i)) components.set(i,pair);
    if ((edition==='moleman'||edition==='twue') && !components.has(0xd0)) components.set(0xd0,'il');
    const accents=new Map([['í',195],['ñ',202],['á',206],['é',207],['ó',208],['ú',209],['ü',210]]);
    function native(code) {
        const tile=out.slice(gbaFont.fontStart+16*code,gbaFont.fontStart+16*(code+1));
        const ink=tile.filter((v,i)=>i%2).reduce((a,v)=>a|v,0);
        let width=8;
        while (width && !(ink&(256>>width))) width--;
        return {tile,width:Math.min(8,width+1)};
    }
    function character(ch) {
        if (accents.has(ch)) return native(accents.get(ch));
        return {tile:cartridgeMenuTile(data,ch),width:data[(ch.charCodeAt(0)-32)*gbaFont.record]};
    }
    for (let code=0;code<256;code++) {
        const text=components.get(code) || ascii.get(code) || (code===255?' ':'');
        const parts=text?Array.from(text,character):[native(code)];
        const width=parts.reduce((sum,g)=>sum+g.width,0);
        out[0x3f6f00+code]=width;
        for (let shift=0;shift<8;shift++) {
            const image=new Uint8Array(64);
            let pen=shift;
            for (const glyph of parts) {
                for (let x=0;x<8;x++) {
                    const col=pen+x,bit=128>>(col%8);
                    for (let r=0;r<16;r++) if (glyph.tile[r]&(128>>x)) image[(col>>3)*16+r]|=bit;
                }
                pen+=glyph.width;
            }
            out.set(image,shiftedPages[shift]+code*64);
        }
    }
    // Battle inventory strips live in ROM, keeping battle WRAM available for effects.
    ensureFree(0x330000,0xdcf0);
    for (let id=0;id<271;id++) {
        const ptr=id<256?(names?0x3f1000:0x12b300)+id*13:(names?0x3f2000:0x360080)+(id-256)*13;
        const record=out.slice(ptr,ptr+13);
        out.set(record,0x33cc00+id*16);
        const strip=new Uint8Array(192);
        let pen=0;
        for (const code of record.subarray(1)) {
            const lookup=shiftedPages[pen%8]+code*64;
            const dest=(pen>>3)*16;
            for (let i=0;i<Math.min(48,192-dest);i++) strip[dest+i]|=out[lookup+i];
            pen+=out[0x3f6f00+code];
        }
        out.set(strip,0x330000+id*192);
    }
    // Reels are hidden on the regular menu's otherwise blank second BG1 page.
    // Restore both map and artwork only while the Slots window is active.
    ensureFree(0x3f3800,0x800);
    ensureFree(0x3f5800,0x800);
    const reelMap=new Uint16Array(1024).fill(0xee);
    for (let reel=0;reel<3;reel++) for (let row=0;row<16;row++) {
        const symbol=out[0x2a800+32*reel+2*row];
        const ptr=0x14958+symbol*2;
        const first=out[ptr]|out[ptr+1]<<8;
        for (let dy=0;dy<2;dy++) for(let dx=0;dx<4;dx++)
            reelMap[(row*2+dy)*32+9+reel*5+dx]=first+dy*16+dx;
    }
    for (let i=0;i<1024;i++) {
        out[0x3f3800+i*2]=reelMap[i]&255;
        out[0x3f3801+i*2]=reelMap[i]>>8;
        out[0x3f5800+i*2]=0xee;
        out[0x3f5801+i*2]=0;
    }
    for(let i=0;i<10;i++) out.set(data.subarray(hudFontOffset+i*16,hudFontOffset+(i+1)*16),0x3b1800+(0xb4+i)*16);
    // The MP panel is BG1 (4bpp), whose second two planes stay zero.
    // Keep its numeric cells at the GBA's native eight-pixel HUD pitch.
    for(let i=0;i<21;i++) {
        const code=out[0x13fc8+i];
        out.set(out.subarray(0x3b1800+code*16,0x3b1800+(code+1)*16),0x3b2800+i*16);
    }
    out.set(data.subarray(hudFontOffset+160,hudFontOffset+192),0x3b2800+17*16);
    const needed=proportionalTiles(data,'Needed');
    for(const [i,slot] of [14,15,16,19].entries()) out.set(needed.subarray(i*16,i*16+16),0x3b2800+slot*16);
    out.set(from64(battleRenderer),0x3dd000);
    battleRowEntries.forEach(([at,bytes],i)=>out.set([0x8f,0xca,0xef,0x7e,...bytes,0x5c,(at+bytes.length)&255,((at+bytes.length)>>8)&255,0xc1],0x3dee00+i*16));
    out.set(from64(nameRenderer),0x3f7000);
    out.set(from64(numberRenderer),0x3fb800);
}
function clearNameSpacing(rom,spaced=false,legacy=false) {
    if(!legacy) {
        rom.fill(255,0x3b1800,0x3b2a00);
        rom.fill(255,0x3dd000,0x3df000);
        for(const [at,original] of battleHooks) rom.set(original,at);
    }
    rom.fill(255,0x3f3800,0x3f4000);
    rom.fill(255,0x3f5800,0x3f6000);
    rom.fill(255,0x330000,0x33dcf0);
    for (const page of shiftedPages) rom.fill(255,page,page+0x4000);
    rom.fill(255,0x3f6f00,0x3f8000);
    for (const [at,original] of rowHooks) rom.set(original,at);
    if (!spaced) {
        rom.fill(255,0x3fb800,0x3fd800);
        for (const [at,original] of numberHooks) rom.set(original,at);
    }
}

// These call sites cover both columns, the equipped label (including empty),
// and the detail heading. Keep the existing per-edition name lengths/colors.
const esperHooks=[
    ...[0x35548,0x35553].map(at=>[at,[0x20,0x68,0x55],[0x20,0xc8,0xfc]]),
    ...[0x33506,0x33517].map(at=>[at,[0x4c,0x35,0x80],[0x4c,0xd0,0xfc]]),
    [0x35a31,[0x20,0x35,0x80],[0x20,0xd8,0xfc]],
    [0x3fcc8,Array(8).fill(255),[0x20,0x68,0x55,0x22,0x2a,0x70,0xff,0x60]],
    [0x3fcd0,Array(8).fill(255),[0x20,0x35,0x80,0x22,0x2d,0x70,0xff,0x60]],
    [0x3fcd8,Array(8).fill(255),[0x20,0x35,0x80,0x22,0x30,0x70,0xff,0x60]]
];
function installEsperSpacing(out) {
    for(const at of [0x3555a,0x334f6,0x35a21])
        if(![8,12].includes(out[at])) throw failure('verifyFail');
    if(!out.subarray(0x3fd800,0x3fd848).every(v=>v===255)) throw failure('verifyFail');
    const length=out[0x3555a];
    const names=(out[0x3555f]|out[0x35560]<<8|out[0x35564]<<16)-0xc00000;
    const capacities=Array(18).fill(1);
    for(let id=0;id<31;id++) {
        const row=out.slice(names+id*length,names+(id+1)*length);
        let end=row.length;while(end && row[end-1]===255)end--;
        const width=Array.from(row.subarray(0,end)).reduce((n,code)=>n+out[0x3f6f00+code],0);
        const slot=(out[0x11f9b5+id]-1)%18;
        if(slot<0||width>64)throw failure('verifyFail');
        capacities[slot]=Math.max(capacities[slot],Math.ceil(width/8));
    }
    let tile=0x200;
    for(let i=0;i<18;i++) {
        const at=0x3fd800+i*4,n=capacities[i];
        out.set([tile&255,tile>>8,n,0x80],at);tile+=n;
    }
    if(tile>0x26e)throw failure('verifyFail');
    for(const [at,before,after] of esperHooks) {
        if(!before.every((v,i)=>out[at+i]===v)) throw failure('verifyFail');
        out.set(after,at);
    }
    // TWUE's class label shares the original Esper routine's final flush.
    // Keep that label on its own native path instead of reusing Esper tiles.
    if(out[0x3ff07]===0x4c && out[0x3ff08]===0x06 && out[0x3ff09]===0x35)
        out.set([0x35,0x80],0x3ff08);
}
function clearEsperSpacing(rom) {
    if(!esperHooks[0][2].every((v,i)=>rom[esperHooks[0][0]+i]===v)) return;
    for(const [at,before] of esperHooks) rom.set(before,at);
    rom.fill(255,0x3fd800,0x3fd848);
    if(rom[0x3ff07]===0x4c && rom[0x3ff08]===0x35 && rom[0x3ff09]===0x80)
        rom.set([0x06,0x35],0x3ff08);
}

// GBA menu help uses its small font; field and battle dialogue use the large
// font. Keep a separate table for the SNES menu-help writer.
const descriptionHooks=[
    [0x3a96d,[0xbf,0xc0,0x90,0xc4],[0xbf,0x00,0xf0,0xfb]],
    [0x3a9d8,[0x7f,0xc0,0x8f,0xc4],[0x7f,0x00,0xfb,0xfb]]
];
function installDescriptionFont(out) {
    if(!out.subarray(0x3bf000,0x3bfc20).every(v=>v===255)) throw failure('verifyFail');
    out.fill(0,0x3bf000,0x3bfc00);
    for(let code=0x80;code<=0xff;code++) {
        const width=out[0x3f6f00+code];
        out[0x3bfb00+code-0x60]=width;
        for(let y=0;y<8;y++) {
            let ink=0;
            for(let x=0;x<12;x++) {
                const address=shiftedPages[0]+code*64+(x>>3)*16+y*2+1;
                if(out[address]&(128>>(x&7))) ink|=1<<(11-x);
            }
            const address=0x3bf000+(code-0x80)*22+y*2;
            out[address]=ink&255;out[address+1]=ink>>8;
        }
    }
    for(const [at,before,after] of descriptionHooks) {
        if(!before.every((v,i)=>out[at+i]===v)) throw failure('verifyFail');
        out.set(after,at);
    }
}
function clearDescriptionFont(rom) {
    for(const [at,before] of descriptionHooks) rom.set(before,at);
    rom.fill(255,0x3bf000,0x3bfc20);
}

const shadowRenderer='XAzg+1yN4PtcBuH7CMIwSNpaiws7OOkoABtb4iCpfkirwiBkG63NACn/ACCl4RhpAICFEan7AIUTrb8AKQcAhR2iAACpAACdA5Do6OCAAND2ogAAoAAAtxEgsOGlH50DkKUhnSOQyMi3ESCw4aUfnUOQpSGdY5DIyOjowDAA0Nd7GGkoABsrq3r6aChrCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG6UwKf8AhRcgpeEYaQCwhRGp+wCFE62NACn/AIUNKQcAhR2lDSn4AAoKGG3tABhpeaKFBakBAIULIMbhpRcYaSAAqr8A+/sp/wAYZQ3iII2NAMIgexhpKAAbK6t6+mgoa1raIiDh+6+sYn7QC0v0HOH0KwBc/13B+nprCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG6UwKf8A4iCN8OzCIDjpYACFFyCl4RhpAICFEan7AIUTrXoAKf8AhQ0pBwCFHaUNKfgACgoYaUfjhQWpAgCFC61LACn/APAC5gsgxuGmF7/Aj8Qp/wAYZQ3iII16AMIgexhpKAAbK6t6+mgoawoKCgqFAQoYZQFgCgoKCoUfZCFapB3wB0YfZiGI0Pl6YKYFoAAAtxEgsOGlC8kBAPAVyQMA8AggD+IgLOKACyBJ4iAs4oADIA/iyMi3ESCw4aULyQEA8AUgD+KAAyAs4sjI6OjAMADQvWDiIKUgHQAAnQAApR8dIACdIAClIh1AAJ1AAMIgYOIgpSAdAQCdAQClHx0hAJ0hAKUiHUEAnUEAwiBg4iClIEn/PQAAnQAApR9J/z0gAJ0gAKUiSf89QACdQADCIGA=';
const shadowHooks=[
    [0x898a,[0xa9,0x7e,0x8d,0x83,0x21],[0x22,0x00,0xe0,0xfb,0x60]],
    [0x3a941,[0x48,0x8f,0x02,0x42,0x00],[0x22,0x04,0xe0,0xfb,0x60]],
    [0x1610e,[0x8d,0xf0,0xec,0x38,0xe9,0x80],[0x22,0x08,0xe0,0xfb,0x60,0xea]]
];
function donorLargeShadow(ink,ch) {
    const rows=Array.from({length:12},(_,y)=>{
        const here=ink[y]||0,above=ink[y-1]||0;
        return ((here>>1)|above|(above>>1))&~here&0xfff;
    });
    // The actual GBA artwork has six hand-tuned shadow pixels. Storing these
    // deltas lets earlier portable font records upgrade without the ROM again.
    const detail={'5':[6,3,1],S:[8,1,0],U:[4,2,0],V:[9,5,0],X:[8,2,0],x:[9,2,0]}[ch];
    if(detail) {
        const [y,x,on]=detail,bit=1<<(11-x);
        rows[y]=on?rows[y]|bit:rows[y]&~bit;
    }
    return rows;
}
function installShadowFont(out,data,edition) {
    if(!out.subarray(0x3b8000,0x3bf000).every(v=>v===255)) throw failure('verifyFail');
    out.fill(0,0x3b8000,0x3bc800);
    const ascii=new Map(Array.from(alphaNumeric,(ch,i)=>[0x20+i,ch]));
    for(const [i,ch] of Array.from("!?/:\"'-.,").entries())
        if(edition!=='es'||ch!=="'") ascii.set(0x5e+i,ch);
    ascii.set(0x6b,'(');ascii.set(0x6c,')');
    if(edition!=='es') for(const [code,ch] of [[0x68,';'],[0x69,'#'],[0x6a,'+'],[0x6d,'%'],[0x6e,'~']]) ascii.set(code,ch);
    if(edition==='regular') ascii.set(0x72,'=');
    const write=(at,ink,shadow)=>{
        for(let y=0;y<12;y++) for(const [plane,row] of [[0,ink[y]||0],[2,shadow[y]||0]]) {
            out[at+y*4+plane]=row&255;out[at+y*4+plane+1]=row>>8;
        }
    };
    for(let code=32;code<256;code++) {
        const ink=Array.from({length:11},(_,y)=>{
            const at=0x490c0+(code-32)*22+y*2;
            return out[at]|out[at+1]<<8;
        });
        let shadow;
        if(ascii.has(code)) shadow=donorLargeShadow(ink,ascii.get(code));
        else if(code===0x67) {
            const ptr=('.'.charCodeAt(0)-32)*gbaFont.record;
            const dot=Array.from({length:11},(_,y)=>data[ptr+18+y*2]|data[ptr+19+y*2]<<8);
            shadow=donorLargeShadow(dot,'.').map(r=>r|(r>>data[ptr+17])|(r>>(2*data[ptr+17])));
        } else shadow=Array.from({length:12},(_,y)=>(ink[y-1]||0)>>1);
        write(0x3b8000+code*48,ink,shadow);
    }
    // Spanish help also uses encoded two-letter glyphs below $80.
    // They wrap after the native subtraction and need the second half-table.
    // That extension is otherwise free; MoleMan alone uses it for job labels.
    for(let code=edition==='es'?0:0x80;code<256;code++) {
        const ink=Array(12).fill(0),shadow=Array(12).fill(0);
        for(let y=0;y<8;y++) for(let x=0;x<12;x++) {
            const at=shiftedPages[0]+code*64+(x>>3)*16+y*2,bit=128>>(x&7),target=1<<(11-x);
            if(out[at+1]&bit) ink[y]|=target;
            else if(out[at]&bit) shadow[y]|=target;
        }
        write(0x3bb000+((code-0x80)&255)*48,ink,shadow);
        if(code<0x80) out[0x3bfb20+((code-0x80)&255)]=out[0x3f6f00+code];
    }
    out.set(from64(shadowRenderer),0x3be000);
    for(const [at,before,after] of shadowHooks) {
        if(!before.every((v,i)=>out[at+i]===v)) throw failure('verifyFail');
        out.set(after,at);
    }
}
function clearShadowFont(rom) {
    if(!shadowHooks[0][2].every((v,i)=>rom[shadowHooks[0][0]+i]===v)) return;
    for(const [at,before] of shadowHooks) rom.set(before,at);
    rom.fill(255,0x3b8000,0x3bf000);
}

// These are the ROM defaults copied by event command $7f, not saved names.
// Preserve each edition's spellings, including its temporary party members.
const defaultNames={start:0x478c0,size:64*6,backup:0x3ee498,tag:[0x54,0x43,0x4e,0x31]};
function installDefaultNames(out,base) {
    const {start,size,backup,tag}=defaultNames;
    if(!base.subarray(backup,backup+4+size).every(v=>v===255)) throw failure('verifyFail');
    out.set(tag,backup);out.set(base.subarray(start,start+size),backup+4);
    for(let record=0;record<64;record++) for(let i=0;i<6;i++) {
        const at=start+record*6+i,value=out[at];
        if(i===0 && value>=0x9a && value<=0xb3) out[at]=value-26;
        else if(i>0 && value>=0x80 && value<=0x99) out[at]=value+26;
    }
}
function clearDefaultNames(rom) {
    const {start,size,backup,tag}=defaultNames;
    // Earlier patchers have no name-default layer or marker.
    if(!tag.every((v,i)=>rom[backup+i]===v)) return;
    rom.set(rom.subarray(backup+4,backup+4+size),start);
    rom.fill(255,backup,backup+4+size);
}

const menuRenderer='TCnZTAbZCMIwSNqpAACi7gOfAON+ysoQ+I+Q4n6PkuJ+j5zifvpoKGumAJvCIKfnhevm5+bn4iCpfoXtt+fwD1qbl+vom6Upl+voesiA7SJX2f9c+QLDCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG4Qfr+sAfoUByUk4sANMDtrJSViQDclJeLADTA7ayUmYsHwgtdylH/B1ySEAsHCmAb0AACn/AMn/ANAK5gHmAcYf0OuAWWQH5gelB8Uf8CcKGGUBqr0AACn/AMnHAPAXyf8A0OOlBxrFH/ALvQIAKf8Ayf8A0NGlAUilB0ilH0ggG9pohR9ohQdohQGlHzjlB4Uf8AqlBwoYZQGFAYCQexhpKAAbK6t6+mgoa+6S4qUHhR2pAQCFI2QlpgGkHb0AACn/AMm0AJAMyb4AsAfo6IjQ64ACZCNkDWQPpQ8KGGUBqr0AACn/AKog0NsYZQ2FDeYPpQ/FHdDipQ0YaQcASkpKhQelI/AMpR2FBwoKCjjlDYUlpQfFHZAD8AFgpQHJSXiwEakgAIUJqQAAhRmp0ACFG4APqRAAhQmp0ACFGan4AYUbIAPckATukOJgqQCWhQumC6UHGhqFFaQJqQAAnQAA6OiIiND3xhXQ7qUlhQ1kD6UPChhlAaq9AAAp/wCFF6og0NuFFaUNKQcACqq/8Xj/hROlFwoKCgoKChh/4Xj/hRGlDUpKSgoKCgqkCcAgANABChhlC6qgAAC3ER0AAJ0AAOjoyMiYKQ8A0O7AMADwD6UJyRAA8OKKGGkQAKqA2qUNGGUVhQ3mD6UPxR3wA0zh2qYFIODbhRelCckQAPAMpRcKCgoKGGkAUIAJpRcKCgoYaQBghQMgZXhkD6UPChhlAaq9AAApAPwJ/wCFFaUPxQewHhhlF4UhpRUpAPwFIZ0AAIpIpQ8YZQUKqmidAOOABaUVnQAA5g+lD8Ud0L1gpSPwBKkGAGC/AG//Kf8AYIrJeACQGMnQALAFGGmoAWDJSAGQBRhp+ABgOOnQABhpCABgphlkIeB4APAF4EgB0AJkISBu3LA74HgAkDrg0ACwF9qKOOl4AAoYaUgBqiBu3LAf6CBu3IAU4EgBkBnaijjpSAFKGGl4AKogbtz6kAeAAfpkIYAOpSHQAoYF5iGlIcUH8Afo5BvQnThgGGDaigqqvQDj+skAAPA4qMlJOJAhyUlAsBytnOLwF5g46Uk4SkpKSkpKOO2a4ikfAM2c4rARIODbhQO5AAAp/wPFA9ACOGAYYK8mAH4p/wDJCADwIskYAPAdyRkA8BjJGgDwE8kcAPAOyR0A8AnJHgDwBJyc4mClAclJQLBEOOlJOEpKSkpKSoUVr0kAfin/AAopHwCNmuKvWgB+Kf8AGgqNnOI6Ojo6hSGlFTjtmuIpHwDFIZALrZriOjopHwCNmuJg';
const generalMenuMarker=[71,77,83,49];
function installGeneralMenuSpacing(out) {
    clearEsperSpacing(out);
    for(const [at,before] of rowHooks) if(at>=0x30000) out.set(before,at);
    if(!out.subarray(0x3fd880,0x3ff000).every(v=>v===255)) throw failure('verifyFail');
    if(![0xa6,0,0x9b,0xc2,0x20].every((v,i)=>out[0x30300+i]===v)) throw failure('verifyFail');
    out.set(generalMenuMarker,0x3fd880);
    out.set(from64(menuRenderer),0x3fd900);
    out.set([0x5c,0,0xd9,0xff,0xea],0x30300);
}
function clearGeneralMenuSpacing(out) {
    if(!generalMenuMarker.every((v,i)=>out[0x3fd880+i]===v)) return;
    out.set([0xa6,0,0x9b,0xc2,0x20],0x30300);
    out.fill(255,0x3fd880,0x3ff000);
}

function cartridgeLayout(base,data,edition,names) {
    const layout=catalog.nameLayer.layouts[edition];
    const out=names?nameLayout(base,layout):base.slice();
    const backupSize=gbaFont.fontEnd-gbaFont.fontStart;
    const end=gbaFont.stash+backupSize+portableLength;
    if (!base.subarray(gbaFont.stash,end).every(byte=>byte===255)) throw failure('verifyFail');
    out.set(base.subarray(gbaFont.fontStart,gbaFont.fontEnd),gbaFont.stash);
    out.set(data,gbaFont.stash+backupSize);
    writeCartridgeFont(out,base,data,edition,names);
    installNameSpacing(out,data,edition,names);
    installEsperSpacing(out);
    installGeneralMenuSpacing(out);
    installDescriptionFont(out);
    installDefaultNames(out,base);
    installShadowFont(out,data,edition);
    writeChecksum(out);
    return out;
}
function restoreCartridge(raw,edition,names,prior=false,spaced=false,legacy=false) {
    const length=legacy?legacyPortableLength:portableLength;
    const size=gbaFont.fontEnd-gbaFont.fontStart;
    const data=raw.slice(gbaFont.stash+size,gbaFont.stash+size+length);
    const base=names?nameLayout(raw,catalog.nameLayer.layouts[edition],true):raw.slice();
    base.set(raw.subarray(gbaFont.stash,gbaFont.stash+size),gbaFont.fontStart);
    clearGeneralMenuSpacing(base);
    clearEsperSpacing(base);
    if (!prior) clearNameSpacing(base,spaced,legacy);
    clearMenuLabels(base);
    clearDescriptionFont(base);
    clearDefaultNames(base);
    clearShadowFont(base);
    base.fill(255,gbaFont.stash,gbaFont.stash+size+length);
    writeChecksum(base);
    return {base,data};
}
async function readCartridge(bytes) {
    if (bytes.length!==gbaFont.spec.size || await hash(bytes)!==gbaFont.donorHash) throw failure('badGba');
    return {cartridge:extractCartridge(bytes)};
}
