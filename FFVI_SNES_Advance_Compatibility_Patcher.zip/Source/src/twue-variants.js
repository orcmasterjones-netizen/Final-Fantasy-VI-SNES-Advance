// Primary TWUE 3.07 editions. Original patches stay external to the patcher.
// Music Player construction is handled separately by twue-music.js.
function twueVariantSelection(selection={}) {
    const variant=selection.variant||'base',music=selection.music||'none';
    const spec=catalog.twueVariants?.variants?.[variant];
    if(!spec || !['none','config1','config2','mainA','mainB'].includes(music))throw failure('twueFiles');
    const fixes=[...new Set(selection.fixes||[])].sort();
    if(fixes.some(id=>!['sfx','lete','caves'].includes(id)))throw failure('twueFiles');
    if((music==='mainA'&&!spec.bugfix)||(music==='mainB'&&spec.bugfix)||(music==='none'&&fixes.length))throw failure('twueFiles');
    return {variant,music,fixes};
}

async function readTWUEVariantSources(files,saved,selection={},family='twue') {
    const specs=catalog.twueVariants?.sources;
    if(!Array.isArray(specs))throw failure('twueFiles');
    return readTWUEFutureSources(files,saved,specs,selection,family);
}

async function constructTWUEVariantDonor(retail,sources,selection={}) {
    const chosen=twueVariantSelection(selection),meta=catalog.twueVariants;
    if(retail.length!==3145728||await hash(retail)!==meta.retailHash)throw failure('verifyFail');
    const variant=meta.variants[chosen.variant];
    const spec=meta.sources.find(s=>s.name===variant.source&&s.role==='primary');
    const patch=sources?.[spec?.name];
    if(!patch)throw failure('twueFiles');
    let donor;
    if(twuePatchFormat(patch)==='bps')donor=applyBPS(retail,patch);
    else{donor=new Uint8Array(4194304).fill(255);donor.set(retail);applyFutureIPS(donor,patch);}
    if(await hash(donor)!==variant.donorHash)throw failure('futureConflict');
    await validateTWUEDialogue(donor);
    return {donor,selection:chosen,source:spec.name,donorHash:variant.donorHash};
}

async function applyTWUEVariant(base,sources,selection={}) {
    const meta=catalog.twueVariants,inputHash=await hash(base);
    const normalize=meta.normalize||catalog.twue.normalize;
    if(normalize?.[inputHash]){
        base=base.slice();
        for(const [at,data]of normalize[inputHash])base.set(from64(data),at);
        writeChecksum(base);
    }
    if(await hash(base)!==meta.input)throw failure('twueLocked');
    const retail=base.slice(0,3145728);
    for(const [at,data]of await unpackPlan(meta.recovery||catalog.twue.recovery))retail.set(from64(data),at);
    const {donor,selection:chosen}=await constructTWUEVariantDonor(retail,sources,selection);
    const variant=meta.variants[chosen.variant];
    // Only completed, hash-verified compatibility plans enter the catalog.
    if(!variant.plan||!variant.target)throw failure('twueFiles');
    const out=base.slice(),[copies,fixes]=await unpackPlan(variant.plan);
    for(const [dest,src,n]of copies)out.set(donor.subarray(src,src+n),dest);
    for(const [at,data]of fixes)out.set(from64(data),at);
    writeChecksum(out);
    if(await hash(out)!==variant.target)throw failure('futureConflict');
    await validateTWUEDialogue(out);
    return out;
}
