// Shared provenance and version-independent intake. Payload equivalence is
// established separately by bounded decoders and edition-specific adapters.
const futurePatchDetails=new WeakMap();
const futureVerifiedVersions={rose:'2.04',twue:'3.07',music:'3.07',spanish:'1.15',multifont:'1.4.1',turn:'0.01',modern:'2.00',classic:'2.00',ctb:'2.00'};
function futureDeclaredVersion(name){
    const value=String(name||'').match(/(?:^|[\s_(\-])v(?:ersion)?[\s_-]*(\d+(?:[._-]\d+){0,2}[a-z]*)(?=$|[\s_).\-])/i)||
        String(name||'').match(/(?:^|[\s_(])(?:TWUE[\s_-]*|Multi_Fonts_)?(\d+(?:[._-]\d+){1,2}[a-z]*)(?=$|[\s_).\-])/i);
    return value?value[1].replace(/[._-]/g,'.').toLowerCase():null;
}
function futureCompareVersions(a,b){
    const x=String(a||'').replace(/[a-z]+$/i,'').split('.').map(Number),y=String(b||'').replace(/[a-z]+$/i,'').split('.').map(Number);
    for(let i=0;i<Math.max(x.length,y.length);i++){const n=(x[i]||0)-(y[i]||0);if(n)return Math.sign(n);}
    const sa=String(a||'').match(/[a-z]+$/i)?.[0]||'',sb=String(b||'').match(/[a-z]+$/i)?.[0]||'';
    return sa<sb?-1:sa>sb?1:0;
}
function futureLatestVersion(...versions){
    return versions.filter(v=>typeof v==='string'&&/^\d+(?:\.\d+){0,2}[a-z]*$/.test(v)).reduce((a,b)=>!a||futureCompareVersions(b,a)>0?b:a,null);
}
function futurePatchInfo(bytes){return futurePatchDetails.get(bytes)||null;}
function registerFuturePatch(bytes,meta={}){
    const family=meta.family,spec=meta.spec;
    if(!family||!spec?.name||!spec?.sha)throw failure('badFiles');
    const saved=typeof personal==='object'?personal.sourceInfo?.[family]?.[spec.name]:null;
    const declaredVersion=futureLatestVersion(meta.declaredVersion,futureDeclaredVersion(meta.name),
        meta.fromSaved&&saved?.declaredVersion);
    const verifiedVersion=meta.verifiedVersion||futureVerifiedVersions[family]||futureDeclaredVersion(spec.name);
    const originalSha=meta.fromSaved&&/^[a-f0-9]{64}$/.test(saved?.originalSha||'')?saved.originalSha:meta.originalSha||spec.sha;
    const warning=!!meta.warning||originalSha!==spec.sha||!!(declaredVersion&&(!verifiedVersion||futureCompareVersions(declaredVersion,verifiedVersion)>0))||
        !!(meta.fromSaved&&saved?.warning);
    const info={family,spec:spec.name,originalSha,declaredVersion,verifiedVersion:verifiedVersion||null,warning};
    futurePatchDetails.set(bytes,info);return bytes;
}
async function collectFuturePatchFiles(files,maxLimit=16*1024*1024){
    if(!files?.length||files.length>64)throw failure('badFiles');
    const result=[];let total=0,expanded=0;
    const push=member=>{expanded+=member.bytes.length;if(expanded>64*1024*1024||result.length>=256)throw failure('badFiles');result.push(member);};
    for(const file of files){
        if(file.size>maxLimit)throw failure('badFiles');
        const bytes=new Uint8Array(await file.arrayBuffer());total+=bytes.length;
        if(total>64*1024*1024)throw failure('badFiles');
        const containerName=String(file.name||''),outer=futureDeclaredVersion(containerName);
        if(bytes[0]===80&&bytes[1]===75){
            const members=await readPatchArchive(bytes,maxLimit);
            for(const member of members)push({name:member.basename||member.name,fullName:member.name,bytes:member.bytes,
                containerName,isArchive:true,declaredVersion:futureLatestVersion(outer,futureDeclaredVersion(member.basename||member.name))});
        }else push({name:containerName,fullName:containerName,bytes,containerName,isArchive:false,declaredVersion:outer});
    }
    if(result.length>256)throw failure('badFiles');
    return result;
}
function futureNeutralName(name){
    return String(name||'').split(/[\\/]/).pop().toLowerCase()
        .replace(/v(?:ersion)?[\s_-]*\d+(?:[._-]\d+){0,2}[a-z]*/g,'{version}')
        .replace(/multi_fonts_[\d._-]+/g,'multi_fonts_{version}_');
}
async function readFutureSourceSet(family,files,saved,specs,{allowDifferent=null,requireAll=true}={}){
    if(!Array.isArray(specs)||!specs.length)throw failure('badFiles');
    let candidates;
    if(files?.length)candidates=await collectFuturePatchFiles(files);
    else candidates=specs.filter(s=>saved?.[s.name]).map(spec=>{
        let bytes;try{bytes=from64(saved[spec.name]);}catch{throw failure('badPersonal');}
        return {name:spec.name,bytes,fromSaved:true,savedSpec:spec,declaredVersion:personal.sourceInfo?.[family]?.[spec.name]?.declaredVersion};
    });
    const entries={};
    for(const candidate of candidates){
        const originalSha=await rawHash(candidate.bytes);
        let spec=specs.find(s=>s.sha===originalSha),body=spec?candidate.bytes:null;
        if(!spec&&String.fromCharCode(...candidate.bytes.subarray(0,5))==='PATCH'){
            const matches=[];
            for(const choice of candidate.savedSpec?[candidate.savedSpec]:specs){
                const normalized=await normalizeFutureIPS(candidate.bytes,choice);
                if(normalized)matches.push([choice,normalized]);
            }
            if(matches.length>1)throw failure('futureAmbiguous');
            if(matches.length)[spec,body]=matches[0];
        }
        if(!spec){
            const named=specs.filter(s=>futureNeutralName(s.name)===futureNeutralName(candidate.name));
            const proposed=candidate.savedSpec||named.length===1&&named[0]||!candidate.isArchive&&specs.length===1&&specs[0];
            if(!proposed){if(candidate.isArchive)continue;throw failure('futureConflict');}
            if(!allowDifferent||!await allowDifferent(candidate.bytes,proposed))throw failure('futureConflict');
            spec=proposed;body=candidate.bytes;
        }
        if(entries[spec.name])throw failure('futureAmbiguous');
        entries[spec.name]=registerFuturePatch(body,{family,spec,originalSha,name:candidate.name,
            declaredVersion:candidate.declaredVersion,fromSaved:candidate.fromSaved,warning:originalSha!==spec.sha});
    }
    if(!Object.keys(entries).length)throw failure('futureConflict');
    if(requireAll)for(const spec of specs)if(!entries[spec.name])throw new Error(t('missing')+' '+spec.name);
    return entries;
}
function futureMetadataForSources(sources={}){
    const result={};
    for(const [family,entries]of Object.entries(sources))for(const [name,bytes]of Object.entries(entries||{})){
        const info=futurePatchInfo(bytes);if(!info)continue;
        (result[family]??={})[name]={originalSha:info.originalSha,declaredVersion:info.declaredVersion,
            verifiedVersion:info.verifiedVersion,warning:info.warning};
    }
    return result;
}
function futureWarningsForSources(sources={}){
    return Object.values(futureMetadataForSources(sources)).flatMap(x=>Object.values(x)).some(x=>x.warning);
}
function futureEditionFamily(profile){
    return profile.edition==='rose'?'rose':profile.edition==='twue'?'twue':profile.edition==='spanish'||profile.options?.includes('spanish')?'spanish':null;
}
async function futureInfoForROM(bytes,profile){
    const family=futureEditionFamily(profile);
    if(family==='rose'&&typeof roseFutureInfo==='function')return roseFutureInfo(bytes);
    if(family==='twue'&&typeof twueFutureInfo==='function')return twueFutureInfo(bytes,profile);
    if(family==='spanish'&&typeof spanishFutureInfo==='function')return spanishFutureInfo(bytes);
    return null;
}
async function identifyV14(file){
    const input=await identifyMolemanLayer(file);
    const raw=new Uint8Array(await file.arrayBuffer()),size=input.profile.edition==='rose'?0x800000:0x400000;
    const info=await futureInfoForROM(raw.slice(-size),input.profile);
    if(!info)return input;
    return {...input,futureRevision:info,profile:{...input.profile,futureUntested:!!info.untested}};
}
async function combineV14(input,selected,sources={},settings={}){
    const output=await combineMolemanLayer(input,selected,sources,settings);
    const info=await futureInfoForROM(output.bytes,output.profile);
    const futureUntested=!!info?.untested||futureWarningsForSources(sources);
    return {...output,id:await rawHash(output.bytes),profile:{...output.profile,futureUntested},futureRevision:info};
}

// v1.5 relocates the two remaining battle-menu reads of the first Lore record.
// Older adapters are authenticated against the original, reversible ROM layout.
const loreReadSites = [[0x158f7,0x6d,0x3d],[0x18306,0x6b,0x3b]];
function hasLoreReads(bytes, corrected) {
    return loreReadSites.every(([at,old,next]) =>
        bytes[at] === 0xbd && bytes[at+1] === (corrected ? next : old) && bytes[at+2] === 0x21);
}
function changeLoreReads(bytes, reverse=false) {
    if (![0x400000,0x800000].includes(bytes.length) || !hasLoreReads(bytes,reverse))
        throw new Error('The battle-menu code does not match the expected version.');
    const result=bytes.slice();
    for (const [at,old,next] of loreReadSites) result[at+1]=reverse ? old : next;
    if(result.length===0x800000) writeROSEChecksum(result);
    else writeChecksum(result);
    return result;
}

async function identify(file) {
    if (![0x400000,0x400200,0x800000,0x800200].includes(file.size)) return identifyV14(file);
    const header=file.size % 0x100000;
    const bytes=new Uint8Array(await file.arrayBuffer()).subarray(header===512 ? 512 : 0);
    const corrected=hasLoreReads(bytes,true);
    let source=file;
    if (corrected) {
        const previous=changeLoreReads(bytes,true);
        const roundTrip=changeLoreReads(previous);
        if (!roundTrip.every((v,i)=>v===bytes[i])) throw failure('verifyFail');
        source=new File([previous],file.name);
    }
    const input=await identifyV14(source);
    return {...input,previousUpgrade:input.upgrade,upgrade:!!input.upgrade || !corrected};
}
async function combine(input,selected,sources={},settings={}) {
    const legacy=await combineV14({...input,upgrade:input.previousUpgrade},selected,sources,settings);
    const bytes=changeLoreReads(legacy.bytes);
    return {...legacy,bytes,id:await rawHash(bytes)};
}
