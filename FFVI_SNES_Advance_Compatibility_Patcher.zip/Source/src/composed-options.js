// Optional layers unwind in reverse installation order. Only known hashes enter
// their decoders; each decoder also verifies its original-source and base hashes.
const musicKey=(placement,fixes=[])=>placement+'|'+[...new Set(fixes)].sort().join(',');
function fontStyle(profile) {
    return profile.options.includes('multifont')?'multifont':profile.cartridge?'cartridge':profile.options.includes('font')?'legacy':'native';
}
async function identifyComposed(file) {
    if([0x800000,0x800200].includes(file.size))return identifyPolished(file);
    if(![0x400000,0x400200].includes(file.size))throw failure('wrongSize');
    const raw=new Uint8Array(await file.arrayBuffer());let bytes=raw.slice(-0x400000),id=await hash(bytes);
    const known=h=>catalog.multiFont?.inputs[h]||catalog.musicLayer?.inputs[h];
    if(!known(id)){const check=bytes.slice();writeChecksum(check);const h=await hash(check);if(known(h)){bytes=check;id=h;}}
    let multi=null,music=null;
    const m=catalog.multiFont?.inputs[id];
    if(m){multi=await restoreMultiFont(bytes);bytes=multi.base;id=await hash(bytes);if(id!==m.base)throw failure('verifyFail');}
    const p=catalog.musicLayer?.inputs[id];
    if(p){music=await restoreTWUEMusic(bytes);if(!music||await hash(music.base)!==p.base||musicKey(music.placement,music.fixes)!==musicKey(p.placement,p.fixes))throw failure('verifyFail');bytes=music.base;}
    const input=await identifyPolished(new File([bytes],file.name));
    const profile={...input.profile,options:[...input.profile.options]};
    if(multi)profile.options.push('multifont');
    if(music){
        if(profile.edition!=='twue'||profile.twueVersion!=='307'||(profile.twueVariant||'base')!==music.profile.twueVariant)throw failure('verifyFail');
        profile.options.push('music');profile.music=music.placement;profile.musicFixes=music.fixes;
    }
    return {...input,profile,multiFontPatch:multi?.patch,musicSources:music?.sources};
}
async function combineComposed(input,selected,sources={},settings={}) {
    selected=new Set(selected);
    if(input.profile.edition==='rose'||selected.has('rose')) {
        if(selected.has('multifont')||selected.has('music'))throw failure('roseUnsupported');
        return combinePolished(input,selected,sources,settings);
    }
    const style=settings.fontStyle||(selected.has('multifont')?'multifont':selected.has('font')||selected.has('names')?(sources.font?.cartridge||input.directData?'cartridge':'legacy'):'native');
    if(!['native','legacy','cartridge','multifont'].includes(style)||(style==='multifont'&&selected.has('names')))throw failure('badFiles');
    const raw=catalog.builds[input.id];
    if(!raw)throw failure('unknown');
    if(raw.options.includes('font')&&['native','multifont'].includes(style))throw failure('nativeFontRequired');
    const wantsTWUE=raw.edition==='twue'||selected.has('twue');
    const variant=settings.variant||raw.twueVariant||'base';
    if(raw.edition==='twue'&&variant!==(raw.twueVariant||'base'))throw failure('variantLocked');
    const primary=catalog.twueVariants?.variants?.[variant];
    const variantSource=raw.edition!=='twue'&&wantsTWUE&&!!sources.twue?.[primary?.source];
    if(raw.edition!=='twue'&&wantsTWUE&&variant!=='base'&&!variantSource)throw failure('twueFiles');
    const placement=selected.has('music')?(settings.music||input.profile.music||'config2'):'none';
    if(selected.has('music')&&!['config1','config2','mainA','mainB'].includes(placement))throw failure('twueFiles');
    const fixes=placement==='none'?[]:(settings.fixes||input.profile.musicFixes||[]);
    if(placement!=='none')twueVariantSelection({variant,music:placement,fixes});
    const innerSelected=new Set([...selected].filter(x=>!['music','multifont','font','names'].includes(x)));
    if(['legacy','cartridge'].includes(style))innerSelected.add('font');
    if(selected.has('names'))innerSelected.add('names');
    const inner={...input,profile:{...input.profile,options:input.profile.options.filter(x=>!['music','multifont','font','names'].includes(x))}};
    inner.profile.options=[...new Set([...inner.profile.options,...raw.options.filter(x=>['font','names'].includes(x))])];
    inner.directData=style==='cartridge'?input.directData:undefined;
    inner.needsBattleDonor=style==='cartridge'&&input.needsBattleDonor;
    const innerSources={...sources};if(style!=='cartridge'&&style!=='legacy')delete innerSources.font;
    let output=await combinePolished(inner,innerSelected,innerSources,{...settings,variant,variantSource});
    if(placement!=='none') {
        if(output.profile.edition!=='twue'||output.profile.twueVersion!=='307')throw failure('twueFiles');
        const source={...input.musicSources,...sources.twue,...sources.music};
        const bytes=await applyTWUEMusic(output.bytes,output.profile,source,placement,fixes),id=await hash(bytes);
        if(catalog.musicLayer?.targets[output.id]?.[musicKey(placement,fixes)]!==id)throw failure('verifyFail');
        output={...output,bytes,id,profile:{...output.profile,options:[...output.profile.options,'music'],music:placement,musicFixes:[...new Set(fixes)].sort()}};
    }
    if(style==='multifont') {
        const patch=sources.multifont?.[multiFontSpec.name]||input.multiFontPatch;
        const bytes=await applyMultiFont(output.bytes,patch,cartridgeEdition(output.profile)),id=await hash(bytes);
        if(catalog.multiFont?.targets[output.id]!==id)throw failure('verifyFail');
        output={...output,bytes,id,profile:{...output.profile,options:[...output.profile.options,'multifont']}};
    }
    return output;
}
