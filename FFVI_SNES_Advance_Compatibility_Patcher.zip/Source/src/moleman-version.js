// Version-independent MoleMan entry and an outer, reversible v1.8 data layer.
// No original translation patch or dialogue is bundled. Unknown donors must
// retain the verified executable/layout; only bounded main dialogue can vary.
const molemanPatchMetadata=new WeakMap();
const molemanMergedDataEdits=[[0x0f2334,0xee,0xce],[0x382334,0xee,0xce],
    [0x0fc7e6,0xfe,0xc5],[0x385382,0xfe,0xc5]];
function molemanPatchInfo(bytes){return molemanPatchMetadata.get(bytes)||{warning:true,knownVersion:null,declaredVersion:null};}
function molemanVersionFromName(name){
    return String(name||'').match(/(?:^|[\s_(-])v(\d+(?:[._-]\d+){0,2}[a-z]*)(?=$|[\s_).(-])/i)?.[1]?.replace(/[._-]/g,'.').toLowerCase()||null;
}
function molemanAboveVerified(version){
    if(!version)return false;
    const parts=version.replace(/[a-z]+$/i,'').split('.').map(Number),last=[1,8,0];
    for(let i=0;i<Math.max(parts.length,last.length);i++){
        const a=parts[i]||0,b=last[i]||0;if(a!==b)return a>b;
    }
    return /[a-z]+$/i.test(version);
}
async function molemanRegisterPatch(bytes,name='',savedVersion=null){
    const config=retailBaseData.molemanVersions;
    if(!(bytes instanceof Uint8Array)||bytes.length<19||bytes.length>3*1024*1024||
        String.fromCharCode(...bytes.subarray(0,4))!=='BPS1')throw failure('retailMolemanInvalid');
    const sha=await rawHash(bytes);
    if(config.alternates.includes(sha)||/minus[\s_-]*pop[\s_-]*culture/i.test(name))throw failure('retailMolemanAlternate');
    const knownVersion=config.patches[sha]||null;
    const declaredVersion=molemanAboveVerified(savedVersion)?savedVersion:molemanVersionFromName(name)||savedVersion||null;
    const warning=!knownVersion||molemanAboveVerified(declaredVersion);
    molemanPatchMetadata.set(bytes,{sha,knownVersion,declaredVersion,warning});
    return bytes;
}
async function extractMolemanZIP(bytes){
    const bad=()=>failure('badZip');
    if(bytes.length<22||bytes.length>3*1024*1024)throw bad();
    const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
    const u16=i=>view.getUint16(i,true),u32=i=>view.getUint32(i,true);
    let end=bytes.length-22;
    const floor=Math.max(0,bytes.length-65557);
    while(end>=floor&&(u32(end)!==0x06054b50||end+22+u16(end+20)!==bytes.length))end--;
    if(end<floor||u16(end+4)||u16(end+6)||u16(end+8)!==u16(end+10)||u16(end+10)>256)throw bad();
    const central=u32(end+16),centralSize=u32(end+12);
    if(central+centralSize!==end)throw bad();
    let pos=central;const candidates=[];
    for(let n=0;n<u16(end+10);n++){
        if(pos+46>end||u32(pos)!==0x02014b50)throw bad();
        const next=pos+46+u16(pos+28)+u16(pos+30)+u16(pos+32);
        if(next>end||u16(pos+34))throw bad();
        const fullName=new TextDecoder().decode(bytes.subarray(pos+46,pos+46+u16(pos+28)));
        const name=fullName.split(/[\\/]/).pop();
        if(/\.bps$/i.test(name)&&!/minus[\s_-]*pop[\s_-]*culture/i.test(name)){
            const size=u32(pos+24),compressed=u32(pos+20),loc=u32(pos+42),method=u16(pos+10),flags=u16(pos+8),crc=u32(pos+16);
            if(size<19||size>3*1024*1024||compressed>3*1024*1024||flags&1||![0,8].includes(method)||
                loc+30>central||u32(loc)!==0x04034b50||u16(loc+6)!==flags||u16(loc+8)!==method)throw bad();
            const start=loc+30+u16(loc+26)+u16(loc+28);
            if(start+compressed>central)throw bad();
            const localName=new TextDecoder().decode(bytes.subarray(loc+30,loc+30+u16(loc+26)));
            if(localName!==fullName)throw bad();
            candidates.push({name,size,crc,method,start,compressed});
        }
        pos=next;
    }
    if(pos!==end)throw bad();
    if(candidates.length!==1)throw failure(candidates.length?'molemanAmbiguous':'retailMolemanRequired');
    const spec=candidates[0],chunk=bytes.subarray(spec.start,spec.start+spec.compressed);
    let out;
    if(spec.method===0){if(chunk.length!==spec.size)throw bad();out=chunk.slice();}
    else{
        if(!globalThis.DecompressionStream)throw failure('browser');
        try{
            const reader=new Blob([chunk]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
            out=new Uint8Array(spec.size);let used=0;
            for(;;){const {value,done}=await reader.read();if(done)break;
                if(used+value.length>out.length){await reader.cancel();throw bad();}out.set(value,used);used+=value.length;}
            if(used!==out.length)throw bad();
        }catch{throw bad();}
    }
    if(retailBaseMerger.crc32(out)!==spec.crc)throw bad();
    return {bytes:out,name:spec.name};
}
async function readMolemanPatch(files=[],saved,savedVersion=null){
    if(files.length>1)throw failure('retailMolemanInvalid');
    if(!files.length){
        if(typeof saved!=='string'||!saved)throw failure('retailMolemanRequired');
        let bytes;try{bytes=from64(saved);}catch{throw failure('badPersonal');}
        return molemanRegisterPatch(bytes,'',savedVersion);
    }
    const file=files[0];if(file.size>3*1024*1024)throw failure('retailMolemanInvalid');
    let bytes=new Uint8Array(await file.arrayBuffer()),name=file.name;
    if(bytes[0]===80&&bytes[1]===75){
        const member=await extractMolemanZIP(bytes);bytes=member.bytes;
        const outer=molemanVersionFromName(name),inner=molemanVersionFromName(member.name);
        name=member.name;if(molemanAboveVerified(outer))savedVersion=outer;
        if(!inner&&outer)savedVersion=outer;
    }
    const registered=await molemanRegisterPatch(bytes,name,savedVersion);
    // An archive advertising a newer version must not hide its warning behind
    // a recognized older member name.
    if(molemanAboveVerified(savedVersion))molemanPatchMetadata.get(bytes).warning=true;
    return registered;
}
async function normalizeMolemanDonor(donor){
    if(donor.length!==0x400000)throw failure('molemanLayout');
    const expected=retailBaseData.mergerHashes.translated;
    if(await hash(donor)===expected){validateMolemanDialogue(donor);return {bytes:donor,revision18:false};}
    const edits=[[0x1936a,[0x1b,0xd7],[0x7c,0x25]],
        [0x193c6,[0x1b,0xd7],[0x7c,0x25]],[0xf2334,[0xee],[0xce]],[0xfc7e6,[0xfe],[0xc5]]];
    const normalized=donor.slice();
    for(const [at,before,after]of edits){
        if(!after.every((v,i)=>normalized[at+i]===v))throw failure('molemanLayout');
        normalized.set(before,at);
    }
    writeChecksum(normalized);
    if(await hash(normalized)!==expected)throw failure('molemanLayout');
    validateMolemanDialogue(normalized);
    return {bytes:normalized,revision18:true};
}
function restoreMolemanData(bytes,revision18,reverse=false){
    if(!revision18)return bytes;
    if(bytes.length!==0x400000)throw failure('molemanLayout');
    const out=bytes.slice();
    for(const [at,before,after]of molemanMergedDataEdits){
        if(out[at]!== (reverse?after:before))throw failure('molemanLayout');
        out[at]=reverse?before:after;
    }
    writeChecksum(out);return out;
}
async function molemanROMInfo(bytes){
    const newer=molemanMergedDataEdits.every(([at,before,after])=>bytes[at]===after);
    const normalized=restoreMolemanData(bytes,newer,true);
    const parts=molemanDialogueMask.filter(([a])=>a!==0xffdc),data=new Uint8Array(parts.reduce((n,[a,b])=>n+b-a,0));
    let pos=0;for(const [a,b]of parts){data.set(normalized.subarray(a,b),pos);pos+=b-a;}
    const textHash=await rawHash(data),config=retailBaseData.molemanVersions;
    const version=newer&&textHash===config.textHashes['1.8']?'1.8':!newer&&textHash===config.textHashes['1.6']?'1.6':null;
    return {bytes:normalized,revision18:newer,version,untested:!version,textHash};
}
function molemanProfile(profile,info){return {...profile,molemanVersion:info.version,molemanUntested:info.untested,molemanRevision18:info.revision18};}
async function identifyMolemanLayer(file){
    if(![0x400000,0x400200].includes(file.size))return identifyLegacy(file);
    const raw=new Uint8Array(await file.arrayBuffer()),bytes=raw.slice(-0x400000);
    let input,info;
    // Try every pre-existing edition unchanged before testing the new outer
    // layer. Other translations can coincidentally share individual data bytes.
    try{input=await identifyLegacy(file);}catch(error){
        info=await molemanROMInfo(bytes);
        if(!info.revision18)throw error;
        input=await identifyLegacy(new File([info.bytes],file.name));
    }
    if(input.profile.edition!=='moleman')return input;
    info=info||await molemanROMInfo(bytes);
    validateMolemanDialogue(info.bytes);
    return {...input,profile:molemanProfile(input.profile,info),molemanLayer:info};
}
async function combineMolemanLayer(input,selected,sources={},settings={}){
    const output=await combineLegacy(input,selected,sources,settings);
    if(input.profile.edition!=='moleman')return output;
    const info=input.molemanLayer||await molemanROMInfo(input.bytes);
    for(const [a,b]of molemanDialogueMask)if(a!==0xffdc){
        if(!input.bytes.subarray(a,b).every((v,i)=>output.bytes[a+i]===v))throw failure('molemanLayout');
    }
    const bytes=restoreMolemanData(output.bytes,info.revision18);
    validateMolemanDialogue(bytes);
    return {...output,bytes,id:await rawHash(bytes),profile:molemanProfile(output.profile,info)};
}
