// Version-independent patch-file intake. Public descriptors contain only IPS
// record geometry; every payload byte is recovered from the user's own file.
// Equivalent IPS files are reconstructed before record-sensitive adapters run.
function futureInputError(kind,detail){
    const error=new Error('Invalid '+kind+' patch input'+(detail?': '+detail:'.'));
    error.code=kind==='ZIP'?'futureBadZip':'futureBadIPS';return error;
}
function decodeFutureIPS(bytes,{maxAddress=0x800200,maxRecords=100000}={}){
    const fail=detail=>{throw futureInputError('IPS',detail);};
    if(!(bytes instanceof Uint8Array)||bytes.length<8||bytes.length>16*1024*1024||
        String.fromCharCode(...bytes.subarray(0,5))!=='PATCH')fail('missing or oversized IPS header');
    if(!Number.isSafeInteger(maxAddress)||maxAddress<=0||maxAddress>0x1000200||
        !Number.isSafeInteger(maxRecords)||maxRecords<=0||maxRecords>100000)fail('decoder bounds');
    const values=new Uint8Array(maxAddress),present=new Uint8Array(maxAddress),records=[];
    let position=5,uniqueBytes=0,totalWrites=0,highestEnd=0,truncate=null,ended=false;
    while(position+3<=bytes.length){
        if(bytes[position]===69&&bytes[position+1]===79&&bytes[position+2]===70){
            position+=3;ended=true;break;
        }
        if(records.length>=maxRecords||position+5>bytes.length)fail('record count or truncated record');
        const offset=bytes[position]*65536+bytes[position+1]*256+bytes[position+2];
        const literalLength=bytes[position+3]*256+bytes[position+4];position+=5;
        let length=literalLength,data,rle=false;
        if(length){
            if(position+length>bytes.length)fail('truncated literal');
            data=bytes.subarray(position,position+length);position+=length;
        }else{
            if(position+3>bytes.length)fail('truncated run');
            length=bytes[position]*256+bytes[position+1];
            if(!length)fail('empty run');
            data=bytes.subarray(position+2,position+3);position+=3;rle=true;
        }
        if(offset+length>maxAddress)fail('write outside supported ROM size');
        totalWrites+=length;
        if(totalWrites>32*1024*1024)fail('excessive repeated writes');
        for(let i=offset;i<offset+length;i++)if(!present[i]){present[i]=1;uniqueBytes++;}
        if(rle)values.fill(data[0],offset,offset+length);else values.set(data,offset);
        records.push({offset,length,rle,data});highestEnd=Math.max(highestEnd,offset+length);
    }
    if(!ended)fail('missing EOF marker');
    if(bytes.length-position===3){
        truncate=bytes[position]*65536+bytes[position+1]*256+bytes[position+2];position+=3;
        if(truncate>maxAddress)fail('truncation outside supported ROM size');
    }
    if(position!==bytes.length)fail('trailing bytes after EOF');
    return {values,image:values,present,records,truncate,uniqueBytes,totalWrites,highestEnd};
}
function applyFutureIPS(target,patch){
    if(!(target instanceof Uint8Array)||!target.length)throw futureInputError('IPS','invalid target image');
    // Validate the entire file before changing any target byte. A truncation
    // footer may confirm this exact size, but cannot resize the caller's ROM.
    const input=patch?.buffer===target.buffer?patch.slice():patch;
    const decoded=decodeFutureIPS(input,{maxAddress:target.length});
    if(decoded.truncate!==null&&decoded.truncate!==target.length)throw futureInputError('IPS','target-size change is unsupported');
    for(const {offset,length,rle,data}of decoded.records){
        if(rle)target.fill(data[0],offset,offset+length);else target.set(data,offset);
    }
    return target;
}
async function normalizeFutureIPS(bytes,spec,descriptor){
    if(!spec||typeof spec.sha!=='string'||!Number.isSafeInteger(spec.size))throw futureInputError('IPS','unknown canonical specification');
    if(await rawHash(bytes)===spec.sha)return bytes;
    descriptor=descriptor||(typeof catalog!=='undefined'?catalog.futureInputs?.ips?.[spec.sha]:null);
    if(!descriptor)return null;
    const decoded=decodeFutureIPS(bytes,{maxAddress:descriptor.maxAddress});
    if(decoded.truncate!==(descriptor.truncate??null)||decoded.uniqueBytes!==descriptor.uniqueBytes)return null;
    const canonical=new Uint8Array(spec.size);canonical.set([80,65,84,67,72]);let position=5;
    for(const record of descriptor.records){
        const [offset,length,rle]=record;
        if(!Number.isSafeInteger(offset)||!Number.isSafeInteger(length)||offset<0||length<=0||length>65535||
            offset+length>decoded.values.length||![0,1].includes(rle))throw futureInputError('IPS','invalid canonical layout');
        if(decoded.present.subarray(offset,offset+length).some(v=>v!==1))return null;
        const needed=rle?8:5+length;
        if(position+needed>canonical.length)throw futureInputError('IPS','invalid canonical size');
        canonical.set([offset>>>16&255,offset>>>8&255,offset&255,rle?0:length>>>8,rle?0:length&255],position);position+=5;
        if(rle){
            const value=decoded.values[offset];
            if(decoded.values.subarray(offset,offset+length).some(v=>v!==value))return null;
            canonical.set([length>>>8,length&255,value],position);position+=3;
        }else{canonical.set(decoded.values.subarray(offset,offset+length),position);position+=length;}
    }
    if(position+3+(decoded.truncate===null?0:3)!==canonical.length)throw futureInputError('IPS','invalid canonical footer');
    canonical.set([69,79,70],position);position+=3;
    if(decoded.truncate!==null)canonical.set([decoded.truncate>>>16&255,decoded.truncate>>>8&255,decoded.truncate&255],position);
    // This simultaneously checks that no changed payload was accepted and that
    // record geometry matches the historical file required by the adapters.
    return await rawHash(canonical)===spec.sha?canonical:null;
}

const futureInputCRCTable=Uint32Array.from({length:256},(_,n)=>{
    for(let bit=0;bit<8;bit++)n=(n>>>1)^((n&1)?0xedb88320:0);return n>>>0;
});
function futureInputCRC32(bytes){let crc=0xffffffff;for(const byte of bytes)crc=(crc>>>8)^futureInputCRCTable[(crc^byte)&255];return (crc^0xffffffff)>>>0;}
async function readPatchArchive(bytes,maxLimit=16*1024*1024){
    const fail=detail=>{throw futureInputError('ZIP',detail);};
    if(!(bytes instanceof Uint8Array)||!Number.isSafeInteger(maxLimit)||maxLimit<22||maxLimit>32*1024*1024||
        bytes.length<22||bytes.length>maxLimit)fail('archive size');
    const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),u16=i=>view.getUint16(i,true),u32=i=>view.getUint32(i,true);
    let end=bytes.length-22;const floor=Math.max(0,bytes.length-65557);
    while(end>=floor&&(u32(end)!==0x06054b50||end+22+u16(end+20)!==bytes.length))end--;
    if(end<floor||u16(end+4)||u16(end+6)||u16(end+8)!==u16(end+10)||u16(end+10)>512)fail('unsupported or invalid directory');
    const count=u16(end+10),central=u32(end+16),centralSize=u32(end+12);
    if(central+centralSize!==end||central>end)fail('directory extent');
    let position=central,totalSize=0;const members=[],names=new Set(),extents=[];
    for(let index=0;index<count;index++){
        if(position+46>end||u32(position)!==0x02014b50)fail('truncated directory');
        const nameSize=u16(position+28),next=position+46+nameSize+u16(position+30)+u16(position+32);
        if(next>end||u16(position+34))fail('invalid directory entry');
        const name=new TextDecoder().decode(bytes.subarray(position+46,position+46+nameSize));
        const clean=name.replace(/\\/g,'/'),basename=clean.split('/').pop();
        if(/\.(?:ips|bps)$/i.test(basename)&&!clean.startsWith('__MACOSX/')&&!basename.startsWith('._')){
            if(!nameSize||name.includes('\0')||clean.startsWith('/')||/^[A-Za-z]:/.test(clean)||clean.split('/').some(p=>p==='..'))fail('invalid member path');
            const identity=clean.toLowerCase();if(names.has(identity))fail('duplicate patch member');names.add(identity);
            if(members.length>=128)fail('too many patch members');
            const flags=u16(position+8),method=u16(position+10),crc=u32(position+16),compressed=u32(position+20),size=u32(position+24),local=u32(position+42);
            if(flags&1||![0,8].includes(method)||size<8||size>maxLimit||compressed>maxLimit||totalSize+size>maxLimit||
                local+30>central||u32(local)!==0x04034b50||u16(local+6)!==flags||u16(local+8)!==method)fail('unsupported member encoding or size');
            const start=local+30+u16(local+26)+u16(local+28),stop=start+compressed;
            if(start>central||stop>central)fail('member extent');
            const localName=new TextDecoder().decode(bytes.subarray(local+30,local+30+u16(local+26)));
            if(localName!==name)fail('member-name disagreement');
            if(!(flags&8)&&(u32(local+14)!==crc||u32(local+18)!==compressed||u32(local+22)!==size))fail('member-header disagreement');
            if(extents.some(([a,b])=>local<b&&stop>a))fail('overlapping patch members');extents.push([local,stop]);
            totalSize+=size;members.push({name,basename,start,compressed,size,method,crc});
        }
        position=next;
    }
    if(position!==end)fail('directory length');
    const result=[];
    for(const member of members){
        const chunk=bytes.subarray(member.start,member.start+member.compressed);let unpacked;
        if(member.method===0){if(chunk.length!==member.size)fail('stored member length');unpacked=chunk.slice();}
        else{
            if(!globalThis.DecompressionStream)throw new Error('This browser cannot decompress the patch ZIP. Extract and select the patch file instead.');
            try{
                const reader=new Blob([chunk]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
                unpacked=new Uint8Array(member.size);let used=0;
                for(;;){const {value,done}=await reader.read();if(done)break;
                    if(used+value.length>unpacked.length){await reader.cancel();fail('expanded member length');}
                    unpacked.set(value,used);used+=value.length;
                }
                if(used!==unpacked.length)fail('expanded member length');
            }catch(error){if(error?.code==='futureBadZip')throw error;fail('decompression failed');}
        }
        if(futureInputCRC32(unpacked)!==member.crc)fail('member CRC');
        result.push({name:member.name,basename:member.basename,bytes:unpacked});
    }
    return result;
}
