// Checked future TWUE sources. The public data contains fingerprints and record
// layouts only; original translation/music patch payloads remain user-supplied.
const twueDialogueMask=Object.freeze([[0xffdc,0xffe0],[0xce602,0xcfe1a],[0xd0000,0xef236]].map(Object.freeze));
async function twueDialogueFingerprint(bytes,rawDigest){
    if(bytes.length!==0x400000)return null;
    const masked=bytes.slice();for(const[a,b]of twueDialogueMask)masked.fill(0,a,b);
    return rawDigest(masked);
}
function twueKnownRawIdentity(id){
    return !!(catalog.builds[id]||catalog.aliases[id]||catalog.nameLayer?.toBase[id]||
        catalog.atb?.inputs[id]||catalog.menuPolish?.inputs[id]||catalog.musicLayer?.inputs[id]||
        catalog.multiFont?.inputs[id]||cartridgeInputs.has(id));
}
async function twueDialogueAlias(bytes,actualId,rawDigest){
    if(bytes.length!==0x400000||twueKnownRawIdentity(actualId))return actualId;
    const aliases=catalog.twueFuture?.aliases||{},fp=await twueDialogueFingerprint(bytes,rawDigest);
    if(!Object.prototype.hasOwnProperty.call(aliases,fp))return actualId;
    await validateTWUEDialogue(bytes);return aliases[fp];
}
async function validateTWUEDialogue(bytes){
    if(bytes.length!==0x400000)throw failure('futureConflict');
    const first=0xd0000,last=0xef236,count=3084;
    const threshold=bytes[0xce600]|bytes[0xce601]<<8;
    if(![1592,1589].includes(threshold))throw failure('futureConflict');
    const ends=new Uint32Array(last-first+2);
    for(let i=last-first-1;i>=0;i--){
        const b=bytes[first+i];
        if(b===0)ends[i]=first+i+1;
        else if([0x11,0x14,0x16].includes(b)){if(i+1<last-first)ends[i]=ends[i+2];}
        else ends[i]=ends[i+1];
    }
    let longest=0,used=first,total=0;const rows=[],starts=[],parameters=new Set();
    for(let i=0;i<count;i++){
        const at=0xce602+2*i,start=(i<threshold?0xd0000:0xe0000)+(bytes[at]|bytes[at+1]<<8);
        if(start<first||start>=last)throw failure('futureConflict');
        const end=ends[start-first];
        if(!end||end-start>65536)throw failure('futureConflict');
        longest=Math.max(longest,end-start);used=Math.max(used,end);starts.push(start);
        const row=[];let glyph=false;
        for(let p=start;p<end;){
            if(++total>0x100000)throw failure('futureConflict');
            const code=bytes[p++];
            if(code<0x20){
                row.push(code);glyph=false;
                if([0x11,0x14,0x16].includes(code)){
                    if(p>=end)throw failure('futureConflict');
                    parameters.add(p);row.push(bytes[p++]);total++;
                }
            }else if(!glyph){row.push(256);glyph=true;}
        }
        rows.push(row);
    }
    if(starts.some(p=>parameters.has(p)))throw failure('futureConflict');
    const controls=await rawHash(new TextEncoder().encode(JSON.stringify(rows)));
    if(controls!==catalog.twueFuture?.controls?.[threshold])throw failure('futureConflict');
    return {count,threshold,longest,lastUsed:used,freeBytes:last-used};
}
async function twueFutureInfo(bytes,profile){
    if(bytes.length!==0x400000)return null;
    if(profile?.twueVersion&&profile.twueVersion!=='307')return {untested:false,version:profile.twueVersion};
    const parts=twueDialogueMask.filter(([a])=>a!==0xffdc),data=new Uint8Array(parts.reduce((n,[a,b])=>n+b-a,0));
    let at=0;for(const[a,b]of parts){data.set(bytes.subarray(a,b),at);at+=b-a;}
    const textHash=await rawHash(data),untested=!(catalog.twueFuture?.textHashes||[]).includes(textHash);
    return {untested,version:untested?null:'3.07',textHash};
}
function twueCanonicalChecksum(bytes){
    // Music metadata retains an undo image. Normalize its checksum fields to
    // the tested text so dialogue revisions do not change that private schema.
    // Only sums are catalogued; no original translation text is bundled.
    const threshold=bytes[0xce600]|bytes[0xce601]<<8;
    const known=catalog.twueFuture?.dialogueSums?.[threshold];
    if(!Number.isSafeInteger(known))return bytes.slice(0xffdc,0xffe0);
    let actual=0;for(const[a,b]of twueDialogueMask)if(a!==0xffdc)for(let p=a;p<b;p++)actual+=bytes[p];
    const sum=((bytes[0xffde]|bytes[0xffdf]<<8)+known-actual)&65535;
    return Uint8Array.of((sum^65535)&255,(sum^65535)>>>8,sum&255,sum>>>8);
}
function twuePatchFormat(bytes){
    const magic=String.fromCharCode(...bytes.subarray(0,5));
    if(magic==='PATCH')return 'ips';
    if(magic.slice(0,4)==='BPS1')return 'bps';
    throw failure('twueFiles');
}
function twueNeutralName(name){
    return String(name).split(/[\\/]/).pop().replace(/\.(ips|bps)$/i,'')
        .replace(/\bv?\d+(?:[._-]\d+)+(?:[a-z])?\b/ig,'').replace(/[^a-z0-9]/ig,'').toLowerCase();
}
function twueNamedSpec(name,specs,selection={},generic=false){
    if(/\banti\b|\breverse\b|\buninstall\b/i.test(name))return null;
    const neutral=twueNeutralName(name),exact=specs.filter(s=>twueNeutralName(s.name)===neutral);
    if(exact.length===1)return exact[0];
    if(/(?:twue|woolsey)/i.test(name)&&/final[\s_-]*fantasy/i.test(name)){
        if(specs.some(s=>s.role==='primary')){
            const addons=/add[\s_-]*ons?/i.test(name),bugfix=addons||/bug[\s_-]*fix/i.test(name),opera=/opera/i.test(name);
            const variant=addons?'addons':bugfix?'bugfix':'base';
            const key=opera?(variant==='base'?'opera':variant+'-opera'):variant;
            return specs.find(s=>s.role==='primary'&&s.variant===key)||null;
        }
        return [...specs].reverse().find(s=>s.variant==='307')||null;
    }
    if(generic&&specs.some(s=>s.role==='primary'))return specs.find(s=>s.role==='primary'&&s.variant===(selection.variant||'base'))||null;
    return null;
}
async function admitTWUEPatch(entry,specs,selection={},family='twue',generic=false){
    if(/\banti\b|\breverse\b|\buninstall\b/i.test(entry.name))return null;
    const originalSha=await rawHash(entry.bytes),format=twuePatchFormat(entry.bytes);
    let spec=specs.find(s=>s.sha===originalSha),bytes=entry.bytes,known=!!spec;
    // Already known historical/BPS sources retain their original reader and
    // exact profile rather than being relabeled as an unrecognized IPS source.
    const legacy=catalog.sources.twue.find(s=>s.sha===originalSha);
    if(!spec&&legacy&&specs.some(s=>s.role==='primary')){
        return null;
    }
    if(!spec&&format==='ips'){
        decodeFutureIPS(bytes);
        for(const candidate of specs){
            const normalized=await normalizeFutureIPS(bytes,candidate);
            if(normalized){spec=candidate;bytes=normalized;break;}
        }
    }
    if(!spec){
        spec=twueNamedSpec(entry.name,specs,selection,generic);
        if(!spec)return null;
        if(spec.role&&spec.role!=='primary')throw failure('futureConflict');
        if(format==='ips')decodeFutureIPS(bytes);
        else{
            if(bytes.length<19||crc32(bytes.subarray(0,-4))!==new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength).getUint32(bytes.length-4,true))throw failure('twueFiles');
        }
    }
    if(!futurePatchInfo(bytes))registerFuturePatch(bytes,{family,spec,originalSha,name:entry.name,
        declaredVersion:entry.declaredVersion,fromSaved:entry.fromSaved,warning:!known});
    return {spec,bytes};
}
async function readTWUEFutureSources(files,saved,specs,selection={},family='twue'){
    const entries={};
    const add=(spec,bytes)=>{if(entries[spec.name])throw failure('twueFiles');entries[spec.name]=bytes;};
    if(files?.length){
        const candidates=await collectFuturePatchFiles(files,16*1024*1024);
        for(const entry of candidates){
            const accepted=await admitTWUEPatch(entry,specs,selection,family,files.length===1&&!entry.isArchive);
            if(accepted)add(accepted.spec,accepted.bytes);
        }
    }else{
        for(const spec of specs)if(saved?.[spec.name]){
            const bytes=from64(saved[spec.name]);
            const accepted=await admitTWUEPatch({name:spec.name,bytes,fromSaved:true},specs,selection,family,false);
            if(!accepted||accepted.spec.name!==spec.name)throw failure('twueFiles');
            add(spec,accepted.bytes);
        }
    }
    if(!Object.keys(entries).length)throw failure('twueFiles');
    return entries;
}
