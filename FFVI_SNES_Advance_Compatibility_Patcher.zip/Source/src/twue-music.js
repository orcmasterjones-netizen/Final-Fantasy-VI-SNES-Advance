// Relocate the user's original TWUE Music Player; no original patch payload is bundled.
async function readTWUEMusic(files,saved) {
    return readTWUEVariantSources(files,saved,{},'music');
}

function twueMusicSparseIPS(bytes) {
    const image=new Uint8Array(4194304),present=new Uint8Array(4194304);
    if(bytes.length<8 || String.fromCharCode(...bytes.subarray(0,5))!=='PATCH')throw failure('twueFiles');
    let p=5;
    while(p+3<=bytes.length) {
        if(bytes[p]===69&&bytes[p+1]===79&&bytes[p+2]===70){p+=3;break;}
        if(p+5>bytes.length)throw failure('twueFiles');
        const at=(bytes[p]<<16)|(bytes[p+1]<<8)|bytes[p+2],n=(bytes[p+3]<<8)|bytes[p+4];p+=5;
        if(n){if(p+n>bytes.length||at+n>image.length)throw failure('twueFiles');image.set(bytes.subarray(p,p+n),at);present.fill(1,at,at+n);p+=n;}
        else {if(p+3>bytes.length)throw failure('twueFiles');const count=(bytes[p]<<8)|bytes[p+1];if(at+count>image.length)throw failure('twueFiles');image.fill(bytes[p+2],at,at+count);present.fill(1,at,at+count);p+=3;}
    }
    if(p!==bytes.length)throw failure('twueFiles');
    return {image,present};
}
function twueMusicHex(text) {
    if(text.length%2||!/^[0-9a-f]*$/i.test(text))throw failure('verifyFail');
    return Uint8Array.from(text.match(/../g)||[],h=>parseInt(h,16));
}
async function applyTWUEMusic(base,profile,sources,placement,fixes=[]) {
    if(placement==='none'||!placement){if(fixes.length)throw failure('twueFiles');return base;}
    const meta=catalog.twueMusic,plan=meta?.[placement];
    const variant=profile?.twueVariant||profile?.variant||'base',spec=catalog.twueVariants?.variants?.[variant];
    if(!plan||!spec||(placement==='mainA'&&!spec.bugfix)||(placement==='mainB'&&spec.bugfix))throw failure('twueFiles');
    const selected=[...new Set(fixes)].sort();
    if(selected.some(id=>!['sfx','lete','caves'].includes(id)))throw failure('twueFiles');
    if(base.length!==4194304)throw failure('verifyFail');
    const out=base.slice();
    // Reserved expansion and near-bank space must be empty before any writes.
    for(const [a,b] of [[0x3cd000,0x3cf000],[0x3f127,0x3f200]])for(let p=a;p<b;p++)if(out[p]!==255)throw failure('verifyFail');
    const apply=async recipe=>{
        if(!recipe)throw failure('twueFiles');
        const patch=sources?.[recipe.source];
        if(!patch||await hash(patch)!==recipe.sha)throw failure('twueFiles');
        const {image,present}=twueMusicSparseIPS(patch);
        for(const [at,hex]of recipe.guards||[]){const guard=twueMusicHex(hex);if(guard.some((v,i)=>out[at+i]!==v))throw failure('verifyFail');}
        for(const [dest,src,n]of recipe.copies){if(dest<0||dest+n>out.length||src<0||src+n>image.length||present.subarray(src,src+n).some(v=>!v))throw failure('verifyFail');out.set(image.subarray(src,src+n),dest);}
        for(const [at,n]of recipe.spaces||[])for(let p=at;p<at+n;p++)if(out[p]===254)out[p]=255;
        if(recipe.triggerAppend)twueMusicAppendTriggers(out,image,present,recipe.triggerAppend);
        for(const [at,hex]of recipe.edits){const bytes=twueMusicHex(hex);if(at<0||at+bytes.length>out.length)throw failure('verifyFail');out.set(bytes,at);}
    };
    await apply(plan);
    for(const id of selected)await apply(meta.fixes?.[id]);
    writeChecksum(out);
    await twueMusicStoreMetadata(out,base,sources,{placement,fixes:selected,profile:{twueVariant:variant}});
    return out;
}

function twueMusicAppendTriggers(out,image,present,spec) {
    const {table,mapCount,recordBytes,map,source,length,limit,firstPointer}=spec;
    const view=new DataView(out.buffer,out.byteOffset,out.byteLength),pointers=[];
    for(let i=0;i<=mapCount;i++)pointers.push(view.getUint16(table+2*i,true));
    if(pointers[0]!==firstPointer||length%recordBytes||pointers.some((p,i)=>p<firstPointer||(p-firstPointer)%recordBytes||(i&&p<pointers[i-1])))throw failure('verifyFail');
    const end=table+pointers[mapCount],at=table+pointers[map+1];
    if(end+length>limit||out.subarray(end,end+length).some(v=>v!==255)||present.subarray(source,source+length).some(v=>!v))throw failure('verifyFail');
    const addition=image.subarray(source,source+length);
    for(let p=table+pointers[map];p<at;p+=recordBytes)for(let n=0;n<length;n+=recordBytes)if(out[p]===addition[n]&&out[p+1]===addition[n+1])throw failure('verifyFail');
    out.copyWithin(at+length,at,end);out.set(addition,at);
    for(let i=map+1;i<=mapCount;i++)view.setUint16(table+2*i,pointers[i]+length,true);
}

const twueMusicMetadata={start:0x3d2000,capacity:0x4000,header:64,magic:'TWUEMUS2',version:2};
// One deterministic zlib-wrapped fixed-Huffman block. Match selection is greedy,
// nearest-first, at most128 candidates in a32KiB window; ties keep the nearest.
const twueMusicLengthBase=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
const twueMusicLengthExtra=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
const twueMusicDistanceBase=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
const twueMusicDistanceExtra=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
function twueMusicReverseBits(v,n){let r=0;while(n--){r=(r<<1)|(v&1);v>>>=1;}return r;}
function twueMusicAdler(bytes){let a=1,b=0;for(const v of bytes){a=(a+v)%65521;b=(b+a)%65521;}return ((b<<16)|a)>>>0;}
function twueMusicFixedCode(symbol){
    if(symbol<=143)return [symbol+0x30,8];
    if(symbol<=255)return [symbol-144+0x190,9];
    if(symbol<=279)return [symbol-256,7];
    return [symbol-280+0xc0,8];
}
function twueMusicDeflate(bytes){
    if(bytes.length>0x40000)throw failure('verifyFail');
    const output=[0x78,0x01];let bits=0,count=0;
    const put=(value,n)=>{bits|=value<<count;count+=n;while(count>=8){output.push(bits&255);bits>>>=8;count-=8;}};
    const symbol=value=>{const [code,n]=twueMusicFixedCode(value);put(twueMusicReverseBits(code,n),n);};
    const heads=new Int32Array(65536).fill(-1),previous=new Int32Array(bytes.length).fill(-1);
    const key=p=>(bytes[p]*251+bytes[p+1]*31+bytes[p+2])&65535;
    const insert=p=>{if(p+2<bytes.length){const h=key(p);previous[p]=heads[h];heads[h]=p;}};
    put(3,3); // BFINAL=1, BTYPE=01 (fixed Huffman).
    for(let p=0;p<bytes.length;){
        let best=0,distance=0;
        if(p+2<bytes.length){
            let candidate=heads[key(p)],budget=128;const maximum=Math.min(258,bytes.length-p);
            while(candidate>=0&&p-candidate<=32768&&budget--){
                if(bytes[candidate]===bytes[p]&&bytes[candidate+1]===bytes[p+1]&&bytes[candidate+2]===bytes[p+2]){
                    let length=3;while(length<maximum&&bytes[candidate+length]===bytes[p+length])length++;
                    if(length>best){best=length;distance=p-candidate;if(best===maximum)break;}
                }
                candidate=previous[candidate];
            }
        }
        if(best<3){symbol(bytes[p]);insert(p++);continue;}
        let li=0;while(li+1<twueMusicLengthBase.length&&twueMusicLengthBase[li+1]<=best)li++;
        symbol(257+li);put(best-twueMusicLengthBase[li],twueMusicLengthExtra[li]);
        let di=0;while(di+1<twueMusicDistanceBase.length&&twueMusicDistanceBase[di+1]<=distance)di++;
        put(twueMusicReverseBits(di,5),5);put(distance-twueMusicDistanceBase[di],twueMusicDistanceExtra[di]);
        const end=p+best;while(p<end)insert(p++);
    }
    symbol(256);if(count)output.push(bits&255);
    const checksum=twueMusicAdler(bytes);output.push(checksum>>>24,(checksum>>>16)&255,(checksum>>>8)&255,checksum&255);
    return Uint8Array.from(output);
}
function twueMusicInflate(bytes){
    if(bytes.length<8||bytes[0]!==0x78||bytes[1]!==0x01)throw failure('verifyFail');
    const end=bytes.length-4,output=new Uint8Array(0x40000);let at=2,bits=0,count=0,used=0;
    const get=n=>{while(count<n){if(at>=end)throw failure('verifyFail');bits|=bytes[at++]<<count;count+=8;}const value=bits&((1<<n)-1);bits>>>=n;count-=n;return value;};
    if(get(3)!==3)throw failure('verifyFail');
    const tables=[null,null,null,null,null,null,null,new Int16Array(128).fill(-1),new Int16Array(256).fill(-1),new Int16Array(512).fill(-1)];
    for(let i=0;i<288;i++){const [code,n]=twueMusicFixedCode(i);tables[n][twueMusicReverseBits(code,n)]=i;}
    const readSymbol=()=>{let code=0;for(let n=1;n<=9;n++){code|=get(1)<<(n-1);if(n>=7&&tables[n][code]>=0)return tables[n][code];}throw failure('verifyFail');};
    for(;;){
        const code=readSymbol();
        if(code<256){if(used===output.length)throw failure('verifyFail');output[used++]=code;continue;}
        if(code===256)break;
        if(code>285)throw failure('verifyFail');
        const li=code-257,length=twueMusicLengthBase[li]+get(twueMusicLengthExtra[li]);
        const di=twueMusicReverseBits(get(5),5);if(di>=30)throw failure('verifyFail');
        const distance=twueMusicDistanceBase[di]+get(twueMusicDistanceExtra[di]);
        if(distance>used||used+length>output.length)throw failure('verifyFail');
        for(let i=0;i<length;i++){output[used]=output[used-distance];used++;}
    }
    // Exactly one block, zero alignment padding, and a verified Adler32 trailer.
    if(at!==end||bits!==0)throw failure('verifyFail');
    const expected=((bytes[end]<<24)|(bytes[end+1]<<16)|(bytes[end+2]<<8)|bytes[end+3])>>>0,result=output.slice(0,used);
    if(twueMusicAdler(result)!==expected)throw failure('verifyFail');return result;
}
async function twueMusicZip(bytes,expand=false){return expand?twueMusicInflate(bytes):twueMusicDeflate(bytes);}
function twueMusicTo64(bytes) {
    let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);
}
function twueMusicFrom64(s) {return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
async function twueMusicStoreMetadata(out,base,sources,selection) {
    const m=twueMusicMetadata;
    for(let p=m.start;p<m.start+m.capacity;p++)if(base[p]!==255||out[p]!==255)throw failure('verifyFail');
    const undo=[];let begin=-1,last=-1;
    const baseChecksum=twueCanonicalChecksum(base),outChecksum=twueCanonicalChecksum(out);
    const value=(bytes,check,p)=>p>=0xffdc&&p<0xffe0?check[p-0xffdc]:bytes[p];
    const undoBytes=(a,b)=>{
        const bytes=base.slice(a,b);
        for(let p=Math.max(a,0xffdc);p<Math.min(b,0xffe0);p++)bytes[p-a]=baseChecksum[p-0xffdc];
        return bytes;
    };
    const excluded=p=>p>=0x3cd000&&p<0x3cf000||p>=0x3f127&&p<0x3f200;
    for(let p=0;p<base.length;p++){
        if(!excluded(p)&&value(base,baseChecksum,p)!==value(out,outChecksum,p)){if(begin<0)begin=p;last=p;}
        if(begin>=0&&(p-last>32||p===base.length-1)){undo.push([begin,twueMusicTo64(undoBytes(begin,last+1))]);begin=-1;}
    }
    const retained={},recipes=[catalog.twueMusic[selection.placement],...selection.fixes.map(id=>catalog.twueMusic.fixes[id])];
    for(const r of recipes)retained[r.source]=twueMusicTo64(sources[r.source]);
    const body={version:m.version,...selection,baseHash:await hash(base),installedHash:await hash(out),undo,sources:retained};
    const compressed=await twueMusicZip(new TextEncoder().encode(JSON.stringify(body)));
    if(compressed.length>m.capacity-m.header)throw failure('verifyFail');
    out.set(new TextEncoder().encode(m.magic),m.start);
    const view=new DataView(out.buffer,out.byteOffset,out.byteLength);view.setUint32(m.start+8,m.version,true);view.setUint32(m.start+12,compressed.length,true);
    out.set(twueMusicHex(await hash(compressed)),m.start+16);out.set(compressed,m.start+m.header);writeChecksum(out);
}
async function restoreTWUEMusic(bytes) {
    const m=twueMusicMetadata;
    if(bytes.length!==4194304)return null;
    if(new TextDecoder().decode(bytes.subarray(m.start,m.start+8))!==m.magic)return null;
    const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),length=view.getUint32(m.start+12,true);
    if(view.getUint32(m.start+8,true)!==m.version||length>m.capacity-m.header||bytes.subarray(m.start+48,m.start+m.header).some(v=>v!==255)||bytes.subarray(m.start+m.header+length,m.start+m.capacity).some(v=>v!==255))throw failure('verifyFail');
    const compressed=bytes.slice(m.start+m.header,m.start+m.header+length),expected=Array.from(bytes.subarray(m.start+16,m.start+48),v=>v.toString(16).padStart(2,'0')).join('');
    if(await hash(compressed)!==expected)throw failure('verifyFail');
    let body;try{body=JSON.parse(new TextDecoder().decode(await twueMusicZip(compressed,true)));}catch{throw failure('verifyFail');}
    if(body.version!==m.version||!catalog.twueMusic[body.placement]||!Array.isArray(body.fixes)||!Array.isArray(body.undo)||!body.sources)throw failure('verifyFail');
    const recipes=[catalog.twueMusic[body.placement],...body.fixes.map(id=>catalog.twueMusic.fixes?.[id])],sources={};
    if(recipes.some(r=>!r)||Object.keys(body.sources).length!==recipes.length)throw failure('verifyFail');
    for(const r of recipes){if(typeof body.sources[r.source]!=='string')throw failure('verifyFail');const src=twueMusicFrom64(body.sources[r.source]);if(await hash(src)!==r.sha)throw failure('verifyFail');sources[r.source]=src;}
    const base=bytes.slice();base.fill(255,m.start,m.start+m.capacity);writeChecksum(base);
    if(await hash(base)!==body.installedHash)throw failure('verifyFail');
    base.fill(255,0x3cd000,0x3cf000);base.fill(255,0x3f127,0x3f200);
    for(const [at,encoded]of body.undo){const value=twueMusicFrom64(encoded);if(!Number.isInteger(at)||at<0||at+value.length>base.length)throw failure('verifyFail');base.set(value,at);}
    writeChecksum(base);
    if(await hash(base)!==body.baseHash)throw failure('verifyFail');
    return {base,sources,placement:body.placement,fixes:body.fixes,profile:body.profile};
}
