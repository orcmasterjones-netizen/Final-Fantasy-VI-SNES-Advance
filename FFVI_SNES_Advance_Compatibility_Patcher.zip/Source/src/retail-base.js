// Original-ROM bootstrap. Only exact pristine USA revisions enter this path.
// Bundled data contains our Regular patches and the existing compatibility
// recipe. The original MoleMan patch is always supplied by the user.
const retailBaseData=JSON.parse(el('retailBase').textContent);
const retailMolemanSpec=retailBaseData.moleman;
const retailBaseMerger=(()=>{
const recipe=retailBaseData.molemanRecipe,hashes=retailBaseData.mergerHashes;
const retailSize=0x300000,expandedSize=0x400000;
const crcTable = Uint32Array.from({length: 256}, (_, index) => {
    let value = index;
    for (let bit = 0; bit < 8; bit++) {
        value = (value >>> 1) ^ ((value & 1) ? 0xedb88320 : 0);
    }
    return value >>> 0;
});
function crc32(bytes) {
    let crc = 0xffffffff;
    for (const byte of bytes) crc = (crc >>> 8) ^ crcTable[(crc ^ byte) & 255];
    return (crc ^ 0xffffffff) >>> 0;
}
async function sha256(bytes) {
    if (!globalThis.crypto?.subtle) {
        throw new Error('Open the extracted HTML file in a current desktop browser to enable SHA-256 verification.');
    }
    const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
    return Array.from(digest, byte => byte.toString(16).padStart(2,'0')).join('');
}
async function verify(bytes, expected, description) {
    if (await sha256(bytes) !== expected) throw new Error(description + ' failed its SHA-256 check.');
}
function bytesOf(encoded) {
    return Uint8Array.from(atob(encoded), character => character.charCodeAt(0));
}
function applyBPS(source, patch, expectedLength, template = false) {
    const fail = () => { throw new Error('BPS validation failed. Check the input files and extract the merger again.'); };
    if (patch.length < 19 || String.fromCharCode(...patch.subarray(0,4)) !== 'BPS1') fail();
    const footer = patch.length - 12;
    const view = new DataView(patch.buffer, patch.byteOffset, patch.byteLength);
    if (crc32(patch.subarray(0,-4)) !== view.getUint32(footer+8, true)) fail();
    if (!template && crc32(source) !== view.getUint32(footer, true)) fail();
    let position = 4;
    function number() {
        let value = 0, factor = 1;
        while (position < footer && factor <= 2**42) {
            const next = patch[position++];
            value += (next & 127) * factor;
            if (next & 128) return value;
            factor *= 128;
            value += factor;
        }
        fail();
    }
    function offset() {
        const encoded = number();
        const distance = Math.floor(encoded / 2);
        return encoded % 2 ? -distance : distance;
    }
    const sourceLength = number(), targetLength = number(), metadataSize = number();
    if (source.length !== sourceLength || targetLength !== expectedLength || metadataSize > footer-position) fail();
    position += metadataSize;
    const target = new Uint8Array(targetLength);
    let written = 0, sourceCursor = 0, targetCursor = 0;
    while (position < footer) {
        const action = number();
        const count = Math.floor(action / 4) + 1;
        if (count > target.length - written) fail();
        switch (action % 4) {
            case 0:
                if (written+count > source.length) fail();
                target.set(source.subarray(written,written+count), written);
                break;
            case 1:
                if (count > footer-position) fail();
                target.set(patch.subarray(position,position+count), written);
                position += count;
                break;
            case 2:
                sourceCursor += offset();
                if (sourceCursor < 0 || count > source.length-sourceCursor) fail();
                target.set(source.subarray(sourceCursor,sourceCursor+count), written);
                sourceCursor += count;
                break;
            case 3:
                targetCursor += offset();
                if (targetCursor < 0 || targetCursor >= written) fail();
                for (let i = 0; i < count; i++) target[written+i] = target[targetCursor++];
                break;
        }
        written += count;
    }
    if (written !== targetLength || !template && crc32(target) !== view.getUint32(footer+4, true)) fail();
    return target;
}
async function upgradeMolemanTemplate(source) {
    const patch=bytesOf(recipe.upgradeCombined);
    await verify(patch,retailBaseData.molemanVersions.upgradePatchHash,'Bundled upgrade patch');
    if(await hash(source)!==hashes.combined)throw failure('molemanLayout');
    validateMolemanDialogue(source);
    const out=applyBPS(source,patch,expandedSize,true);
    // The audited upgrade leaves these data ranges unchanged. Preserve the
    // player's text even if a BPS literal happens to encode an identical old byte.
    for(const [a,b]of molemanDialogueMask)if(a!==0xffdc)out.set(source.subarray(a,b),a);
    writeChecksum(out);
    if(await hash(out)!==hashes.updatedCombined)throw failure('molemanLayout');
    return out;
}
function copyRecords(target, source, ranges) {
    for (const [dest, start, count] of ranges) {
        if (start < 0 || dest < 0 || count <= 0 || start+count > source.length || dest+count > target.length) {
            throw new Error('A compatibility record falls outside the image.');
        }
        target.set(source.subarray(start,start+count), dest);
    }
}
function correctSpellNames(bytes, edition, reverse = false) {
    const edits = edition === 'regular' ? [[3169282,"e8","ea"],[3169289,"86ab9aafa2a39a","e986ab9aafa39a"],[3169914,"86ab9aafa2a39affffff","86ab9aafa39affffffff"]] : [[3965675,"e8959aa5a8abffffff","ea959aa5a8abffffff"],[3965684,"86ab9aafa2a39affff","e986ab9aafa2a39aff"],[188507,"0f","07"],[188513,"0f","07"]];
    const out = bytes.slice();
    const hex = value => Uint8Array.from(value.match(/../g), v => parseInt(v,16));
    for (const [at, before, after] of edits) {
        const expected = hex(reverse ? after : before), replacement = hex(reverse ? before : after);
        if (!expected.every((value,i) => out[at+i] === value)) throw new Error('Spell-name verification failed.');
        out.set(replacement,at);
    }
    out.set([255,255,0,0],0xffdc);
    const sum = out.reduce((total,value) => total+value,0) & 65535;
    new DataView(out.buffer).setUint16(0xffdc,sum^65535,true);
    new DataView(out.buffer).setUint16(0xffde,sum,true);
    return out;
}
function correctStandaloneBase(bytes, reverse = false) {
    const edits = [[201997,"f02065fd15","f0062065fd"],[260935,"ff","00"]];
    const out = bytes.slice();
    const hex = value => Uint8Array.from(value.match(/../g), v => parseInt(v,16));
    for (const [at, before, after] of edits) {
        const expected = hex(reverse ? after : before), replacement = hex(reverse ? before : after);
        if (!expected.every((value,i) => out[at+i] === value)) throw new Error('Standalone correction verification failed.');
        out.set(replacement,at);
    }
    out.set([255,255,0,0],0xffdc);
    const sum = out.reduce((total,value) => total+value,0) & 65535;
    new DataView(out.buffer).setUint16(0xffdc,sum^65535,true);
    new DataView(out.buffer).setUint16(0xffde,sum,true);
    return out;
}
async function finishStandaloneBase(bytes) {
    if(await hash(bytes)!==hashes.correctedCombined)throw failure('molemanLayout');
    const out = correctStandaloneBase(bytes);
    if(await hash(out)!==hashes.refreshedCombined)throw failure('molemanLayout');
    return out;
}
async function mergeRetail(rom, userPatch) {
    if(!molemanPatchMetadata.has(userPatch))await molemanRegisterPatch(userPatch);
    const id=await sha256(rom);
    if(rom.length!==retailSize || ![hashes.rev0,hashes.rev1].includes(id))throw failure('retailUnknown');
    let retailZero=id===hashes.rev0?rom:null,retailOne=rom;
    if(retailZero) {
        retailOne=applyBPS(retailZero,bytesOf(recipe.retailRevisionOne),retailSize);
        await verify(retailOne,hashes.rev1,'Retail revision 1');
    }
    const preview=applyBPS(retailOne,bytesOf(recipe.previewPatch),expandedSize);
    await verify(preview,hashes.preview,'Regular Advance Preview');
    if(!retailZero) {
        retailZero=applyBPS(preview,bytesOf(recipe.retailSourceLayout),retailSize);
        await verify(retailZero,hashes.rev0,'Retail source for the translation');
    }
    const donorInfo=await normalizeMolemanDonor(applyBPS(retailZero,userPatch,expandedSize));
    const donor=donorInfo.bytes;
    const relocated=applyBPS(preview,bytesOf(recipe.relocatedPreview),expandedSize);
    await verify(relocated,hashes.relocated,'Relocated preview');
    const result=relocated.slice();
    copyRecords(result,relocated,recipe.previewCopies);
    copyRecords(result,donor,recipe.donorCopies);
    for(const [address,value]of recipe.fixups)result[address]=value;
    writeChecksum(result);
    if(await hash(result)!==hashes.combined)throw failure('molemanLayout');
    const updated=await upgradeMolemanTemplate(result);
    const corrected=correctSpellNames(updated,'moleman');
    return restoreMolemanData(await finishStandaloneBase(corrected),donorInfo.revision18);
}
return {applyBPS:(source,patch,size)=>applyBPS(source,patch,size),mergeRetail,crc32};
})();

async function identifyRetailROM(file) {
    if(![0x300000,0x300200].includes(file.size))return null;
    const raw=new Uint8Array(await file.arrayBuffer()),bytes=raw.slice(-0x300000),id=await hash(bytes);
    const revision=Object.keys(retailBaseData.regular).find(key=>retailBaseData.regular[key].source===id);
    if(!revision)throw failure('retailUnknown');
    return {bytes,id,revision};
}
async function readRetailMoleman(files=[],saved,savedVersion=null) {
    return readMolemanPatch(files,saved,savedVersion);
}
async function buildRetailBase(input,edition,molePatch) {
    if(!['regular','moleman'].includes(edition))throw failure('badFiles');
    const spec=retailBaseData.regular[input?.revision];
    if(!spec||!input?.bytes||input.bytes.length!==0x300000||input.id!==spec.source||await hash(input.bytes)!==spec.source)
        throw failure('retailUnknown');
    let bytes;
    if(edition==='regular') {
        const patch=from64(spec.patch);
        if(await hash(patch)!==spec.patchSha256)throw failure('verifyFail');
        bytes=retailBaseMerger.applyBPS(input.bytes,patch,0x400000);
    } else {
        if(!molePatch)throw failure('retailMolemanRequired');
        bytes=await retailBaseMerger.mergeRetail(input.bytes,molePatch);
    }
    const id=await rawHash(bytes);
    const normalized=edition==='moleman'?(await molemanROMInfo(bytes)).bytes:bytes;
    if(bytes.length!==0x400000||await hash(normalized)!==retailBaseData.targets[edition])throw failure('verifyFail');
    if(edition==='moleman')validateMolemanDialogue(bytes);
    if(edition==='moleman'&&molemanPatchInfo(molePatch).knownVersion==='1.8'&&id!==retailBaseData.molemanVersions.standard18MergedHash)throw failure('verifyFail');
    const corrected=changeLoreReads(bytes);
    return {bytes:corrected,id:await rawHash(corrected)};
}
