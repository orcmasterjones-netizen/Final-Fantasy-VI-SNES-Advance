// Spell-category corrections sit outside every reversible edition/font/music
// layer. Reopening first reverses only the guarded correction and verifies the
// complete prior ROM against the existing catalog before decoding those layers.
// This preserves all previously published input hashes and retained donors.
// Native seven-cell editions use icon + Gravja without changing any reader.
// Optional fonts retain icon + Gravija through the existing eight-cell adapter;
// editions with wider native tables always keep the full name.
const spellIconRecipes = [{"id":"native-seven-cell","size":4194304,"guards":[[217033,"Bw=="],[217038,"vVk="],[217043,"8A=="],[91622,"Bw=="],[91633,"vVnw"],[90136,"Bw=="],[90159,"vlnw"],[3151869,"Bw=="],[217093,"kg=="],[217190,"kg=="],[219993,"kg=="],[217147,"Cw=="]],"edits":[[3169282,"6A==","6g=="],[3169289,"hquar6Kjmg==","6Yarmq+jmg=="],[3169914,"hquar6Kjmv///w==","hquar6Oa/////w=="]]},{"id":"seven-to-eight-cell","size":4194304,"guards":[[3169282,"6A=="],[3169289,"hquar6Kjmg=="]],"sourceTable":{"source":3168701,"count":85,"width":7,"destination":4026368,"targetWidth":8},"edits":[[217033,"Bw==","CA=="],[217038,"vVk=","AHA="],[217043,"8A==","/Q=="],[91622,"Bw==","CA=="],[91633,"vVnw","AHD9"],[90136,"Bw==","CA=="],[90159,"vlnw","AXD9"],[3151869,"Bw==","CA=="],[217093,"kg==","kw=="],[217190,"kg==","kw=="],[219993,"kg==","kw=="],[217147,"Cw==","DA=="]]},{"id":"expanded-nine-cell","size":4194304,"guards":[],"edits":[[3965675,"6JWapair////","6pWapair////"],[3965684,"hquar6Kjmv//","6Yarmq+io5r/"]]},{"id":"rose-valor","size":8388608,"guards":[],"edits":[[188507,"Dw==","Bw=="],[188513,"Dw==","Bw=="],[8229611,"6A==","6g=="],[8231472,"6A==","6g=="]]},{"id":"standalone-nine-cell","size":4194304,"standalone":true,"guards":[],"edits":[[3965675,"6JWapair////","6pWapair////"],[3965684,"hquar6Kjmv//","6Yarmq+io5r/"],[188507,"Dw==","Bw=="],[188513,"Dw==","Bw=="]]}];

function spellIconChecksum(bytes) {
    if(bytes.length===0x800000)writeROSEChecksum(bytes);else writeChecksum(bytes);
}
function knownSpellIconBase(id,size) {
    return size===0x800000?!!catalog.rose?.profiles[id]:!!(catalog.menuPolish?.inputs[id]||catalog.musicLayer?.inputs[id]||catalog.multiFont?.inputs[id]);
}
function spellIconEdits(bytes,recipe) {
    if(!recipe.sourceTable)return recipe.edits;
    // Copy the user's edition-specific spell names; do not bundle translated
    // spell tables in the public patcher. The original table remains intact.
    const {source,count,width,destination,targetWidth}=recipe.sourceTable;
    const table=new Uint8Array(count*targetWidth).fill(255);
    for(let i=0;i<count;i++)table.set(bytes.subarray(source+i*width,source+(i+1)*width),i*targetWidth);
    table[83*targetWidth]=0xea;
    table.set(bytes.subarray(source+84*width,source+85*width),84*targetWidth+1);
    table[84*targetWidth]=0xe9;
    return [...recipe.edits,[destination,to64(new Uint8Array(table.length).fill(255)),to64(table)]];
}
function spellIconMatches(bytes,recipe,side) {
    return bytes.length===recipe.size&&(recipe.guards||[]).every(([at,data])=>from64(data).every((v,i)=>bytes[at+i]===v))&&spellIconEdits(bytes,recipe).every(([at,before,after])=>{
        const data=from64(side==='before'?before:after);
        return data.every((v,i)=>bytes[at+i]===v);
    });
}
function spellIconRecipe(bytes,side='before',profile) {
    const sevenCell=profile&&fontStyle(profile)==='native'?'native-seven-cell':'seven-to-eight-cell';
    return spellIconRecipes.find(recipe=>!recipe.standalone&&
        (!['native-seven-cell','seven-to-eight-cell'].includes(recipe.id)||recipe.id===sevenCell)&&
        spellIconMatches(bytes,recipe,side));
}
// New standalone downloads normalize to these exact, already supported inputs.
// This list does not broaden acceptance to arbitrary edited ROMs.
const standaloneSpellIconBases=new Set([
    '881313788f00b36af61ae7373274cfebefcab46cd6a447683407c63ee1ffcc7d',
    'e040f27df1c9637278e6cbff135fa30cb52550cc651d2a43ca34cae37a5f2e0c'
]);
function applySpellIconRecipe(bytes,recipe,side='after') {
    const expected=side==='after'?'before':'after';
    if(!spellIconMatches(bytes,recipe,expected))throw failure('verifyFail');
    const out=bytes.slice();
    for(const [at,before,after]of spellIconEdits(bytes,recipe))out.set(from64(side==='after'?after:before),at);
    spellIconChecksum(out);return out;
}
async function applySpellIcons(output) {
    if(!knownSpellIconBase(output.id,output.bytes.length)||await hash(output.bytes)!==output.id)throw failure('verifyFail');
    const recipe=spellIconRecipe(output.bytes,'before',output.profile);
    if(!recipe)throw failure('verifyFail');
    const bytes=applySpellIconRecipe(output.bytes,recipe),id=await hash(bytes);
    const reverted=applySpellIconRecipe(bytes,recipe,'before');
    if(await hash(reverted)!==output.id)throw failure('verifyFail');
    return {...output,bytes,id,spellIconBase:output.id,spellIconRecipe:recipe.id};
}
async function identifySpellIcons(file) {
    if(![0x400000,0x400200,0x800000,0x800200].includes(file.size))throw failure('wrongSize');
    const raw=new Uint8Array(await file.arrayBuffer()),size=file.size>=0x800000?0x800000:0x400000;
    const bytes=raw.slice(-size),checksumOffsets=size===0x800000?[0xffdc,0x40ffdc]:[0xffdc];
    const previousChecksums=checksumOffsets.map(at=>bytes.slice(at,at+4));
    spellIconChecksum(bytes);
    const checksumChanged=checksumOffsets.some((at,j)=>previousChecksums[j].some((v,i)=>bytes[at+i]!==v));
    const id=await hash(bytes);
    // The refreshed standalone MoleMan release carries only the shared
    // Continue/Bushido repairs, without the optional menu/job-title layer.
    // Normalize this one exact ROM to its already recognized predecessor.
    // Unknown ROMs cannot enter through a partial byte-pattern match.
    if(id==='bd483705bee66ea51616ca83657ade09e1ed75d52166dd70ce453913ebf9d306') {
        const restored=bytes.slice();
        const repairs=[[0x3150d,[0xf0,0x06,0x20,0x65,0xfd],[0xf0,0x20,0x65,0xfd,0x15]],
            [0x3fb47,[0x00],[0xff]]];
        for(const [at,fixed,prior]of repairs) {
            if(!fixed.every((v,i)=>restored[at+i]===v))throw failure('verifyFail');
            restored.set(prior,at);
        }
        spellIconChecksum(restored);
        if(await hash(restored)!=='5fb6841b35a81bdcef558a3886c416ac854e7cc7794739311e1148c424fa9f7d')throw failure('verifyFail');
        const input=await identifyLegacy(new File([restored],file.name));
        if(input.profile.edition!=='moleman'||input.profile.options.length)throw failure('verifyFail');
        // The base itself is current. Optional builds still use the existing
        // guarded composition and retain all previously published outputs.
        return {...input,upgrade:checksumChanged,standaloneCurrent:true,spellIconId:id};
    }
    if(knownSpellIconBase(id,size)){
        const input=await identifyComposed(file);
        return {...input,upgrade:true};
    }
    for(const recipe of spellIconRecipes){
        if(!spellIconMatches(bytes,recipe,'after'))continue;
        const restored=applySpellIconRecipe(bytes,recipe,'before'),baseId=await hash(restored);
        const standalone=standaloneSpellIconBases.has(baseId);
        if(!knownSpellIconBase(baseId,size)&&!standalone)continue;
        // Verify the recipe that was actually found. An older full-name native
        // output remains a valid input even though its next build is shortened.
        if(await hash(applySpellIconRecipe(restored,recipe))!==id)throw failure('verifyFail');
        const input=await identifyComposed(new File([restored],file.name));
        const expected=spellIconRecipe(restored,'before',input.profile);
        return {...input,upgrade:!!input.upgrade||checksumChanged||standalone||!expected||expected.id!==recipe.id,
            spellIcons:true,spellIconId:id};
    }
    // Raw and older supported inputs still enter the original recognition and
    // upgrade flow. No unknown ROM is admitted by matching a few name bytes.
    const input=await identifyComposed(file);
    return {...input,upgrade:true};
}
// ROSE uses event opcode $67 for its Continue/soft-reset event. Advance also
// uses it once after the ending to open the clear-save menu. Preserve both:
// the wrapper selects Advance's handler only at that exact event PC, and
// restores the full accumulator and processor status before either tail jump.
// No RAM, save-format, battle, or per-frame rendering changes are introduced.
const roseClearSavePrior='844c3e8848e1e94d70678931d115dc0d8d427477a7aab30fa8387d600085ceb8';
const roseClearSaveCurrent='c2de12df021d9728e5026a38c83e70f6a84419a95c6b470b722489abf4cb2859';
const roseClearSaveWrapper=Uint8Array.from([
    0x08,0xc2,0x20,0x48,0xa5,0xe5,0xc9,0xdb,0xb6,0xd0,0x0f,
    0xe2,0x20,0xa5,0xe7,0xc9,0xf1,0xd0,0x07,0xc2,0x20,0x68,
    0x28,0x4c,0x57,0xda,0xc2,0x20,0x68,0x28,0x4c,0x28,0xd7
]);
function roseClearSaveTransform(bytes,reverse=false) {
    if(bytes.length!==roseSize)throw failure('verifyFail');
    const out=bytes.slice();
    for(const mirror of [0,0x400000]){
        for(const [at,before,after]of [
            [mirror+0x9928,Uint8Array.of(0x28,0xd7),Uint8Array.of(0x20,0xd6)],
            [mirror+0xd620,new Uint8Array(roseClearSaveWrapper.length).fill(255),roseClearSaveWrapper]
        ]){
            const expected=reverse?after:before,replacement=reverse?before:after;
            if(!expected.every((v,i)=>out[at+i]===v))throw failure('verifyFail');
            out.set(replacement,at);
        }
    }
    writeROSEChecksum(out);return out;
}
async function applyROSEClearSave(output) {
    if(output.profile.edition!=='rose')return output;
    if(output.id!==roseClearSavePrior||await hash(output.bytes)!==roseClearSavePrior)throw failure('verifyFail');
    const bytes=roseClearSaveTransform(output.bytes),id=await hash(bytes);
    if(id!==roseClearSaveCurrent||await hash(roseClearSaveTransform(bytes,true))!==roseClearSavePrior)throw failure('verifyFail');
    return {...output,bytes,id,roseClearSave:true};
}
async function identifyLegacy(file) {
    if([roseSize,roseSize+512].includes(file.size)){
        const raw=new Uint8Array(await file.arrayBuffer()),bytes=raw.slice(-roseSize);
        const checksums=[0xffdc,0x40ffdc].map(at=>bytes.slice(at,at+4));
        writeROSEChecksum(bytes);
        const checksumChanged=[0xffdc,0x40ffdc].some((at,j)=>checksums[j].some((v,i)=>bytes[at+i]!==v));
        if(await hash(bytes)===roseClearSaveCurrent){
            const restored=roseClearSaveTransform(bytes,true);
            if(await hash(restored)!==roseClearSavePrior)throw failure('verifyFail');
            const input=await identifySpellIcons(new File([restored],file.name));
            if(input.profile.edition!=='rose')throw failure('verifyFail');
            return {...input,upgrade:!!input.upgrade||checksumChanged,roseClearSave:true,roseClearSaveId:roseClearSaveCurrent};
        }
    }
    const input=await identifySpellIcons(file);
    return input.profile.edition==='rose'?{...input,upgrade:true}:input;
}
async function combineLegacy(input,selected,sources={},settings={}) {
    return applyROSEClearSave(await applySpellIcons(await combineComposed(input,selected,sources,settings)));
}
