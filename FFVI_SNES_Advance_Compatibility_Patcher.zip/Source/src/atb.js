const atbKinds=['modern','classic','ctb'];
const battleKinds=['vanilla','turn',...atbKinds];
function applyATB(before,patch,family) {
    const shifted=!['moleman','twue'].includes(family);
    const dest=a=>shifted && a>=0x25a83 && a<0x26700 ? a+1 : a;
    const out=before.slice(),calls=[];
    if (![0xb2,0x76,0xc9,0xff,0xf0,0x12,0x20,0x3c,0x95,0xc2,0x20,0xa5,0x76].every((b,i)=>before[0x1950e+i]===b) ||
        !before.subarray(0x3dc000,0x3dc100).every(b=>b===255)) throw failure('verifyFail');
    let pos=5;
    while (pos<patch.length-3) {
        const at=patch[pos]*65536+patch[pos+1]*256+patch[pos+2],n=patch[pos+3]*256+patch[pos+4];pos+=5;
        let data;
        if(n){data=patch.subarray(pos,pos+n);pos+=n;}
        else{const count=patch[pos]*256+patch[pos+1];data=new Uint8Array(count).fill(patch[pos+2]);pos+=3;}
        if(at===0x19538){
            out.set(data.subarray(0,4),0x1950e);calls.push(0x1950e);
            if(data.length===13){out.set(data.subarray(9,13),0x19517);calls.push(0x19517);}
            else if(data.length!==4)throw failure('verifyFail');
            continue;
        }
        const target=at===0x4b4d9?0x3dc000:dest(at);
        out.set(data,target);
        for(let i=0;i<data.length-3;i++){
            const addr=data[i+1]+256*data[i+2]+65536*data[i+3];
            if(data[i]===0x22 && addr>=0xc4b4d9 && addr<0xc4b573)calls.push(target+i);
        }
    }
    if(![8,9].includes(calls.length))throw failure('verifyFail');
    for(const at of calls){
        const old=out[at+1]+256*out[at+2]+65536*out[at+3],addr=old-0xc4b4d9+0xfdc000;
        out.set([addr&255,(addr>>8)&255,(addr>>16)&255],at+1);
    }
    if(shifted){
        for(const [source,old] of [[0x20960,0x5864],[0x245f9,0x5b39],[0x25ad3,0x5b06],[0x25af4,0x5afa],[0x25c38,0x5cf7]]){
            const at=dest(source);
            if(out[at]+256*out[at+1]!==old)throw failure('verifyFail');
            out.set([(old+1)&255,(old+1)>>8],at);
        }
        for(let source=0x25afa;source<0x25b06;source+=2){
            const at=dest(source),old=out[at]+256*out[at+1];
            if(old<0x5a83 || old>=0x5d26)throw failure('verifyFail');
            out.set([(old+1)&255,(old+1)>>8],at);
        }
    }
    writeChecksum(out);return out;
}
async function identifyUnpolished(file) {
    if(![4194304,4194816].includes(file.size))throw failure('wrongSize');
    const raw=new Uint8Array(await file.arrayBuffer()),bytes=raw.slice(raw.length-4194304);
    let id=await hash(bytes),entry=catalog.atb.inputs[id];
    if(!entry){writeChecksum(bytes);id=await hash(bytes);entry=catalog.atb.inputs[id];}
    if(!entry)return identifyBase(file);
    const edits=[];
    for(const [at,encoded] of catalog.atb.undo[entry.undo]){
        const original=from64(encoded);edits.push([at,bytes.slice(at,at+original.length)]);bytes.set(original,at);
    }
    writeChecksum(bytes);
    if(await hash(bytes)!==entry.base)throw failure('verifyFail');
    const input=await identifyBase(new File([bytes],file.name));
    return {...input,atbKind:entry.kind,atbEdits:edits,profile:{...input.profile,options:[...input.profile.options,entry.kind]}};
}
async function combineUnpolished(input,selected,sources,settings) {
    selected=new Set(selected);selected.delete('vanilla');
    const timing=[...selected].filter(id=>id==='turn'||atbKinds.includes(id));
    if(timing.length>1 || (input.profile.options.includes('turn') && atbKinds.some(id=>selected.has(id))))throw failure('battleConflict');
    const kind=timing.find(id=>atbKinds.includes(id));
    const plain={...input,profile:{...input.profile,options:input.profile.options.filter(id=>!atbKinds.includes(id))}};
    const output=await combineBase(plain,new Set([...selected].filter(id=>!atbKinds.includes(id))),sources,settings);
    if(!kind)return output;
    let bytes;
    const patch=sources[kind]?.[catalog.sources[kind][0].name];
    if(patch)bytes=applyATB(output.bytes,patch,output.profile.edition);
    else if(input.atbKind===kind && input.atbEdits && input.profile.edition===output.profile.edition){
        bytes=output.bytes.slice();for(const [at,data] of input.atbEdits)bytes.set(data,at);writeChecksum(bytes);
    }else throw failure('badFiles');
    const id=await hash(bytes);
    if(catalog.atb.targets[output.id]?.[kind]!==id)throw failure('verifyFail');
    return {bytes,id,profile:{...output.profile,options:[...output.profile.options,kind]}};
}
