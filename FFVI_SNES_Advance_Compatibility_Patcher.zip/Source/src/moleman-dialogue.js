// MoleMan future-text compatibility: hashes protect every byte except the
// checksum, existing CD/CE caption pointers, and their bounded text payload.
// This module contains no translated text and does not authenticate BPS files.
// Keep raw SHA-256 for upstream-file and patch-footer authentication.
const molemanDialogueMask = Object.freeze([
    Object.freeze([0xffdc, 0xffe0]),
    Object.freeze([0xce602, 0xcfbdc]),
    Object.freeze([0xd0000, 0xef1fc])
]);
const molemanDialogueLayout = Object.freeze({
    size: 0x400000,
    pointerStart: 0xce602,
    firstBankCount: 1397,
    mutableCaptionCount: 2797,
    totalCaptionCount: 3084,
    textStart: 0xd0000,
    textEnd: 0xef1fc,
    maximumCaptionBytes: 65536
});

async function molemanDialogueFingerprint(bytes, rawDigest) {
    if (bytes.length !== molemanDialogueLayout.size) return null;
    const masked = bytes.slice();
    for (const [start, end] of molemanDialogueMask) masked.fill(0, start, end);
    return rawDigest(masked);
}

async function molemanDialogueAlias(bytes, actualId, aliases, rawDigest) {
    if (bytes.length !== molemanDialogueLayout.size) return actualId;
    const fingerprint = await molemanDialogueFingerprint(bytes, rawDigest);
    // Never admit an unregistered protected layout by a partial byte signature.
    return Object.prototype.hasOwnProperty.call(aliases, fingerprint)
        ? aliases[fingerprint] : actualId;
}

function validateMolemanDialogue(bytes) {
    const m = molemanDialogueLayout;
    const fail = detail => {
        throw new Error('This MoleMan patch changes an unsupported dialogue layout (' + detail + ').');
    };
    if (bytes.length !== m.size) fail('ROM size');
    const word = at => bytes[at] | (bytes[at + 1] << 8);
    if (word(0xce600) !== m.firstBankCount) fail('bank header');
    const thresholds = [0x75, 0x05, 0xcd, 0xed, 0x0a, 0xce, 0xff, 0xff, 0xf0];
    if (!thresholds.every((value, i) => bytes[0xdf80 + i] === value)) fail('bank table');

    // Find the terminator reachable from each byte in linear time. Controls
    // 11/14/16 consume one parameter; a zero parameter is not a terminator.
    // Crossing CD/CE is valid: upstream v1.8's caption1396 does exactly that.
    const length = m.textEnd - m.textStart;
    const ends = new Uint32Array(length + 2);
    for (let i = length - 1; i >= 0; --i) {
        const value = bytes[m.textStart + i];
        if (value === 0) ends[i] = m.textStart + i + 1;
        else if (value === 0x11 || value === 0x14 || value === 0x16) {
            if (i + 1 < length) ends[i] = ends[i + 2];
        } else ends[i] = ends[i + 1];
    }
    let longestCaption = 0, lastUsed = m.textStart;
    for (let id = 0; id < m.mutableCaptionCount; ++id) {
        const bank = id < m.firstBankCount ? 0xd0000 : 0xe0000;
        const start = bank + word(m.pointerStart + 2 * id);
        if (start < m.textStart || start >= m.textEnd) fail('caption ' + id + ' pointer');
        const end = ends[start - m.textStart];
        if (!end || end - start > m.maximumCaptionBytes) fail('caption ' + id + ' terminator');
        longestCaption = Math.max(longestCaption, end - start);
        lastUsed = Math.max(lastUsed, end);
    }
    // Third-bank captions and their pointers are not masked. Their correctness
    // is established by the full protected fingerprint, not guessed here.
    return {captionCount:m.mutableCaptionCount, longestCaption, lastUsed,
        freeBytes:m.textEnd - lastUsed};
}
