// Adapt Madsiur's original Multi-Font Selection1.4.1 from the user's verified
// IPS. Font pixels and upstream routines are extracted at runtime, never bundled.
// This final layer is exclusive with the proportional cartridge renderer.
const multiFontSpec={name:'Multi_Fonts_1.4.1_nh.ips',size:10948,sha:'454437c493a0e8487e46ea9ae95f7013a43b6a8f94f7da17a604bb69a566caab',crc:2279850801};
const multiFontSourceHash='1d287206cd3ea5abda8648b6e821d2179a70a251f78a92906dc0eb616d55f108';
const multiFontRegions=[[0x330000,0x335000],[0x338000,0x33b100],[0x33c000,0x33d100]];
const multiFontNearRegions=[[0x3fca8,0x3fd00],[0x3ffab,0x40000],[0x3fee4,0x3ff00],[0x3fd7b,0x3fd90],[0x3ff32,0x3ff3c]];
const multiFontGuards=[[27372,283,"331a93fdc19fb27564ea5a77b4bfeec9cdf6eb1079a33f32176fd3499ee69218"],[32871,227,"9842b156d33fa5da9fee418fa1e316decefa0176cac9a8ca100dc976e6770ad2"],[33397,1,"d4b0c0a4a8cc6c257aed34d16d39dd3c2d3539ed67fd4badd40aef16c1591715"],[33407,1,"d4b0c0a4a8cc6c257aed34d16d39dd3c2d3539ed67fd4badd40aef16c1591715"],[33809,9,"fb8bbe10e9b4f75c7583f5f936dfbdb64a0c092ac340036ffead7d2eca0f7c63"],[33877,1,"d4b0c0a4a8cc6c257aed34d16d39dd3c2d3539ed67fd4badd40aef16c1591715"],[33889,1,"d4b0c0a4a8cc6c257aed34d16d39dd3c2d3539ed67fd4badd40aef16c1591715"],[33941,126,"5be44d9f01ed32e8063eb3997d00c30f6cfa5802639f8d6537d8c8241e0743cf"],[35407,7,"8941c0631c432a480c920d32085bd7296b599297e0c9886ef419adf5a732f8cd"],[35423,521,"b2137fbadedaff2f99a38de751b858165f8574546c4e391c234037116dce88b2"],[82014,5,"b8907aa380d33de28d560c6077b28048105ef9372617727b7e3a9c9e9d5b2a18"],[82131,4,"edbafeaeb6a3ba57442947612bc13519d3d9ba7dfd5d550e72fbc9aae232b106"],[82876,5,"87f35d4527f8f588285e893b8b852ab886f84802d9bf534e82c37729c36d545e"],[90392,4,"9366db618ad421c0a99a0749bd523ac86010feb1cdcccf9dfbc77ea665bc97e5"],[90447,10,"4d816dbd225a212c221ba5dbfdbb07b8e9417c4ae5e771b530a7e888558e74e1"],[90582,4,"3ad0cc10602e64a908f5ed7d70a585e29f1532d32f53477a33b3f131d130689a"],[90670,1,"5d5c7d20a3aab9c158f23304df4bec3bd9d56c517db3caeaa519d4d05624d7a0"],[90677,6,"6f903bfb36140a3d7f9c916e2bfe74caa3d8fc3fb899289732d2ccaf13809db4"],[90759,10,"4d816dbd225a212c221ba5dbfdbb07b8e9417c4ae5e771b530a7e888558e74e1"],[90905,4,"3ad0cc10602e64a908f5ed7d70a585e29f1532d32f53477a33b3f131d130689a"],[91003,1,"5d5c7d20a3aab9c158f23304df4bec3bd9d56c517db3caeaa519d4d05624d7a0"],[91010,6,"6f903bfb36140a3d7f9c916e2bfe74caa3d8fc3fb899289732d2ccaf13809db4"],[224122,21,"f6147924abdc8919f1d435796e328f8fd780eff4637b79a8372016abb26d31c0"],[224180,17,"3b7ad4810a953911b3d879f28ad7abafee784136873f439f8166f4023dfa2e44"],[224221,5,"1cb3e8b3cdbc8a2934cd6f884d8e857015504515b312ac2a98a58a0bbb5476f1"],[239973,12,"7fca4dc35167ceededb32c867b49dee3a759e52e85533c8079879d82a160f4be"],[240078,14,"7d62e1714c3980f541d85b7a0b93f7513ab4996ae5b0bc3ac45aa990da601ca1"]];
// Adapter-owned signature/state helpers, assembled from reference/multi-font/state.s.
// Missing/invalid old-save state defaults to Advance; Config can save Normal.
const multiFontStateCode='CMIgrSQdyU1G0BriIK0mHckB0Ax7rScdyQLwDckA8Al7qQKABOIggPcoqmsIwiAp/wBIqU1GjSQdqQEAjSYdaCkCAOIgjScdKGs=';
function multiFontAssert(ok){if(!ok)throw failure('verifyFail');}
function multiFontWord(n){return [n&255,n>>>8&255];}
function multiFontFar(n){return [n&255,n>>>8&255,n>>>16&255];}
function multiFontReadWord(b,a){return b[a]|b[a+1]<<8;}
function multiFontPatchRecords(patch){
    multiFontAssert(patch.length===multiFontSpec.size && patch[0]===80&&patch[1]===65&&patch[2]===84&&patch[3]===67&&patch[4]===72);
    let p=5;const result=[];
    while(p+3<=patch.length && !(patch[p]===69&&patch[p+1]===79&&patch[p+2]===70)){
        multiFontAssert(p+5<=patch.length);
        const at=patch[p]*65536+patch[p+1]*256+patch[p+2],n=patch[p+3]*256+patch[p+4];p+=5;
        let data;
        if(n){multiFontAssert(p+n<=patch.length);data=patch.slice(p,p+n);p+=n;}
        else{multiFontAssert(p+3<=patch.length);const count=patch[p]*256+patch[p+1];data=new Uint8Array(count).fill(patch[p+2]);p+=3;}
        multiFontAssert(data.length>0 && at+data.length<=0x50000);result.push([at,data]);
    }
    multiFontAssert(p+3===patch.length);return result;
}
async function applyMultiFont(base,patch,edition){
    multiFontAssert(base.length===0x400000 && ['regular','spanish','es','moleman','twue'].includes(edition));
    multiFontAssert(patch instanceof Uint8Array && await hash(patch)===multiFontSpec.sha);
    for(const [a,e]of [...multiFontRegions,...multiFontNearRegions])multiFontAssert(base.subarray(a,e).every(v=>v===255));
    for(const [at,n,digest]of multiFontGuards)multiFontAssert(await hash(base.subarray(at,at+n))===digest);
    const records=multiFontPatchRecords(patch),donor=base.slice(),out=base.slice();
    donor.fill(0,0x49cb0,0x4b9b0);donor[0x4ad06]=255;
    for(const [a,b]of records)donor.set(b,a);
    const blob=donor.slice(0x49cb0,0x4b9b0);multiFontAssert(await hash(blob)===multiFontSourceHash);
    for(const [a,b]of records){
        if(a<0x10000 && a!==0xbdf1)out.set(b,a);
        else if(a>=0x10000&&a<0x20000)out.set(b,a-3);
        else if(a>=0x36b1b&&a<0x36b83)out.set(b,a+0x5f);
        else if(a>=0x3a8d5&&a<0x3a94c)out.set(b,a+0x90);
    }
    const normal=base.slice(0x47fc0,0x4a4c0),advance=normal.slice();advance.set(blob,0x800);
    if(['moleman','twue'].includes(edition))for(const code of [0xd0,0xd1,0xd2,0xeb,0xec])advance.set(normal.subarray(code*16,code*16+16),code*16);
    const spanish=edition==='spanish'||edition==='es';
    if(spanish){
        for(const code of [0xc3,0xc8,0xc9,0xca,0xce,0xcf,0xd0,0xd1,0xd2])advance.set(normal.subarray(code*16,code*16+16),code*16);
        const keep=new Set([0x63,0x68,0x69,0x6a,0x6d,0x6e,0x6f,0x70,0x71,0x72,0x74,0x75,0x76]);
        for(let code=0;code<256;code++)if(code<32||code>=128||keep.has(code)){
            advance[0x1000+code]=normal[0x1000+code];
            if(code>=32){const at=0x1100+(code-32)*22;advance.set(normal.subarray(at,at+22),at);}
        }
    }
    out.set(normal,0x330000);out.set(advance,0x332800);
    for(const at of [0x6af3,0x8b94,0x8bef,0x8c2f,0x8c44]){multiFontAssert(out[at]===0xc4);out[at]=0xf3;}
    out.set([0x1000,0x3800,0x1100,0x3900,0x0b40,0x3340,0,0x2800,0x800,0x3000].flatMap(multiFontWord),0x8ae7);
    const get=[0x22,...multiFontFar(0xf3d000)],same=(at,bytes)=>bytes.every((v,i)=>out[at+i]===v);
    for(const at of [0x8b97,0x8bc8,0x8bf4,0x8c32,0x8c47]){multiFontAssert(same(at,[0x7b,0xad,0x1f,0x1e]));out.set(get,at);}
    multiFontAssert(same(0x6aee,[0xad,0x1f,0x1e,0xaa]));out.set(get,0x6aee);
    multiFontAssert(same(0x8bd9,[0x7b,0xe2,0x20,0xad,0x1f,0x1e]));out.set([0xe2,0x20,...get],0x8bd9);
    multiFontAssert(same(0x8c57,[0xad,0x1f,0x1e,0xc2,0x20,0xaa]));out.set([...get,0xc2,0x20],0x8c57);
    out.fill(0xea,0x8bb7,0x8bba);
    for(const [at,bytes]of [[0x8c1a,[0x20,0xfb,0x6b]],[0x8c27,[0x20,0xd1,0x6b]]]){multiFontAssert(same(at,bytes));out.fill(0xea,at,at+3);}
    for(const at of [0x14067,0x140e1,0x143c5]){multiFontAssert(out[at]===0xc4);out[at]=0xf3;}
    // Append to the current Config tables; MusicConfig2 already owns row9.
    const count=base[0x3386c];multiFontAssert([9,10].includes(count));
    multiFontAssert(base[0x33862]===0xa0&&base[0x3233f]===0x7c&&base[0x33d41]===0x7c&&base[0x3393c]===0x20);
    const ptrs=[0x33863,0x32340,0x33d42].map(a=>0x30000+multiFontReadWord(base,a));
    const entries=[0x2960+0x1000*count,0x2342,0xffbb];let table=0x3fca8;
    for(let i=0;i<3;i++){
        const data=[...base.subarray(ptrs[i],ptrs[i]+2*count),...multiFontWord(entries[i])];
        if(count===10&&i===0)for(let p=0;p<data.length;p+=2)data.splice(p,2,...multiFontWord(multiFontReadWord(data,p)-0x800));
        out.set(multiFontWord(table&65535),[0x33863,0x32340,0x33d42][i]);out.set(data,table);table+=data.length;
    }
    // Eleven Config rows fit by moving BG1 text/cursors up8pixels and extending
    // its native clipping window down8. Both pages retain their256pixel gap.
    if(count===10){
        for(const [at,value]of [[0x339ec,0x00fb],[0x339f7,0xfffb],[0x33a3a,0xfffb]]){
            multiFontAssert(multiFontReadWord(base,at)===value);out.set(multiFontWord(value+8),at);
        }
        multiFontAssert(base[0x33888]===0xa0);const page2=0x30000+multiFontReadWord(base,0x33889);
        for(let at=page2;at<page2+12;at+=2)out.set(multiFontWord(multiFontReadWord(base,at)-0x800),at);
        multiFontAssert(same(0x33a7b,[39,255,255,80,8,247,80,8,247,16,255,255,0]));out[0x33a7b]=31;out[0x33a7e]=88;out[0x33a81]=88;out[0x33a84]=8;
    }
    multiFontAssert(table<=0x3fd00);out[0x3386c]=count+1;
    multiFontAssert(base[0x322d1]===0xc9&&base[0x33a41]===0xa9);out[0x322d2]=count;out[0x33a42]=count;
    const strings=spanish?new Uint8Array([...multiFontWord(0x3e0f),0x85,0xae,0x9e,0xa7,0xad,0x9e,0,...donor.subarray(0x3f0ec,0x3f0ff)]):donor.slice(0x3f0e5,0x3f0ff);
    const starts=[0,spanish?9:7,spanish?18:16];
    for(const at of starts)strings.set(multiFontWord(multiFontReadWord(strings,at)+(count-9)*0x80),at);
    // A37C's FF bytes are the native Equip erasure string, not free space.
    // Split these labels between the already reserved table and code tails.
    multiFontAssert(table+starts[1]<=0x3fd00);out.set(strings.subarray(0,starts[1]),table);out.set(strings.subarray(starts[1]),0x3ffe5);
    const fontPtr=table&65535,normalPtr=0xffe5,advancePtr=normalPtr+starts[2]-starts[1],code=donor.slice(0x3f0ff,0x3f139);
    const mapping=new Map([[0xf139,0xfee4],[0xf122,0xffce],[0xf0e5,fontPtr],[0x02f9,0x02fa],[0x0ea3,0x0ea4],[0x6b13,0x6b72],[0x6b37,0x6b96],[0x40ea,0x40eb],[0x3a87,0x3a88]]);
    for(const i of [1,8,11,14,17,28,33,44,47,50,53,56]){
        const old=multiFontReadWord(code,i),value=i===1?multiFontReadWord(base,0x3393d):mapping.get(old);
        multiFontAssert(value!==undefined);code.set(multiFontWord(value),i);
    }
    multiFontAssert(code[35]===0x8d&&code[36]===0x1f&&code[37]===0x1e);code.set([0x20,...multiFontWord(0xff37)],35);
    out.set(code,0x3ffab);out.set(multiFontWord(0xffab),0x3393d);
    const select=[...donor.subarray(0x3f139,0x3f147)],normalSelect=[...donor.subarray(0x3f147,0x3f150)];
    select.splice(0,3,0x20,...multiFontWord(0xff32));select[4]=10;select.splice(8,2,...multiFontWord(0xfd7b));select.splice(-2,2,0x4c,...multiFontWord(0xfd84));
    normalSelect.splice(3,2,...multiFontWord(0xfd7b));normalSelect.splice(-2,2,0x4c,...multiFontWord(0xfd84));out.set([...select,...normalSelect],0x3fee4);
    const labels=donor.slice(0x3f150,0x3f162);labels.set(multiFontWord(normalPtr),3);labels.set(multiFontWord(0x02fa),6);labels.set(multiFontWord(advancePtr),12);labels.set(multiFontWord(0x02fa),15);out.set(labels,0x3fd7b);
    out.set([0x22,...multiFontFar(0xf3d000),0x60,0x22,...multiFontFar(0xf3d02c),0x60],0x3ff32);out.set(from64(multiFontStateCode),0x33d000);
    const undo=[],skip=i=>multiFontRegions.some(([a,e])=>i>=a&&i<e)||(i>=0xffdc&&i<0xffe0);
    for(let i=0;i<base.length;){
        if(base[i]===out[i]||skip(i)){i++;continue;}
        let end=i+1;while(end<base.length&&base[end]!==out[end]&&end-i<65535&&!skip(end))end++;
        undo.push(...multiFontFar(i),...multiFontWord(end-i),...base.subarray(i,end));i=end;
    }
    multiFontAssert(undo.length<=0x1000);out.set(patch,0x338000);out.set(undo,0x33c000);
    const meta=new Uint8Array(48);meta.set(new TextEncoder().encode('MF141V01'));
    const view=new DataView(meta.buffer);view.setUint32(8,patch.length,true);view.setUint32(12,undo.length,true);
    const baseHash=await hash(base);meta.set(baseHash.match(/../g).map(v=>parseInt(v,16)),16);out.set(meta,0x33b000);
    writeChecksum(out);return out;
}
async function restoreMultiFont(data){
    multiFontAssert(data.length===0x400000 && new TextDecoder().decode(data.subarray(0x33b000,0x33b008))==='MF141V01');
    const view=new DataView(data.buffer,data.byteOffset+0x33b000,48),plen=view.getUint32(8,true),ulen=view.getUint32(12,true);
    multiFontAssert(plen===multiFontSpec.size && ulen<=0x1000);
    const patch=data.slice(0x338000,0x338000+plen);multiFontAssert(await hash(patch)===multiFontSpec.sha);
    const out=data.slice();let p=0x33c000;
    while(p<0x33c000+ulen){
        multiFontAssert(p+5<=0x33c000+ulen);
        const at=data[p]+256*data[p+1]+65536*data[p+2],n=multiFontReadWord(data,p+3);p+=5;
        multiFontAssert(n>0&&at+n<=out.length&&p+n<=0x33c000+ulen&&!multiFontRegions.some(([a,e])=>at<e&&at+n>a));
        out.set(data.subarray(p,p+n),at);p+=n;
    }
    for(const [a,e]of multiFontRegions)out.fill(255,a,e);
    writeChecksum(out);const expected=Array.from(data.subarray(0x33b010,0x33b030),v=>v.toString(16).padStart(2,'0')).join('');
    multiFontAssert(await hash(out)===expected);return {base:out,patch};
}
