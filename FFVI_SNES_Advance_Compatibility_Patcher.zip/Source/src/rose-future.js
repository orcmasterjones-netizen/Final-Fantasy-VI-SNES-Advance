// ROSE's adaptive text contains encoded RAM operations. New wording is admitted
// only when the existing per-caption control structure stays identical. All
// other ROM bytes remain covered by registered protected-layout SHA-256 hashes.
// Public data below contains hashes and boundaries, never upstream dialogue.
const roseFutureData = {"controls":{"donor":"96a3a8209659572d5ddb6eaa1d6ff64d919b36ff961abe06ce7eb7f3bac7eee7","merged":"c57c27bd233ed3546bbf9129a2301c439cbd420f8ef0e2457d26d0a81fb61459"},"textHashes":{"donor":"968ce659b4b3c1f9655d4741d7d2dca8f8ea01d99a18e4b92e6e8205bf0fd528","merged":"e734b44f9d9f99ff80d8f271d052b8d319bdb2643b5ce309eddfe15735dadb8f"},"aliases":{"donor":{"89acdbec5e6411cf467598c4ecd53b10bc8b9ec7167582633c14b6ef144632fb":"332e700b91d851db06a758eff42b1875d22765cb8e6851379ae59e97855360fc"},"merged":{"9a0246b87c9c4688cec31c204a15dc72368cc63988b8d66258af3cffbbc0083b":"844c3e8848e1e94d70678931d115dc0d8d427477a7aab30fa8387d600085ceb8","bdab906e5715c83a9bedcff93924df7b5a78a0cc6a82c0aa3d5cc56a0c66165e":"c5b9f4bd8e666af613f49b15c14c0f7acb5e106af29a7faa9b89fe40a6131c9b","3c51ba89343e8ee3264bedf2cbde471e5c30cb551a37c6f82122a365def14caf":"c2de12df021d9728e5026a38c83e70f6a84419a95c6b470b722489abf4cb2859"}}};
function roseFutureKind(bytes){
    if(bytes.length!==0x400000&&bytes.length!==0x800000)return null;
    const threshold=[0x85,0x04,0xcd,0xcd,0x08,0xce,0xff,0xff,bytes.length===0x800000?0x70:0xf0];
    if(!threshold.every((v,i)=>bytes[0xdf80+i]===v))return null;
    return bytes.length===0x800000?'merged':'donor';
}
function roseFutureRanges(kind){
    const ranges=[[0xffdc,0xffe0],[0xce602,0xcf79c],[0xd0000,0xef100]];
    return kind==='merged'?[...ranges,...ranges.map(([a,b])=>[a+0x400000,b+0x400000])]:ranges;
}
async function roseFutureFingerprint(bytes,kind,digest=rawHash){
    const masked=bytes.slice();for(const[a,b]of roseFutureRanges(kind))masked.fill(0,a,b);
    return digest(masked);
}
function roseFutureControlTokens(bytes,kind){
    const fail=()=>{throw failure('roseFutureLayout');};
    if(roseFutureKind(bytes)!==kind||bytes[0xce600]!==0x85||bytes[0xce601]!==0x04)fail();
    if(kind==='merged')for(const[a,b]of roseFutureRanges('donor'))if(a!==0xffdc){
        if(!bytes.subarray(a,b).every((v,i)=>bytes[a+0x400000+i]===v))fail();
    }
    const records=[];let total=0;
    for(let id=0;id<2253;id++){
        const at=0xce602+id*2,bank=id<1157?0xd0000:0xe0000;
        let p=bank+bytes[at]+256*bytes[at+1],end=false,glyph=false,used=0;
        if(p<0xd0000||p>=0xef100)fail();
        const tokens=[];
        while(p<0xef100&&used<65536){
            const value=bytes[p++];used++;total++;if(total>0x100000)fail();
            if(value===0){tokens.push(0);end=true;break;}
            if(value===0x11||value===0x14||value===0x16){
                if(p>=0xef100)fail();tokens.push(value,bytes[p++]);used++;total++;glyph=false;continue;
            }
            if(value>=0x20&&value<0x54||value>=0x80){
                // A marker records a contiguous displayed-letter/DTE run. Its
                // length may change, but inserting text into encoded control
                // arguments splits a run and changes the guarded signature.
                if(!glyph)tokens.push(256);glyph=true;
            }else{tokens.push(value);glyph=false;}
        }
        if(!end)fail();records.push(tokens);
    }
    return records;
}
async function validateRoseFutureDialogue(bytes,kind,digest=rawHash){
    const tokens=roseFutureControlTokens(bytes,kind);
    const id=await digest(new TextEncoder().encode(JSON.stringify(tokens)));
    if(id!==roseFutureData.controls[kind])throw failure('roseFutureLayout');
    return true;
}
async function roseFutureAlias(bytes,actualId,digest=rawHash){
    const kind=roseFutureKind(bytes);if(!kind)return actualId;
    const aliases=roseFutureData.aliases[kind];
    if(Object.values(aliases).includes(actualId))return actualId;
    const fingerprint=await roseFutureFingerprint(bytes,kind,digest),canonical=aliases[fingerprint];
    if(!canonical)return actualId;
    await validateRoseFutureDialogue(bytes,kind,digest);
    return canonical;
}
async function roseFutureTextHash(bytes,digest=rawHash){
    const data=new Uint8Array(0xcf79c-0xce602+0xef100-0xd0000);
    data.set(bytes.subarray(0xce602,0xcf79c));data.set(bytes.subarray(0xd0000,0xef100),0xcf79c-0xce602);
    return digest(data);
}
async function roseFutureInfo(bytes){
    if(roseFutureKind(bytes)!=='merged')return null;
    const actualSha=await rawHash(bytes),canonicalId=await roseFutureAlias(bytes,actualSha,rawHash);
    if(!Object.values(roseFutureData.aliases.merged).includes(canonicalId))return null;
    const textHash=await roseFutureTextHash(bytes);
    return {untested:textHash!==roseFutureData.textHashes.merged,verifiedVersion:'2.04',actualSha,canonicalId};
}
async function applyRoseFutureDialogue(out,donor){
    await validateRoseFutureDialogue(donor,'donor');
    const text=donor.slice(0xd0000,0xef100);
    const encoded=word=>Array.from(word.toString(16).padStart(4,'0'),n=>0x54+parseInt(n,16));
    const edits=[[0x1ff7,0x1dd6,52],[0x1ff8,0x1dd7,44],[0x1ff9,0x1dd8,59],[0x1ffa,0x1dd9,38],
        [0x1ffb,0x1dd6,1],[0x1ffc,0x1dd7,1],[0x1ffd,0x1dd8,1]];
    for(const[old,next,expectedCount]of edits){
        const before=encoded(old),after=encoded(next);let count=0;
        for(let p=0;p<=text.length-4;p++)if(before.every((v,i)=>text[p+i]===v)){
            if(p===0||![0x55,0x56,0x79,0x7a].includes(text[p-1]))throw failure('roseFutureLayout');
            if(old>=0x1ffb&&(text[p-1]!==0x7a||text[p+4]!==0x54||text[p+5]!==0x54||text[p+6]!==0x7e))throw failure('roseFutureLayout');
            text.set(after,p);count++;p+=3;
        }
        if(count!==expectedCount)throw failure('roseFutureLayout');
    }
    for(const mirror of [0,0x400000]){
        out.set(donor.subarray(0xce602,0xcf79c),mirror+0xce602);
        out.set(text,mirror+0xd0000);
    }
    await validateRoseFutureDialogue(out,'merged');
}
