// A reversible final layer: menu layout, GBA job labels, the Bushido title
// terminator and the shared Continue save-loading hook.
const jobWriter='CMIgpWeouQAAKT8ACgoKCqriIKCLnoyBIaAOAL8AyfuNgCHoiND1nIAhKGs=';
const gbaJobNames=['Magitek Elite','Adventurer','Samurai','Assassin','Machinist','Monk','Rune Knight','Blue Mage','Pictomancer','Gambler','Moogle','Feral Youth','Mime','Yeti','Oracle','General','Ghost','Soldier'];
function applyMenuPolish(base,edition) {
    const out=base.slice();
    // The inherited Continue hook overwrote the BEQ displacement with JSR.
    // Restore BEQ +6 and place the expanded-save call on its instruction boundary.
    if(![0xf0,0x20,0x65,0xfd,0x15].every((v,i)=>out[0x3150d+i]===v))throw failure('verifyFail');
    out.set([0xf0,0x06,0x20,0x65,0xfd],0x3150d);
    if(out[0x3fb47]!==255)throw failure('verifyFail');
    out[0x3fb47]=0;
    if(edition==='twue') {
        // TWUE's menu sprite table uses retail character-art addresses.
        // SNES Advance moved these first 18 graphics blocks forward $140.
        for(let i=0;i<18;i++) {
            const at=0xff9d1+i*4;
            const ptr=(out[at]<<16)|(out[at+3]<<8)|out[at+2];
            const expected=i===17?0xd67e20:0xd4fec0+i*0x16a0;
            if(ptr!==expected || out[at+1]!==0)throw failure('verifyFail');
            const fixed=ptr+0x140;
            out[at]=fixed>>>16;out[at+2]=fixed&255;out[at+3]=(fixed>>>8)&255;
        }
    }
    if(edition==='moleman') {
        if(!out.subarray(0x3bc800,0x3bcd00).every(v=>v===255) || !out.subarray(0x3ff50,0x3ff70).every(v=>v===255))throw failure('verifyFail');
        out.set(from64(jobWriter),0x3bc800);
        const encode=text=>Array.from(text,ch=>ch===' '?255:128+alphaNumeric.indexOf(ch));
        out.fill(255,0x3bc900,0x3bcd00);
        gbaJobNames.forEach((name,i)=>out.set(encode(name),0x3bc900+i*16));
        const edits=[
            [0x334af,[0xe6,0x34],[0x50,0xff]],
            [0x3ff50,Array(7).fill(255),[0x22,0x00,0xc8,0xfb,0x4c,0x35,0x80]],
            [0x3ff60,Array(7).fill(255),[0x20,0x1a,0x35,0x20,0x50,0xff,0x60]],
            [0x360b2,[0xe6,0x34],[0x60,0xff]],
            [0x360af,[0x9d,0x39],[0xdd,0x39]]
        ];
        for(const at of [0x33308,0x33354,0x333a0,0x333ec]){
            const value=out[at]|out[at+1]<<8;
            edits.push([at,[out[at],out[at+1]],[(value+0x32)&255,(value+0x32)>>8]]);
        }
        for(const [at,before,after]of edits){if(!before.every((v,i)=>out[at+i]===v))throw failure('verifyFail');out.set(after,at);}
    }
    // Skills keep the original aligned LV/HP/MP and equipped-Esper rows.
    // Suppress only this screen's no-status job title. The shared routine still
    // draws KO text and status icons; main-menu and Status job labels remain.
    if(edition==='moleman'||edition==='twue') {
        const wrapper=[0x5a,0xa4,0x67,0xb9,0x14,0x00,0x29,0xf7,0xd0,0x0d,
            0xb9,0x15,0x00,0x29,0x80,0xd0,0x06,0x7a,0xa9,0x20,0x85,0x29,
            0x60,0x7a,0x4c,0x28,0x34];
        if(!out.subarray(0x3ff90,0x3ff90+wrapper.length).every(v=>v===255) ||
            ![0x20,0x28,0x34].every((v,i)=>out[0x34ef4+i]===v))throw failure('verifyFail');
        out.set(wrapper,0x3ff90);out.set([0x20,0x90,0xff],0x34ef4);
        // TWUE's full-length Espers need their own row in the native font.
        // Keep the name on row one and align LV/HP/MP below it. Its KO caption
        // belongs beside the status icons, not in the old class-title border.
        if(edition==='twue') {
            // Add-Ons moves three header fields before drawing its new lists.
            // Normalize that exact layout, then use the shared aligned header.
            const addonCoordinates=[[0x34eef,[0x1d,0x42],[0xdd,0x41]],
                [0x35d21,[0x9d,0x42],[0x37,0x42]],[0x34f13,[0xa5,0x42],[0x41,0x42]]];
            if(addonCoordinates.every(([at,before])=>before.every((v,i)=>out[at+i]===v)))
                for(const [at,,after]of addonCoordinates)out.set(after,at);
            if(out[0x34eef]!==0xdd||out[0x34ef0]!==0x41)throw failure('verifyFail');
            out[0x34ef0]=0x42;
            if(out[0x35d21]!==0x37||out[0x34f13]!==0x41||
                out[0x34e89]!==10||out[0x34e8f]!==13||out[0x34e90]!==8)throw failure('verifyFail');
            out[0x35d21]=0x2d;out[0x34f13]=0x37;
            for(const at of [0x35d21,0x34f13,0x34f15,0x34f17,0x34f19,0x34f1b,0x35d26,0x35d2b,0x35d30,0x35d34]) {
                const value=out[at]|out[at+1]<<8;
                out[at]=(value+0x80)&255;out[at+1]=(value+0x80)>>8;
            }
            // Complete the MP row, then blank the unused bottom rows until
            // the list starts; this prevents a repeated heading or MP fragment.
            out[0x34e89]=11;out[0x34e8f]=12;out[0x34e90]=0x8c;
        }
    }
    // The native Equip/Relics option loops clear and redraw their captions on
    // every poll. Proportional uploads wait for VBlank, which made those loops
    // take several frames and miss short presses. Their initial menu builders
    // already draw the captions. Repaint only when returning from the shifted
    // slot/item screen (BG2 horizontal scroll $0100), then resume normal polling.
    // The font compositor keeps the visible captions' graphics allocated.
    if(generalMenuMarker.every((v,i)=>out[0x3fd880+i]===v)) {
        applyFontOptimization(out,edition);
        const equipLoop=edition==='twue'&&[0x20,0x75,0x96,0x20,0xb7,0x90].every((v,i)=>out[0x39687+i]===v)?0x39687:0x3968a;
        for(const [at,helper,draw]of [[equipLoop,0x3ffb0,0x90b7],[0x39f4b,0x3ffc0,0x90c5]]) {
            const before=[0x20,0x75,0x96,0x20,draw&255,draw>>>8];
            const code=[0xa4,0x39,0xf0,0x06,0x20,0x75,0x96,0x20,draw&255,draw>>>8,0x60];
            if(!before.every((v,i)=>out[at+i]===v) ||
                !out.subarray(helper,helper+code.length).every(v=>v===255))throw failure('verifyFail');
            out.set(code,helper);
            out.set([0x20,helper&255,(helper>>>8)&255,0xea,0xea,0xea],at);
        }
    }
    applySpellNameFix(out,edition);
    writeChecksum(out);return out;
}
async function identifyPolished(file) {
    if([0x800000,0x800200].includes(file.size)) {
        if(typeof identifyROSE!=='function')throw failure('unknown');
        return identifyROSE(file);
    }
    if(![4194304,4194816].includes(file.size))throw failure('wrongSize');
    const raw=new Uint8Array(await file.arrayBuffer()),bytes=raw.slice(raw.length-4194304);
    let id=await hash(bytes),entry=catalog.menuPolish?.inputs[id];
    if(!entry){writeChecksum(bytes);id=await hash(bytes);entry=catalog.menuPolish?.inputs[id];}
    if(!entry) {
        const input=await identifyUnpolished(file);
        // The menu fixes also apply with no optional font or gameplay changes.
        // Let a recognized unpolished ROM build with its detected choices.
        return {...input,upgrade:true};
    }
    for(const [at,data]of catalog.menuPolish.undo[entry.undo])bytes.set(from64(data),at);
    writeChecksum(bytes);
    if(await hash(bytes)!==entry.base)throw failure('verifyFail');
    const input=await identifyUnpolished(new File([bytes],file.name));
    return {...input,menuPolish:true,upgrade:!!input.upgrade||id!==catalog.menuPolish.targets[entry.base]};
}
async function combinePolished(input,selected,sources,settings) {
    if(input.profile.edition==='rose'||selected.has('rose')) {
        if(typeof combineROSE!=='function')throw failure('roseUnavailable');
        return combineROSE(input,selected,sources);
    }
    const output=await combineUnpolished(input,selected,sources,settings);
    const bytes=applyMenuPolish(output.bytes,output.profile.edition),id=await hash(bytes);
    if(catalog.menuPolish?.targets[output.id]!==id)throw failure('verifyFail');
    return {...output,bytes,id};
}

// FONT_OPTIMIZATION_BEGIN — generated by reference/font-optimization/build.py
const fontOptimizationEnabled=true;
const fontOptimizationSegments=[{start:0x3f7000,capacity:0x1000,before:nameRenderer,after:"TDNwTIhwTKxxTPJxTHtyTJlyTHt1TLV1TJx3TL13TPV3TAZ4TBl4TDl4TPVwTDlxTGdxCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG6+Jnn6FATjpGTmiAADJgAGQBumAAeiA9YoKhQUKZQVpQAKFBSDecKkGAIUHIHRzexhpKAAbK6t6+mgoawjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBuviZ5+GhqFAa/lAH4p/wDJDACQBekMAID2CoUFCgplBWkAAoUFIN5wqQwAhQcgdHN7GGkoABsrq3r6aChrpQUKCgoKGGkAUIUDqSAAhQmpAJaFC2AIwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbr+UAfin/AMkSAJAF6RIAgPYKCqq/ANj/hQW/Atj/hRuvWlXDKf8AhQeAWgjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBupdgKFBakIgIUbr/Y0wyn/AIUHgCwIwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbqW4ChQWpCICFG68hWsMp/wCFB6+Jnn6FASDecCB0c3sYaSgAGyurevpoKGt7S/S3cfQrAFxXTsFL9MJx9CsAXK5mwQjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBup7VqFAamyAIUFqQoAhQepMACFGYBFqQFL9P5x9CsAXFdOwUv0CXL0KwBcrmbBCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG6mjW4UBqdYAhQWpBgCFB6kcAIUZqQQAhRupIPeFC6kQAIUJpQUKCgoYaQBAhQMgdHOlBRhlB6YH4AoA0AE6hQWlARhlGYUBxhvQ2HsYaSgAGyurevpoKGsIwiAp/ABI4iC9llspAwMBnZZb6OjGEtDwwiBoKGuM8PepAY3I70v0q3L0KwBcBE7BS/S2cvQrAFyoY8GcyO8IwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbogAAhhegAADiIL8AzPPZlV7QDMjI6MAaANDvwiCAEMIgpRcYaRAAquDwENDWgFut8PfJGQCQBekZAID2ogAAyQUAkAfpBQDo6ID0v2pz/4UFpRcKCoUVCmUVGp3g96KXXqAAAL0AACkA/AUFhRWYGGUVwAoAkAilFSkA/An/A50AAOjoyMAMANDaexhpKAAbK6t6+mgoa4AAigCUAJ4AqABkDWQPpQcKCgqFHaYBpAe9AAAp/wDJ/wDQBujoiNDwYKUHGhqFFaULqqQJqQAAnQAA6OiIiND3xhXQ7qUPCmUBqr0AACn/AIUXqr8Ab/8p/wCFFaUNKQcACqq/8Xj/hROlFwoKCgoKChh/4Xj/hRGlDUpKSgoKCgqkCcAgANABChhlC6qgAAC3ER0AAJ0AAOjoyMiYKQ8A0O7AMADwD6UJyRAA8OKKGGkQAKqA2qUNGGUVhQ3mD6UPxQfwJKUNxR2QGqYPigoYZQGouQAAKf8Ayf8A0Aro5AfQ6oAETK9zYKUJyRAA0B2lBckAA5AGIoHR/YA9ye4AkAYia9P9gDIgNnWALaUbEBKlB0ilGyn/f4UHIGV4aIUHgBelB8kMANANxgfGByBleOYH5geAAyBleKYBoAAAvQAAKQD8BQWFF5gYZRfapgngEADwLEilGxASKf9/hRVoxBWQWCkA/An/AIBQaKYH4AwA0EjACgCQQykA/An/AIA7pgdIpQXJAANokBBIpQXJZANokArABgCQIoAITBd1wAoAkBgpAPwJ/wOAEOAKANALwAkA0AYpAPwJ/wP6nQAA6OjIxAfwA0yqdGCiAAClBd98d//wBOjogPSeAPeGF6UFOOmyAAoKCgoYaQDzqKYXv4x3/0qFFaYLvQAAmQAA6OjIyMYV0PKmF6kBAJ0A92Ai59H9IhW4/wjCIKkAAKIOAJ8A937KyhD4oggAn+D3fsrKEPipVkaPEPd+qQAAjxL3fiiiAGigAAhrCNqpfkirwiAiD7j/Iv7R/aIIAL2QYikAA8kAAdAJvZBiCQACnZBiysoQ6K0Q98lWRvADTHd3rRL3yRAAkHvJGACwdjjpEADrjRT3GGkA8I9yQwCtFPdKGGkARI8WIQCpAAGPdUMAqQEYj3BDAO4S960S98kYANAGqQMAjRL34iCp0o90QwCpgI8VIQCpgI8LQgDCIK0U9xhpADiPckMArRT3ShhpAGyPFiEAqQABj3VDAOIgqf9MZ3fJIACwGMkAAPBoyQIA0GCti3sp/wDQWKkgAI0S960S9ykHAOuNFPcYaQBYj3JDAK0U90oYaQBsjxYhAKkAAY91QwCpARiPcEMA7hL3rRL3ySgA0AOcEvfiIKn/j3RDAKmAjxUhAKmAjwtCAMIggANMd3eiAAC9APfJAQDwQ+jo4BAA0PGiAAC94PfQCejo4AoA0PSAdDqPckMAnuD3v2pz/woKChhpAECPFiEAqaAAj3VDAKkBGI9wQwDiIKnzgDmeAPe/fHf/CgoKGGkAQI8WIQC/fHf/OOmyAAoKCgoYaQDzj3JDAKkBGI9wQwC/jHf/j3VDAOIgqX6PdEMAqYCPFSEAqYCPC0IA+iipfmuyALsAxADNANYA3ADiAOgAkACQAJAAkABgAGAAYABgAK0S98kD8A3JELAFqRCNEvdcH0rBqQGNEvd7qqlMXMpVwUv0x3f0KwBc+0DBS/TSd/QrAFwbQcEIwiCpAQCiDgCdAPfKyhD5oggAnuD3ysoQ+akCAI0S9yhrkUyp/5FKyKVOCQKRTJFKyGvCIAkAApFTpVUJAAKRUeIgyMhri6kASKuOFiHCIKnuAeAAeJADCQACjRghiND6e+Igq2sIwiBI2qIAAL0/5ykAA8kAAdAJvT/nCQACnT/n6OjggADQ5fpoKKKAAIYQawjiIK8E+n7QGq8SQgAQ+q8/IQCvNyEArz0hAMn2sOrJ3JDmeKIGAL8AQwBIyhD4qYCPFSEAwiClA48WIQCpARiPAEMApQuPAkMApQcKCgoKpgngIADQAQqPBUMA4iCpfo8EQwCpAY8LQgCiAABonwBDAOjgBwDQ9cIgKGAAQACAAMAAwACAAMAAgADA9wD3APcA+AD5APkA+gD6AABwAKAAUACQAMAAIABQAKD7APsA/AD8APwA/QD9AP0AIHRzawjiIK8E+n7QGq8SQgAQ+q8/IQCvNyEArz0hAMn2sOrJ3JDmeKIGAL8AQwBIyhD4qYCPFSEAwiClA48WIQCpARiPAEMApQuPAkMApQcKCgoKpgngIADQAQqPBUMA4iCp9o8EQwCpAY8LQgCiAABonwBDAOjgBwDQ9cIgKGA=",edition:null},{start:0x3fb800,capacity:0x2000,before:numberRenderer,after:"TCS4TIC4TL64TCO5TI+5TIG/TDC/TGq/TOTATA7BTCbBTDPBhuupfoXtu6AAALX3l+vIpSmX68jo5ODQ8QjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBuYSoUdr+sAfoUBqQAAhRsgZcAg2sGwBiA9uiDRwnsYaSgAGyurevpoKGtL9Iq49CsAXK5owbVpS/SXuPQrAFzwZsHo4AQA0O0IwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbqQQAhR2APEv0yLj0KwBcxmjBtWpL9NW49CsAXPBmwejgAwDQ7QjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBupAwCFHZgYb0wAfoUBpR0KhRWlATjlFYUBqQEAhRsgPbp7GGkoABsrq3r6aChrS/QtufQrAFz0Y8FkQLJPOOkKkATmQID3GGkKhUGlQNACqUsYabRL9FO59CsAXPtjwaVBBUDQBKn/gAWlQRhptEv0bbn0KwBc+2PBCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG6kCAIUdTBS6S/SZufQrAFz0Y8FkQGRBsk846WSQBOZAgPcYaWQ46QqQBOZBgPcYaQpIpUDQAqlLGGm0S/TMufQrAFz7Y8GlQQVA0ASp/4AFpUEYabRL9Oa59CsAXPtjwWgYabRL9PW59CsAXPtjwQjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBupAwCFHZgYb1MAfoUBpR0KhRWlATjlFYUBqQEAhRsgPbp7GGkoABsrq3r6aChrZCGlHdABYMkJAJABYKYBpB29AAAp/wDJ/wDwDMm0ALABYMm+AJABYOjoiNDkpR2FH6YBvQAAKf8Ayf8A0Afo6MYf0O9gpR8KGGUfCoUVGGkHAEpKSoUHCgoKOOUVhQ2lHTjlB4UZpRvQY6kgAIUJqQCWhQulHckCAPAFyQMA0CGlAcnJd5AapR0KGGUBqiA9w5AOpR2FB2QZCgoKOOUVhQ2lHckCANAvpQHJyXeQKDo6qiA9w5AgqQIAhSGp//+FGakGAIUNqQMAhQeACqkQAIUJqSD3hQulG/ADTKm7pR3JBADwA0ypu6UBOjqqvQAAKf8DSCn/AMnAAPAfaDjp0AHJUACwZgqqvQD5yQEA0Fy9APgaGsUB0FOAAWilH8kEAJAg5iGp//+FGakGAIUNpR8aChhlHxoKGGkHAEpKSoUHgClkGakDAIUHpR8KGGUfCoUNqRYAOOUNhQ2lATo6qr0AACkA/AnAAJ0AAKUhyQIA0BilATo6qr0AACn/AzjpoAHJoACwBKqeAPgggb6QAWClHTjlH4UPpQcahRWmC6kAAJ0AAJ0CAJ0EAJ0GAJ0IAJ0KAJ0MAJ0OAKQJwBAA8BidEACdEgCdFACdFgCdGACdGgCdHACdHgCKGGUJqsYV0L2lIdADTL68pgulIckCAPA6rwBw950AAK8CcPedAgCvBHD3nQQArwZw950GAK8IcPedCACvCnD3nQoArwxw950MAK8OcPedDgCAOK9AcPedAACvQnD3nQIAr0Rw950EAK9GcPedBgCvSHD3nQgAr0pw950KAK9McPedDACvTnD3nQ4ApQ8KGGUBqr0AACn/AMn/ANAL5g+lD8Ud0OZMub2lDwoYZQGqvQAAKf8AhRelDSkHAAqqv/F4/4UTpRcKCgoKCgoYf+F4/4URpQ1KSkoKCgoKpAnAIADQAQoYZQuqoAAAtxEdAACdAADIyLcRHQIAnQIAyMi3ER0EAJ0EAMjItxEdBgCdBgDIyLcRHQgAnQgAyMi3ER0KAJ0KAMjItxEdDACdDADIyLcRHQ4AnQ4AyMiKGGUJqrcRHQAAnQAAyMi3ER0CAJ0CAMjItxEdBACdBADIyLcRHQYAnQYAyMi3ER0IAJ0IAMjItxEdCgCdCgDIyLcRHQwAnQwAyMi3ER0OAJ0OAMjIpQ0YaQYAhQ3mD6UPxR3wA0y+vKUb0BalBQoKCgoYaQBthQMgPsHwMCBleIArnP7vpQUKCgoKGGkA8KimC6UHCgoKhRW9AACZAADo6MjIxhXQ8qkBAI3+76YBvQAAKQD8hRUJ/wCkG/ADCQADpB2dAADo6IjQ+KUZChhlAYUBZA+lBRhlD6ogX74FFaQBmQAAigqqmKQb0BGdAPipAACkD9ACpSGdAPmAA50A7+YB5gHmD6UPxQfQyGClG9AUpQHJyXeQB4oKGGmgAWCKGGnQAWDaigqqvwXA//pgZBeiAAClG9AmrQL68Bav5QB+Kf8AyQwAkAXpDACA9gqFBRhgrQD6yQEA0AOiGADaigqqpRvQBb0A+IADvQDv+skAAPAyqKUb0BTAyXeQCIoKGGmgAYAQihhp0AGACdqKCqq/BcD/+oUDuQAAKf8DxQPQBGQXgA6lF9AChgXmF6UXxQfwKOilG9AZrQD68A/JAgDwBeAwAIAN4CAAgAjgUACAA+AoANCH7vzvOGAYYCLzzdQiEtn/CMIwSNqpAACi/gGfAPh+ysoQ+I/8736PAPp+jwL6fo8E+n6iLgCfEPp+ysoQ+PpoKGsIwjBI2qkAAKL+A58A737KyhD4+mgoawjCMEjaWq3+7/BWrRL30FGiAADgEADQCK3VZCn/ANBBv+e//48WIQC/6b//j3VDANqKSqq/+7//+o9yQwCpARiPcEMA4iCpfo90QwCpgI8VIQCPC0IAwiDo6Ojo4BAA0LJ6+mgoa3BHIAFAQIAA0EFgAMBDgAAAWIAAAPAg8aDxAPKA8u4A7wDwAPEA8gDzAPQA9QD2APcA+AD5APoA+wD8AP0A/gD/AAgACQAKAAsADAANAA4ADwA6ADsAPAA9AD4APwB4AHkAegB7AHwAfQB+AH8AAAMBAwIDAwMEAwUDBgMHA68mAH4p/wDJCQDwUMkKAPBLyRoAkAXJHwCQQckzAPA8yTQA8DfJPgDwMskHAPAoyQgA8CPJFwCQGckaAJAZyV4A8BTJZADwD8lxAPAKyXIA8AWpAACACKkBAIADqQIAzQD68BqNAPqi/gGpAACdAPjKyhD5oi4AnRD6ysoQ+WDCILfvqsAEAPAFwAgA0A2lKSn/AOsJwACf/v994iBL9AzB9Ib/XJEEw2upAY8C+n5L9B7B9Ib/XLcEw6kAjwL6fmupAY8E+n6pgI8AIQBrqQCPBPp+qQGFRGtkF6UFCqqkB70A+NAC5hfo6IjQ9KUFCgoKCqqkC6UHhQ+5AADdAPvwBZ0A++YXuQIA3QL78AWdAvvmF7kEAN0E+/AFnQT75he5BgDdBvvwBZ0G++YXuQgA3Qj78AWdCPvmF7kKAN0K+/AFnQr75he5DADdDPvwBZ0M++YXuQ4A3Q778AWdDvvmF4oYaRAAqpgYaSAAqMYP0IilF2CcBvpkIaUdyQIA8BvJAwDQE6UBycl3kAwYaQYAqiA9w5ACGGBMLsOlAcnJd7ADTC7DGGkEAKogPcOwFKUBOjqqID3DkAepAgCFIYADTC7D7gb6pQGNOvqqvQAAjTz6vQIAjT76ogAAvRD6xQHQeb0S+s08+tBxvRT6zT760Gm9Fvop/wOkAcDJd5AHOOmgAUqABDjp0AHJUACwTAqopSHJAgDQBqUBOjqAAqUB2QD40DYaGtkC+NAvpSHJAgDQCaUBGhrZBPjQH6QBpSHJAgDQCIiIvUD6mQQAvRb6mQAAvRj6mQIAOGCKGGkKAKrgKADwA0xBwhhgrQb68FeiAAC9EPrNOvrwDooYaQoAquAoANDtrjj6rTr6nRD6qKUhyQIA0AKIiK08+p0S+q0++p0U+rkAAJ0W+rkCAJ0Y+rkEAJ1A+ooYaQoAySgAkAOpAACNOPpgoigAqQAAnRD6ysoQ+RhgvQAAKf8DycEA8B046aAByaAAsBaJAQDQEaiK2QD40Aq5APnJAgDQAjhgGGA=",edition:null},{start:0x3fd900,capacity:0x1600,before:menuRenderer,after:"TE3ZTBLZTPnjTCvkTF7lTJ7lCMIwSNqpAACi7gOfAON+ysoQ+I+Q4n6PkuJ+j5zifo+g4n6PouJ+j6Tifo+m4n6PqOJ+j6rifvpoKGumAJvCIKfnhevm5+bn4iCpfoXtt+fwD1qbl+vom6Upl+voesiA7SJ72f9c+QLDCMIwSNpaiws7OOkoABtb4iCpfkirwiBkG1qEH6/rAH6FAclJOLADTDPayUlYkA3JSXiwA0wz2slJmLB8IBjfpR/wdckhALBwpgG9AAAp/wDJ/wDQCuYB5gHGH9DrgFlkB+YHpQfFH/AnChhlAaq9AAAp/wDJxwDwF8n/ANDjpQcaxR/wC70CACn/AMn/ANDRpQFIpQdIpR9IIETaaIUfaIUHaIUBpR845QeFH/AKpQcKGGUBhQGAkHog7OV7GGkoABsrq3r6aChr7pLipQeFHakBAIUjZCWmAaQdvQAAKf8AybQAkAzJvgCwB+joiNDrgAJkI2QNZA+lDwoYZQGqvQAAKf8AqiA03hhlDYUN5g+lD8Ud0OKlDRhpBwBKSkqFB6Uj8AylHYUHCgoKOOUNhSWlB8UdkAPwAWClAclJeLARqSAAhQmpAACFGanQAIUbgA+pEACFCanQAIUZqfgBhRsgZ96QBO6Q4mAgguOQA0y13akAloULpgulBxoahRWeAACeAgCeBACeBgCeCACeCgCeDACeDgClCckQAPAYnhAAnhIAnhQAnhYAnhgAnhoAnhwAnh4AihhlCarGFdDApSWFDWQPpQ8KGGUBqr0AACn/AIUXqiA03oUVpQ0pBwAKqr/xeP+FE6UXCgoKCgoKGH/heP+FEaUNSkpKCgoKCqQJwCAA0AEKGGULqqUJyRAA8ANMm9ygAAC3ER0AAJ0AAKACALcRHQIAnQIAoAQAtxEdBACdBACgBgC3ER0GAJ0GAKAIALcRHQgAnQgAoAoAtxEdCgCdCgCgDAC3ER0MAJ0MAKAOALcRHQ4AnQ4AoBAAtxEdEACdEACgEgC3ER0SAJ0SAKAUALcRHRQAnRQAoBYAtxEdFgCdFgCgGAC3ER0YAJ0YAKAaALcRHRoAnRoAoBwAtxEdHACdHACgHgC3ER0eAJ0eAKAgALcRHSAAnSAAoCIAtxEdIgCdIgCgJAC3ER0kAJ0kAKAmALcRHSYAnSYAoCgAtxEdKACdKACgKgC3ER0qAJ0qAKAsALcRHSwAnSwAoC4AtxEdLgCdLgBMo92gAAC3ER0AAJ0AAKACALcRHQIAnQIAoAQAtxEdBACdBACgBgC3ER0GAJ0GAKAIALcRHQgAnQgAoAoAtxEdCgCdCgCgDAC3ER0MAJ0MAKAOALcRHQ4AnQ4AoBAAtxEdIACdIACgEgC3ER0iAJ0iAKAUALcRHSQAnSQAoBYAtxEdJgCdJgCgGAC3ER0oAJ0oAKAaALcRHSoAnSoAoBwAtxEdLACdLACgHgC3ER0uAJ0uAKAgALcRHUAAnUAAoCIAtxEdQgCdQgCgJAC3ER1EAJ1EAKAmALcRHUYAnUYAoCgAtxEdSACdSACgKgC3ER1KAJ1KAKAsALcRHUwAnUwAoC4AtxEdTgCdTgClDRhlFYUN5g+lD8Ud8ANMQNumBSBE3oUXpQnJEADwDKUXCgoKChhpAFCACaUXCgoKGGkAYIUDIMTksA+lC8kAwJAFICV5gAMgZXhkD6UPChhlAaq9AAApAPwJ/wCFFaUPxQewHhhlF4UhpRUpAPwFIZ0AAIpIpQ8YZQUKqmidAOOABaUVnQAA5g+lD8Ud0L1gpSPwBKkGAGC/AG//Kf8AYIrJeACQGMnQALAFGGmoAWDJSAGQBRhp+ABgOOnQABhpCABgphlkIeB4APAF4EgB0AJkISDS3rA74HgAkDrg0ACwF9qKOOl4AAoYaUgBqiDS3rAf6CDS3oAU4EgBkBnaijjpSAFKGGl4AKog0t76kAeAAfpkIYAOpSHQAoYF5iGlIcUH8Afo5BvQnThgGGDaigqqvQDj8Dqov5Lf/4UD+q2c4vAhmMlJOJAbyUlAsBY46Uk4SkpKSkpKOO2a4ikfAM2c4rANuQAAKf8DxQPQAzhg+hhgryYAfin/AMkIAPAiyRgA8B3JGQDwGMkaAPATyRwA8A7JHQDwCckeAPAEnJziYKUByUlAsEQ46Uk4SkpKSkpKhRWvSQB+Kf8ACikfAI2a4q9aAH4p/wAaCo2c4jo6OjqFIaUVOO2a4ikfAMUhkAutmuI6OikfAI2a4mAIAAkACgALAAwADQAOAA8AEAARABIAEwAUABUAFgAXABgAGQAaABsAHAAdAB4AHwAgACEAIgAjACQAJQAmACcAKAApACoAKwAsAC0ALgAvADAAMQAyADMANAA1ADYANwA4ADkAOgA7ADwAPQA+AD8AQABBAEIAQwBEAEUARgBHAEgASQBKAEsATABNAE4ATwBQAFEAUgBTAFQAVQBWAFcAWABZAFoAWwBcAF0AXgBfAGAAYQBiAGMAZABlAGYAZwBoAGkAagBrAGwAbQBuAG8AcABxAHIAcwB0AHUAdgB3AHgAeQB6AHsAfAB9AH4AfwAgAiECIgIjAiQCJQImAicCKAIpAioCKwIsAi0CLgIvAjACMQIyAjMCNAI1AjYCNwI4AjkCOgI7AjwCPQI+Aj8CQAJBAkICQwJEAkUCRgJHAkgCSQJKAksCTAJNAk4CTwJQAlECUgJTAlQCVQJWAlcCWAJZAloCWwJcAl0CXgJfAmACYQJiAmMCZAJlAmYCZwJoAmkCagJrAmwCbQJuAm8CcAJxAnICcwJ0AnUCdgJ3AggACQAKAAsADAANAA4ADwAQABEAEgATABQAFQAWABcAGAAZABoAGwAcAB0AHgAfACAAIQAiACMAJAAlACYAJwAoACkAKgArACwALQAuAC8AMAAxADIAMwA0ADUANgA3ADgAOQA6ADsAPAA9AD4APwBAAEEAQgBDAEQARQBGAEcASABJAEoASwBMAE0ATgBPAFAAUQBSAFMAVABVAFYAVwBYAFkAWgBbAFwAXQBeAF8AYABhAGIAYwBkAGUAZgBnAGgAaQBqAGsAbABtAG4AbwBwAHEAcgBzAHQAdQB2AHcAeAB5AHoAewB8AH0AfgB/AEACQQJCAkMCRAJFAkYCRwJIAkkCSgJLAkwCTQJOAk8CUAJRAlICUwJUAlUCVgJXAlgCWQJaAlsCXAJdAl4CXwJgAmECYgJjAmQCZQJmAmcCaAJpAmoCawJsAm0CbgJvAnACcQJyAnMCdAJ1AnYCdwJ4AnkCegJ7AnwCfQJ+An8CgAKBAoICgwKEAoUChgKHAogCiQKKAosCjAKNAo4CjwKQApECkgKTApQClQKWApcCmAKZApoCmwKcAp0CngKfAqACoQKiAqMCpAKlAqYCpwKoAqkCqgKrAqwCrQKuAq8CsAKxArICswK0ArUCtgK3ArgCuQK6ArsCvAK9Ar4CvwLAAsECwgLDAsQCxQLGAscCyALJAsoCywLMAs0CzgLPAtAC0QLSAtMC1ALVAtYC1wLYAtkC2gLbAtwC3QLeAt8C4ALhAuIC4wLkAuUC5gLnAugC6QLqAusC7ALtAu4C7wKlAclJOJBuyUlAsGmvJgB+Kf8AyQoA8AXJHgDQWK/lAH4p/wDJHwCwTKq/iZ1+Kf8AyR8AsD+FDwoKCgqqvwzf9in/AMUd0C2kAWQVuQAAKf8AhSG/AN/2Kf8AxSHQFujIyOYVpRXFHdDipQ/rGGkAwIULOGAYYAjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBucouKcpOKpAQCNoOJ7GGkoABsrq3r6aChrCMIwSNpaiws7OOkoABtb4iCpfkirwiBkGyCA5Jyg4nsYaSgAGyurevpoKGsIwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbIIDkexhpKAAbK6t6+mgoa2QPpQ/NouLwNKq9AOeFA70C54ULvQTnSkpKSkqFB6kgAIUJvQbnyfYA0AUgJXmAAyBleKUPGGkIAIUPgMWcouKcpOJgraDiyQEA0BGvJgB+Kf8AyQoA8AfJHgDwAhhgpQcKCgoKCoUVraLiyQABkAQiV+T/pQvJAMCwPa2k4hhlFckBB5AEIlfk/62k4hhpAOiFEaqkC6UVhSG5AACdAADIyOjoxiHGIdDwraTiGGUVjaTiqX4AgAelC4URqfYArqLinQbnpQOdAOelEZ0C56UVnQTnihhpCACNouI4YAjCMEjaWosLOzjpKAAbW+IgqX5Iq8IgZBucpuKtoOLJAQDwD5yi4pyk4qkBAI2g4o2m4nsYaSgAGyurevpoKGsIwjBI2lqLCzs46SgAG1viIKl+SKvCIGQbrabiyQEA0AkggOScoOKcpuJ7GGkoABsrq3r6aChrr6jifkkBj6jifmprr6rifkkBj6rifmvAAgDQY6/rAH7Jv4HQWq8mAH4p/wDJCgDwCskaAPAFyRwA0EQI4iCvBPp+0BqvEkIAEPqvPyEArzchAK89IQDJ9rDqydyQ5nipgI8VIQDCIKm7RI8WIQCvv4F+jxghAK/BgX6PGCEAKGA=",edition:null}];
const fontOptimizationHooks=[{"start":206830,"symbol":"genericMagicDMAParity","target":16770517,"before":[173,30,2,106],"after":[34,213,229,255]},{"start":237223,"symbol":"genericRelicDMAParity","target":16770529,"before":[173,30,2,41,1],"after":[34,225,229,255,234]}];
// Precompose the imported GBA font's current Esper names. No donor-format change.
// Output maps to ROM $36C000..$36E0EF: 31 256-byte 4bpp strips then
// 31 16-byte records (12 native codes, trimmed length, three reserved bytes).
function makeEsperFontAtlas(rom) {
    const start=0x36c000, size=0x20f0;
    const length=rom[0x3555a];
    const names=(rom[0x3555f]|rom[0x35560]<<8|rom[0x35564]<<16)-0xc00000;
    if (![8,12].includes(length)||names<0||names+31*length>rom.length) throw new Error('Invalid Esper name layout');
    const pages=[0x374000,0x378000,0x37c000,0x38c000,0x398000,0x39c000,0x3a8000,0x3ac000];
    const data=new Uint8Array(size);
    for(let id=0;id<31;id++) {
        const codes=rom.slice(names+id*length,names+(id+1)*length);
        let used=codes.length;
        while(used&&codes[used-1]===255) used--;
        const strip=new Uint8Array(512);
        let pen=0;
        for(let i=0;i<used;i++) {
            const code=codes[i], source=pages[pen&7]+code*64, dest=(pen>>3)*32;
            for(let fragment=0;fragment<3;fragment++) for(let j=0;j<16;j++) {
                const at=dest+fragment*32+j;
                if(at<strip.length) strip[at]|=rom[source+fragment*16+j];
            }
            pen+=rom[0x3f6f00+code];
        }
        data.set(strip.subarray(0,256),id*256);
        const record=0x1f00+id*16;
        data.fill(255,record,record+12);
        data.set(codes.subarray(0,used),record);
        // Exceptional names retain the ordinary compositor's native fallback.
        data[record+12]=pen<=64?used:0;
    }
    return {start,data};
}
const esperBatchHooks=[
    [0x354cb,[0x20,0xe5,0x54],[0x20,0xc8,0xfc]],
    [0x354e0,[0x7a,0x88,0xd0,0xf0,0x60],[0x4c,0xd0,0xfc,0xea,0xea]],
    [0x35542,[0x20,0x59,0x55],[0x20,0xe0,0xfc]],
    [0x35556,[0xe6,0xe5,0x60],[0x4c,0xe8,0xfc]],
    [0x3fcc8,new Array(8).fill(255),[0x22,0x06,0xd9,0xff,0x20,0xe5,0x54,0x60]],
    [0x3fcd0,new Array(12).fill(255),[0x7a,0x88,0xf0,0x03,0x4c,0xd4,0x54,0x22,0x09,0xd9,0xff,0x60]],
    [0x3fce0,new Array(8).fill(255),[0x22,0x0c,0xd9,0xff,0x20,0x59,0x55,0x60]],
    [0x3fce8,new Array(7).fill(255),[0xe6,0xe5,0x22,0x0f,0xd9,0xff,0x60]],
];
function writeOptimizedEsperAtlas(out,edition) {
    const {start,data}=makeEsperFontAtlas(out);
    if(!out.subarray(start,start+data.length).every(v=>v===255)) throw failure('verifyFail');
    for(const [at,before] of esperBatchHooks) if(!before.every((v,i)=>out[at+i]===v)) throw failure('verifyFail');
    out.set(data,start);
    for(const [at,,after] of esperBatchHooks) out.set(after,at);
}

function applyFontOptimization(out,edition) {
    if(!fontOptimizationEnabled)return;
    if(!generalMenuMarker.every((v,i)=>out[0x3fd880+i]===v))throw failure('verifyFail');
    for(const segment of fontOptimizationSegments) {
        if(segment.edition && segment.edition!==edition)continue;
        const before=from64(segment.before),after=from64(segment.after),at=segment.start;
        if(before.length>segment.capacity||after.length>segment.capacity||
            !before.every((v,i)=>out[at+i]===v)||
            !out.subarray(at+before.length,at+Math.max(before.length,after.length)).every(v=>v===255))throw failure('verifyFail');
        out.fill(255,at,at+Math.max(before.length,after.length));
        out.set(after,at);
    }
    if(!out.subarray(0x36c000,0x36e0f0).every(v=>v===255))throw failure('verifyFail');
    writeOptimizedEsperAtlas(out,edition);
    for(const hook of fontOptimizationHooks) {
        if(!hook.before.every((v,i)=>out[hook.start+i]===v))throw failure('verifyFail');
        out.set(hook.after,hook.start);
    }
}
// FONT_OPTIMIZATION_END
