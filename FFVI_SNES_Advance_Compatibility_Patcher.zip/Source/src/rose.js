// ROSE uses a verified adapter plan and guarded source layout. Future wording
// is permitted while adaptive controls, code, assets and other tables stay fixed.
const roseSize=0x800000;
function roseSourceEligible(input) {
    return !!(roseEnabled && input && input.id===catalog.rose.input &&
        input.bytes.length===0x400000 && input.profile.edition==='regular' &&
        input.profile.options.length===0 && !input.atbKind);
}
function roseProfile(id=catalog.rose?.target) {
    const profile=catalog.rose?.profiles?.[id];
    if(!profile || profile.edition!=='rose' || !Array.isArray(profile.options) ||
        !profile.options.includes('rose') || !profile.options.includes('dash') ||
        !Array.isArray(profile.capabilities))throw failure('verifyFail');
    return {...profile,add:profile.add||{}};
}
function writeROSEChecksum(bytes) {
    if(bytes.length!==roseSize)throw failure('verifyFail');
    for(const offset of [0xffdc,0x40ffdc])bytes.set([255,255,0,0],offset);
    let sum=0;for(const byte of bytes)sum=(sum+byte)&65535;
    const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
    for(const offset of [0xffdc,0x40ffdc]){
        view.setUint16(offset,sum^65535,true);view.setUint16(offset+2,sum,true);
    }
}
function checkROSEHeader(bytes) {
    return bytes.length===roseSize && [0xffc0,0x40ffc0].every(at=>bytes[at+0x15]===0x35&&bytes[at+0x17]===13);
}
async function readROSE(files,saved) {
    if(!roseEnabled)throw failure('roseUnavailable');
    const specs=catalog.sources.rose;let candidates;
    if(files.length){
        if(files.length!==1)throw failure('roseFiles');
        candidates=await collectFuturePatchFiles(files);
    }else candidates=specs.filter(spec=>saved?.[spec.name]).map(spec=>({name:spec.name,
        bytes:from64(saved[spec.name]),savedSpec:spec,fromSaved:true}));
    const ips=candidates.filter(candidate=>String.fromCharCode(...candidate.bytes.subarray(0,5))==='PATCH');
    if(!ips.length)throw failure('roseFiles');
    const entries={};
    for(const candidate of ips){
        const originalSha=await rawHash(candidate.bytes);
        let spec=specs.find(s=>s.sha===originalSha),body=spec?candidate.bytes:null;
        if(!spec){
            const matches=[];
            for(const choice of candidate.savedSpec?[candidate.savedSpec]:specs){
                const normalized=await normalizeFutureIPS(candidate.bytes,choice);
                if(normalized)matches.push([choice,normalized]);
            }
            if(matches.length>1)throw failure('futureAmbiguous');
            if(matches.length)[spec,body]=matches[0];
        }
        if(!spec){
            const named=specs.find(s=>futureNeutralName(s.name)===futureNeutralName(candidate.name));
            // Full upstream archives contain alternate gameplay patches and
            // authoring utilities. Only the main edition is an input here.
            if(candidate.isArchive&&!named&&ips.length!==1)continue;
            spec=candidate.savedSpec||named||specs.find(s=>(s.header||0)===(/_H\.ips$/i.test(candidate.name)?512:0));
            if(!spec)throw failure('roseFiles');
            decodeFutureIPS(candidate.bytes);body=candidate.bytes;
        }
        if(entries[spec.name])throw failure('futureAmbiguous');
        entries[spec.name]=registerFuturePatch(body,{family:'rose',spec,originalSha,name:candidate.name,
            declaredVersion:candidate.declaredVersion,fromSaved:candidate.fromSaved,warning:originalSha!==spec.sha});
    }
    const selected=[...specs].sort((a,b)=>(a.header||0)-(b.header||0)).find(s=>entries[s.name]);
    if(!selected)throw failure('roseFiles');
    return {[selected.name]:entries[selected.name]};
}
function roseCopy(out,source,records) {
    if(!Array.isArray(records))throw failure('verifyFail');
    for(const record of records){
        if(!Array.isArray(record)||record.length!==3)throw failure('verifyFail');
        const [dest,src,count]=record;
        if(![dest,src,count].every(Number.isSafeInteger)||dest<0||src<0||count<0||dest+count>out.length||src+count>source.length)throw failure('verifyFail');
        out.set(source.subarray(src,src+count),dest);
    }
}
function roseFix(out,records) {
    if(!Array.isArray(records))throw failure('verifyFail');
    for(const record of records){
        if(!Array.isArray(record)||record.length!==2)throw failure('verifyFail');
        const [dest,encoded]=record;
        if(!Number.isSafeInteger(dest)||dest<0||typeof encoded!=='string')throw failure('verifyFail');
        const bytes=from64(encoded);if(dest+bytes.length>out.length)throw failure('verifyFail');
        out.set(bytes,dest);
    }
}
function roseGenerate(out,donor,records=[]) {
    if(!Array.isArray(records))throw failure('verifyFail');
    for(const asset of records){
        if(!asset || asset.type!=='rose-monster-name')throw failure('verifyFail');
        const {destination:dest,font,width}=asset;
        if(![dest,font,width].every(Number.isSafeInteger)||dest<0||font<0||width!==88||
            dest+width*2>out.length||font+256*16>donor.length||typeof asset.record!=='string')throw failure('verifyFail');
        const record=from64(asset.record);
        if(record.length>32)throw failure('verifyFail');
        let end=record.length;while(end&&record[end-1]===255)end--;
        const pixels=new Uint8Array(width*8);let cursor=0;
        for(const ch of record.subarray(0,end)){
            if(ch===254||ch===255){cursor+=3;continue;}
            const tile=donor.subarray(font+ch*16,font+(ch+1)*16);
            let left=8,right=-1;
            for(let x=0;x<8;x++)for(let y=0;y<8;y++){
                if((tile[y*2]|tile[y*2+1])&(1<<(7-x))){left=Math.min(left,x);right=Math.max(right,x);}
            }
            if(right<0){cursor+=3;continue;}
            for(let y=0;y<8;y++)for(let x=left;x<=right;x++){
                const at=cursor+x-left;
                if(at<width)pixels[y*width+at]=((tile[y*2]>>(7-x))&1)+2*((tile[y*2+1]>>(7-x))&1);
            }
            cursor+=right-left+2;
        }
        if(cursor>width+1)throw failure('verifyFail');
        const bytes=new Uint8Array(width*2);let at=0;
        for(let tile=0;tile<width/8;tile++)for(let y=0;y<8;y++)for(let plane=0;plane<2;plane++){
            let value=0;for(let x=0;x<8;x++)value|=((pixels[y*width+tile*8+x]>>plane)&1)<<(7-x);
            bytes[at++]=value;
        }
        out.set(bytes,dest);
    }
}
async function applyROSE(base,sources) {
    if(!roseEnabled || await hash(base)!==catalog.rose.input)throw failure('roseLocked');
    const spec=catalog.sources.rose.find(s=>sources?.[s.name]);
    if(!spec || ![0,512].includes(spec.header||0))throw failure('roseFiles');
    const patch=sources[spec.name];
    const retail=base.slice(0,0x300000);
    roseFix(retail,await unpackPlan(catalog.rose.recovery||catalog.twue.recovery));
    if(await hash(retail)!==catalog.rose.retailHash)throw failure('verifyFail');
    let donor=null;
    // A renamed future IPS need not retain its H/NH filename. Both supported
    // header layouts are tried; the protected donor hash selects the valid one.
    for(const header of [spec.header||0,(spec.header||0)?0:512]){
        try{
            const patched=new Uint8Array(0x400000+header).fill(255);
            if(header)patched.fill(0,0,header);
            patched.set(retail,header);applyFutureIPS(patched,patch);
            const candidate=patched.slice(header);
            if(await hash(candidate)===catalog.rose.donorHash){donor=candidate;break;}
        }catch{}
    }
    if(!donor)throw failure('roseFutureLayout');
    const plan=await unpackPlan(catalog.rose.plan),out=new Uint8Array(roseSize).fill(255);
    out.set(base);
    roseCopy(out,base,plan.baseCopies);
    roseCopy(out,donor,plan.donorCopies);
    roseGenerate(out,donor,plan.generatedAssets);
    roseFix(out,plan.fixes);
    await applyRoseFutureDialogue(out,donor);
    if(!checkROSEHeader(out))throw failure('verifyFail');
    writeROSEChecksum(out);
    const id=await hash(out);
    if(id!==catalog.rose.target)throw failure('verifyFail');
    return {bytes:out,id,profile:roseProfile(id)};
}
async function identifyROSE(file) {
    if(!roseEnabled || ![roseSize,roseSize+512].includes(file.size))throw failure('unknown');
    const raw=new Uint8Array(await file.arrayBuffer()),bytes=raw.slice(raw.length-roseSize);
    if(!checkROSEHeader(bytes))throw failure('unknown');
    const previous=[...bytes.subarray(0xffdc,0xffe0),...bytes.subarray(0x40ffdc,0x40ffe0)];
    // Structural aliases intentionally exclude checksums. Repair these before
    // identity lookup, including when the remaining future layout is recognized.
    writeROSEChecksum(bytes);
    const repairedChecksum=previous.some((value,i)=>bytes[(i<4?0xffdc:0x40ffdc)+i%4]!==value);
    const id=await hash(bytes);
    if(!catalog.rose.profiles[id])throw failure('unknown');
    return {bytes,id,profile:roseProfile(id),upgrade:repairedChecksum||id!==catalog.rose.target};
}
async function combineROSE(input,selected,sources) {
    if(!roseEnabled)throw failure('roseUnavailable');
    const profile=roseProfile(input.profile.edition==='rose'?input.id:catalog.rose.target);
    const allowed=new Set([...profile.capabilities,'rose','dash']),chosen=new Set(selected);
    chosen.add('rose');chosen.add('dash');
    if([...chosen].some(id=>!allowed.has(id)))throw failure('roseUnsupported');
    chosen.delete('vanilla');
    // Only catalogued output profiles are supported. A capability flag alone
    // never authorizes an untested legacy font or battle-system transformation.
    if(chosen.size!==profile.options.length||profile.options.some(id=>!chosen.has(id)))throw failure('roseUnsupported');
    if(input.profile.edition==='rose'){
        if(await hash(input.bytes)!==input.id || !checkROSEHeader(input.bytes))throw failure('verifyFail');
        const bytes=input.bytes.slice(),visited=new Set();let id=input.id;
        while(id!==catalog.rose.target){
            if(visited.has(id)||visited.size>=16)throw failure('verifyFail');
            visited.add(id);
            const update=catalog.rose.upgrades?.[id];
            if(!update||!catalog.rose.profiles[update.target])throw failure('verifyFail');
            roseFix(bytes,update.fixes);writeROSEChecksum(bytes);
            id=await hash(bytes);
            if(id!==update.target||!checkROSEHeader(bytes))throw failure('verifyFail');
        }
        return {bytes,id,profile:roseProfile(id)};
    }
    if(!roseSourceEligible(input))throw failure('roseLocked');
    return applyROSE(input.bytes,sources.rose);
}
