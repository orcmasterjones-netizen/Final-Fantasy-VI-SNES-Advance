// TWUE is an alternative English edition. Original patches remain external.
async function unpackPlan(encoded) {
    const stream=new Blob([from64(encoded)]).stream().pipeThrough(new DecompressionStream('deflate'));
    return JSON.parse(await new Response(stream).text());
}
function crc32(bytes) {
    let crc=0xffffffff;
    for(const b of bytes){crc^=b;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}
    return (crc^0xffffffff)>>>0;
}
function applyBPS(source,patch) {
    // Newer/unrecognized sources must use the strict source/target/patch CRC
    // decoder; the original TWUE decoder assumed an exact prior source hash.
    return retailBaseMerger.applyBPS(source,patch,0x400000);
}
async function readTWUE(files,saved) {
    const specs=catalog.sources.twue;
    let entries=await readTWUEFutureSources(files,saved,specs);
    if(Object.keys(entries).length>1){
        const selected=[...specs].reverse().find(s=>entries[s.name]);
        entries={[selected.name]:entries[selected.name]};
    }
    if(Object.keys(entries).length!==1)throw failure('twueFiles');
    return entries;
}
async function applyTWUE(base,sources) {
    const inputHash=await hash(base);
    if(catalog.twue.normalize?.[inputHash]){base=base.slice();for(const [at,data]of catalog.twue.normalize[inputHash])base.set(from64(data),at);writeChecksum(base);}
    if(await hash(base)!==catalog.twue.input)throw failure('twueLocked');
    const spec=catalog.sources.twue.find(s=>sources?.[s.name]);
    if(!spec)throw failure('twueFiles');
    const retail=base.slice(0,3145728);
    for(const [at,data]of await unpackPlan(catalog.twue.recovery))retail.set(from64(data),at);
    if(await hash(retail)!==catalog.twue.retailHash)throw failure('verifyFail');
    let donor;
    if(twuePatchFormat(sources[spec.name])==='bps')donor=applyBPS(retail,sources[spec.name]);
    else{donor=new Uint8Array(4194304).fill(255);donor.set(retail);applyFutureIPS(donor,sources[spec.name]);}
    const variant=catalog.twue.variants[spec.variant];
    if(await hash(donor)!==variant.donorHash)throw failure('futureConflict');
    if(spec.variant==='307')await validateTWUEDialogue(donor);
    const out=base.slice(),[copies,fixes]=await unpackPlan(variant.plan);
    for(const [dest,src,n]of copies)out.set(donor.subarray(src,src+n),dest);
    for(const [at,data]of fixes)out.set(from64(data),at);
    writeChecksum(out);
    if(await hash(out)!==variant.target)throw failure('futureConflict');
    if(spec.variant==='307')await validateTWUEDialogue(out);
    return out;
}
