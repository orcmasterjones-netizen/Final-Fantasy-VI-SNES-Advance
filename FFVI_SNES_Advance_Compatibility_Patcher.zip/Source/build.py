"""Assemble the standalone public patcher. No network or external packages required."""
from pathlib import Path
from html import escape

root = Path(__file__).resolve().parent
src = root / "src"
template = (src / "template.html").read_text(encoding="utf-8")
assets = {
    "CATALOG": (src / "catalog.json").read_text(encoding="utf-8").strip(),
    "RETAIL_BASE": (src / "retail-base.json").read_text(encoding="utf-8").strip(),
    "SCRIPT": (src / "app.js").read_text(encoding="utf-8").replace("/* CARTRIDGE_FONT */", (src / "cartridge-font.js").read_text(encoding="utf-8")).replace("/* TWUE_LAYER */", (src / "twue.js").read_text(encoding="utf-8")).replace("/* ATB_LAYER */", (src / "atb.js").read_text(encoding="utf-8")).replace("/* ROSE_LAYER */", (src / "rose.js").read_text(encoding="utf-8")),
    "DASH_CREDITS": escape((src / "dash-credits.txt").read_bytes().decode("utf-8-sig")),
}
for name, content in assets.items():
    if name=='SCRIPT':
        content=content.replace('/* SPELL_NAMES */',(src/'spell-names.js').read_text())
        content=content.replace('/* MENU_POLISH */',(src/'menu-polish.js').read_text())
        content=content.replace('/* RETAIL_BASE */',(src/'retail-base.js').read_text())
        for marker,file in [('FUTURE_INPUTS','future-inputs.js'),('FUTURE_SOURCES','future-sources.js'),('ROSE_FUTURE','rose-future.js'),('TWUE_FUTURE','twue-future.js'),('SPANISH_FUTURE','spanish-future.js'),('MOLEMAN_DIALOGUE','moleman-dialogue.js'),('MOLEMAN_VERSION','moleman-version.js'),('TWUE_VARIANTS','twue-variants.js'),('TWUE_MUSIC','twue-music.js'),('MULTI_FONT','multi-font.js'),('COMPOSED_OPTIONS','composed-options.js'),('SPELL_ICONS','spell-icons.js')]:
            content=content.replace('/* '+marker+' */',(src/file).read_text())
    template = template.replace("%%" + name + "%%", content)
output = root / "out" / "FFVI_SNES_Advance_Compatibility_Patcher.html"
output.parent.mkdir(exist_ok=True)
output.write_bytes(template.encode("utf-8"))
print(output)
