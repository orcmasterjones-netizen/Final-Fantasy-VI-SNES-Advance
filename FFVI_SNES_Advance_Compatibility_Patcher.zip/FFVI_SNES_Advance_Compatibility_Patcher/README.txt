﻿FINAL FANTASY VI — SNES ADVANCE COMPATIBILITY PATCHER
Public sharing package · November 10, 2026

Combine optional gameplay, language, and font changes with FFVI SNES Advance.
The patcher is a self-contained HTML file. It runs locally in your browser and
creates a new ROM; your input files are not uploaded or overwritten.

PACKAGE CONTENTS

  FFVI_SNES_Advance_Compatibility_Patcher.html
      The complete public patcher. Open this file to begin.
  README.txt
      Instructions, option descriptions, required downloads, and credits.
  Credits/Cancel_Button_Dash_Readme.txt
      SilentEnigma's original, unmodified Dash readme, contributor credits,
      and redistribution terms.

1. QUICK START

1) Extract this ZIP to a folder, then open the HTML file in a current desktop
   browser. No installation or local web server is needed. The interface is
   available in English and Spanish.
2) Select your extracted SNES Advance ROM (.sfc or .smc).
3) Choose one battle system, then any additional options you want.
4) Supply the original patch files or GBA donor requested by those options.
   The patcher provides download links for the optional hacks.
5) Click Build ROM. After verification succeeds, click Download ROM.
6) Open the downloaded ROM in your emulator. For clymax or CTB Wait's
   turn-based behavior, choose Wait in the game's battle configuration.

Keep a backup of your normal battery save. To continue with the new ROM, copy
your SNES Advance battery save under its new ROM basename, following your
emulator's naming convention, and load from the title screen. Start the new
ROM normally rather than restoring a save state made with different code.

2. SUPPORTED STARTING FILES

Use a recognized Regular or MoleMan v1.6 edition of SNES Advance v0.9.20
(public release v1.2), or a recognized output from this compatibility patcher.
The tool verifies supported inputs and final outputs. A 512-byte copier header
is handled automatically.

This is an options patcher for an existing SNES Advance installation. It does
not install the main SNES Advance content onto a clean retail ROM. Prepare
that installation using the main project's release first. The MoleMan input
must already have been merged using the SNES Advance-compatible merger; this
tool does not offer MoleMan as an additional translation checkbox.

Spanish is available for the Regular edition, not the MoleMan edition.
Other revisions, edited ROMs, and additional unrelated hacks are not covered
by the verified input catalog.

3. BATTLE SYSTEM — CHOOSE ONE

Original ATB
  Keeps the normal SNES Advance battle timing for the selected edition.
  No additional patch file is needed.

Turn-Based (clymax)
  Uses clymax's Final Fantasy VI: Turn-Based v0.01 for USA Rev 1, with the
  SNES Advance compatibility adjustments and Fight-targeting fix.
  Set the game's battle mode to Wait.
  Required: the original v0.01 ZIP, or this IPS from it:
    Final Fantasy III (USA) (Rev 1) (Turn-Based v0.01 by clymax).ips
  Download:
    https://romhackplaza.org/romhacks/final-fantasy-vi-turn-based-snes/

Modern ATB Enhanced (RoSoDude)
  The standard version of Comprehensive ATB Enhancement v2.00. Time may
  advance during the current animation until someone is ready to act, then
  pauses to let queued actions catch up. Supports Active and Wait settings.

Classic ATB Enhanced (RoSoDude)
  Uses the earlier style of the enhancement: time pauses during every battle
  animation. Supports Active and Wait settings.

CTB Wait (RoSoDude)
  In Wait mode, pauses time at the main command menu as well as during queued
  actions, removing the real-time pressure to select a command. Skip turn
  advances time. In Active mode, it uses Modern ATB behavior.

  All three RoSoDude choices include the release's shared timing rebalance
  and integrated bug fixes, not just a different pause rule. The changes
  affect ATB speed, status timers, Battle Speed scaling, and command delays.

  Required: RoSoDude's original Comprehensive ATB Enhancement v2.00 ZIP,
  or the matching standalone 1.1 US IPS:
    Modern_ATB_Enhancement_(1.1_US_ROMs).ips
    ATB_Classic_Addon_(1.1_US_ROMs).ips
    CTB_Wait_Addon_(1.1_US_ROMs).ips

  Each file is a complete alternative. The files called Addon do not require
  Modern to be applied first. Supply the original files to this patcher; it
  handles the SNES Advance adaptations. Do not apply the upstream IPS directly
  to your SNES Advance ROM or stack multiple battle systems.

  Download and original project listing:
    https://romhackplaza.org/romhacks/ff6-comprehensive-atb-enhancement-snes/
    https://www.romhacking.net/hacks/8513/

4. ADDITIONAL OPTIONS

Cancel Button Dash
  Hold the mapped Cancel button (normally B) to run in the field. The effect
  stacks with Sprint Shoes. The upstream feature is disabled in multi-party
  battles and makes timed-challenge countdowns advance faster while dashing.
  The adapted Dash option is included; no separate input file is requested.
  See Credits/Cancel_Button_Dash_Readme.txt for the original details and terms.

GBA font — direct cartridge import
  Supply an unmodified U.S. Final Fantasy VI Advance ROM (.gba, game code
  BZ6E), or a ZIP containing Final Fantasy VI Advance (USA).gba.
  Imports the original font data for field text, dialogue, and battle text,
  including the separate battle HUD digits. Adds proportional name/command
  spacing and compact, right-aligned field numbers. Battle digits retain
  their native GBA eight-pixel spacing.

  The game retains the SNES resolution, window layout, palettes, and saved
  ATB-gauge setting. Translation-specific accents and some symbols use their
  existing slots; MoleMan and Spanish retain their dialogue wrapping widths.
  This option does not replace the story translation or force ATB bars off.

GBA font — optional legacy appearance
  The same font option also accepts seibaby's FFVI Advance font pack v1.01
  ZIP, or BOTH unheadered IPS files from that pack:
    gba-dialogue-font-N.ips
    new-menu-font-N.ips
  This uses the older pack's appearance. Its menu font is seibaby's custom
  design, distinct from the direct cartridge import described above.
  Download:
    https://www.ff6hacking.com/forums/thread-3358.html

Longer item and monster names
  Requires the GBA font option; selecting longer names also selects the font.
  Expands supported abbreviations in item lists and monster displays, using
  vocabulary appropriate to the selected edition. Some names retain their
  existing spelling or abbreviation. Dialogue and reward messages can still
  use the original names. Item identities and inventory limits are unchanged.
  No separate names patch is needed.

Spanish translation
  Combines Rod Mérida / Traducciones Crackowia's original-story translation
  with the SNES Advance bonus-content translation and compatibility work.
  Requires the Regular edition and the original NTSC v1.15 ZIP or FF6ESP.IPS.
  Use the NTSC file; this option does not use PAL/FF6ESPAL.IPS or the optional
  patches in the translation archive's extra folder.
  Downloads:
    https://romhackplaza.org/translations/final-fantasy-vi-spanish-translation-snes/
    https://crackowia.com/ff6esp.html
    https://retrohackers.net/translation-details.php?id=5487

5. REOPENING, UPGRADING, AND PERSONAL COPIES

Recognized outputs can be reopened to add supported options. Already-installed
options are shown in the interface. A current font output carries the font
record needed for later supported additions; an older direct-font output may
ask for the U.S. GBA ROM again to import the separate battle digits. The tool
also offers an upgrade from the legacy font to the cartridge font.

Modern, Classic, and CTB outputs can switch between those battle systems or
return to Original ATB. Supply the source patch for the newly selected system.
Adding other options while retaining an installed ATB mode does not require
resupplying its ATB file. Switching to clymax requires its original source.

Existing clymax outputs keep clymax installed. To choose another battle system,
start again with an input without clymax. To remove other installed extras,
start from your original supported SNES Advance build.

After a successful build, Save a personal patcher can retain your verified
optional patch data, font record, and choices for offline reuse. It does not
save the complete donor ROM. A personal copy may contain third-party patch
data: share this PUBLIC ZIP with other players, rather than your personal copy.

6. TROUBLESHOOTING AND TEST COVERAGE

Unrecognized ROM:
  Use a supported SNES Advance build, not a clean retail ROM. Extract the ROM
  from its archive before selecting it. Additional edits can change its hash.

Patch file does not match:
  Check the exact version and variant listed above. For RoSoDude, use the
  1.1 US files. If a ZIP cannot be read, extract and select its required IPS
  file(s) instead. For direct fonts, use the unmodified U.S. GBA release.

Browser error:
  Open the extracted HTML in a current browser with Web Crypto and
  DecompressionStream support. Use the public copy if a personal copy fails
  validation, then select the original files again.

This release passed 126 new ATB reference-output comparisons and 237 ATB
reopening/addition/switching paths, alongside the existing combination and
font regression checks. Targeted Snes9x checks covered timing, menu scrolling,
numbers, dialogue/HUD restoration, spells, and summons; offline Chromium
checks covered the patcher's main workflows. These checks were not a new
full-game playthrough or a physical-hardware compatibility certification.

7. CREDITS AND ACKNOWLEDGMENTS

Original game and artwork
  Square / Square Enix — Final Fantasy VI and Final Fantasy VI Advance,
  including the original game data and font artwork. This is an unofficial
  fan-made compatibility tool, not a Square Enix release.

SNES Advance integration
  The SNES Advance project — bonus content, compatibility adaptations,
  combined patcher, direct-cartridge font renderer, spacing changes, longer
  name layouts, and bonus-content language integration. These contributions
  are separate from the original optional hacks credited below.

Cancel Button Dash v1.2
  SilentEnigma (David R. Thompson) — author, including Sliding Dash Fix.
  Master ZED — original FF3 Dash button hack.
  Duran Divine Dragon — inspiration credited by the original author.
  Imzogelmo — free-space documentation and C0 disassembly.
  Novalia Spirit — bugs list.
  Rob "CintariZero" (@Cintari_) — bug report acknowledged in Dash v1.2.
  Full original credits and terms accompany this package unchanged.
    https://silentenigma.neocities.org/ff6/
    https://masterzed.cavesofnarshe.com/ff3.html

Final Fantasy VI: Turn-Based v0.01
  clymax — original turn-based hack.
  Original download: the Romhack Plaza link in section 3.

Comprehensive ATB Enhancement v2.00
  RoSoDude — enhancement, timing redesign, CTB option, and Quick Fix v1.02.
  Think0028 — original simple nATB.
  C-Dude — restoration of the Active/Wait setting in simple nATB.
  Lightning Hunter — USA v1.1 compatibility work.
  Assassin — Premature Continuation v0.20.
  Leet Sketcher — Rock Bottom v1.3, Death Row v1.2, Self Sneeze v2.0,
                 and Invisible Zombie v1.0.
  HatZen08 — Even Gauge v1.1d.
  These contributors are credited by RoSoDude's release. Its original
  readme remains the authoritative description of that hack.
    https://rosodudemods.wordpress.com/

Final Fantasy VI Advance font pack v1.01 (legacy option)
  seibaby — font pack, including its custom menu font.
  Lord J — FF3usME, acknowledged by seibaby.
  Madsiur — FFVI Advance Editor, acknowledged by seibaby.
  The direct-cartridge font import is separate work and uses the player's
  original GBA font data, rather than seibaby's replacement menu artwork.

Spanish translation v1.15
  Rod Mérida (Roberto Mérida), Traducciones Crackowia — translation and ROM work.
  Vicks Delgado / Vicks Dg. — primary review and testing.
  Bernar Carrasco / Bernar Carrasc. — secondary review and testing.
  The translation's readme also acknowledges Lenophis, abw, Yousei,
  Terii Senshi, Riggy Portillo, Éneko, Javitsu95, signatux, David López,
  and Yerko Candia Goycochea; it discusses Yazoo's original-title-screen work.
  Please retain that release's own credits when using its original files.

Final Fantasy VI - GBA Text v1.6 (supported starting edition)
  MoleMan — the GBA Text project used by the supported merged edition.
  Its original release credits the additional fixes and contributors it
  incorporates. This package does not redistribute that translation.
    https://www.romhacking.net/hacks/5864/
    https://retrohackers.net/hack-details.php?id=5864

Technical references
  everything8215 and contributors — Final Fantasy VI disassembly.
    https://github.com/everything8215/ff6
  Thanks to the FFVI hacking community for its documentation and tools.

8. SHARING AND THIRD-PARTY MATERIAL

Share this public ZIP with its README and Credits folder intact. It contains
the standalone tool, compatibility data, and the attributed Dash adaptation.
It contains no game ROM, GBA font donor record, or original RoSoDude, clymax,
Spanish-translation, MoleMan, or legacy-font patch archive. Players obtain
those optional inputs separately from their authors' releases.

Keep this package non-commercial, in accordance with the included Dash terms.
The original games and third-party works remain the property of their
respective rights holders. This package does not grant rights to redistribute
their ROMs or source patches, and compatibility support does not imply their
authors' endorsement of SNES Advance.
