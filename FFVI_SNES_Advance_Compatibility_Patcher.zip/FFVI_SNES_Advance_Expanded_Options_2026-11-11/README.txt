FFVI SNES Advance Compatibility Patcher — expanded options
November 12, 2026

Open FFVI_SNES_Advance_Expanded_Options_2026-11-11.html in a current browser.
Choose a supported SNES Advance Regular/MoleMan ROM, or reopen a ROM already
made by the patcher. Files are processed locally; the tool works offline.

SPELL-NAME CORRECTION
The added battle spells Flood, Valor and Gravija now use their spell-name
records in MoleMan and TWUE. Reopen an older recognized ROM and build once to
apply this correction while retaining its selected options.

TWUE 3.07
Start from Regular and select one primary edition:
  Base; Base + Updated Opera;
  Bug Fixes; Bug Fixes + Updated Opera;
  Bug Fixes + Add-Ons; Bug Fixes + Add-Ons + Updated Opera.
Supply the original TWUE 3.07 ZIP, or that edition's original IPS. The primary
edition cannot be changed after installation; start from Regular to choose
another. Earlier base TWUE 3.06 IPS and 3.06a/3.07 BPS inputs remain supported.
TWUE is an alternative to MoleMan, Spanish and ROSE, and includes Cancel dash.
When adding TWUE to a Regular ROM with Modern/Classic/CTB already installed,
select that original ATB patch again to adapt its hooks to the new edition.

GBA FONT CHOICES
Our cartridge font imports original glyphs from an unmodified U.S. FFVI Advance
ROM (.gba or its ZIP). It uses proportional menus and supports longer names.

Multi-Font Selection 1.4.1 uses the author's original ZIP or
Multi_Fonts_1.4.1_nh.ips. Menus use fixed-width cells; dialogue is proportional.
It defaults to Advance and offers Normal/Advance in Config. Normal uses the
chosen edition's native font. The selected font survives normal saves.

Leave GBA font unchecked for native fonts. New builds can switch between the
two font implementations, or return to native fonts, by reopening the ROM.
Old seibaby-font builds did not retain native glyphs: use a native-font base to
choose Multi-Font or native fonts from those builds. Longer item/monster names
require our cartridge font. ROSE retains its separately supported native font.

MUSIC PLAYER
TWUE 3.07 offers Config 1 (Music replaces the Mono option beside Stereo),
Config 2 (a new Music row), or the compatible Main Menu version. Main Menu A
is for Bug Fixes editions; B is for Base editions. Both retain Config.
The player includes SNES Advance's bonus music track.

Optional sound-effect volume, Lete River and caves/cliffs fixes can be selected
independently. Supply the original TWUE ZIP or the chosen player/fix IPS files.
A TWUE ZIP selected in the edition row can also supply the Music Player files.

BUILDING AND REOPENING
Choose one battle system and any compatible extra options, then Build ROM and
Download ROM. Every supported output is checked against an expected SHA-256.
Installed Music/Multi-Font sources are retained for reopening without uploads.
Changing a player placement or adding a new fix requires its original source.
A personal HTML copy retains verified selected sources for private offline use.
Share the public patcher with other players, not a personal copy.

Existing battery saves can continue. Boot normally after changing ROMs; do not
load an emulator state containing code from another ROM. Keep a backup save.
Existing clymax Turn-Based builds retain that battle system; use a build without
clymax when switching away from it.

Read EXPANDED_OPTIONS_VALIDATION.txt for the final test scope. Other validation
files describe earlier releases and are retained as historical evidence.
No game ROM or original third-party patch is included in this package.
Original author credits/readmes are in Credits/.
