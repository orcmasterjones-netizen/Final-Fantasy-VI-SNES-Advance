from pathlib import Path
import hashlib,json
import sys
p=Path(__file__).resolve().parent
if len(sys.argv)!=3: raise SystemExit('Usage: python build_patcher.py ORIGINAL_PATCHER.html OUTPUT.html')
source=Path(sys.argv[1]).read_text(encoding='utf8')
def edit(key,val):
 global source
 assert source.count(key)==1, (key,source.count(key))
 source=source.replace(key,val,1)
js=(p/'list-names.js').read_text()+(p/'additions.js').read_text()+(p/'menu.js').read_text()+(p/'twue-menus.js').read_text()+(p/'twue-terms.js').read_text()+(p/'preset.js').read_text().replace('GBA_FORMAT',(p/'format.json').read_text())
edit('const controls=new Map();',js+'\nconst controls=new Map();')
outputs=json.loads((p/'Verified_outputs.json').read_text(encoding='utf8'))
edit('function chooseEdition(edition){','const gbaOutputs='+json.dumps(outputs)+';\n'+'const gbaTwueHashes='+(p/'TWUE_outputs.json').read_text()+';\nconst gbaTwuePreviews='+(p/'TWUE_preview_hashes.json').read_text()+';\n'+(p/'ui.js').read_text()+'\nfunction chooseEdition(edition){')
edit('<option id="retailMoleChoice"','<option value="gba-twue-menus" data-gba="twueOption">GBA presentation + TWUE menus · US English</option><option value="gba-presentation" data-gba="option">GBA presentation · US English</option><option id="retailMoleChoice"')
edit('<section id="sayansPanel"', '''<section id="gbaPanel" class="panel" hidden><h2 data-gba="title"></h2><p data-gba="intro"></p><div id="gbaInputs"><div class="source"><label for="gbaCart" data-gba="cart"></label><input id="gbaCart" type="file" accept=".gba"></div><div id="gbaTwueInputs" class="source" hidden><label for="gbaTwueFile" data-gba="twueFile"></label><input id="gbaTwueFile" type="file" accept=".zip,.ips"><small data-gba="twueHint"></small></div><p><small>MultiFont Advance · madsiur · <a href="https://github.com/fred65816/ff6-multi-fonts-romhack" target="_blank" rel="noopener noreferrer">v1.4.1</a></small></p><p><label><input type="checkbox" id="gbaDash" checked> <span data-gba="dash"></span></label></p><p><label><input type="checkbox" id="gbaRules" checked> <span data-gba="rules"></span></label></p></div><p><small data-gba="fixes"></small></p></section>
<section id="sayansPanel"''')
edit('if(sayansInput){renderSayans();return;}','if(renderGbaPresentation())return;\n    if(sayansInput){renderSayans();return;}')
edit('function filename(p){',"function filename(p){\n    if(p.edition==='gba-twue-menus')return gbaPreviewName+'_TWUE_Menus'+(p.options.includes('dash')?'_BDash':'')+(p.advanceRules?'':'_SNESRules')+'.sfc';\n    if(p.edition==='gba-presentation')return (p.prior?(p.prior==='v1.6.6'?'FFVI_SNES_Advance_v1.6.6_GBA_Presentation':'FFVI_SNES_Advance_GBA_Presentation_'+p.prior):gbaPreviewName)+(p.options.includes('dash')?'_BDash':'')+(p.advanceRules?'':'_SNESRules')+'.sfc';")
edit('sayansInput=null;plainRegular=null;','sayansInput=null;plainRegular=null;gbaReopened=null;')
edit('const found=await identify(file);if(token!==romRevision)return;','const reopened=await reopenGba(file);if(token!==romRevision)return;\n            if(reopened){gbaReopened=reopened;return;}\n            const found=await identify(file);if(token!==romRevision)return;')
edit('if(sayansInput){await runSayans();return;}',"if(isGbaEdition(retailEdition)){await buildGbaUI();return;}\n    if(sayansInput){await runSayans();return;}")
for old,new in [
    ('Compatibility Patcher · v1.6.5</title>','Compatibility Patcher · v1.6.9</title>'),
    ('SNES Advance v1.6.5</p>','SNES Advance v1.6.9</p>'),
    ("return 'FFVI_Advance_v1.6.5_Sayans_'","return 'FFVI_Advance_v1.6.9_Sayans_'"),
    ("return 'FFVI_Advance_v1.6.5_'+tags","return 'FFVI_Advance_v1.6.9_'+tags")
]:edit(old,new)
Path(sys.argv[2]).write_text(source,encoding='utf8')
