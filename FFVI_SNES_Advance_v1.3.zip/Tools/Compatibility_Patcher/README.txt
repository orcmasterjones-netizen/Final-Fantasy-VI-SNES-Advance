FFVI SNES Advance Compatibility Patcher — expanded options
November 12, 2026 — native spell-name update

Open FFVI_SNES_Advance_Compatibility_Patcher.html in a current browser.
Choose a supported SNES Advance Regular/MoleMan ROM, or reopen a ROM already
made by the patcher. Files are processed locally; the tool works offline.

SPELL NAMES AND CATEGORY ICONS
Regular and Spanish with native fonts use the name Gravja, with its black-
magic icon. The shorter name fits the original seven-cell spell record;
the native readers, buffers and memory layout are unchanged. The separate
casting announcement also uses Gravja.

MoleMan, every supported TWUE edition and ROSE retain Gravija in full.
Regular/Spanish with either optional GBA font also retain the full name using
the existing font-compatible eight-cell adapter. Returning to native fonts
restores Gravja and the original seven-cell readers automatically.

Valor uses the support/effect icon in every edition. The added battle spells
use their proper spell-name records, including the routing fixes for MoleMan,
TWUE and ROSE. The new standalone Regular and MoleMan downloads are accepted,
along with the previously supported inputs and older full-name native builds.

Reopen an older recognized ROM and select Build ROM once to apply the latest
corrections while retaining its selected options. Installed font and music
sources are reused; a corrected current ROM does not need another rebuild.

TWUE 3.07
Start from Regular and select one primary edition:
  Base; Base + Updated Opera;
  Bug Fixes; Bug Fixes + Updated Opera;
  Bug Fixes + Add-Ons; Bug Fixes + Add-Ons + Updated Opera.
Supply the original TWUE 3.07 ZIP, or that edition's original IPS. The primary
edition cannot be changed after installation; start from Regular to choose
another. Earlier base TWUE 3.06 IPS and 3.06a/3.07 BPS inputs remain supported.
TWUE is an alternative to MoleMan, Spanish and ROSE, and includes Cancel dash.
When adding TWUE to a Regular ROM with Modern/Classic/CTB already installed,
select that original ATB patch again to adapt its hooks to the new edition.

GBA FONT CHOICES
Multi-Font Selection 1.4.1 is now the default when enabling GBA font in a new
build. Supply the author's original ZIP or Multi_Fonts_1.4.1_nh.ips. Menus use
fixed-width cells; dialogue is proportional. In-game Config defaults to
Advance and offers Normal/Advance; Normal uses the chosen edition's native
font. The selected font survives normal saves.

Our cartridge font remains available. It imports original glyphs from an
unmodified U.S. FFVI Advance ROM (.gba or its ZIP), uses proportional menus,
and supports longer names. Selecting it displays an inline timing note:
some menus and battle item/spell lists may be slightly slower to open or
redraw. The note is hidden when another font is selected or GBA font is off.

Reopening a ROM preserves its installed font. Personal patchers preserve
explicit saved font preferences and their verified source files. The new
default does not silently replace an existing cartridge or legacy font.

Leave GBA font unchecked for native fonts. New builds can switch between the
two font implementations, or return to native fonts, by reopening the ROM.
Old seibaby-font builds did not retain native glyphs: use a native-font base to
choose Multi-Font or native fonts from those builds. Longer item/monster names
require our cartridge font. ROSE retains its separately supported native font.

MUSIC PLAYER
TWUE 3.07 offers Config 1 (Music replaces the Mono option beside Stereo),
Config 2 (a new Music row), or the compatible Main Menu version. Main Menu A
is for Bug Fixes editions; B is for Base editions. Both retain Config.
The player includes SNES Advance's bonus music track.

Optional sound-effect volume, Lete River and caves/cliffs fixes can be selected
independently. Supply the original TWUE ZIP or the chosen player/fix IPS files.
A TWUE ZIP selected in the edition row can also supply the Music Player files.

BUILDING AND REOPENING
Choose one battle system and any compatible extra options, then Build ROM and
Download ROM. Every supported build is verified, including its reversible
spell-icon correction.
Installed Music/Multi-Font sources are retained for reopening without uploads.
Changing a player placement or adding a new fix requires its original source.
A personal HTML copy retains verified selected sources for private offline use.
Share the public patcher with other players, not a personal copy.

Existing battery saves can continue. Boot normally after changing ROMs; do not
load an emulator state containing code from another ROM. Keep a backup save.
Existing clymax Turn-Based builds retain that battle system; use a build without
clymax when switching away from it.

Read GRAVJA_NATIVE_NAMES_VALIDATION.txt for the latest test scope.
SPELL_ICON_AND_FONT_DEFAULTS_VALIDATION.txt records the preceding update.
EXPANDED_OPTIONS_VALIDATION.txt documents the earlier expanded-options release;
it and the other older reports are retained as historical evidence.
No game ROM or original third-party patch is included in this package.
Original author credits/readmes are in Credits/.
