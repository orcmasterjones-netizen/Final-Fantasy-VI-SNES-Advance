Final Fantasy VI • SNES Advance
v0.9.21 | Native spell-name/icon update + compatibility patcher (2026-11-12)

Play the Advance bonus content in the Super NES game. Seek out four new
espers, explore the three-party Dragon’s Den, take on the Soul Shrine,
and save clear data after the ending.

This release packages the verified Gravja/icon update and the compatibility
patcher as v0.9.21. If you already have the corrected Gravja/icon ROM, its
game data is unchanged; no additional ROM patch is needed for this packaging
update. Some included tools and practice-save filenames retain v0920 labels.
Those are the verified files for this release. Existing ROM filenames can
remain unchanged so their battery-save filenames continue to match.

PATCH THE GAME • REGULAR SNES TEXT

1. Extract this ZIP. Use a clean North American Final Fantasy III SNES ROM.
   The headerless file is 3,145,728 bytes. If yours is 3,146,240 bytes,
   remove the 512-byte copier header from a copy before patching.
2. Check the source CRC32 in your BPS patcher and apply the matching file.

   Original ROM       Source CRC32     File in Patches/
   USA v1.0           A27F1C7A         Regular_from_USA_v1.0.bps
   USA v1.1 (Rev 1)   C0FA0464         Regular_from_USA_v1.1.bps

3. Save the patched ROM as FFVI_Advance_v0920.sfc and open it in your
   SNES emulator. Either patch produces the same Regular edition.

   BPS patchers
   Floating IPS      https://github.com/Alcaro/Flips
   Rom Patcher JS    https://www.marcrobledo.com/RomPatcher.js/

OPTIONAL GBA TEXT BY MOLEMAN

1. Obtain MoleMan’s Final Fantasy VI - GBA Text v1.6 separately. Extract
   “Final Fantasy VI - GBA Text v1.6 (USA).bps”, the standard edition
   that keeps the pop-culture references.
   Project listing   https://www.romhacking.net/hacks/5864/
   v1.6 listing      https://retrohackers.net/hack-details.php?id=5864

2. Open Tools/Merge.html in a desktop browser. Select your clean USA v1.0
   or v1.1 ROM and MoleMan’s BPS. You can also select the patched Regular
   v0.9.21 ROM from the previous section. The merger works offline and
   accepts a ROM with a 512-byte copier header.
3. Choose “Build merged ROM”, then “Download verified ROM”. Open
   FFVI_Advance_v0920_MoleMan16.sfc in your emulator.

   Both finished ROMs are 4,194,304 bytes, headerless.
   Regular edition CRC32     8810E180
   MoleMan edition CRC32     0A338D73

OPTIONAL PATCHES • INCLUDED COMPATIBILITY TOOL

Open this file in a current desktop browser:
   Tools/Compatibility_Patcher/FFVI_SNES_Advance_Compatibility_Patcher.html

Select your SNES Advance ROM, choose compatible options, then Build ROM and
Download ROM. The tool works offline and processes your files locally.
It offers the supported battle systems, GBA fonts, Spanish, TWUE editions,
ROSE and Music Player options. Its README and original author credits are
included in the same folder. Third-party patches and game ROMs are not bundled;
the tool requests the original source files when a newly selected option
requires them.

You do not need to know which spell-name revision you have. The same tool
automatically recognizes the original v0.9.20 Regular/MoleMan releases, this
updated release, and supported older outputs from the compatibility patcher,
including the earlier eight-cell full-name Gravija builds. A ROM's filename
does not determine its version. Headered copies are also recognized.

When reopening an existing patcher build, keep its detected choices and build
to apply the current corrections. Installed font/music sources are reused.
Native Regular/Spanish builds use Gravja; MoleMan, TWUE, ROSE and optional GBA
font builds retain Gravija. The separately downloaded compatibility tool is
the same file and accepts the same older ROMs; this ZIP is not needed to run it.

UPGRADE AN EXISTING ROM

Apply the matching edition and source-version patch in Upgrade/ to your
headerless v0.9.19 or original v0.9.20 ROM. The v0.9.19 patches also include
the v0.9.20 bonus-boss battle-music update. BPS validates the exact source.
Keep the same ROM filename to continue with your existing battery save.
Load battery saves normally; do not resume an emulator state from an older ROM.

SPELL-NAME AND ICON CORRECTION

Regular uses the black-magic icon followed by "Gravja" in the original
seven-cell spell record. The separate cast-announcement name also reads
"Gravja". Valor uses the support/effect-magic icon. These are name-data
changes: Regular's executable code, name-reader widths, RAM usage and ROM
size are unchanged, with no additional name-reading CPU work.

MoleMan retains the full "Gravija" spelling in its existing nine-cell records,
with the black-magic icon, and uses the correct Valor icon. Its two battle
Magic columns now call the existing expanded spell-name reader, correcting
the routing for the added spells. No new name table or reader is allocated.

The included compatibility patcher retains the full "Gravija" spelling in
its full-name-capable editions and optional GBA-font builds. Use the included
tool when adding those options to either the older or corrected base ROM.

CHOOSE HOW TO PLAY

New game
   Choose New Game on the title screen.

Try the bonus content right away
   Open “Practice Saves/Start here.txt”. Three optional battery saves give
   you nine starting points, including the Soul Shrine ghost, the Dragon’s
   Den entrance, and the esper encounters. The same saves work with either
   edition. The guide explains how to try them alongside your own game.

Continue an original North American SNES save
   Back up your original battery save. Open Tools/FFVI_SNES_Save_Importer.html
   in a desktop browser and select the 8,192-byte .srm or .sav written by
   the original SNES game. Select only the original-game slots you want to
   import, then choose “Download compatible save”. The selected slots
   start the bonus content fresh. The tool copies the other slots as-is.

   Close the emulator and back up any same-named save before placing the
   downloaded file in its battery-save folder. Match the ROM’s basename
   (FFVI_Advance_v0920.srm or FFVI_Advance_v0920_MoleMan16.srm).
   Open the ROM and load the slot at the title screen. The practice saves
   are already in SNES Advance format and can be loaded directly.


CREDITS

Final Fantasy VI, Final Fantasy VI Advance, and the original game assets
and music are by Square / Square Enix. The FFVI disassembly and FF6Tools
are by everything8215 and contributors. The project uses Terii Senshi’s
Vanish/Doom fix and the disassembly’s Evade fix.
https://github.com/everything8215/ff6
https://github.com/everything8215/ff6tools
https://www.rpglegion.com/ff6/hack/vanish.htm
https://www.rpglegion.com/ff6/hack/evade.htm

MoleMan created the optional GBA Text hack. His original release lists
its additional contributors. Floating IPS is by Alcaro and contributors.
The FantasyAnime FF6 save collection was used in earlier compatibility tests.
