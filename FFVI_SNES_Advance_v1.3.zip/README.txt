ROSE CLEAR-SAVE COMPATIBILITY UPDATE - November 12, 2026

Fixes ROSE's post-ending Yes response returning to title before the clear-save slot screen. Open a recognized prior ROSE ROM in this updated compatibility patcher and build once to apply the repair; the original ROSE IPS is not required again for recognized outputs. The standalone Regular/MoleMan base and upgrade BPS patches are unchanged. This v1.3 bundle updates its embedded compatibility tool. Non-ROSE compatibility output bytes are unchanged.

See ROSE_CLEAR_SAVE_VALIDATION.txt for the exact corrected ROM and validation scope.

Final Fantasy VI • SNES Advance
v1.3 | Corrected standalone base + original-ROM compatibility patcher (2026-11-12)

Play the Advance bonus content in the Super NES game. Seek out four new
espers, explore the three-party Dragon’s Den, take on the Soul Shrine,
and save clear data after the ending.

This refreshed v1.3 release carries the Continue/save-restoration and Bushido
heading fixes into both standalone editions. It also retains the Gravja/icon
corrections and bundled compatibility patcher. The first public v1.3 ZIP used
the internal v0.9.21 label; its ROMs can be updated with the matching
Upgrade/*_from_v0.9.21.bps file in this ZIP.

Some tools and practice-save filenames retain v0920 labels. Keep an existing
ROM's filename when updating so its battery-save filename continues to match.
New ROMs may use any filename; recognition depends on their contents.

START WITH THE INCLUDED ALL-IN-ONE PATCHER

1. Open Tools/Compatibility_Patcher/FFVI_SNES_Advance_Compatibility_Patcher.html
   in a current desktop browser and select your clean North American Final
   Fantasy III v1.0 or v1.1 (Rev 1) ROM. Copier headers are handled automatically.
2. Choose Regular or MoleMan v1.6. For MoleMan, supply the original standard
   v1.6 BPS or its ZIP, obtained separately from the project listed below.
3. Choose Apply base edition. The tool automatically selects the correct
   original-ROM revision. Download the verified base, or choose optional
   compatibility features and build them before downloading.

Both original revisions produce the same current v1.3 ROM for each edition.
Existing SNES Advance ROMs can still be opened directly. The standalone BPS
and Merge.html routes below remain available and produce identical bases.

PATCH THE GAME • REGULAR SNES TEXT

1. Extract this ZIP. Use a clean North American Final Fantasy III SNES ROM.
   The headerless file is 3,145,728 bytes. If yours is 3,146,240 bytes,
   remove the 512-byte copier header from a copy before patching.
2. Check the source CRC32 in your BPS patcher and apply the matching file.

   Original ROM       Source CRC32     File in Patches/
   USA v1.0           A27F1C7A         Regular_from_USA_v1.0.bps
   USA v1.1 (Rev 1)   C0FA0464         Regular_from_USA_v1.1.bps

3. Save the patched ROM as FFVI_Advance_v1.3.sfc and open it in your
   SNES emulator. Either patch produces the same Regular edition.

   BPS patchers
   Floating IPS      https://github.com/Alcaro/Flips
   Rom Patcher JS    https://www.marcrobledo.com/RomPatcher.js/

OPTIONAL GBA TEXT BY MOLEMAN

1. Obtain MoleMan’s Final Fantasy VI - GBA Text v1.6 separately. Extract
   “Final Fantasy VI - GBA Text v1.6 (USA).bps”, the standard edition
   that keeps the pop-culture references.
   Project listing   https://www.romhacking.net/hacks/5864/
   v1.6 listing      https://retrohackers.net/hack-details.php?id=5864

2. Open Tools/Merge.html in a desktop browser. Select your clean USA v1.0
   or v1.1 ROM and MoleMan’s BPS. You can also select the patched Regular
   v1.3 ROM from the previous section. The merger works offline and
   accepts a ROM with a 512-byte copier header.
3. Choose “Build merged ROM”, then “Download verified ROM”. Open
   the downloaded MoleMan ROM in your emulator.

   Both finished ROMs are 4,194,304 bytes, headerless.
   Regular edition CRC32     E921D132
   MoleMan edition CRC32     B36CC621

OPTIONAL PATCHES • INCLUDED COMPATIBILITY TOOL

Open this file in a current desktop browser:
   Tools/Compatibility_Patcher/FFVI_SNES_Advance_Compatibility_Patcher.html

Select your SNES Advance ROM, or prepare a clean original as described above,
choose compatible options, then Build ROM and Download ROM. The tool works offline and processes your files locally.
It offers the supported battle systems, GBA fonts, Spanish, TWUE editions,
ROSE and Music Player options. Its README and original author credits are
included in the same folder. Third-party patches and game ROMs are not bundled;
the tool requests the original source files when a newly selected option
requires them.

You do not need to know which spell-name revision you have. The same tool
automatically recognizes the original v0.9.20 Regular/MoleMan releases, this
updated release, and supported older outputs from the compatibility patcher,
including the earlier eight-cell full-name Gravija builds. A ROM's filename
does not determine its version. Headered copies are also recognized.

When reopening an existing patcher build, keep its detected choices and build
to apply the current corrections. Installed font/music sources are reused.
Native Regular/Spanish builds use Gravja; MoleMan, TWUE, ROSE and optional GBA
font builds retain Gravija. The separately downloaded compatibility tool is
the same file and accepts the same older ROMs; this ZIP is not needed to run it.

UPGRADE AN EXISTING ROM

Apply the matching edition and source-version patch in Upgrade/ to your
headerless ROM:
- *_from_v0.9.19.bps: the earlier v0.9.19 release.
- *_from_v0.9.20.bps: the original full-name v0.9.20 release.
- *_from_v0.9.21.bps: the preceding Gravja/icon release, also first uploaded
  under the public v1.3 name.
The v0.9.19 patches include the bonus-boss battle-music update. Every path
includes the current spell icons and Continue/Bushido fixes. BPS verifies
the exact source contents, so the ROM filename does not select its version.
Keep the same ROM filename to continue with your existing battery save.
Load battery saves normally; do not resume an emulator state from an older ROM.

CONTINUE AND BUSHIDO CORRECTIONS IN THIS REFRESH

The Continue path now calls the existing expanded-save restoration routine
on the correct instruction boundary. The Bushido menu heading now ends at
its intended terminator. Relative to the preceding v0.9.21/first-v1.3 ROMs,
each edition changes five functional byte values and four checksum bytes.
These edits do not change battle timing code, name-reader widths, ROM size,
RAM allocation or save layout. No optional font, job-title or menu-layout
features are added to the standalone base.

SPELL-NAME AND ICON CORRECTION (RETAINED)

Regular uses the black-magic icon followed by "Gravja" in the original
seven-cell spell record. The separate cast-announcement name also reads
"Gravja". Valor uses the support/effect-magic icon. Those earlier spelling
and icon edits only changed name data, with no extra name-reading CPU work.
The separate Continue instruction repair in this refresh is described above.

MoleMan retains the full "Gravija" spelling in its existing nine-cell records,
with the black-magic icon, and uses the correct Valor icon. Its two battle
Magic columns now call the existing expanded spell-name reader, correcting
the routing for the added spells. No new name table or reader is allocated.

The included compatibility patcher retains the full "Gravija" spelling in
its full-name-capable editions and optional GBA-font builds. Use the included
tool when adding those options to either the older or corrected base ROM.

CHOOSE HOW TO PLAY

New game
   Choose New Game on the title screen.

Try the bonus content right away
   Open “Practice Saves/Start here.txt”. Three optional battery saves give
   you nine starting points, including the Soul Shrine ghost, the Dragon’s
   Den entrance, and the esper encounters. The same saves work with either
   edition. The guide explains how to try them alongside your own game.

Continue an original North American SNES save
   Back up your original battery save. Open Tools/FFVI_SNES_Save_Importer.html
   in a desktop browser and select the 8,192-byte .srm or .sav written by
   the original SNES game. Select only the original-game slots you want to
   import, then choose “Download compatible save”. The selected slots
   start the bonus content fresh. The tool copies the other slots as-is.

   Close the emulator and back up any same-named save before placing the
   downloaded file in its battery-save folder. Match the ROM’s basename
   (for example, FFVI_Advance_v1.3.srm for FFVI_Advance_v1.3.sfc).
   Open the ROM and load the slot at the title screen. The practice saves
   are already in SNES Advance format and can be loaded directly.


CREDITS

Final Fantasy VI, Final Fantasy VI Advance, and the original game assets
and music are by Square / Square Enix. The FFVI disassembly and FF6Tools
are by everything8215 and contributors. The project uses Terii Senshi’s
Vanish/Doom fix and the disassembly’s Evade fix.
https://github.com/everything8215/ff6
https://github.com/everything8215/ff6tools
https://www.rpglegion.com/ff6/hack/vanish.htm
https://www.rpglegion.com/ff6/hack/evade.htm

MoleMan created the optional GBA Text hack. His original release lists
its additional contributors. Floating IPS is by Alcaro and contributors.
The FantasyAnime FF6 save collection was used in earlier compatibility tests.
