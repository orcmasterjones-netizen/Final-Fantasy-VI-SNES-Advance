// Reproducible focused check of the exact distributed HTML.
// Usage: node verify-automatic-rom-recognition.mjs /absolute/path/to/input
// Inputs are the public HTML and current standalone Regular/MoleMan ROMs.
// Old fixtures are recovered in memory through guarded undo, then accepted only
// after their complete SHA-256 equals the previously published original hash.
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import assert from 'node:assert/strict';
import {webcrypto,createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const directory=path.resolve(process.argv[2]||new URL('../input/',import.meta.url).pathname);
const here=fileURLToPath(new URL('.',import.meta.url));
const htmlPath=path.join(directory,'FFVI_SNES_Advance_Compatibility_Patcher.html');
const html=fs.readFileSync(htmlPath,'utf8');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const htmlHash='520c95d92a51686472958da63354758e1fab68088bc52abb3d793440af8817be';
assert.equal(sha(Buffer.from(html)),htmlHash,'Unexpected public HTML');
const catalog=JSON.parse(html.match(/<script type="application\/json" id="catalog">([\s\S]*?)<\/script>/)[1]);
const script=html.match(/<script>\n([\s\S]*)<\/script>/)[1];
const context=vm.createContext({console,Uint8Array,DataView,TextDecoder,TextEncoder,URL,File,Blob,Response,atob,btoa,CompressionStream,DecompressionStream,crypto:webcrypto,navigator:{language:'en'},document:{getElementById:id=>({textContent:JSON.stringify(id==='catalog'?catalog:{})}),documentElement:{outerHTML:''}}});
vm.runInContext(script.split('const controls=new Map()')[0]+';globalThis.api={identify,combine,combineComposed,applySpellIconRecipe,spellIconRecipes};',context);
const api=context.api;
const load=(bytes,name='user-renamed-game.bin')=>api.identify(new File([bytes],name));
const expected={
 regular:{rawOld:'881313788f00b36af61ae7373274cfebefcab46cd6a447683407c63ee1ffcc7d',rawNew:'74f3ed4611775ce7ddae7671388e6e9add15f79bed71831705f4910c0a548855',composed:'d49c880d31042ef93a489e0a587ecb3bf83280d7ed4b9836daef3b6e75989a31'},
 moleman:{rawOld:'e040f27df1c9637278e6cbff135fa30cb52550cc651d2a43ca34cae37a5f2e0c',rawNew:'5fb6841b35a81bdcef558a3886c416ac854e7cc7794739311e1148c424fa9f7d',composed:'2a47e5e137786a9dc4eda1e5f4e162ec42c5825753a1c2bf94469bf544683e52'}
};
const report={passed:false,publicHtmlSha256:htmlHash,cases:[],counts:{recognitions:0,builds:0,headered:0,checksumRepairs:0,corruptionRejections:0},scope:'Current exact public HTML; automatic old/new Regular and MoleMan recognition, preceding eight-cell Regular output, current composed output, arbitrary filenames, copier headers, checksum repair, and unknown modifications. Full donor/font-option matrix is retained prior evidence, not rerun here.'};
const all=[];
for(const [edition,filename,recipeId] of [['regular','FFVI_Advance_v0920.sfc','native-seven-cell'],['moleman','FFVI_Advance_v0920_MoleMan16.sfc','standalone-nine-cell']]){
 const currentRaw=new Uint8Array(fs.readFileSync(path.join(directory,filename)));assert.equal(sha(currentRaw),expected[edition].rawNew);
 const recipe=api.spellIconRecipes.find(r=>r.id===recipeId);assert(recipe);
 const oldRaw=api.applySpellIconRecipe(currentRaw,recipe,'before');assert.equal(sha(oldRaw),expected[edition].rawOld);
 const oldInput=await load(oldRaw),before=await api.combineComposed(oldInput,new Set()),current=await api.combine(oldInput,new Set());
 assert.equal(current.id,expected[edition].composed);
 all.push({edition,kind:'old-standalone',bytes:oldRaw},{edition,kind:'current-standalone',bytes:currentRaw},{edition,kind:'old-pre-icon-composed',bytes:before.bytes},{edition,kind:'current-composed',bytes:current.bytes});
 if(edition==='regular'){
  const wide=api.spellIconRecipes.find(r=>r.id==='seven-to-eight-cell'),oldFull=api.applySpellIconRecipe(before.bytes,wide);
  assert(sha(oldFull).startsWith('9754d75d'),'Unexpected preceding full-name native output');
  all.push({edition,kind:'previous-eight-cell-full-name',bytes:oldFull});
  assert.equal(Buffer.from(current.bytes.subarray(0x305c09,0x305c10)).toString('hex'),'e986ab9aafa39a');
  assert.equal(Buffer.from(current.bytes.subarray(0x305e7a,0x305e84)).toString('hex'),'86ab9aafa39affffffff');
 }else assert.equal(Buffer.from(current.bytes.subarray(0x3c82f4,0x3c82fd)).toString('hex'),'e986ab9aafa2a39aff');
}
for(const record of all){
 const item={edition:record.edition,kind:record.kind,inputHash:sha(record.bytes),outputHash:expected[record.edition].composed,variants:[]};
 for(const headered of [false,true]){
  const bytes=headered?new Uint8Array(Buffer.concat([Buffer.alloc(512,0xa5),Buffer.from(record.bytes)])):record.bytes;
  const input=await load(bytes,headered?'arbitrary-name.smc':'unrelated-title.bin');
  assert.equal(input.profile.edition,record.edition);assert.deepEqual([...input.profile.options],[]);
  const built=await api.combine(input,new Set(input.profile.options));assert.equal(built.id,expected[record.edition].composed);assert.equal(sha(built.bytes),built.id);
  if(record.kind==='previous-eight-cell-full-name')assert(input.upgrade);
  if(record.kind==='current-composed')assert(!input.upgrade);
  report.counts.recognitions++;report.counts.builds++;if(headered)report.counts.headered++;
  item.variants.push({headered,recognizedEdition:input.profile.edition,upgrade:!!input.upgrade});
 }
 report.cases.push(item);
}
for(const edition of ['regular','moleman']){
 const record=all.find(r=>r.edition===edition&&r.kind==='current-standalone');
 const badChecksum=record.bytes.slice();badChecksum.fill(0,0xffdc,0xffe0);
 const input=await load(badChecksum);assert(input.upgrade);assert.equal((await api.combine(input,new Set())).id,expected[edition].composed);report.counts.checksumRepairs++;
 for(const at of [0x1234,edition==='regular'?0x305c09:0x3c82f4]){
  const unknown=record.bytes.slice();unknown[at]^=1;await assert.rejects(()=>load(unknown));report.counts.corruptionRejections++;
 }
}
assert.equal(sha(fs.readFileSync(htmlPath)),htmlHash,'HTML changed during test');
report.passed=true;
fs.writeFileSync(path.join(here,'automatic-rom-recognition.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
