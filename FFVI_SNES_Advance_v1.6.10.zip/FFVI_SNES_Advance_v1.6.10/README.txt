Final Fantasy VI • SNES Advance v1.6.10

SNES Advance brings the bonus content from Final Fantasy VI Advance to the North American SNES game. It includes the Dragon’s Den, Soul Shrine, four additional Espers and their quests, new equipment and magic, and the option to save after defeating Kefka.

New in v1.6.10
ROSE 2.04 now works with RoSoDude’s Modern ATB Enhanced, Classic ATB Enhanced, and CTB Wait through the compatibility patcher. See CHANGELOG_v1.6.10.txt for setup, checksums and test results.

Added in v1.6.9
The compatibility patcher adds “GBA presentation + TWUE menus · US English”. This combines MultiFont Advance dialogue and descriptions with the TWUE menu lettering, digits and layout, including Relic and the full MP Cost label. Open either TWUE-menu preview ROM to upgrade directly. For a fresh build, see Tools/Compatibility_Patcher/START_HERE_GBA_Presentation.txt. See CHANGELOG_v1.6.9.txt for release tests.

Added in v1.6.8
GBA Presentation uses M. Def. and M. Eva. in Status, Equip, Relics and item details. The opening Narshe walk matches the US GBA cartridge with or without B. Open an existing v1.6.7, v1.6.6 or RC3 GBA Presentation ROM in the compatibility patcher and choose Download ROM to upgrade. See CHANGELOG_v1.6.8.txt.

Added in v1.6.7
GBA Presentation corrects the Items title and the MP Cost display. Open your v1.6.6 or RC3 GBA Presentation ROM in the compatibility patcher and choose Download ROM to update it with the same settings. See CHANGELOG_v1.6.7.txt for the menu checks.

Added in v1.6.6
The compatibility patcher now offers GBA presentation · US English. Select a clean US SNES ROM or current plain Regular ROM, choose this edition, and supply your unmodified Final Fantasy VI Advance (USA) ROM. Select Build ROM and Download ROM. MultiFont Advance is active from the intro. B-Dash and the GBA Evade/Vanish rules are on by default. Both switches are optional. Find the instructions in Tools/Compatibility_Patcher/START_HERE_GBA_Presentation.txt and the release tests in CHANGELOG_v1.6.6.txt.

Also available since v1.6.5
Both Sayans Spanish translations are available in the main compatibility patcher. Choose either translation alone or with TWUE, with an optional Music Player. The tool recognizes already-translated Sayans ROMs and the six RC1 Sayans outputs. See Tools/Compatibility_Patcher/Sayans/ for instructions in English and Spanish.

QUICK START

1. Extract the ZIP and open Tools/Compatibility_Patcher/FFVI_SNES_Advance_Compatibility_Patcher.html in a desktop browser.
2. Load a clean Final Fantasy III (USA) v1.0 or v1.1 ROM. For Regular or MoleMan, choose the base edition and select Apply base edition. MoleMan requires the original translation ZIP or BPS. You can then download the base or build it with optional patches.
3. For Sayans, choose Spain or South America, select a gameplay preset, then select Build ROM and Download ROM. An original Sayans-translated ROM opens directly at the preset selector. The TWUE presets accept the original TWUE 3.07 ZIP.
4. To update a supported SNES Advance ROM, open it in the same tool and review its detected edition and available options. Choose Build ROM when prompted.
5. Keep your .srm battery save paired with the new ROM’s basename. Restart the emulator and load through Continue to pick up the updated map data. The save importer in Tools/ is for original-game saves.

See Tools/Compatibility_Patcher/Bestiary/README.txt for controls, encounter tracking, and credits.

DIRECT BPS PATCHES

Use a copy of a headerless ROM with a BPS patcher such as Floating IPS or Rom Patcher JS. For the Regular edition from clean retail, match the input CRC32 below. Both patches produce the same game.

  Input                        CRC32       Patch in Patches/
  Final Fantasy III USA v1.0   A27F1C7A    Regular_from_USA_v1.0.bps
  Final Fantasy III USA v1.1   C0FA0464    Regular_from_USA_v1.1.bps

  Floating IPS      https://github.com/Alcaro/Flips
  Rom Patcher JS    https://www.marcrobledo.com/RomPatcher.js/

For plain earlier SNES Advance builds, choose the matching BPS in Upgrade/. The filename gives the edition and input version. Each patch upgrades to the plain v1.6.1 game data also used by v1.6.6. For MoleMan v1.6 game inputs, the files ending in _Compatibility.bps accept the corresponding plain ROM rebuilt with the compatibility tool. Regular uses one file for either route. The patcher checks the input checksum. Use the HTML compatibility patcher for other combinations.

OPTIONAL MOLEMAN MERGER

Tools/Merge.html builds the MoleMan edition directly from a clean USA v1.0/v1.1 ROM or a plain Regular ROM and your original MoleMan translation patch. Select Build merged ROM, then Download verified ROM. Supported translations include v1.6 Standard and v1.8 Standard and Minus Pop-Culture References.
https://www.romhacking.net/hacks/5864/

Expected CRC32 for a fresh base or standalone merge
  Regular                        5ACCB7C3
  MoleMan text v1.6              E435EDCD
  MoleMan text v1.8 Standard     DEC3C6CD
  MoleMan text v1.8 Minus        F89535D8

RELEASE_MANIFEST.json gives the source CRC32 and output SHA-256 for every BPS, including the compatibility-tool builds with their distinct checksums.

OPTIONAL PATCHES AND MUSIC

The compatibility patcher supports Spanish, TWUE, ROSE, fonts, battle systems and other combinations. See Tools/Compatibility_Patcher/README.txt for supported sources and options. The default uses native SNES audio. Selecting Dancing Mad MSU-1 enables separately supplied PCM tracks. Setup, credits and the driver license are in Tools/Compatibility_Patcher/Dancing_Mad/.

CHOOSE HOW TO PLAY

New game
   Choose New Game on the title screen.

Try the bonus content right away
   Open “Practice Saves/Start here.txt”. Three optional battery saves give
   you nine starting points, including the Soul Shrine ghost, the Dragon’s
   Den entrance, and the esper encounters. The same saves work with either
   edition. The guide explains how to try them alongside your own game.

Continue an original North American SNES save
   Back up your original battery save. Open Tools/FFVI_SNES_Save_Importer.html
   in a desktop browser and select the 8,192-byte .srm or .sav written by
   the original SNES game. Select only the original-game slots you want to
   import, then choose “Download compatible save”. The selected slots
   start the bonus content fresh. The tool copies the other slots as-is.

   Close the emulator and back up any same-named save before placing the
   downloaded file in its battery-save folder. Match the ROM’s basename
   (for example, FFVI_Advance_v1.6.10_Regular_Bestiary.srm for FFVI_Advance_v1.6.10_Regular_Bestiary.sfc).
   Open the ROM and load the slot at the title screen. The practice saves
   are already in SNES Advance format and can be loaded directly.


CREDITS

Final Fantasy VI, Final Fantasy VI Advance, and the original game assets
and music are by Square / Square Enix. The FFVI disassembly and FF6Tools
are by everything8215 and contributors. The project uses Terii Senshi’s
Vanish/Doom fix and the disassembly’s Evade fix.
https://github.com/everything8215/ff6
https://github.com/everything8215/ff6tools
https://www.rpglegion.com/ff6/hack/vanish.htm
https://www.rpglegion.com/ff6/hack/evade.htm

MoleMan created the optional GBA Text hack. His original release lists
its additional contributors. Floating IPS is by Alcaro and contributors.
The FantasyAnime FF6 save collection was used in earlier compatibility tests.
