Final Fantasy VI • SNES Advance v1.7 compatibility patcher

Extract the ZIP, then open FFVI_SNES_Advance_Compatibility_Patcher.html in a desktop browser. The tool builds the ROM locally and works offline.

To add MoleMan’s translation to a clean US ROM or a supported plain SNES Advance Regular ROM, open ../Merge.html. Select your ROM and MoleMan’s GBA Text ZIP or BPS. The v1.8 ZIP includes Standard and Minus Pop-Culture References.

Build a new ROM

1. Select your unmodified Final Fantasy III (USA) SNES ROM, v1.0 or v1.1. The patcher recognizes either revision with or without a 512-byte copier header.
2. Choose a base edition. For Regular or MoleMan, select “Apply base edition”. MoleMan requires the original GBA Text patch or ZIP. For GBA Presentation, supply Final Fantasy VI Advance (USA). The TWUE-menu presentation also requires the original TWUE 3.07 source.
3. Download the prepared base, or choose compatible options and supply the requested files. Select “Build ROM” when prompted, then “Download ROM”.

Update a ROM or keep playing from a save

Open your existing SNES Advance ROM, review the detected edition and options, and download the updated ROM. If the patcher offers “Build ROM”, select it first. If your input requires rebuilding from retail, follow the prompt and select the same options on the fresh build.

Close your emulator, back up your battery save, and give a copy of the .srm the same basename as your new ROM. Boot the new ROM and choose Continue. Keep emulator save states with the ROM version that created them.

Choose a GBA font

MultiFont Advance (default) uses the Advance design from Multi-Font Selection v1.4.1. Menu letters occupy fixed-width slots. Switch between Normal and Advance in Config. For the optional font on a custom build, supply the Multi-Font Selection patch. The GBA Presentation presets already include it.

Original Game Boy Advance font imports the letter shapes from your US Final Fantasy VI Advance ROM. Menu letters take up different widths, so a narrow letter like “i” takes less space than “W”. Choose this option for longer item and monster names. Some menus and long battle lists may redraw slightly more slowly. This option requires 16 KiB of battery-backed SRAM. Check your cartridge or flashcart before using it.

A direct upgrade is included for the unheadered v1.6.12 MoleMan v1.8 build with the original Game Boy Advance font and longer names. Use a BPS patcher with the following file only when your source SHA-256 matches.

  Patch   ../../Patches/Cartridge_Font_Long_Names_16KiB_from_v1.6.12.bps
  Source  c31dae59586a06011d0ef3dd8c89efb6fd15ccfcb39132180ab9df0441f562d5
  Result  5a099a38d9feade7e6273942cd476320348f30bd0c0a07298c059ee339243fd2

Options and references

• GBA Presentation and GBA Presentation + TWUE menus both offer optional field portraits. See START_HERE_GBA_Presentation.txt for sources, setup and the v1.7 portrait fix.
• For the TWUE story translation, select TWUE under the Regular edition’s options. For ROSE 2.04 with an optional battle mode, select ROSE and the desired mode and supply the original patch ZIPs when asked.
• Sayans/README.txt and Sayans/LEEME.txt cover the Spanish editions. Bestiary/README.txt covers bestiary controls and tracking. Dancing_Mad/README.txt covers MSU-1 audio.
• ../../CHANGELOG_v1.7.txt lists the gameplay fixes. ../../RELEASE_MANIFEST.json contains the expected hashes. README_v1.6.12.txt preserves the earlier detailed option reference. Original author credits and notices are in Credits/.
