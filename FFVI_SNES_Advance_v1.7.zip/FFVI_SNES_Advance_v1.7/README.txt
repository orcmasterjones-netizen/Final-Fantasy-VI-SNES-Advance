Final Fantasy VI • SNES Advance v1.7

SNES Advance brings the Dragon’s Den, Soul Shrine, four additional espers and their quests, new equipment and magic, and post-Kefka clear saves to Final Fantasy III on the North American SNES. Press A at “The End” to save cleared game data.

Install Regular

Use a BPS patcher on a copy of your unheadered Final Fantasy III (USA) ROM. Match your source to one of the files in Patches/.

  Source              Source CRC32   Patch
  USA v1.0            A27F1C7A       Regular_from_USA_v1.0.bps
  USA v1.1 (Rev 1)    C0FA0464       Regular_from_USA_v1.1.bps

Both produce the same v1.7 Regular ROM. Its SHA-256 is
3c128e41751686d25d3199eae24a1f8179169a9910e18eeab6339e915c88017f

Choose an edition or update an existing ROM

Extract the ZIP and open Tools/Compatibility_Patcher/FFVI_SNES_Advance_Compatibility_Patcher.html in a desktop browser. The tool runs offline and accepts a US v1.0 or v1.1 SNES ROM with or without a 512-byte copier header. Choose your edition and supply any original files the tool requests. For Regular and MoleMan, choose “Apply base edition”. Download the base directly, or select options, choose “Build ROM” and then “Download ROM”.

For MoleMan’s translation alone, open Tools/Merge.html. Choose a clean US SNES ROM or a supported plain Regular SNES Advance ROM, then supply MoleMan’s original GBA Text ZIP or BPS. The v1.8 ZIP offers both Standard and Minus Pop-Culture References.

To update a recognized SNES Advance ROM, open it in the v1.7 tool, check the detected edition and options, and download the updated ROM. Choose “Build ROM” first if prompted. If you use one of the older BPS files in Legacy_Upgrade_to_v1.6.12/, apply it to its matching input, then open the resulting v1.6.12 ROM in the v1.7 tool to finish.

What changed in v1.7

Escaping with an added weapon queued for Throw now returns it to the correct inventory stack. Automatically cast Valor uses the corrected targeting logic. GBA Presentation fixes cover the Opera’s second verse, the brief flash before field portraits appear, and battle entry with SNES rules. ROSE fixes include the Zozo window jump, Stop and confused Runic, the mine cart and Cranes, the Fanatics’ Tower summit chest, and both Joker Doom outcomes. See CHANGELOG_v1.7.txt for the full list.

Original Game Boy Advance font and existing saves

The original Game Boy Advance font now requires 16 KiB of battery-backed SRAM. Check that your cartridge or flashcart supports this size before choosing the option. This fix protects the field return after Serpent Trench and mine-cart battles. It also preserves expanded item quantities in battle. GBA Presentation uses MultiFont Advance and does not require the upgrade for the original Game Boy Advance font.

Back up your .srm with the emulator closed. Give a copy of the battery save the same basename as the new ROM, start the game normally and choose Continue. Emulator save states contain code from the old ROM. For an original SNES game save, use Tools/FFVI_SNES_Save_Importer.html. For ready-to-play bonus content, see Practice Saves/Start here.txt.

Guides and credits

Tools/Compatibility_Patcher/README.txt covers editions, optional sources and the exact-input upgrade for the original Game Boy Advance font. Its START_HERE_GBA_Presentation.txt covers both GBA menu styles and optional portraits. RELEASE_MANIFEST.json lists the v1.7 ROM hashes by profile. README_v1.6.12.txt and earlier changelogs document their named versions.

Final Fantasy VI, Final Fantasy VI Advance, and the original game assets
and music are by Square / Square Enix. The FFVI disassembly and FF6Tools
are by everything8215 and contributors. The project uses Terii Senshi’s
Vanish/Doom fix and the disassembly’s Evade fix.
https://github.com/everything8215/ff6
https://github.com/everything8215/ff6tools
https://www.rpglegion.com/ff6/hack/vanish.htm
https://www.rpglegion.com/ff6/hack/evade.htm

MoleMan created the optional GBA Text hack. His original release lists
its additional contributors. Floating IPS is by Alcaro and contributors.
The FantasyAnime FF6 save collection was used in earlier compatibility tests.
