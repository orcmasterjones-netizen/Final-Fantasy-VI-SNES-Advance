Rebuilding the v1.6.10 compatibility patcher

Run python build_patcher.py original-v1.6.5.html output.html with the original SNES Advance v1.6.5 compatibility patcher as input. Use the scripts and JSON files in this folder together.

Verified_outputs.json identifies the four GBA Presentation outputs. TWUE_outputs.json identifies the four GBA Presentation + TWUE menus outputs. Each SHA-256 maps to a pair of switches in B-Dash, GBA battle rules order. TWUE_preview_hashes.json identifies supported preview upgrades.

twue-menus.js and twue-terms.js import the menu layout and adapt its terminology. The base TWUE 3.07 menu data comes from the player's copy of the TWUE distribution. The preset-specific JavaScript and builder are licensed under GPL-3.0. See ../MultiFont/LICENSE. The original patcher and credited projects retain their respective licenses.

The ROSE ATB adapter is in rose-atb.js. Its loader uses the original ROM bytes in originals.json and the verified output hashes in outputs.json. rose_atb_build.py integrates it into the patcher.
