==========================INSTRUCTIONS==========================

This rom is for an unheadered 1.0 USA rom. It is completely incompatible with the Japanese version.

Unzip the file into your asar folder and copy your rom into the same folder. Edit the .asm file to specify the bank in which you want to install the Bestiary, then run asar.exe. Type "Bestiary.asm", enter, the name of your rom, and enter. The command window will say that it encountered errors and ask if you want to continue patching; this is normal, hit enter. Your rom is now patched.

Make sure you ONLY use asar to assemble this, other assemblers will not work. You must also make sure your FF6 rom is in .sfc format, simply rename it from a .smc and then rename it back after assembly.

==============================USAGE=============================

The Bestiary is called up in-game by the event code "9E". This goes unused in the vanilla and has been edited to open the Bestiary menu. Note that while this code is functional upon installation, no changes were made to the game itself to add a way to open the Bestiary - that is, no NPC or book, etc, was added to access it. You'll have to do that on your own.

For troubleshooting purposes, there is a way to default the Bestiary to displaying all possible enemies. To do this, navigate in the asm to the header "Initialize Bestiary menu", and there will be an obvious line informing you it is a placeholder for code to load all enemies. Copy the following over that line:

        TDC
        TAX
        LDA #$FF
.Loop:  STA $1CF8,X
        INX
        CPX.W #48
        BNE .Loop

You can simply delete this code and re-assemble your rom to revert the Bestiary to its previous functionality. There is also a function to replace the main menu with the Bestiary, again for ease of access. Navigate to "invoke bestiary instead of main menu", there will be a line that reads "LDA.B #0". Change that 0 to a 6, and the "X" button will open the Bestiary in the field; the normal main menu can still be accessed from the world map. Simply change the value back and reassemble to revert this.

Because the Bestiary enemy list is generated using a new subroutine added to battles, any saves from a game without the Bestiary will load an inaccurate list. Playing a new game however will store and load it properly. 

===========================MODIFYING============================

By default the Bestiary list is organized by rough order of when you encounter enemies in the game. The download includes three lists: "Organized" is the default; "Alphabetical" lists enemies by name, only sorting out bosses and minibosses to put them at the end, also alphabetically; and "Vanilla" is the original enemy list according to ID, without sorting out bosses.

To change any of these lists, open the Bestiary.asm and search for "HEADER: MONSTER LIST", and copy the list you want to use over the list under "monster_id_table". All lists except for "Vanilla" exclude cinematic and dummied enemies, and also exclude the final bosses, since you can't access the Bestiary after fighting them and thus their entries cannot be added in a normal game. You can otherwise reorganize the lists as you like.

To rewrite descriptions, search the Bestiary.asm for "HEADER: DESCRIPTIONS". Descriptions are linked directly to the monster IDs and their vanilla names in the rom. By default with installation, the descriptions describe enemies by sprite and list their location.

Also take note of the field in the opening section of the asm that determines the length of your Bestiary menu. If you have a different number of enemies in your mod, you'll have to change that value to allow the full Bestiary to load.

=========================TECHNICAL DATA=========================

The Bestiary functions by repurposing unused menu commands, most prominently the feature to rename Cyan's Swdtech/Bushido commands. This feature was removed from the NA version, so its menu functions went unused. The SRAM to save the names of his attacks in save data was likewise repurposed to save the list of enemies encountered to generate the Bestiary.

Most of the Bestiary's coding is relocatable to free space as designated in the asm file. That which could not relates to battle subroutines in C2 bank, or tables in C0 and C3 bank that the game uses to track which menu the player is accessing; to accomodate the Bestiary these tables had to be relocated to have another pointer added.

By their nature most mods do not meddle with these sorts of functions, so hopefully conflicts will be at a minimum. At the least, this mod is fully compatible with the CV Reynolds Bugfix Compilation, "Restored Ability Names" (including character classes), "Expanded Item Names", and "Description Expansions". Any other mods or projects, compatibility cannot be assured, but if you know what you're doing it ought to be possible to relocate code in the Bestiary asm to allow it to work.

A limitation of the Bestiary is that if an enemy is Weak/Resists/Absorbs all eight elements, only the first six will be displayed. This is not a bug with the Bestiary, but a limitation of FF6 itself; the developers limited the menus to only display six elements due to lack of space on the screen. It it possible to enable all eight elements to display, but this needs an additional patch to work that rearranges the display for armor stats.

https://www.romhacking.net/hacks/256/

All eight elements will display in the Bestiary with this patch, but with eight elements at once, the Fire icon will be cut off by the names of items, yet will still display enough to be legible.

Additionally, as a separate issue it has sometimes been observed that the right side of the Fire icon can be distorted or rotated somehow. This cannot be recreated reliably and seems to only occur on certain emulators, so the exact cause is unknown and a fix is unclear.

============================CREDITS=============================

Original concept by DrakeyC, most of the work done by everything8215 and Ryo_Hazuki. Descriptions for enemies adapted from SilentEnigma's "Description Expansions" patches.
