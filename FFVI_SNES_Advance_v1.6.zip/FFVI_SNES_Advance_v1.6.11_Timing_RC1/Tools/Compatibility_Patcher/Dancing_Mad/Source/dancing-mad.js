// Dancing Mad audio port. The original driver is distributed under the BSD 2-Clause license.
// Check every occupied section in both directions, then authenticate the underlying v1.6 image.
const dancingMadSections = DANCING_MAD_SECTIONS;
function setDancingMad(bytes, enable) {
    const output = bytes.slice();
    for (const [offset, original, adapted] of dancingMadSections) {
        const expected = from64(enable ? original : adapted);
        if (!expected.every((value, index) => bytes[offset + index] === value)) {
            throw failure('dmConflict');
        }
        output.set(from64(enable ? adapted : original), offset);
    }
    if (output.length === 0x800000) writeROSEChecksum(output);
    else writeChecksum(output);
    return output;
}
async function identify(file) {
    if (![0x400000, 0x400200, 0x800000, 0x800200].includes(file.size)) return identifyWithoutMSU(file);
    const header = file.size % 0x100000;
    const raw = new Uint8Array(await file.slice(header).arrayBuffer());
    // A JSL to our reset routine uniquely marks this adapter version.
    if (!r16match(raw, 0x500fc, [0x22, 0x00, 0xf1, 0xfe])) return identifyWithoutMSU(file);
    const restored = setDancingMad(raw, false);
    const input = await identifyWithoutMSU(new File([restored], file.name));
    const verified = setDancingMad(restored, true);
    const repair = !verified.every((value, index) => value === raw[index]);
    return {...input, upgrade: input.upgrade || repair, profile: {...input.profile, options: [...input.profile.options, 'msu']}};
}
async function combine(input, selected, sources = {}, settings = {}) {
    const options = new Set(selected);
    const enable = options.delete('msu');
    const profile = {...input.profile, options: input.profile.options.filter(id => id !== 'msu')};
    const output = await combineWithoutMSU({...input, profile}, options, sources, settings);
    if (!enable) return output;
    const bytes = setDancingMad(output.bytes, true);
    return {...output, bytes, id: await rawHash(bytes), profile: {...output.profile, options: [...output.profile.options, 'msu']}};
}
