Rebuilding the SNES Advance v1.6 music adapter

Upstream driver commit
https://github.com/Dizzy611/DancingMadFF6/tree/198fcb39d0f3116e71dbbe5f7493114b43728b8b
Assembler used
https://github.com/vhelin/wla-dx/tree/8a5e68e0b5d18000ac5e18e1a4980a9a41dce853

Copy an unheadered, plain Regular SNES Advance v1.6 ROM into this directory
as base.sfc. Its SHA-256 is
188f9b7874930b9b17745a7c3e7183ae101bceba29afa6fc7a72fbb9636bec5f

Run in this directory with WLA-DX on your path:

    wla-65816 -o driver.o driver.asm
    wlalink -S -r driver.link audio.sfc

audio.sfc is the raw linker output. The HTML patcher also updates the SNES
checksum. To regenerate the distributable patcher, supply the v1.6 HTML
from before the Dancing Mad option was added. Keep the bundled LICENSE.txt
in the parent directory and choose a separate output file.

    python3 embed_driver.py previous-v1.6.html new-v1.6-msu.html

The 14 linker sections describe every driver write. The patcher checks the
expected bytes before adding or removing those sections and uses the normal
v1.6 edition recognition after removal. ROSE uses its 8 MiB checksum logic.

Port details
* Playback state is in volatile WRAM $7E:14D0–14DA, beyond the sound engine's
  64-byte instrument pointer transfer at $1480. The APU startup routine
  clears that state. Flood and Valor learning data stay in their own area.
* The field event $FA hook is at $C0:B8D4. Control returns to $C0:B8D9
  while waiting and $C0:B8DA to advance. Event $F9 keeps its original
  song-position comparison.
* A new first-tier Dancing Mad stream resets the flag that absorbs its
  initial subsong cue, including when the sequence is played again.
* The upstream debugging overlay and title metadata are omitted. The
  music hooks, fading, native fallback and Shadow's music events are ported.
