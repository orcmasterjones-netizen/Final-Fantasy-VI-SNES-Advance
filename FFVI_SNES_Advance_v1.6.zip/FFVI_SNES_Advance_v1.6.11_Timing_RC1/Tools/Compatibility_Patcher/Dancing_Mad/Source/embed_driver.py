from pathlib import Path
from base64 import b64encode
import argparse
import json

parser = argparse.ArgumentParser(description='Embed the assembled Dancing Mad driver into a plain v1.6 patcher.')
parser.add_argument('source',type=Path)
parser.add_argument('output',type=Path)
args=parser.parse_args()
if args.source.resolve()==args.output.resolve():
    parser.error('Choose a separate output file.')
h=Path(__file__).resolve().parent
base=(h/'base.sfc').read_bytes();adapt=(h/'audio.sfc').read_bytes();rebuilt=bytearray(base);sections=[]
for line in (h/'audio.sym').read_text().split('[sections]\n')[1].strip().splitlines():
 fields=line.split();p=int(fields[0],16);n=int(fields[3],16);rebuilt[p:p+n]=adapt[p:p+n];sections.append([p,*[b64encode(b[p:p+n]).decode() for b in (base,adapt)]])
assert rebuilt==adapt
html=args.source.read_text()
def change(a,b):
 global html
 assert html.count(a)==1,(a,html.count(a));html=html.replace(a,b)
change('async function identify(file){','async function identifyWithoutMSU(file){');change('async function combine(input,selected,sources={},settings={}){','async function combineWithoutMSU(input,selected,sources={},settings={}){')
change('const controls=new Map();',(h/'dancing-mad.js').read_text().replace('DANCING_MAD_SECTIONS',json.dumps(sections,separators=(',',':')))+'\nconst controls=new Map();')
change("    {id:'names'},","    {id:'names'},\n    {id:'msu'},")
for lang,values in [('en',['Dancing Mad MSU-1 music','Use Dancing Mad PCM tracks. Place the .msu and numbered .pcm files beside the ROM with the same base name. Missing tracks use SNES audio.','This ROM uses part of the Dancing Mad driver area. Choose another combination.']),('es',['Música MSU-1 de Dancing Mad','Usa las pistas PCM de Dancing Mad. Coloca el archivo .msu y las pistas .pcm numeradas junto a la ROM con el mismo nombre base. Las pistas que falten usarán el audio de SNES.','Esta ROM utiliza parte del espacio del controlador Dancing Mad. Elige otra combinación.'])]:
 anchor='    "'+lang+'": {\n';change(anchor,anchor+'        '+',\n        '.join(json.dumps(k)+': '+json.dumps(v,ensure_ascii=False)for k,v in zip(['msu','msuDesc','dmConflict'],values))+',\n')
change("const names={modern:'ModernATB'","const names={msu:'DancingMadMSU1',modern:'ModernATB'")
change("removable=['font','names','music']","removable=['font','names','music','msu']")
change("if(id==='rose')supported=roseSelectable;","if(id==='msu')supported=true;\n        else if(id==='rose')supported=roseSelectable;")
change("other!=='rose'&&!roseProfile()","other!=='rose'&&other!=='msu'&&!roseProfile()")
change("current=found;const style", "if(found.profile.options.includes('msu') || personal.options?.includes('msu')) wanted.add('msu');\n    else wanted.delete('msu');\n    current=found;const style")
change("return current.upgrade||settings.fontStyle", "return current.upgrade||selected.has('msu')!==installed.has('msu')||settings.fontStyle")
license=(h.parent/'LICENSE.txt').read_text();change('</head>','<!-- Dancing Mad audio driver license\n'+license+'\n-->\n</head>')
args.output.write_text(html)
