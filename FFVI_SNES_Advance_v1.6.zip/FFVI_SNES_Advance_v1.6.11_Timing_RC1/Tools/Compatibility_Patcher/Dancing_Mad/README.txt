Dancing Mad MSU-1 for FFVI SNES Advance v1.6.1

Setup
1. Open FFVI_SNES_Advance_Compatibility_Patcher.html and select your SNES
   Advance ROM. With an original North American FFIII v1.0 or v1.1 ROM,
   choose an edition and apply the base first.
2. Check “Dancing Mad MSU-1 music”, choose Build ROM, and download the result.
3. Choose a soundtrack from the upstream Dancing Mad prepack collection.
   https://github.com/Dizzy611/DancingMadFF6#prepacks
4. Put the ROM, the included empty ff3.msu, and the numbered PCM tracks in
   one folder. Give the ROM and companions the same base name. For example:

      ff3.sfc
      ff3.msu
      ff3-1.pcm
      ff3-51.pcm

   The prepack may use a different prefix. It is usually easiest to rename
   the ROM and .msu to match the PCM filenames. Keep every track number.
   The checkbox supplies the adapted ROM code. Use only the audio assets
   from the soundtrack pack; omit its standalone ROM patches.
5. Load the ROM in an MSU-1-capable emulator such as Snes9x. To resume a
   battery save, use the same base name for its .srm in the usual save folder.

SNES Advance tracks
Kaiser Dragon and Omega Weapon request the Atma Weapon theme, PCM 51.
Gilgamesh plays the SNES Advance arrangement of Battle on the Big Bridge
when PCM 85 is absent. A custom track with that number plays in its place.
The game can also use SNES audio when MSU-1 is unavailable.

To remove the option, reopen the built ROM in the patcher, clear the music
checkbox, and build again. Plain v1.6.1 BPS patches use the native soundtrack.

Credits
Upstream Dancing Mad driver by Dylan “Dizzy” O'Malley-Morrison and
contributors. Conn provided the original fade routine. The project credits
madsiur, qwertymodo, Rodimus Primal and the TWUE team, and mziab for work on
the driver and its optional patches. Soundtrack arrangement credits and
presets are available from the upstream project.
https://github.com/Dizzy611/DancingMadFF6#credits

This option ports the core audio driver. The upstream debug title overlay
is omitted to preserve translated title screens. The upstream all-options
IPS has a separate cut-song restoration and music menu. TWUE users can
select the patcher's existing TWUE Music Player independently.

Driver revision and license are in Source/README.txt and LICENSE.txt.
QA.txt describes the emulator and patcher checks.
