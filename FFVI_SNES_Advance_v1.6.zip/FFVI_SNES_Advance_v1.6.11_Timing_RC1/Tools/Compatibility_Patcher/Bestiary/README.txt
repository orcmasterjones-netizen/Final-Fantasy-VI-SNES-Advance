DrakeyC’s Bestiary for SNES Advance

Enable it
Open the compatibility patcher, choose your ROM, check DrakeyC’s Bestiary, then choose Build ROM and Download ROM. The option is off by default. It is included in the offline tool and can be combined with the supported editions and other patcher options. To remove it, reopen the built ROM, clear the checkbox, and rebuild.

Open the book
From the field or world map, open the main menu, choose Config and press R for page two. Move down to Bestiary below the Blue control and press A. Select from the main menu is a shortcut. Use the D-pad to move through the two-column list. L and R move by one page. A opens the selected enemy. On a detail page, L and R move to the previous or next recorded enemy. B returns to the list, then to the Config row or the main menu, depending on where you opened the book.

What it shows
The encounter-ordered list contains enemies met in this playthrough. Meeting an enemy is enough to register it. Repeat encounters with the same enemy ID share one record. Different phases, parts and Glutturn variants may have separate records. The 400-entry catalog covers all 384 retail GBA entries and 16 additional enemy records. The 100-HP Phantom Train Siegfried and the 32,760-HP Coliseum Siegfried unlock independently. Enemy and item names use the edition’s compact tables. The interface and descriptions are in English.

The detail page shows the record’s level, HP, MP, combat stats, EXP, GP, elemental affinities and common/rare steals and drops. A boss script can restore HP, change phases or award a separate event item. Element abbreviations are Fi (Fire), Ic (Ice), Lt (Lightning), Ps (Poison), Wi (Wind), Ho (Holy), Ea (Earth), and Wa (Water).

Save behavior
When updating from v1.6.2 or v1.6.3, your recorded encounters carry forward. If you already fought Coliseum Siegfried with the Bestiary enabled and saved afterward, his card appears when you load that save.

Keep your battery save (.srm) with the same basename as the new ROM and load it through Continue. The book starts empty on a save made before tracking was installed. Earlier encounters cannot be reconstructed. Save normally to keep new entries. Saving into another slot copies the current playthrough’s log there. The post-Kefka clear save includes the final battle’s entries.

Each log belongs to one of the three native save slots. Its signature and the slot’s native checksum are checked on load. If you disable the bestiary and later save over that slot, re-enabling the option starts a fresh log when the checksum has changed. A backup of your .srm preserves the earlier log. New Game starts with an empty log.

Credits
DrakeyC conceived the original bestiary. Everything8215 and Ryo_Hazuki did most of the original implementation. Its enemy descriptions were adapted from SilentEnigma’s Description Expansions. This SNES Advance adaptation uses the donor’s organized roster, descriptions and stat-page design with a menu, encounter tracker and slot storage adapted for the expanded game.
