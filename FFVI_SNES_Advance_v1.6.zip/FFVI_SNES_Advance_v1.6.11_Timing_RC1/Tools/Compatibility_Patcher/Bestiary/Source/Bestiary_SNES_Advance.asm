.memorymap
slotsize $10000
defaultslot 0
slot 0 $0000
.endme
.rombanksize $10000
.rombanks 64
.hirom
.fastrom
.base $c0
.background "base.sfc"
.bank $31
.org $c200
.section "DrakeyC encounter descriptions" overwrite

DescriptionTable:
.dw desc_25,desc_0,desc_27,desc_19,desc_77,desc_70,desc_23,desc_40,desc_92,desc_93,desc_66,desc_98,desc_99,desc_46,desc_18,desc_168,desc_21,desc_11,desc_122,desc_134,desc_50,desc_56,desc_57,desc_34,desc_17,desc_113,desc_159,desc_54,desc_148,desc_245,desc_239,desc_244,desc_96,desc_182,desc_207,desc_118,desc_24,desc_47,desc_41,desc_26,desc_1,desc_2,desc_68,desc_90,desc_162,desc_8,desc_79,desc_14,desc_186,desc_15,desc_94,desc_89,desc_58,desc_101,desc_121,desc_28,desc_120,desc_108,desc_42,desc_140,desc_144,desc_35,desc_223,desc_78,desc_82,desc_83,desc_115,desc_209,desc_123,desc_107,desc_141,desc_129,desc_61,desc_232,desc_199,desc_203,desc_65,desc_357,desc_71,desc_102,desc_45,desc_117,desc_136,desc_6,desc_175,desc_160,desc_110,desc_229,desc_179,desc_72,desc_130,desc_3,desc_150,desc_29,desc_31,desc_222,desc_214,desc_184,desc_235,desc_238,desc_208,desc_227,desc_67,desc_12,desc_74,desc_164,desc_131,desc_216,desc_32,desc_361,desc_163,desc_170,desc_114,desc_178,desc_213,desc_202,desc_33,desc_49,desc_124,desc_152,desc_230,desc_44,desc_225,desc_192,desc_53,desc_60,desc_88,desc_48,desc_195,desc_151,desc_185,desc_95,desc_169,desc_73,desc_75,desc_215,desc_139,desc_211,desc_167,desc_219,desc_137,desc_16,desc_5,desc_111,desc_145,desc_97,desc_221,desc_20,desc_242,desc_197,desc_142,desc_143,desc_126,desc_187,desc_91,desc_210,desc_135,desc_153,desc_176,desc_59,desc_52,desc_51,desc_9,desc_204,desc_146,desc_119,desc_173,desc_188,desc_247,desc_241,desc_191,desc_236,desc_233,desc_147,desc_226,desc_248,desc_206,desc_156,desc_218,desc_196,desc_231,desc_243,desc_201,desc_180,desc_158,desc_205,desc_198,desc_84,desc_133,desc_190,desc_171,desc_172,desc_177,desc_10,desc_4,desc_30,desc_157,desc_149,desc_254,desc_138,desc_212,desc_43,desc_165,desc_116,desc_105,desc_181,desc_200,desc_154,desc_112,desc_87,desc_109,desc_166,desc_81,desc_69,desc_62,desc_76,desc_369,desc_220,desc_103,desc_250,desc_240,desc_104,desc_125,desc_38,desc_39,desc_85,desc_306,desc_304,desc_293,desc_299,desc_307,desc_313,desc_323,desc_355,desc_356,desc_224,desc_128,desc_183,desc_132,desc_228,desc_217,desc_234,desc_246,desc_237,desc_253,desc_252,desc_193,desc_7,desc_13,desc_189,desc_106,desc_251,desc_86,desc_161,desc_249,desc_22,desc_261,desc_155,desc_37,desc_333,desc_314,desc_373,desc_315,desc_334,desc_335,desc_374,desc_342,desc_340,desc_341,desc_63,desc_258,desc_194,desc_174,desc_280,desc_80,desc_255,desc_256,desc_308,desc_100,desc_259,desc_300,desc_260,desc_305,desc_55,desc_262,desc_330,desc_263,desc_301,desc_264,desc_265,desc_266,desc_267,desc_319,desc_320,desc_269,desc_270,desc_278,desc_302,desc_360,desc_303,desc_275,desc_325,desc_327,desc_326,desc_279,desc_283,desc_316,desc_317,desc_318,desc_257,desc_309,desc_284,desc_285,desc_363,desc_364,desc_365,desc_127,desc_281,desc_286,desc_328,desc_324,desc_272,desc_287,desc_288,desc_289,desc_290,desc_359,desc_291,desc_294,desc_352,desc_353,desc_354,desc_312,desc_292,desc_358,desc_331,desc_332,desc_336,desc_337,desc_338,desc_339,desc_36,desc_329,desc_268,desc_321,desc_322,desc_381,desc_274,desc_295,desc_296,desc_297,desc_343,desc_344,desc_345,desc_346,desc_347,desc_348,desc_349,desc_350,desc_351,desc_298,desc_367,desc_372,desc_380,desc_416,desc_417,desc_418,desc_419,desc_420,desc_421,desc_422,desc_423,desc_424,desc_425,desc_426,desc_427,desc_428,desc_429,desc_430,desc_431,desc_432,desc_433,desc_434,desc_435,desc_436,desc_437,desc_438,desc_439,desc_440,desc_441,desc_442,desc_443,desc_444,desc_445,desc_446,desc_447,desc_448,desc_449,desc_450,desc_451
desc_25:
.db $96,$a8,$a5,$9f,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$00
.db $00
desc_0:
.db $86,$ae,$9a,$ab,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$00
.db $00
desc_27:
.db $8c,$9a,$a6,$a6,$a8,$ad,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$00
.db $00
desc_19:
.db $91,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_77:
.db $8c,$9e,$9c,$a1,$9a,$a7,$a2,$9c,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_70:
.db $82,$a5,$a8,$ae,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_23:
.db $81,$ae,$a7,$a7,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_40:
.db $82,$ab,$a8,$b0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_92:
.db $92,$9a,$a7,$9d,$ff,$91,$9a,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$9d,$9e,$ac,$9e,$ab,$ad,$00
.db $00
desc_93:
.db $92,$9c,$a8,$ab,$a9,$a2,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$9d,$9e,$ac,$9e,$ab,$ad,$00
.db $00
desc_66:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$80,$ab,$a6,$a8,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_98:
.db $92,$a5,$ae,$a0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_99:
.db $84,$b2,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$9c,$9a,$af,$9e,$00
.db $00
desc_46:
.db $81,$ae,$a0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_18:
.db $92,$aa,$ae,$a2,$ab,$ab,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_168:
.db $8c,$9e,$9c,$a1,$9a,$a7,$a2,$9c,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$c6,$ff,$8d,$a2,$a4,$9e,$9a,$a1,$00
.db $ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_21:
.db $91,$a1,$a2,$a7,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_11:
.db $81,$ab,$9a,$b0,$a5,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$ad,$c5,$ff,$8a,$a8,$a5,$ad,$ac,$00
.db $00
desc_122:
.db $8c,$9a,$a6,$a6,$a8,$ad,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$ad,$c5,$ff,$8a,$a8,$a5,$ad,$ac,$00
.db $00
desc_134:
.db $82,$ab,$a8,$b0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$ad,$c5,$ff,$8a,$a8,$a5,$ad,$ac,$00
.db $00
desc_50:
.db $88,$af,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$ad,$c5,$ff,$8a,$a8,$a5,$ad,$ac,$00
.db $00
desc_56:
.db $92,$aa,$ae,$a2,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8b,$9e,$ad,$9e,$ff,$91,$a2,$af,$9e,$ab,$00
.db $00
desc_57:
.db $82,$ab,$9a,$9b,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8b,$9e,$ad,$9e,$ff,$91,$a2,$af,$9e,$ab,$00
.db $00
desc_34:
.db $96,$b2,$af,$9e,$ab,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8b,$9e,$ad,$9e,$ff,$91,$a2,$af,$9e,$ab,$00
.db $00
desc_17:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$ad,$ab,$a8,$a8,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$00
.db $00
desc_113:
.db $87,$a8,$ae,$a7,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$00
.db $00
desc_159:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$80,$ab,$a6,$a8,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$c6,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$00
.db $9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_54:
.db $92,$9a,$a7,$9d,$ff,$91,$9a,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_148:
.db $82,$ab,$9a,$9b,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_245:
.db $81,$9e,$9a,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_239:
.db $8c,$9e,$9c,$a1,$9a,$a7,$a2,$9c,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_244:
.db $91,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_96:
.db $92,$a9,$a2,$ab,$a2,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_182:
.db $86,$a1,$a8,$ac,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$8c,$a2,$a7,$9e,$ac,$00
.db $00
desc_207:
.db $82,$a5,$a8,$ae,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_118:
.db $81,$ae,$a7,$a7,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$83,$a8,$a6,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_24:
.db $82,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$83,$a8,$a6,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_47:
.db $86,$ab,$9a,$ac,$ac,$a1,$a8,$a9,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$83,$a8,$a6,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_41:
.db $87,$9a,$ab,$a9,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$83,$a8,$a6,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_26:
.db $87,$a8,$ae,$a7,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$82,$9a,$a6,$a9,$00
.db $00
desc_1:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$ad,$ab,$a8,$a8,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$81,$9a,$ac,$9e,$00
.db $00
desc_2:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$9e,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$82,$9a,$a6,$a9,$00
.db $00
desc_68:
.db $92,$9a,$ad,$9e,$a5,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$82,$9a,$a6,$a9,$00
.db $00
desc_90:
.db $86,$a1,$a8,$ac,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$85,$a8,$ab,$9e,$ac,$ad,$00
.db $00
desc_162:
.db $82,$a5,$a8,$ae,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$85,$a8,$ab,$9e,$ac,$ad,$00
.db $00
desc_8:
.db $96,$9a,$ab,$a5,$a8,$9c,$a4,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$93,$ab,$9a,$a2,$a7,$00
.db $00
desc_79:
.db $81,$a8,$a6,$9b,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$93,$ab,$9a,$a2,$a7,$00
.db $00
desc_14:
.db $92,$a9,$a2,$ab,$a2,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$93,$ab,$9a,$a2,$a7,$00
.db $00
desc_186:
.db $86,$ae,$9a,$ab,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$93,$ab,$9a,$a2,$a7,$00
.db $00
desc_15:
.db $8d,$9e,$9c,$ab,$a8,$a6,$9a,$a7,$9c,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$93,$ab,$9a,$a2,$a7,$00
.db $00
desc_94:
.db $85,$a2,$ac,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$9e,$ab,$a9,$9e,$a7,$ad,$ff,$93,$ab,$9e,$a7,$9c,$a1,$00
.db $00
desc_89:
.db $89,$9e,$a5,$a5,$b2,$9f,$a2,$ac,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$9e,$ab,$a9,$9e,$a7,$ad,$ff,$93,$ab,$9e,$a7,$9c,$a1,$00
.db $00
desc_58:
.db $84,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$9e,$ab,$a9,$9e,$a7,$ad,$ff,$93,$ab,$9e,$a7,$9c,$a1,$00
.db $00
desc_101:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$ad,$ab,$a8,$a8,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_121:
.db $87,$a8,$ae,$a7,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_28:
.db $81,$ae,$a5,$a5,$9d,$a8,$a0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_120:
.db $96,$a8,$a5,$9f,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$91,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_108:
.db $81,$ab,$9a,$b0,$a5,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_42:
.db $84,$9a,$a0,$a5,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_140:
.db $81,$ae,$a0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$c4,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_144:
.db $88,$af,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_35:
.db $83,$ab,$9a,$a0,$a8,$a7,$ff,$99,$a8,$a6,$9b,$a2,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $9d,$9e,$ac,$9e,$ab,$ad,$ac,$00
.db $00
desc_223:
.db $8c,$9e,$9c,$a1,$9a,$a7,$a2,$9c,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_78:
.db $87,$9a,$ab,$af,$9e,$ac,$ad,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_82:
.db $83,$9a,$a7,$9c,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_83:
.db $86,$a2,$a0,$9a,$ac,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_115:
.db $91,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8e,$a9,$9e,$ab,$9a,$ff,$87,$a8,$ae,$ac,$9e,$00
.db $00
desc_209:
.db $91,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8e,$a9,$9e,$ab,$9a,$ff,$87,$a8,$ae,$ac,$9e,$00
.db $00
desc_123:
.db $81,$ae,$a5,$a5,$9d,$a8,$a0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_107:
.db $8f,$9a,$ab,$9a,$ac,$a8,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_141:
.db $86,$ab,$9a,$ac,$ac,$a1,$a8,$a9,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$83,$a8,$a6,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_129:
.db $96,$b2,$af,$9e,$ab,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_61:
.db $82,$a8,$9c,$a4,$9a,$ad,$ab,$a2,$9c,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_232:
.db $87,$a8,$ab,$a7,$9e,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9d,$9e,$ac,$9e,$ab,$ad,$ac,$00
.db $00
desc_199:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$ad,$ab,$a8,$a8,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_203:
.db $87,$a8,$ae,$a7,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_65:
.db $8f,$ae,$a9,$a9,$9e,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_357:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$a9,$ab,$a8,$ad,$a8,$ad,$b2,$a9,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$95,$9e,$9c,$ad,$a8,$ab,$00
.db $00
desc_71:
.db $85,$a5,$9a,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_102:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$9e,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_45:
.db $93,$ab,$9a,$a9,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_117:
.db $91,$a1,$a2,$a7,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_136:
.db $84,$9a,$a0,$a5,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_6:
.db $93,$ab,$a2,$b0,$a1,$9e,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_175:
.db $83,$ae,$9a,$a5,$b0,$a1,$9e,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_160:
.db $92,$9a,$ad,$9e,$a5,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$95,$9e,$9c,$ad,$a8,$ab,$00
.db $00
desc_110:
.db $92,$a9,$a2,$ab,$a2,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$82,$9a,$af,$9e,$ff,$ad,$a8,$ff,$ad,$a1,$9e,$ff,$92,$9e,$9a,$a5,$9e,$9d,$ff,$86,$9a,$ad,$9e,$00
.db $00
desc_229:
.db $86,$a1,$a8,$ac,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$82,$9a,$af,$9e,$ff,$ad,$a8,$ff,$ad,$a1,$9e,$ff,$92,$9e,$9a,$a5,$9e,$9d,$ff,$86,$9a,$ad,$9e,$00
.db $00
desc_179:
.db $92,$9c,$a8,$ab,$a9,$a2,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$82,$9a,$af,$9e,$ff,$ad,$a8,$ff,$ad,$a1,$9e,$ff,$92,$9e,$9a,$a5,$9e,$9d,$ff,$86,$9a,$ad,$9e,$00
.db $00
desc_72:
.db $82,$a8,$ab,$a9,$ac,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$82,$9a,$af,$9e,$ff,$ad,$a8,$ff,$ad,$a1,$9e,$ff,$92,$9e,$9a,$a5,$9e,$9d,$ff,$86,$9a,$ad,$9e,$00
.db $00
desc_130:
.db $83,$ab,$9a,$a0,$a8,$a7,$ff,$99,$a8,$a6,$9b,$a2,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$82,$9a,$af,$9e,$ff,$ad,$a8,$ff,$ad,$a1,$9e,$ff,$92,$9e,$9a,$a5,$9e,$9d,$ff,$86,$9a,$ad,$9e,$00
.db $00
desc_3:
.db $8d,$a2,$a7,$a3,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_150:
.db $92,$aa,$ae,$a2,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$93,$a1,$9a,$a6,$9a,$ac,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_29:
.db $80,$9d,$9a,$a6,$9a,$a7,$ad,$a8,$a2,$ac,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$93,$a1,$9a,$a6,$9a,$ac,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_31:
.db $82,$a1,$a2,$a6,$9e,$ab,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$93,$a1,$9a,$a6,$9a,$ac,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_222:
.db $81,$a8,$a6,$9b,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$81,$ae,$ab,$a7,$a2,$a7,$a0,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_214:
.db $80,$9d,$9a,$a6,$9a,$a7,$ad,$a8,$a2,$ac,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$84,$ac,$a9,$9e,$ab,$ff,$82,$9a,$af,$9e,$ac,$00
.db $00
desc_184:
.db $92,$a5,$ae,$a0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$84,$ac,$a9,$9e,$ab,$ff,$82,$9a,$af,$9e,$ac,$00
.db $00
desc_235:
.db $87,$9a,$ab,$a9,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$84,$ac,$a9,$9e,$ab,$ff,$82,$9a,$af,$9e,$ac,$00
.db $00
desc_238:
.db $88,$af,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$84,$ac,$a9,$9e,$ab,$ff,$82,$9a,$af,$9e,$ac,$00
.db $00
desc_208:
.db $86,$ab,$9a,$ac,$ac,$a1,$a8,$a9,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$84,$ac,$a9,$9e,$ab,$ff,$82,$9a,$af,$9e,$ac,$00
.db $00
desc_227:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$9f,$a5,$b2,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_67:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$9f,$a5,$b2,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_12:
.db $86,$ab,$9e,$a6,$a5,$a2,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_74:
.db $85,$9a,$9c,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_164:
.db $82,$a8,$ab,$a9,$ac,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_131:
.db $83,$ab,$9a,$a0,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_216:
.db $96,$b2,$af,$9e,$ab,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_32:
.db $81,$9e,$a1,$9e,$a6,$a8,$ad,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_361:
.db $89,$9e,$ac,$ad,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_163:
.db $81,$9e,$a1,$9e,$a6,$a8,$ad,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$93,$ab,$a2,$9a,$a7,$a0,$a5,$9e,$ff,$88,$ac,$a5,$9a,$a7,$9d,$00
.db $00
desc_170:
.db $81,$a8,$a6,$9b,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$81,$a8,$a6,$9b,$ff,$85,$a8,$ab,$9e,$ac,$ad,$00
.db $00
desc_114:
.db $92,$aa,$ae,$a2,$ab,$ab,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$a5,$a2,$ad,$9a,$ab,$b2,$ff,$88,$ac,$a5,$9a,$a7,$9d,$00
.db $00
desc_178:
.db $92,$9a,$a7,$9d,$ff,$91,$9a,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$a5,$a2,$ad,$9a,$ab,$b2,$ff,$88,$ac,$a5,$9a,$a7,$9d,$00
.db $00
desc_213:
.db $83,$ab,$9a,$a0,$a8,$a7,$ff,$99,$a8,$a6,$9b,$a2,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9d,$9e,$ac,$9e,$ab,$ad,$ac,$00
.db $00
desc_202:
.db $96,$a8,$a5,$9f,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_33:
.db $91,$9e,$a9,$ad,$a2,$a5,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_49:
.db $8c,$9a,$a7,$ad,$a2,$ac,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_124:
.db $80,$9d,$9a,$a6,$9a,$a7,$ad,$a8,$a2,$ac,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_152:
.db $93,$a8,$9a,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_230:
.db $84,$9a,$a0,$a5,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_44:
.db $87,$9e,$ab,$a6,$a2,$ad,$ff,$9c,$ab,$9a,$9b,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$82,$a8,$a5,$a5,$9a,$a9,$ac,$a2,$a7,$a0,$ff,$87,$a8,$ae,$ac,$9e,$00
.db $00
desc_225:
.db $92,$9c,$a8,$ab,$a9,$a2,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$82,$a8,$a5,$a5,$9a,$a9,$ac,$a2,$a7,$a0,$ff,$87,$a8,$ae,$ac,$9e,$00
.db $00
desc_192:
.db $92,$a9,$a2,$ab,$a2,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$82,$a8,$a5,$a5,$9a,$a9,$ac,$a2,$a7,$a0,$ff,$87,$a8,$ae,$ac,$9e,$00
.db $00
desc_53:
.db $95,$9a,$a6,$a9,$a2,$ab,$9e,$ff,$93,$a1,$a8,$ab,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$9e,$ab,$a9,$9e,$a7,$ad,$ff,$93,$ab,$9e,$a7,$9c,$a1,$00
.db $00
desc_60:
.db $8b,$a2,$b3,$9a,$ab,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$9e,$ab,$a9,$9e,$a7,$ad,$ff,$93,$ab,$9e,$a7,$9c,$a1,$00
.db $00
desc_88:
.db $81,$ae,$9f,$9f,$9a,$a5,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$9e,$ab,$a9,$9e,$a7,$ad,$ff,$93,$ab,$9e,$a7,$9c,$a1,$00
.db $00
desc_48:
.db $8f,$b2,$ab,$9a,$a6,$a2,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$9e,$ab,$a9,$9e,$a7,$ad,$ff,$93,$ab,$9e,$a7,$9c,$a1,$00
.db $00
desc_195:
.db $81,$ae,$a7,$a7,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_151:
.db $82,$ab,$9a,$9b,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_185:
.db $84,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_95:
.db $92,$9e,$9a,$a1,$a8,$ab,$ac,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$9d,$9e,$ac,$9e,$ab,$ad,$00
.db $00
desc_169:
.db $87,$9a,$ab,$af,$9e,$ac,$ad,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$9c,$9a,$af,$9e,$00
.db $00
desc_73:
.db $93,$ab,$a8,$a5,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_75:
.db $80,$a6,$a8,$9e,$9b,$a8,$a2,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_215:
.db $91,$a2,$9d,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_139:
.db $93,$ab,$9a,$a9,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_211:
.db $81,$ae,$a5,$a5,$9d,$a8,$a0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_167:
.db $84,$b2,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_219:
.db $85,$a5,$9a,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_137:
.db $80,$aa,$ae,$a2,$a5,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$a8,$a1,$a5,$a2,$a7,$a0,$9e,$a7,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_16:
.db $92,$a4,$9e,$a5,$9e,$ad,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$9a,$ab,$a2,$a5,$a5,$c3,$ac,$ff,$93,$a8,$a6,$9b,$00
.db $00
desc_5:
.db $8e,$a0,$ab,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$9a,$ab,$a2,$a5,$a5,$c3,$ac,$ff,$93,$a8,$a6,$9b,$00
.db $00
desc_111:
.db $8d,$9e,$9c,$ab,$a8,$a6,$9a,$a7,$9c,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$9a,$ab,$a2,$a5,$a5,$c3,$ac,$ff,$93,$a8,$a6,$9b,$00
.db $00
desc_145:
.db $85,$a5,$a8,$b0,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$9a,$ab,$a2,$a5,$a5,$c3,$ac,$ff,$93,$a8,$a6,$9b,$00
.db $00
desc_97:
.db $8c,$9a,$a5,$9b,$a8,$ab,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$9a,$ab,$a2,$a5,$a5,$c3,$ac,$ff,$93,$a8,$a6,$9b,$00
.db $00
desc_221:
.db $87,$9a,$ab,$af,$9e,$ac,$ad,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8c,$ad,$c5,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_20:
.db $81,$9e,$9a,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8c,$ad,$c5,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_242:
.db $86,$a2,$a0,$9a,$ac,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8c,$ad,$c5,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_197:
.db $81,$ab,$9a,$b0,$a5,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8c,$ad,$c5,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_142:
.db $8f,$b2,$ab,$9a,$a6,$a2,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8c,$ad,$c5,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_143:
.db $8c,$9a,$a7,$ad,$a2,$ac,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$95,$9e,$a5,$9d,$ad,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_126:
.db $82,$a1,$a2,$a6,$9e,$ab,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$95,$9e,$a5,$9d,$ad,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_187:
.db $92,$a4,$9e,$a5,$9e,$ad,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_91:
.db $96,$a8,$ab,$a6,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$89,$a2,$9d,$a8,$a8,$ab,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_210:
.db $8c,$9a,$a7,$ad,$a2,$ac,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$92,$a8,$ae,$ad,$a1,$9e,$ab,$a7,$ff,$9c,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_135:
.db $87,$9a,$ab,$a9,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$89,$a2,$9d,$a8,$a8,$ab,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_153:
.db $8b,$a2,$b3,$9a,$ab,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$89,$a2,$9d,$a8,$a8,$ab,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_176:
.db $82,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$89,$a2,$9d,$a8,$a8,$ab,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_59:
.db $93,$a8,$9a,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$89,$a2,$9d,$a8,$a8,$ab,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_52:
.db $81,$ab,$9a,$a6,$9b,$a5,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$a8,$a6,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_51:
.db $85,$a5,$a8,$b0,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_9:
.db $92,$a8,$9c,$a2,$9a,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_204:
.db $82,$ab,$a8,$b0,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_146:
.db $81,$ab,$9a,$a6,$9b,$a5,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_119:
.db $82,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_173:
.db $83,$9a,$a7,$9c,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_188:
.db $85,$9a,$9c,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_247:
.db $89,$9e,$ac,$ad,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_241:
.db $86,$a1,$a8,$ac,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_191:
.db $8f,$9a,$ab,$9a,$ac,$a8,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_236:
.db $80,$aa,$ae,$a2,$a5,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_233:
.db $85,$a2,$ac,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_147:
.db $95,$9a,$a6,$a9,$a2,$ab,$9e,$ff,$93,$a1,$a8,$ab,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_226:
.db $91,$9e,$b1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_248:
.db $96,$a8,$a5,$9f,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$00
.db $00
desc_206:
.db $8c,$9a,$a6,$a6,$a8,$ad,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$00
.db $00
desc_156:
.db $91,$a2,$9d,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$00
.db $00
desc_218:
.db $82,$a5,$a8,$ae,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_196:
.db $96,$9a,$ab,$a5,$a8,$9c,$a4,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_231:
.db $93,$ab,$a2,$b0,$a1,$9e,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_243:
.db $83,$ae,$9a,$a5,$b0,$a1,$9e,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_201:
.db $92,$aa,$ae,$a2,$ab,$ab,$9e,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$98,$9e,$ad,$a2,$c3,$ac,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_180:
.db $85,$a2,$ac,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$98,$9e,$ad,$a2,$c3,$ac,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_158:
.db $8f,$ae,$a9,$a9,$9e,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$98,$9e,$ad,$a2,$c3,$ac,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_205:
.db $87,$9a,$ab,$a9,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$98,$9e,$ad,$a2,$c3,$ac,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_198:
.db $91,$a1,$a2,$a7,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$98,$9e,$ad,$a2,$c3,$ac,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_84:
.db $93,$a8,$a7,$9b,$9e,$ab,$ab,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$98,$9e,$ad,$a2,$c3,$ac,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_133:
.db $91,$9e,$b1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_190:
.db $92,$a8,$9c,$a2,$9a,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_171:
.db $92,$ae,$9c,$9c,$ae,$9b,$ae,$ac,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_172:
.db $8f,$9a,$a7,$9d,$a8,$ab,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_177:
.db $89,$9e,$a5,$a5,$b2,$9f,$a2,$ac,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_10:
.db $8f,$9a,$ab,$9a,$ac,$a8,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_4:
.db $92,$9a,$a6,$ae,$ab,$9a,$a2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_30:
.db $96,$9a,$ab,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_157:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$80,$ab,$a6,$a8,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_149:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$9f,$a5,$b2,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_254:
.db $80,$ab,$ad,$a2,$a5,$a5,$9e,$ab,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_138:
.db $87,$9e,$ab,$a6,$a2,$ad,$ff,$9c,$ab,$9a,$9b,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$93,$a1,$9a,$a6,$9a,$ac,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_212:
.db $81,$9e,$9a,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$93,$a1,$9a,$a6,$9a,$ac,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_43:
.db $80,$aa,$ae,$a2,$a5,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$93,$a1,$9a,$a6,$9a,$ac,$9a,$ff,$ab,$9e,$a0,$a2,$a8,$a7,$00
.db $00
desc_165:
.db $93,$ab,$a8,$a5,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_116:
.db $81,$9e,$9a,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_105:
.db $96,$9a,$ab,$a5,$a8,$9c,$a4,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_181:
.db $92,$9e,$9a,$a1,$a8,$ab,$ac,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_200:
.db $81,$ae,$9f,$9f,$9a,$a5,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_154:
.db $82,$a8,$9c,$a4,$9a,$ad,$ab,$a2,$9c,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_112:
.db $92,$a4,$9e,$a5,$9e,$ad,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_87:
.db $96,$a8,$ab,$a6,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$80,$a7,$9c,$a2,$9e,$a7,$ad,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_109:
.db $86,$ab,$9e,$a6,$a5,$a2,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$80,$a7,$9c,$a2,$9e,$a7,$ad,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_166:
.db $80,$a6,$a8,$9e,$9b,$a8,$a2,$9d,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$80,$a7,$9c,$a2,$9e,$a7,$ad,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_81:
.db $8f,$9a,$a7,$9d,$a8,$ab,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$80,$a7,$9c,$a2,$9e,$a7,$ad,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_69:
.db $80,$ab,$ad,$a2,$a5,$a5,$9e,$ab,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$80,$a7,$9c,$a2,$9e,$a7,$ad,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_62:
.db $92,$9a,$a7,$9d,$b0,$a8,$ab,$a6,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8c,$9a,$ab,$9a,$a7,$9d,$9a,$ff,$9d,$9e,$ac,$9e,$ab,$ad,$00
.db $00
desc_76:
.db $94,$a7,$a2,$aa,$ae,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8c,$9a,$ab,$9a,$a7,$9d,$9a,$ff,$9d,$9e,$ac,$9e,$ab,$ad,$00
.db $00
desc_369:
.db $92,$9a,$a7,$9d,$b0,$a8,$ab,$a6,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$93,$ab,$a2,$9a,$a7,$a0,$a5,$9e,$ff,$88,$ac,$a5,$9a,$a7,$9d,$00
.db $00
desc_220:
.db $82,$a8,$ab,$a9,$ac,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$99,$a8,$a7,$9e,$ff,$84,$9a,$ad,$9e,$ab,$c3,$ac,$ff,$81,$9e,$a5,$a5,$b2,$00
.db $00
desc_103:
.db $8d,$a2,$a7,$a3,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$99,$a8,$a7,$9e,$ff,$84,$9a,$ad,$9e,$ab,$c3,$ac,$ff,$81,$9e,$a5,$a5,$b2,$00
.db $00
desc_250:
.db $80,$9c,$ab,$a8,$9b,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$99,$a8,$a7,$9e,$ff,$84,$9a,$ad,$9e,$ab,$c3,$ac,$ff,$81,$9e,$a5,$a5,$b2,$00
.db $00
desc_240:
.db $83,$9a,$a7,$9c,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$99,$a8,$a7,$9e,$ff,$84,$9a,$ad,$9e,$ab,$c3,$ac,$ff,$81,$9e,$a5,$a5,$b2,$00
.db $00
desc_104:
.db $8e,$a0,$ab,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$99,$a8,$a7,$9e,$ff,$84,$9a,$ad,$9e,$ab,$c3,$ac,$ff,$81,$9e,$a5,$a5,$b2,$00
.db $00
desc_125:
.db $96,$9a,$ab,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$99,$a8,$a7,$9e,$ff,$84,$9a,$ad,$9e,$ab,$c3,$ac,$ff,$81,$9e,$a5,$a5,$b2,$00
.db $00
desc_38:
.db $81,$ab,$9a,$9c,$a1,$a2,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$a2,$a7,$a8,$ac,$9a,$ae,$ab,$ff,$9f,$a8,$ab,$9e,$ac,$ad,$00
.db $00
desc_39:
.db $91,$9e,$b1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$83,$a2,$a7,$a8,$ac,$9a,$ae,$ab,$ff,$85,$a8,$ab,$9e,$ac,$ad,$00
.db $00
desc_85:
.db $94,$a7,$a2,$aa,$ae,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_306:
.db $86,$a1,$a8,$ac,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_304:
.db $96,$9a,$ab,$a5,$a8,$9c,$a4,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_293:
.db $83,$9a,$a7,$9c,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_299:
.db $8f,$9a,$ab,$9a,$ac,$a8,$a5,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_307:
.db $8d,$9e,$9c,$ab,$a8,$a6,$9a,$a7,$9c,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_313:
.db $80,$9c,$ab,$a8,$9b,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_323:
.db $83,$9e,$a6,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_355:
.db $92,$a8,$9c,$a2,$9a,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_356:
.db $89,$9e,$ac,$ad,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_224:
.db $81,$9e,$a1,$9e,$a6,$a8,$ad,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_128:
.db $91,$9e,$a9,$ad,$a2,$a5,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_183:
.db $8c,$9a,$a5,$9b,$a8,$ab,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_132:
.db $81,$ab,$9a,$9c,$a1,$a2,$a8,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_228:
.db $82,$a1,$a2,$a6,$9e,$ab,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_217:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$80,$ab,$a6,$a8,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_234:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$a9,$ab,$a8,$ad,$a8,$ad,$b2,$a9,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_246:
.db $92,$9a,$ad,$9e,$a5,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_237:
.db $93,$ab,$9a,$a9,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_253:
.db $8f,$ae,$a9,$a9,$9e,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_252:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$9f,$a5,$b2,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_193:
.db $8e,$a0,$ab,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_7:
.db $92,$9a,$a6,$ae,$ab,$9a,$a2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_13:
.db $83,$9e,$a6,$a8,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_189:
.db $8d,$a2,$a7,$a3,$9a,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_106:
.db $92,$a8,$9c,$a2,$9a,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_251:
.db $94,$a7,$a2,$aa,$ae,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_86:
.db $94,$a7,$a2,$aa,$ae,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_161:
.db $80,$ab,$ad,$a2,$a5,$a5,$9e,$ab,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_249:
.db $87,$a8,$ab,$ac,$9e,$a6,$9a,$a7,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_22:
.db $86,$a2,$9a,$a7,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_261:
.db $93,$ae,$a7,$a7,$9e,$a5,$ff,$9a,$ab,$a6,$a8,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_155:
.db $92,$9a,$a7,$9d,$b0,$a8,$ab,$a6,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_37:
.db $96,$b2,$ab,$a6,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_333:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8c,$ad,$c5,$ff,$8a,$a8,$a5,$ad,$b3,$00
.db $00
desc_314:
.db $94,$a7,$a2,$aa,$ae,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$00
.db $00
desc_373:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$ad,$ab,$a8,$a8,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$00
.db $00
desc_315:
.db $94,$a7,$a2,$aa,$ae,$9e,$00
.db $96,$a8,$81,$c1,$ff,$92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$00
.db $00
desc_334:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$83,$a8,$a6,$9a,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_335:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$ad,$ab,$a8,$a8,$a9,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$82,$9a,$a6,$a9,$00
.db $00
desc_374:
.db $82,$a2,$a7,$9e,$a6,$9a,$ad,$a2,$9c,$00
.db $94,$ac,$9e,$9d,$ff,$9f,$a8,$ab,$ff,$9c,$a2,$a7,$9e,$a6,$9a,$ad,$a2,$9c,$ff,$a8,$a7,$ff,$ad,$a1,$9e,$00
.db $81,$a5,$9a,$9c,$a4,$a3,$9a,$9c,$a4,$00
.db $00
desc_342:
.db $92,$a9,$a2,$ab,$a2,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$93,$ab,$9a,$a2,$a7,$00
.db $00
desc_340:
.db $85,$a2,$ac,$a1,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$81,$9a,$ab,$9e,$a7,$ff,$85,$9a,$a5,$a5,$ac,$00
.db $00
desc_341:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$81,$9a,$ab,$9e,$a7,$ff,$85,$9a,$a5,$a5,$ac,$00
.db $00
desc_63:
.db $91,$a2,$9d,$9e,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_258:
.db $8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$80,$ab,$a6,$a8,$ab,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$8f,$9a,$a5,$9a,$9c,$9e,$00
.db $00
desc_194:
.db $88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$9e,$a5,$a2,$ad,$9e,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$88,$a6,$a9,$9e,$ab,$a2,$9a,$a5,$ff,$8f,$9a,$a5,$9a,$9c,$9e,$00
.db $00
desc_174:
.db $86,$a2,$a0,$9a,$ac,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_280:
.db $80,$9c,$ab,$a8,$9b,$9a,$ad,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_80:
.db $94,$a7,$a2,$aa,$ae,$9e,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_255:
.db $93,$a8,$a7,$9b,$9e,$ab,$ab,$b2,$c4,$ad,$b2,$a9,$9e,$00
.db $96,$a8,$91,$c1,$ff,$98,$9e,$ad,$a2,$c3,$ac,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_256:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_308:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$00
.db $00
desc_100:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$a6,$a2,$a7,$9e,$ac,$00
.db $00
desc_259:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8c,$ad,$c5,$ff,$8a,$a8,$a5,$ad,$ac,$00
.db $00
desc_300:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8b,$9e,$ad,$9e,$ff,$91,$a2,$af,$9e,$ab,$00
.db $00
desc_260:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_305:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$93,$ab,$9a,$a2,$a7,$00
.db $00
desc_55:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$82,$a8,$a5,$a2,$ac,$9e,$ae,$a6,$00
.db $00
desc_262:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8f,$a1,$9a,$a7,$ad,$a8,$a6,$ff,$93,$ab,$9a,$a2,$a7,$00
.db $00
desc_330:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_263:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_301:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8e,$a9,$9e,$ab,$9a,$ff,$87,$a8,$ae,$ac,$9e,$00
.db $00
desc_264:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_265:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_266:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_267:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_319:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_320:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$8c,$9a,$a0,$a2,$ad,$9e,$a4,$ff,$91,$9e,$ac,$9e,$9a,$ab,$9c,$a1,$00
.db $85,$9a,$9c,$a2,$a5,$a2,$ad,$b2,$00
.db $00
desc_269:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$95,$9e,$9c,$ad,$a8,$ab,$00
.db $00
desc_270:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$95,$9e,$9c,$ad,$a8,$ab,$00
.db $00
desc_278:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$81,$ae,$ab,$a7,$a2,$a7,$a0,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_302:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$84,$ac,$a9,$9e,$ab,$ff,$82,$9a,$af,$9e,$ac,$00
.db $00
desc_360:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_303:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_275:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_325:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_327:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_326:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_279:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$81,$c1,$ff,$85,$a5,$a8,$9a,$ad,$a2,$a7,$a0,$ff,$82,$a8,$a7,$ad,$a2,$a7,$9e,$a7,$ad,$00
.db $00
desc_283:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_316:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_317:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_318:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_257:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$83,$9a,$ab,$a2,$a5,$a5,$c3,$ac,$ff,$93,$a8,$a6,$9b,$00
.db $00
desc_309:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$83,$9a,$ab,$a2,$a5,$a5,$c3,$ac,$ff,$93,$a8,$a6,$9b,$00
.db $00
desc_284:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$83,$9a,$ab,$a2,$a5,$a5,$c3,$ac,$ff,$93,$a8,$a6,$9b,$00
.db $00
desc_285:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$80,$a2,$ab,$ac,$a1,$a2,$a9,$00
.db $00
desc_363:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8c,$a8,$9b,$a5,$a2,$b3,$00
.db $00
desc_364:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8c,$a8,$9b,$a5,$a2,$b3,$00
.db $00
desc_365:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8c,$a8,$9b,$a5,$a2,$b3,$00
.db $00
desc_127:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$95,$9e,$a5,$9d,$ad,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_281:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$95,$9e,$a5,$9d,$ad,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_286:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_328:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8e,$b0,$b3,$9e,$ab,$c3,$ac,$ff,$8c,$9a,$a7,$ac,$a2,$a8,$a7,$00
.db $00
desc_324:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_272:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$98,$9e,$ad,$a2,$c3,$ac,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_287:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_288:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_289:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_290:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_359:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$83,$ab,$9e,$9a,$a6,$ac,$9c,$9a,$a9,$9e,$00
.db $00
desc_291:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_294:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_352:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_353:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_354:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$84,$9b,$a8,$ad,$c3,$ac,$ff,$91,$a8,$9c,$a4,$00
.db $00
desc_312:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$80,$a7,$9c,$a2,$9e,$a7,$ad,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_292:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$80,$a7,$9c,$a2,$9e,$a7,$ad,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_358:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_331:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8c,$ad,$c5,$ff,$99,$a8,$b3,$a8,$00
.db $00
desc_332:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8e,$a9,$9e,$ab,$9a,$ff,$87,$a8,$ae,$ac,$9e,$00
.db $00
desc_336:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_337:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_338:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$80,$a7,$9c,$a2,$9e,$a7,$ad,$ff,$82,$9a,$ac,$ad,$a5,$9e,$00
.db $00
desc_339:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8f,$a1,$a8,$9e,$a7,$a2,$b1,$ff,$82,$9a,$af,$9e,$00
.db $00
desc_36:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$85,$9a,$a7,$9a,$ad,$a2,$9c,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_329:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8d,$9a,$ab,$ac,$a1,$9e,$ff,$9c,$a5,$a2,$9f,$9f,$ac,$00
.db $00
desc_268:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_321:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_322:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_381:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_274:
.db $81,$a8,$ac,$ac,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_295:
.db $83,$9e,$a2,$ad,$b2,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_296:
.db $83,$9e,$a2,$ad,$b2,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_297:
.db $83,$9e,$a2,$ad,$b2,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_343:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b5,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_344:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b5,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_345:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b5,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_346:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b6,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_347:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b6,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_348:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b6,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_349:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b6,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_350:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b7,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_351:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$93,$a2,$9e,$ab,$ff,$b7,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_298:
.db $85,$a2,$a7,$9a,$a5,$ff,$9b,$9a,$ad,$ad,$a5,$9e,$ff,$c4,$ff,$8a,$9e,$9f,$a4,$9a,$00
.db $96,$a8,$91,$c1,$ff,$8a,$9e,$9f,$a4,$9a,$c3,$ac,$ff,$93,$a8,$b0,$9e,$ab,$00
.db $00
desc_367:
.db $84,$ac,$a9,$9e,$ab,$00
.db $82,$a8,$a5,$a2,$ac,$9e,$ae,$a6,$00
.db $00
desc_372:
.db $84,$ac,$a9,$9e,$ab,$00
.db $8c,$9a,$ab,$9a,$a7,$9d,$9a,$ff,$9d,$9e,$ac,$9e,$ab,$ad,$00
.db $00
desc_380:
.db $84,$ac,$a9,$9e,$ab,$00
.db $92,$a8,$ae,$ad,$a1,$ff,$85,$a2,$a0,$9a,$ab,$a8,$ff,$9f,$9e,$ab,$ab,$b2,$00
.db $00
desc_416:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_417:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_418:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_419:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_420:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_421:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_422:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_423:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_424:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_425:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_426:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_427:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_428:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_429:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_430:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_431:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_432:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_433:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_434:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_435:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_436:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_437:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_438:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_439:
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_440:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_441:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_442:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_443:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
desc_444:
.db $92,$a8,$ae,$a5,$ff,$92,$a1,$ab,$a2,$a7,$9e,$00
.db $00
desc_445:
.db $92,$a8,$ae,$a5,$ff,$92,$a1,$ab,$a2,$a7,$9e,$00
.db $00
desc_446:
.db $92,$a8,$ae,$a5,$ff,$92,$a1,$ab,$a2,$a7,$9e,$00
.db $00
desc_447:
.db $92,$a8,$ae,$a5,$ff,$92,$a1,$ab,$a2,$a7,$9e,$00
.db $00
desc_448:
.db $80,$9d,$af,$9a,$a7,$9c,$9e,$ff,$9e,$a7,$9c,$a8,$ae,$a7,$ad,$9e,$ab,$00
.db $00
desc_449:
.db $80,$9d,$af,$9a,$a7,$9c,$9e,$ff,$9e,$a7,$9c,$a8,$ae,$a7,$ad,$9e,$ab,$00
.db $00
desc_450:
.db $80,$9d,$af,$9a,$a7,$9c,$9e,$ff,$9e,$a7,$9c,$a8,$ae,$a7,$ad,$9e,$ab,$00
.db $00
desc_451:
.db $81,$a8,$ac,$ac,$00
.db $83,$ab,$9a,$a0,$a8,$a7,$c3,$ac,$ff,$83,$9e,$a7,$00
.db $00
DescriptionEnd:
.ends
.bank $3d
.org $4400
.section "Bestiary core" overwrite

BookStart:
; In the unmodified menu the four displaced bytes test the A button.
MenuGate:
 lda $4219
 bit.b #$20
 bne OpenBook
 lda $08
 bit.b #$80
 jml $c31dac
OpenBook:
 php
 phb
 sep #$20
 lda.b #$00
 pha
 plb
 ldx.w #$001f
SaveScratch:
 lda $a0,x
 pha
 dex
 bpl SaveScratch
 stz $24
 lda.b #$81
 sta $4200
 stz $420c
 lda.b #$80
 sta $2100
 lda.b #$06
 sta $212c
 stz $212d
 stz $212e
 stz $212f
 stz $2130
 stz $2131
 stz $2111
 stz $2111
 stz $2112
 stz $2112
 stz $210f
 stz $210f
 stz $2110
 stz $2110
 stz $a0
 stz $a1
 stz $a2
 stz $a3
 stz $ae
 stz $af
 jsr BuildList
 rep #$20
 lda.w #$1000
 sta $2116
 ldx.w #WindowMap
 stx $4302
 lda.w #$0800
 sta $4305
 sep #$20
 lda.b #$fd
 sta $4304
 jsr Transfer
 jsr DrawPage
 jsr UploadPage
 lda.b #$0f
 sta $2100
 rep #$20
 lda $4218
 sta $aa
 sep #$20
BookLoop:
 jsr NextVblank
 lda $1188
 and.b #$20
 beq ReadButtons
 ldy $1189
 bne ReadButtons
 jmp CloseBook
ReadButtons:
 rep #$20
 lda $4218
 eor $aa
 and $4218
 sta $ac
 lda $4218
 sta $aa
 lda $ac
 bit.w #$8000
 beq NotBack
 lda $ae
 bne WasDetail
 jmp CloseBook
WasDetail:
 stz $ae
 bra Redraw
NotBack:
 lda $ac
 bit.w #$0080
 beq NotAccept
 lda $a2
 beq Idle
 lda.w #1
 sta $ae
 bra Redraw
NotAccept:
 lda $ac
 bit.w #$0030
 bne Shoulder
 lda $ae
 bne Idle
 lda $ac
 bit.w #$0f00
 beq Idle
 bit.w #$0300
 bne SingleMove
 lda.w #2
 bra Distance
SingleMove:
 lda.w #1
 bra Distance
Shoulder:
 lda $ae
 bne SingleMove
 lda.w #16
Distance:
 sta $a6
 lda $ac
 bit.w #$0a20
 beq MoveForward
 lda $a0
 sec
 sbc $a6
 bcs Moved
 lda.w #0
 bra Moved
MoveForward:
 lda $a2
 beq Idle
 dec a
 sta $a8
 lda $a0
 clc
 adc $a6
 cmp $a8
 bcc Moved
 lda $a8
Moved:
 cmp $a0
 beq Idle
 sta $a0
Redraw:
 sep #$20
 jsr DrawPage
 jsr NextVblank
 jsr UploadPage
 jmp BookLoop
Idle:
 sep #$20
 jmp BookLoop
CloseBook:
 sep #$20
 lda.b #$80
 sta $2100
 lda.b #$1f
 sta $212c
 lda.b #$0f
 sta $212d
 sta $212e
 ; Native menu color math and HDMA are rebuilt by the main menu initializer.
 ldx.w #0
RestoreScratch:
 pla
 sta $a0,x
 inx
 cpx.w #$0020
 bne RestoreScratch
 plb
 plp
 jml ExitBook
 .rept 9
 nop
 .endr

NextVblank:
 bit $4212
 bmi NextVblank
WaitStart:
 bit $4212
 bpl WaitStart
WaitPad:
 lda $4212
 and.b #$01
 bne WaitPad
 rts
UploadPage:
 rep #$20
 lda.w #$4000
 sta $2116
 lda.w #$7849
 sta $4302
 lda.w #$0800
 sta $4305
 sep #$20
 lda.b #$7e
 sta $4304
Transfer:
 lda.b #$80
 sta $2115
 lda.b #1
 sta $4300
 lda.b #$18
 sta $4301
 lda.b #1
 sta $420b
 rts

; $a0 selection (word), $a2 encountered count, $ae detail mode.
; Store roster indices for encountered enemies, in DrakeyC's encounter order.
BuildList:
 rep #$20
 ldy.w #0
BuildLoop:
 tya
 asl a
 tax
 lda.l Roster,x
 pha
 and.w #7
 tax
 lda.l Masks,x
 and.w #$00ff
 sta $a8
 pla
 lsr a
 lsr a
 lsr a
 tax
 lda.l $307fb7,x
 and $a8
 beq BuildNext
 lda $a2
 asl a
 tax
 tya
 sta.l $7eb800,x
 inc $a2
BuildNext:
 iny
 cpy.w #400
 bne BuildLoop
 sep #$20
 rts
Masks:
 .db 1,2,4,8,16,32,64,128
DrawPage:
 rep #$20
 lda.w #0
 ldx.w #$07fe
ClearMap:
 sta.l $7e7849,x
 dex
 dex
 bpl ClearMap
 sep #$20
 lda $ae
 beq DrawList
 jmp DrawDetails
DrawList:
 jsr ListLabels
 rep #$20
 lda $a2
 ldx.w #178
 jsr Number
 lda $a2
 bne ListNotEmpty
 sep #$20
 jmp EmptyLabels
ListNotEmpty:
 lda $a0
 and.w #$fff0
 sta $b0
 stz $b2
ListRow:
 lda $b2
 and.w #$000e
 xba
 lsr a
 lsr a
 clc
 adc.w #454
 sta $b4
 lda $b2
 and.w #1
 beq ListLeft
 lda $b4
 clc
 adc.w #28
 sta $b4
ListLeft:
 lda $b0
 cmp $a0
 bne NotSelected
 ldx $b4
 lda.w #$2ccf
 sta.l $7e7845,x
NotSelected:
 lda $b0
 jsr GetMonster
 ldx $b4
 jsr PrintName
 inc $b0
 inc $b2
 lda $b0
 cmp $a2
 bcs ListDone
 lda $b2
 cmp.w #16
 bcc ListRow
ListDone:
 sep #$20
 rts
; Input selection; return actual enemy ID in A and roster index in Y.
GetMonster:
 asl a
 tax
 lda.l $7eb800,x
 asl a
 tay
 tax
 lda.l Roster,x
 rts
; Fixed-size 10-glyph enemy name record; use SNES Advance's relocated names.
PrintName:
 sta $a6
 asl a
 asl a
 adc $a6
 asl a
 tay
 phx
 tyx
 ply
 sep #$20
 lda.b #10
 sta $a8
NameLoop:
 lda.l $f84bec,x
 phx
 tyx
 sta.l $7e7849,x
 lda.b #$20
 sta.l $7e784a,x
 plx
 iny
 iny
 inx
 dec $a8
 bne NameLoop
 rep #$20
 rts

DrawDetails:
 jsr DetailLabels
 rep #$20
 lda $a0
 jsr GetMonster
 sty $bc
 sta $b0
 ldx.w #160
 jsr PrintName
 ldx $bc
 lda.l $f1c200,x
 tay
 ldx.w #260
 sep #$20
 lda.b #$20
 sta $ba
DescStart:
 tyx
 lda.l $f10000,x
 beq DescDone
 ldx.w #260
 jsr DescLine
 ldx.w #324
 jsr DescLine
DescDone:
 rep #$20
 lda $b0
 asl a
 asl a
 asl a
 asl a
 asl a
 sta $b2
 ldy.w #0
StatLoop:
 sty $b4
 tyx
 lda.l StatOffsets,x
 and.w #255
 clc
 adc $b2
 tax
 lda.l $f80000,x
 cpy.w #7
 bcs WideStat
 and.w #255
WideStat:
 pha
 tya
 asl a
 tax
 lda.l StatPlaces,x
 tax
 pla
 jsr Number
 ldy $b4
 iny
 cpy.w #11
 bne StatLoop
 ; Weakness, absorption, nullification. Each set bit gets a readable icon.
 ldy.w #0
ElementGroup:
 sty $b4
 tyx
 lda.l ElementOffsets,x
 and.w #255
 clc
 adc $b2
 tax
 lda.l $f80000,x
 and.w #255
 sta $b6
 lda $b4
 xba
 lsr a
 lsr a
 clc
 adc.w #976
 tax
 ldy.w #0
ElementBit:
 lsr $b6
 bcc SkipElement
 phx
 tya
 asl a
 tax
 lda.l ElementIcons,x
 sta $a6
 plx
 lda $a6
 and.w #255
 ora.w #$2000
 sta.l $7e7849,x
 inx
 inx
 lda $a6
 xba
 and.w #255
 ora.w #$2000
 sta.l $7e7849,x
 inx
 inx
 inx
 inx
SkipElement:
 iny
 cpy.w #8
 bne ElementBit
 ldy $b4
 iny
 cpy.w #3
 bne ElementGroup
 lda $b0
 asl a
 asl a
 sta $b2
 ldy.w #0
LootLoop:
 sty $b4
 tya
 clc
 adc $b2
 tax
 lda.l $f844dc,x
 and.w #255
 cmp.w #255
 beq LootNext
 sta $b6
 asl a
 adc $b6
 asl a
 asl a
 adc $b6
 tax
 inx
 phx
 tya
 asl a
 tax
 lda.l LootPlaces,x
 tay
 plx
 sep #$20
 lda.b #12
 sta $a8
LootChar:
 lda.l $d2b300,x
 phx
 tyx
 sta.l $7e7849,x
 lda.b #$20
 sta.l $7e784a,x
 plx
 inx
 iny
 iny
 dec $a8
 bne LootChar
 rep #$20
LootNext:
 ldy $b4
 iny
 cpy.w #4
 bne LootLoop
 sep #$20
 rts
; Stats and layout follow the donor's level/HP/MP, offense/defense, rewards and affinities.
StatOffsets:
 .db $10,$01,$05,$03,$07,$06,$04,$08,$0a,$0e,$0c
StatPlaces:
 .dw 458,592,656,720,626,690,756,474,496,810,782
ElementOffsets:
 .db $19,$17,$18
ElementIcons:
 .db 133,162,136,156,139,173,143,172,150,162,135,168,132,154,150,154
LootPlaces:
 .dw 1254,1228,1382,1356
DescLine:
 phx
 tyx
 lda.l $f10000,x
 plx
 cmp.b #0
 beq EndDesc
 sta.l $7e7849,x
 lda.b #$20
 sta.l $7e784a,x
 inx
 inx
 iny
 bra DescLine
EndDesc:
 iny
 rts
Print:
 sta $ba
PrintLoop:
 phx
 tyx
 lda.l $fd0000,x
 plx
 cmp.b #0
 beq PrintEnd
 sta.l $7e7849,x
 lda $ba
 sta.l $7e784a,x
 inx
 inx
 iny
 bra PrintLoop
PrintEnd:
 rts
; Unsigned 0..65535. Only used while displaying a page.
Number:
 stx $b8
 ldy.w #0
 stz $a6
 stz $be
DigitLoop:
 ldx.w #0
DigitAgain:
 phy
 tyx
 cmp.l Divisors,x
 ply
 bcc DigitDone
 phy
 tyx
 sec
 sbc.l Divisors,x
 ply
 inc $a6
 bra DigitAgain
DigitDone:
 pha
 lda $a6
 bne PrintDigit
 cpy.w #8
 beq PrintDigit
 lda $be
 bne PrintDigit
 bra BlankDigit
PrintDigit:
 lda $a6
 clc
 adc.w #$20b4
 ldx $b8
 sta.l $7e7849,x
 inx
 inx
 stx $b8
 inc $be
 bra NextDigit
BlankDigit:
NextDigit:
 pla
 stz $a6
 iny
 iny
 cpy.w #10
 bne DigitLoop
 rts
Divisors:
 .dw 10000,1000,100,10,1

; Fast bounded encounter registration. Replay both original stores exactly.
Encounter:
 sta $1ff9,y
 sta $33a8,y
 php
 cmp.w #255
 bcs ExtendedEnemy
RecordEnemy:
 phx
 pha
 lsr a
 lsr a
 lsr a
 tax
 lda 1,s
 and.w #7
 phx
 tax
 sep #$20
 lda.l Masks,x
 plx
 ora.l $307fb7,x
 sta.l $307fb7,x
 rep #$20
 pla
 plx
EncounterReturn:
 plp
 rtl
ExtendedEnemy:
 cmp.w #452
 bcs EncounterReturn
 cmp.w #255
 bne RecordEnemy
 ; Reject $00ff fillers in unused formation slots but retain enemy ID 255.
 pha
 sep #$20
 lda $3a97
 bmi Present255
 lda.l Masks,x
 and $3f45
 bne Present255
 rep #$20
 pla
 bra EncounterReturn
Present255:
 rep #$20
 pla
 bra RecordEnemy
; Per-slot record is 2-byte signature, 2-byte native checksum and 57 flag bytes.
SlotOffset:
 and.w #$00ff
 cmp.w #2
 bcc SlotOne
 beq SlotTwo
 ldx.w #122
 rts
SlotTwo:
 ldx.w #61
 rts
SlotOne:
 ldx.w #0
 rts
SaveFlags:
 ldy $e7
 sty $1ffe
 php
 rep #$30
 pha
 phx
 phy
 lda.l $307ff0
 jsr SlotOffset
 lda.w #$b1d6
 sta.l $307f00,x
 lda $1ffe
 sta.l $307f02,x
 ldy.w #0
SaveByte:
 sep #$20
 phx
 tyx
 lda.l $307fb7,x
 plx
 sta.l $307f04,x
 inx
 iny
 cpy.w #57
 bne SaveByte
 rep #$30
 ply
 plx
 pla
 plp
 rtl
LoadFlags:
 php
 rep #$30
 pha
 phx
 phy
 lda $021f
 jsr SlotOffset
 lda.l $307f00,x
 cmp.w #$b1d6
 bne OldSave
 lda.l $307f02,x
 cmp $1ffe
 bne OldSave
 sep #$20
 ldy.w #0
LoadByte:
 lda.l $307f04,x
 phx
 tyx
 sta.l $307fb7,x
 plx
 inx
 iny
 cpy.w #57
 bne LoadByte
 bra LoadDone
OldSave:
 jsr ClearFlags
LoadDone:
 rep #$30
 ply
 plx
 pla
 plp
 ; Resume the original SNES Advance extension (PopTimers).
 jml $ffa5f7
NewGameFlags:
 ; The US engine copies 48 name bytes here on every new game.
 ; Copy the same words and spend the freed time clearing the encounter log.
 rep #$20
 pha
 lda.l $cf3c40
 sta $1cf8
 lda.l $cf3c42
 sta $1cfa
 lda.l $cf3c44
 sta $1cfc
 lda.l $cf3c46
 sta $1cfe
 lda.l $cf3c48
 sta $1d00
 lda.l $cf3c4a
 sta $1d02
 lda.l $cf3c4c
 sta $1d04
 lda.l $cf3c4e
 sta $1d06
 lda.l $cf3c50
 sta $1d08
 lda.l $cf3c52
 sta $1d0a
 lda.l $cf3c54
 sta $1d0c
 lda.l $cf3c56
 sta $1d0e
 lda.l $cf3c58
 sta $1d10
 lda.l $cf3c5a
 sta $1d12
 lda.l $cf3c5c
 sta $1d14
 lda.l $cf3c5e
 sta $1d16
 lda.l $cf3c60
 sta $1d18
 lda.l $cf3c62
 sta $1d1a
 lda.l $cf3c64
 sta $1d1c
 lda.l $cf3c66
 sta $1d1e
 lda.l $cf3c68
 sta $1d20
 lda.l $cf3c6a
 sta $1d22
 lda.l $cf3c6c
 sta $1d24
 lda.l $cf3c6e
 sta $1d26
 jsr ClearFlags
 rep #$20
 pla
 sep #$20
 lda.l $cf3c6f
 ; Match the original loop's master-clock count, including its final
 ; non-taken branch. This keeps the opening battle RNG at the same phase.
 ldx.w #69
NewGameDelay:
 dex
 bne NewGameDelay
 nop
 nop
 ldx.w #48
 cpx.w #48
 jml $c0bdfe
ClearFlags:
 rep #$20
 lda.w #0
 sta.l $307fb7
 sta.l $307fb9
 sta.l $307fbb
 sta.l $307fbd
 sta.l $307fbf
 sta.l $307fc1
 sta.l $307fc3
 sta.l $307fc5
 sta.l $307fc7
 sta.l $307fc9
 sta.l $307fcb
 sta.l $307fcd
 sta.l $307fcf
 sta.l $307fd1
 sta.l $307fd3
 sta.l $307fd5
 sta.l $307fd7
 sta.l $307fd9
 sta.l $307fdb
 sta.l $307fdd
 sta.l $307fdf
 sta.l $307fe1
 sta.l $307fe3
 sta.l $307fe5
 sta.l $307fe7
 sta.l $307fe9
 sta.l $307feb
 sta.l $307fed
 sep #$20
 sta.l $307fef
 rts

Roster:
.dw 25,0,27,19,77,70,23,40,92,93,66,98,99,46,18,168,21,11,122,134,50,56,57,34,17,113,159,54,148,245,239,244,96,182,207,118,24,47,41,26,1,2,68,90,162,8,79,14,186,15,94,89,58,101,121,28,120,108,42,140,144,35,223,78,82,83,115,209,123,107,141,129,61,232,199,203,65,357,71,102,45,117,136,6,175,160,110,229,179,72,130,3,150,29,31,222,214,184,235,238,208,227,67,12,74,164,131,216,32,361,163,170,114,178,213,202,33,49,124,152,230,44,225,192,53,60,88,48,195,151,185,95,169,73,75,215,139,211,167,219,137,16,5,111,145,97,221,20,242,197,142,143,126,187,91,210,135,153,176,59,52,51,9,204,146,119,173,188,247,241,191,236,233,147,226,248,206,156,218,196,231,243,201,180,158,205,198,84,133,190,171,172,177,10,4,30,157,149,254,138,212,43,165,116,105,181,200,154,112,87,109,166,81,69,62,76,369,220,103,250,240,104,125,38,39,85,306,304,293,299,307,313,323,355,356,224,128,183,132,228,217,234,246,237,253,252,193,7,13,189,106,251,86,161,249,22,261,155,37,333,314,373,315,334,335,374,342,340,341,63,258,194,174,280,80,255,256,308,100,259,300,260,305,55,262,330,263,301,264,265,266,267,319,320,269,270,278,302,360,303,275,325,327,326,279,283,316,317,318,257,309,284,285,363,364,365,127,281,286,328,324,272,287,288,289,290,359,291,294,352,353,354,312,292,358,331,332,336,337,338,339,36,329,268,321,322,381,274,295,296,297,343,344,345,346,347,348,349,350,351,298,367,372,380,416,417,418,419,420,421,422,423,424,425,426,427,428,429,430,431,432,433,434,435,436,437,438,439,440,441,442,443,444,445,446,447,448,449,450,451
RosterEnd:
ListLabels:
ldx.w #132
ldy.w #txt_0
lda.b #$2c
jsr Print
ldx.w #158
ldy.w #txt_1
lda.b #$20
jsr Print
ldx.w #1604
ldy.w #txt_2
lda.b #$20
jsr Print
ldx.w #1624
ldy.w #txt_3
lda.b #$20
jsr Print
ldx.w #1648
ldy.w #txt_4
lda.b #$20
jsr Print
rts
EmptyLabels:
ldx.w #646
ldy.w #txt_5
lda.b #$20
jsr Print
ldx.w #838
ldy.w #txt_6
lda.b #$20
jsr Print
rts
DetailLabels:
ldx.w #132
ldy.w #txt_0
lda.b #$2c
jsr Print
ldx.w #452
ldy.w #txt_7
lda.b #$20
jsr Print
ldx.w #468
ldy.w #txt_8
lda.b #$20
jsr Print
ldx.w #490
ldy.w #txt_9
lda.b #$20
jsr Print
ldx.w #580
ldy.w #txt_10
lda.b #$20
jsr Print
ldx.w #610
ldy.w #txt_11
lda.b #$20
jsr Print
ldx.w #644
ldy.w #txt_12
lda.b #$20
jsr Print
ldx.w #674
ldy.w #txt_13
lda.b #$20
jsr Print
ldx.w #708
ldy.w #txt_14
lda.b #$20
jsr Print
ldx.w #738
ldy.w #txt_15
lda.b #$20
jsr Print
ldx.w #772
ldy.w #txt_16
lda.b #$20
jsr Print
ldx.w #802
ldy.w #txt_17
lda.b #$20
jsr Print
ldx.w #964
ldy.w #txt_18
lda.b #$2c
jsr Print
ldx.w #1028
ldy.w #txt_19
lda.b #$2c
jsr Print
ldx.w #1092
ldy.w #txt_20
lda.b #$2c
jsr Print
ldx.w #1156
ldy.w #txt_21
lda.b #$2c
jsr Print
ldx.w #1170
ldy.w #txt_22
lda.b #$20
jsr Print
ldx.w #1192
ldy.w #txt_23
lda.b #$20
jsr Print
ldx.w #1284
ldy.w #txt_24
lda.b #$2c
jsr Print
ldx.w #1604
ldy.w #txt_25
lda.b #$20
jsr Print
ldx.w #1638
ldy.w #txt_26
lda.b #$20
jsr Print
rts
txt_0:
.db $81,$9e,$ac,$ad,$a2,$9a,$ab,$b2,$00
txt_1:
.db $91,$9e,$9c,$a8,$ab,$9d,$9e,$9d,$00
txt_2:
.db $80,$ff,$83,$9e,$ad,$9a,$a2,$a5,$ac,$00
txt_3:
.db $8b,$c0,$91,$ff,$8f,$9a,$a0,$9e,$00
txt_4:
.db $81,$ff,$81,$9a,$9c,$a4,$00
txt_5:
.db $8d,$a8,$ff,$9e,$a7,$9c,$a8,$ae,$a7,$ad,$9e,$ab,$ac,$ff,$ab,$9e,$9c,$a8,$ab,$9d,$9e,$9d,$ff,$b2,$9e,$ad,$c5,$00
txt_6:
.db $85,$a2,$a0,$a1,$ad,$ff,$9a,$a7,$ff,$9e,$a7,$9e,$a6,$b2,$ff,$ad,$a8,$ff,$9a,$9d,$9d,$ff,$a2,$ad,$c5,$00
txt_7:
.db $8b,$95,$00
txt_8:
.db $87,$8f,$00
txt_9:
.db $8c,$8f,$00
txt_10:
.db $95,$a2,$a0,$a8,$ab,$00
txt_11:
.db $8c,$9a,$a0,$a2,$9c,$00
txt_12:
.db $83,$9e,$9f,$c5,$00
txt_13:
.db $8c,$c5,$83,$9e,$9f,$00
txt_14:
.db $84,$af,$9a,$9d,$9e,$00
txt_15:
.db $8c,$c5,$84,$af,$9a,$9d,$9e,$00
txt_16:
.db $84,$97,$8f,$00
txt_17:
.db $86,$8f,$00
txt_18:
.db $96,$9e,$9a,$a4,$00
txt_19:
.db $80,$9b,$ac,$a8,$ab,$9b,$00
txt_20:
.db $88,$a6,$a6,$ae,$a7,$9e,$00
txt_21:
.db $92,$ad,$9e,$9a,$a5,$00
txt_22:
.db $82,$a8,$a6,$a6,$a8,$a7,$00
txt_23:
.db $91,$9a,$ab,$9e,$00
txt_24:
.db $83,$ab,$a8,$a9,$00
txt_25:
.db $8b,$c0,$91,$ff,$84,$a7,$9e,$a6,$b2,$00
txt_26:
.db $81,$ff,$8b,$a2,$ac,$ad,$00
WindowMap:
.dw 7568,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7571,7572,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7573,7574,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7575,7572,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7573,7574,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7575,7572,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7573,7574,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7575,7572,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7573,7574,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7575,7572,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7573,7574,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7575,7572,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7573,7574,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7575,7572,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7573,7574,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7575,7572,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7573,7574,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7575,7572,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7573,7574,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7575,7572,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7573,7574,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7566,7567,7564,7565,7575,7572,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7573,7576,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7579,7568,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7569,7570,7571,7572,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7554,7555,7552,7553,7573,7574,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7558,7559,7556,7557,7575,7572,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7562,7563,7560,7561,7573,7576,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7577,7578,7579,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
; Enter through the native Config handler, after its B button check.
ConfigInput:
 lda $4a
 beq NormalConfigInput
 lda $4e
 cmp.b #6
 bne NormalConfigInput
 lda $08
 bit.b #$80
 bne EnterConfigBook
 ; Keep shoulder-page navigation; Left/Right do not index a color routine.
 jml $c323ed
EnterConfigBook:
 jml OpenBook
NormalConfigInput:
 lda $0b
 bit.b #1
 jml $c3231b

ExitBook:
 lda $26
 cmp.b #$0e
 beq RebuildConfig
 lda.b #4
 sta $26
 lda.b #$81
 sta $4200
 jml $c31dd2
RebuildConfig:
 stz $5f
 lda.b #$81
 sta $4200
 jml $c3a37c

DrawBookLabel:
 php
 rep #$30
 pha
 phx
 ldx.w #14
ConfigTextLoop:
 lda.l ConfigBookText,x
 sta.l $7e468f,x
 dex
 dex
 bpl ConfigTextLoop
 plx
 pla
 plp
 rtl
ConfigBookText:
 .dw $2481,$249e,$24ac,$24ad,$24a2,$249a,$24ab,$24b2

BookEnd:
.ends

.bank $03
.org $1da8
.section "adapter hook 031da8" overwrite
.db $5c,$00,$44,$fd
.ends

.bank $03
.org $2317
.section "adapter hook 032317" overwrite
.db $5c,$16,$58,$fd
.ends

.bank $02
.org $2c34
.section "adapter hook 022c34" overwrite
.db $22,$bd,$48,$fd,$ea,$ea
.ends

.bank $03
.org $fd65
.section "adapter hook 03fd65" overwrite
.db $22,$64,$49,$fd
.ends

.bank $03
.org $fd76
.section "adapter hook 03fd76" overwrite
.db $22,$64,$49,$fd
.ends

.bank $03
.org $153a
.section "adapter hook 03153a" overwrite
.db $22,$26,$49,$fd,$ea
.ends

.bank $00
.org $bdef
.section "adapter hook 00bdef" overwrite
.db $5c,$a8,$49,$fd
.ends

.bank $03
.org $39e6
.section "adapter hook 0339e6" overwrite
.db $17
.ends

.bank $03
.org $3a81
.section "adapter hook 033a81" overwrite
.db $5d,$08,$f7,$03
.ends

.bank $03
.org $294b
.section "adapter hook 03294b" overwrite
.db $60,$29,$60,$69,$60,$79,$60,$99,$60,$a9,$60,$b9,$08,$c9,$22,$54,$58,$fd,$4c,$29,$0e
.ends

.bank $03
.org $a37c
.section "adapter hook 03a37c" overwrite
.db $20,$7e,$1c,$a9,$01,$85,$4a,$20,$eb,$39,$a9,$06,$85,$4e,$4c,$88,$38
.ends

.bank $03
.org $3889
.section "adapter hook 033889" overwrite
.db $4b,$29
.ends

.bank $03
.org $3892
.section "adapter hook 033892" overwrite
.db $07
.ends

.bank $03
.org $3942
.section "adapter hook 033942" overwrite
.db $20,$59,$29
.ends
