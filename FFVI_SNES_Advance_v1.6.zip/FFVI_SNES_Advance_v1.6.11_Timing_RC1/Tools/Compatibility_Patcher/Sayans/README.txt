SAYANS TRADUCTIONS — INTEGRATED PATCHER

1. Open FFVI_SNES_Advance_Compatibility_Patcher.html from the patcher directory.
2. Load Final Fantasy III (USA) 1.0 or 1.1, a current plain Regular SNES Advance ROM, or a ROM produced with an original Sayans Spanish patch. Both unheadered ROMs and ROMs with a 512-byte copier header are supported.
3. Choose Sayans · Spain (Pablito’s) or Sayans · South America (Magimaster 2). An already-translated ROM automatically selects its own edition.
4. Select your gameplay preset and choose Build ROM, then Download ROM. TWUE additions require the original complete Ted Woolsey Uncensored Edition 3.07 ZIP or previously verified source files saved in a personal patcher.

Every preset includes SNES Advance’s GBA bonus content. The original story uses the selected Sayans script. The added quests and dungeons use the SNES Advance Spanish localization. The South American preset imports Magimaster 2’s text and uses SNES Advance or TWUE combat balance.

Both TWUE choices include B-button running and the faster Cyan gauge from TWUE Add-Ons. The Music Player is on the first Config page and uses TWUE’s English track titles. The six presets use the native SNES font and standard battle system. The general options panel’s Bestiary, MSU-1, alternative fonts, ATB rules and other TWUE layouts have separate compatibility requirements and are unavailable in these presets.

Reopen a finished Sayans ROM, including an RC1 output, to add or remove TWUE or the Config 2 player. Removing features uses the verified ROM alone. To change the translation itself, start from a compatible clean US or plain Regular ROM. A personal copy remembers the selected preset and the TWUE patches verified during that build. Choose your ROM again when using a personal copy.

Original Sayans archives and credits are in Credits/. General TWUE and Music Player credits are in the patcher’s main Credits/ directory.
