"""Build reversible links between the exact, previously validated Sayans game images."""
from pathlib import Path
import json,hashlib,zlib,zipfile,base64,subprocess
w=Path('work');rom=Path('roms')
db=json.loads((w/'db.json').read_bytes())
regular=Path('inputs/regular-native.sfc').read_bytes()
sha=lambda data:hashlib.sha256(data).hexdigest()
db['regular']=sha(regular)
def spec(archive,name):
 with zipfile.ZipFile(archive) as z:
  i=z.getinfo(name);return dict(name=name.split('/')[-1],size=i.file_size,crc=i.CRC,sha=sha(z.read(i)))
tw=Path('inputs/TWUE-3.07.zip')
db['twue']=spec(tw,db.pop('twname'));db['music']=spec(tw,db.pop('musicname'));assert db['twue']['sha']==db.pop('twhash') and db['music']['sha']==db.pop('musichash')
for ed,archive,ips in [('esp','ff3_esp.zip','ff3esp.ips'),('sur','ff3m2_esp.zip','FF3v2.IPS')]:
 e=db['editions'][ed];e['ips']=spec(Path('inputs')/archive,ips)
 with zipfile.ZipFile(Path('inputs')/archive) as z:source=z.read(ips)
 for key,body,target in [('regular',regular+source,'advance'),('removeMusic',(rom/f'{ed}-music.sfc').read_bytes(),'twue'),('removeTwue',(rom/f'{ed}-twue.sfc').read_bytes(),'advance')]:
  s=w/'source.tmp';s.write_bytes(body);t=rom/f'{ed}-{target}.sfc';p=w/'delta.tmp'
  subprocess.run(['work/delta',s,t,p],check=True)
  db['patches'][ed+'-'+key]={'data':base64.b64encode(zlib.compress(p.read_bytes(),9)).decode(),'sha':sha(t.read_bytes())}
(w/'source.tmp').unlink();(w/'delta.tmp').unlink()
(w/'data.json').write_text(json.dumps(db,separators=(',',':')))
