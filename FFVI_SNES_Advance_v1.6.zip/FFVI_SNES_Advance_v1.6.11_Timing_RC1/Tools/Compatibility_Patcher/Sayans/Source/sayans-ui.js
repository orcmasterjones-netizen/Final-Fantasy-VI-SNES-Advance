let sayansInput=null,plainRegular=null;
let sayansPreset='advance';
function chooseSayans(source){
    sayansInput=source;
    sayansPreset=source.preset||(sayansPresets.includes(personal.sayans?.preset)?personal.sayans.preset:'advance');
}
function chooseEdition(edition){
    if(!retailInput&&!plainRegular)return;
    resetRetailPreparation();
    retailEdition=edition;sayansInput=null;
    if(isSayansEdition(edition)){
        const base=retailInput||plainRegular;
        chooseSayans({kind:retailInput?'retail':'regular',edition,bytes:retailInput?base.bytes:base.sayansRegular,revision:retailInput?.revision==='1.1'?1:0});
    }else if(plainRegular)current=plainRegular;
    render();
}
function savedSayansSource(name){
    return personal.sources?.sayans?.[name]||personal.sources?.music?.[name]||personal.sources?.twue?.[name];
}
el('sayansPreset').addEventListener('change',()=>{
    sayansPreset=el('sayansPreset').value;clearResult();render();
});
el('sayansZip').addEventListener('change',()=>{clearResult();render();});
function renderSayans(){
    const input=sayansInput;
    const unlocked=!!retailInput||!!plainRegular;
    el('retailPanel').hidden=!unlocked;el('retailEdition').value=input.edition;
    el('retailStatus').textContent='';el('retailMoleSource').hidden=true;
    el('molemanWarning').hidden=true;el('futureWarning').hidden=true;
    el('battlePanel').hidden=true;el('optionsPanel').hidden=true;
    el('sayansPreset').value=sayansPreset;
    const specs=sayansSourceSpecs(input,sayansPreset);
    const cached=specs.length>0&&specs.every(s=>savedSayansSource(s.name));
    const file=el('sayansZip').files[0];
    el('sayansZipBox').hidden=!specs.length;
    el('sayansCached').hidden=!cached||!!file;
    const profile=sayansProfile(input.edition,sayansPreset);
    const currentName=editionLabel(sayansProfile(input.edition,input.preset||'advance'));
    const status=el('romStatus');status.className='status ok';
    status.textContent=t('romVerified')+' · '+(input.kind==='retail'?t('retailDetected')+retailInput.revision:input.kind==='regular'?t('editionRegular'):input.kind==='output'?currentName:t(input.edition));
    el('selection').replaceChildren(...[t(input.edition),t('sayans-'+sayansPreset)].map(label=>{const li=make('li');li.textContent=label;return li;}));
    const same=input.kind==='output'&&input.preset===sayansPreset;
    if(same&&!result&&!building)publishOutput({bytes:input.bytes,id:sayansData.patches[input.edition+'-'+sayansPreset].sha,profile});
    const missing=specs.length&&!file&&!cached;
    el('status').textContent=buildError||(building?t('working'):result?t('done'):missing?t('sayansNeedZip'):t('ready'));
    el('status').className='status'+(buildError?' error':result?' ok':'');
    el('build').disabled=building||!!missing||!!result;el('build').hidden=!!result;
    el('download').hidden=!result;el('outputName').hidden=!result;
    el('outputName').textContent=result?filename(result.profile)+' · CRC32 '+result.outputCRC32:'';
    el('personalButton').hidden=!result;el('personalHint').hidden=!result;
}
async function runSayans(){
    clearResult();const token=buildRevision,source=sayansInput,preset=sayansPreset;
    const file=el('sayansZip').files[0];building=true;render();
    try{
        const saved={};for(const spec of sayansSourceSpecs(source,preset))saved[spec.name]=savedSayansSource(spec.name);
        const assets=await readSayansSources(source,preset,file,saved);
        if(token!==buildRevision)return;
        const output=await buildSayans(source,preset,assets);
        if(token===buildRevision){publishOutput(output);verifiedSources={sayans:assets};}
    }catch(error){if(token===buildRevision)buildError=error.message||t('verifyFail');}
    finally{if(token===buildRevision){building=false;render();}}
}
