from merge import *
import base64,zlib,subprocess
sha=lambda s:hashlib.sha256(s).hexdigest()
def b64(b):return base64.b64encode(b).decode()
dist=root/'out';z=zipfile.ZipFile(root/'inputs/TWUE-3.07.zip')
twname=next(n for n in z.namelist() if n.endswith('(TWUE 3.07).ips'))
musicname=next(n for n in z.namelist() if n.endswith('Config 2.ips'));tw=z.read(twname);m=z.read(musicname)
db={'retail':{sha(V0):0,sha(V1):1},'editions':{},'patches':{},'twname':twname,'musicname':musicname,'twhash':sha(tw),'musichash':sha(m)}
from bps_util import apply_bps
for ed,path in ED.items():
 r=full(path);r1=full(path,V1);native=(root/'roms'/f'{ed}-advance.sfc').read_bytes();t=(root/'roms'/f'{ed}-twue.sfc').read_bytes();music=(root/'roms'/f'{ed}-music.sfc').read_bytes()
 srczip={'esp':'ff3_esp.zip','sur':'ff3m2_esp.zip'}[ed]
 db['editions'][ed]={'canonical':sha(r),'other':sha(r1),'archive':b64((root/'inputs'/srczip).read_bytes())}
 for profile,src,target in [('advance',r,native),('advance-r1',r1,native),('twue',native+tw,t),('music',t+m,music)]:
  sfile=root/'work/source.tmp';sfile.write_bytes(src);pfile=root/'work'/f'{ed}-{profile}.bps'
  subprocess.run([str(root/'work/delta'),str(sfile),str(root/'roms'/(ed+'-'+profile.split('-')[0]+'.sfc')),str(pfile)],check=True)
  patch=pfile.read_bytes();assert apply_bps(src,patch)==target
  db['patches'][ed+'-'+profile]={'data':b64(zlib.compress(patch,9)),'sha':sha(target)}
  print(ed,profile,len(patch),len(zlib.compress(patch,9)),flush=True)
(root/'work/db.json').write_text(json.dumps(db,separators=(',',':')))
