#include <algorithm>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iterator>
#include <vector>
#include <zlib.h>
#include <stdexcept>
using Bytes=std::vector<unsigned char>;
Bytes read(const char* path){std::ifstream f(path,std::ios::binary);return Bytes(std::istreambuf_iterator<char>(f),{});}
void num(Bytes &o,int n){for(;;){int lo=n&127;n>>=7;if(!n){o.push_back(lo|128);return;}o.push_back(lo);--n;}}
void crc(Bytes &o,const Bytes &v){uint32_t h=crc32(0,v.data(),v.size());for(int j=0;j<4;j++)o.push_back(h>>(j*8));}
unsigned key(const Bytes &s,int i){uint32_t n;memcpy(&n,&s[i],4);return (n*2654435761U)>>(32-21);}
int run(const Bytes &a,int i,const Bytes &b,int j){
 if(i<0||j<0)return 0;
 int n=std::min((int)a.size()-i,(int)b.size()-j);
 int k=0;while(k+8<=n&&!memcmp(&a[i+k],&b[j+k],8))k+=8;while(k<n&&a[i+k]==b[j+k])++k;return k;
}
int main(int argc,char** argv){
 if(argc!=4)return 1;
 auto s=read(argv[1]),t=read(argv[2]);Bytes p={'B','P','S','1'};
 num(p,s.size());num(p,t.size());num(p,0);
 std::vector<int> first(1<<21,-1),last(1<<21,-1),prior(1<<21,-1);
 for(int i=0;i+4<=(int)s.size();i+=2){auto h=key(s,i);if(first[h]<0)first[h]=i;last[h]=i;}
 int literal=0,sc=0,tc=0,i=0;
 auto literals=[&](int end){if(end<=literal)return;num(p,((end-literal-1)<<2)|1);p.insert(p.end(),t.begin()+literal,t.begin()+end);};
 while(i<(int)t.size()){
  int len=0,kind=0,pos=i;
  if(i<(int)s.size())len=run(s,i,t,i);
  if(i+4<=(int)t.size()){
   auto h=key(t,i);
   for(int candidate:{first[h],last[h]}){int n=run(s,candidate,t,i);if(n>len+3){len=n;kind=2;pos=candidate;}}
   int j=prior[h];int n=run(t,j,t,i);if(n>len+3){len=n;kind=3;pos=j;}
  }
  if(len<(kind?8:4)){if(i+4<=(int)t.size())prior[key(t,i)]=i;++i;continue;}
  literals(i);num(p,((len-1)<<2)|kind);
  if(kind){int &cursor=kind==2?sc:tc;int delta=pos-cursor;num(p,std::abs(delta)*2+(delta<0));cursor=pos+len;}
  for(int j=i;j<i+len&&j+4<=(int)t.size();j+=2)prior[key(t,j)]=j;
  i+=len;literal=i;
 }
 literals(i);crc(p,s);crc(p,t);crc(p,p);std::ofstream f(argv[3],std::ios::binary);f.write((char*)p.data(),p.size());
}
