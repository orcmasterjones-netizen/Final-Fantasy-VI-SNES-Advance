from pathlib import Path
import hashlib,sys,shutil,subprocess,zipfile
root=Path(__file__).resolve().parent
import os
os.chdir(root)
for folder in ('work','roms','out','inputs'):Path(folder).mkdir(exist_ok=True)
for line in Path('inputs.sha256').read_text().splitlines():
 digest,name=line.split();assert hashlib.sha256((Path('inputs')/name).read_bytes()).hexdigest()==digest,name
for archive in ('ff3_esp.zip','ff3m2_esp.zip'):
 source=Path('../Credits')/archive;shutil.copyfile(source,Path('inputs')/archive)
 with zipfile.ZipFile(source) as z:
  name=next(n for n in z.namelist() if n.lower().endswith('.ips'));(Path('inputs')/Path(name).name.lower()).write_bytes(z.read(name))
subprocess.run(['c++','-O3','-std=c++17','delta.cpp','-lz','-o','work/delta'],check=True)
subprocess.run([sys.executable,'merge.py'],check=True)
subprocess.run([sys.executable,'payload.py'],check=True)
subprocess.run([sys.executable,'data.py'],check=True)
subprocess.run([sys.executable,'integrate.py'],check=True)
