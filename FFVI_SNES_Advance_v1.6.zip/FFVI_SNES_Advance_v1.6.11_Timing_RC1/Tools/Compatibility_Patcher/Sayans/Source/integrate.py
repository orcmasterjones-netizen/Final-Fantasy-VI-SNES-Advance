from pathlib import Path
import json,shutil
w=Path('.')
s=Path('inputs/FFVI_SNES_Advance_Compatibility_Patcher_v1.6.4.html').read_text()
def edit(old,new):
 global s
 assert s.count(old)==1,(old[:115],s.count(old))
 s=s.replace(old,new)
s=s.replace('v1.6.4','v1.6.5')
edit('<script type="application/json" id="personal">','<script type="application/json" id="sayansData">'+Path('work/data.json').read_text()+'</script>\n<script type="application/json" id="personal">')
edit('<option value="" data-t="retailChoose">','<option id="retailBlank" value="" data-t="retailChoose">')
edit('<option value="moleman" data-t="retailMoleman"></option>','<option id="retailMoleChoice" value="moleman" data-t="retailMoleman"></option><option value="esp" data-t="esp"></option><option value="sur" data-t="sur"></option>')
edit('<small data-t="retailHint">','<small id="retailHint" data-t="retailHint">')
panel='''<section id="sayansPanel" class="panel" aria-labelledby="sayansTitle" hidden>
<h2 id="sayansTitle" data-t="sayansTitle">Sayans Traductions</h2>
<div class="choice" style="margin-left:0"><label for="sayansPreset" data-t="sayansPreset"></label><select id="sayansPreset">
<option value="advance" data-t="sayans-advance"></option><option value="twue" data-t="sayans-twue"></option><option value="music" data-t="sayans-music"></option></select></div>
<p><small data-t="sayansHint"></small></p>
<div id="sayansZipBox" class="source" hidden><label for="sayansZip" data-t="sayansNeedZip"></label><input type="file" id="sayansZip" accept=".zip"><a href="https://www.romhacking.net/hacks/1386/" target="_blank" rel="noopener noreferrer" data-t="source"></a><p id="sayansCached" class="reused" data-t="bundled" hidden></p></div>
</section>
'''
edit('<section id="battlePanel"',panel+'<section id="battlePanel"')
edit('<details id="roseReadme"','<p><a href="https://sayans.romhackhispano.org/old/traducciones/snes/a_f.htm" target="_blank" rel="noopener noreferrer">Sayans Traductions · Pablito’s / Magimaster 2</a></p><details id="roseReadme"')
keys=['esp','sur','sayansTitle','sayansPreset','sayans-advance','sayans-twue','sayans-music','sayansHint','sayansNeedZip','plainEditionHint','sayansBaseHint']
vals=[['Sayans · Spain (Pablito’s)','Sayans · South America (Magimaster 2)','Sayans Traductions','Gameplay preset','SNES Advance','SNES Advance + TWUE','SNES Advance + TWUE + Music Player','All three presets use the native SNES font and include the GBA bonus content in Spanish. TWUE adds B-button running and faster Bushido. Its optional Music Player is on the first Config page.','Choose the original Ted Woolsey Uncensored Edition 3.07 ZIP.','Keep Regular to use the options below, or choose a Sayans Spanish edition.','Choose a gameplay preset below, then select Build ROM.'],['Sayans · España (Pablito’s)','Sayans · Sudamérica (Magimaster 2)','Sayans Traductions','Opciones de juego','SNES Advance','SNES Advance + TWUE','SNES Advance + TWUE + reproductor de música','Las tres opciones usan la fuente de SNES e incluyen el contenido adicional de GBA en español. TWUE permite correr con B y acelera las técnicas de Cyan. El reproductor opcional se abre desde la primera página de Configuración.','Elige el ZIP original de Ted Woolsey Uncensored Edition 3.07.','Mantén Regular para usar las opciones de abajo o elige una traducción de Sayans.','Elige las opciones de juego de abajo y pulsa Crear ROM.']]
for edition,val in zip(['en','es'],vals):
 marker='const labels = {' if edition=='en' else None
 import re
 pat=re.search(r'(?:^|\n)    "?'+edition+r'"?:\s*\{',s)
 assert pat,edition
 pos=pat.end();s=s[:pos]+'\n'+''.join('        '+json.dumps(k)+': '+json.dumps(v,ensure_ascii=False)+',\n' for k,v in zip(keys,val))+s[pos:]
s=s.replace('Original ROMs prompt you to choose Regular or MoleMan.', 'Clean ROMs offer Regular, MoleMan and both Sayans Spanish editions. Original Sayans ROMs are recognized directly.').replace('Con una ROM original podrás elegir Regular o MoleMan.', 'Con una ROM original podrás elegir Regular, MoleMan o una de las dos ediciones de Sayans. También se reconocen las ROM ya traducidas por Sayans.')
s=s.replace('"Spanish translation",','"Spanish translation · Crackowia",').replace('"Traducción al español",','"Traducción al español · Crackowia",')
edit('const controls=new Map();',(w/'sayans.js').read_text()+'\nconst controls=new Map();')
edit('function make(tag,className)',(w/'sayans-ui.js').read_text()+'\nfunction make(tag,className)')
edit('    const matches=edits=>r16match(bytes,edits[0].offset,edits[0].installed);','''    let directRegular=false;
    if(bytes.length===0x400000){
        const id=await rawHash(bytes),source=sayansMatch(id);
        if(source)return {id,bytes,upgrade:false,sayans:{...source,bytes},profile:sayansProfile(source.edition,source.preset||'advance')};
        if(r16match(bytes,0x399000,[0xc2,0x20,0xa5,0xd0,0x0a,0x18,0x65,0xd0,0xaa,0xbf,0x00,0x60,0xf9]) || r16match(bytes,0x7fbf,[0x5c,0x00,0x90,0xf9]))throw failure('verifyFail');
        directRegular=id===sayansData.regular;
    }
    const matches=edits=>r16match(bytes,edits[0].offset,edits[0].installed);''')
edit('        const found=await identifyBeforeBook(file);\n        return found.standaloneCurrent','        const found=await identifyBeforeBook(file);\n        if(directRegular)found.sayansRegular=bytes;\n        return found.standaloneCurrent')
edit('    const enabled=options.delete(\'bestiary\');',"""    if(input.sayans){
        if([...options].some(id=>id!=='vanilla'))throw failure('badFiles');
        return buildSayans(input.sayans,settings.sayansPreset||input.sayans.preset||'advance',sources.sayans||{});
    }
    const enabled=options.delete('bestiary');""")
edit("    if(!retailInput)return;\n    resetRetailPreparation();retailEdition=['regular','moleman'].includes(el('retailEdition').value)?el('retailEdition').value:'';render();","    chooseEdition(el('retailEdition').value);")
edit("function filename(p){","function filename(p){\n    if(p.edition==='sayans')return 'FFVI_Advance_v1.6.5_Sayans_'+({esp:'Espana',sur:'Sudamerica'}[p.locale])+({advance:'',twue:'_TWUE',music:'_TWUE_Music_Config2'}[p.preset])+'.sfc';")
edit("function editionLabel(p){","function editionLabel(p){\n    if(p.edition==='sayans')return t(p.locale)+' · '+t('sayans-'+p.preset);")
edit("    const retailPending=!!retailInput&&!current;","""    el('sayansPanel').hidden=!sayansInput;el('retailApply').hidden=!!sayansInput||!!plainRegular;
    el('retailBlank').hidden=!!plainRegular;el('retailMoleChoice').hidden=!!plainRegular;
    el('retailHint').textContent=t(plainRegular?'plainEditionHint':sayansInput?'sayansBaseHint':'retailHint');
    if(sayansInput){renderSayans();return;}
    const retailPending=!!retailInput&&!current;""")
edit("el('retailPanel').hidden=!retailInput;","el('retailPanel').hidden=!retailInput&&!plainRegular;")
edit("    const file=el('rom').files[0];reading=!!file;render();if(!file)return;","    sayansInput=null;plainRegular=null;\n    const file=el('rom').files[0];reading=!!file;render();if(!file)return;")
edit("            retailInput=original;","""            retailInput=original;
            if(isSayansEdition(personal.sayans?.edition)){
                retailEdition=personal.sayans.edition;
                chooseSayans({kind:'retail',edition:retailEdition,revision:original.revision==='1.1'?1:0,bytes:original.bytes});
            }""")
edit("else{const found=await identify(file);if(token===romRevision)acceptCurrent(found);}","""else{
            const found=await identify(file);if(token!==romRevision)return;
            if(found.sayans)chooseSayans(found.sayans);
            else{
                acceptCurrent(found);
                if(found.sayansRegular){
                    plainRegular=found;retailEdition='regular';
                    if(isSayansEdition(personal.sayans?.edition)){
                        retailEdition=personal.sayans.edition;
                        chooseSayans({kind:'regular',edition:retailEdition,bytes:found.sayansRegular});
                    }
                }
            }
        }""")
edit("    if(!current||el('build').disabled)return;clearResult();","    if(el('build').disabled)return;\n    if(sayansInput){await runSayans();return;}\n    if(!current)return;clearResult();")
edit("    const payload=JSON.stringify({lang,options:[...selectedOptions()]", """    if(sayansInput){
        const cache={};
        for(const spec of [sayansData.twue,sayansData.music]){
            const value=sources.sayans?.[spec.name]||savedSayansSource(spec.name);
            if(value)cache[spec.name]=value;
        }
        const payload=JSON.stringify({lang,sayans:{edition:sayansInput.edition,preset:sayansPreset},sources:{sayans:cache}});
        return template.replace(/(<script type="application\\/json" id="personal">)[^<]*/,(_,tag)=>tag+payload);
    }
    const payload=JSON.stringify({lang,options:[...selectedOptions()]""")
Path('out/FFVI_SNES_Advance_Compatibility_Patcher.html').write_text(s)
