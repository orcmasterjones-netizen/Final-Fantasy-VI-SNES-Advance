// Verified Sayans sources and outputs share the main patcher's ROM picker.
const sayansData=JSON.parse(el('sayansData').textContent);
const sayansPresets=['advance','twue','music'];
function isSayansEdition(value){return Object.hasOwn(sayansData.editions,value);}
function sayansProfile(edition,preset){return {edition:'sayans',locale:edition,preset,options:[],add:{}};}
function sayansMatch(id){
    for(const [edition,source] of Object.entries(sayansData.editions)){
        for(const preset of sayansPresets){
            if(id===sayansData.patches[edition+'-'+preset].sha)return {kind:'output',edition,preset};
        }
        if(id===source.canonical||id===source.other)return {kind:'donor',edition,revision:id===source.canonical?0:1};
    }
    return null;
}
function sayansSourceSpecs(source,preset){
    const from=source.kind==='output'?source.preset:'advance';
    if(sayansPresets.indexOf(from)>=sayansPresets.indexOf(preset))return [];
    return [from==='advance'&&sayansData.twue,preset==='music'&&sayansData.music].filter(Boolean);
}
function sayansJoined(a,b){
    const out=new Uint8Array(a.length+b.length);
    out.set(a);out.set(b,a.length);return out;
}
async function sayansStep(source,edition,step){
    const spec=sayansData.patches[edition+'-'+step];
    const stream=new Blob([from64(spec.data)]).stream().pipeThrough(new DecompressionStream('deflate'));
    const patch=new Uint8Array(await new Response(stream).arrayBuffer());
    const output=retailBaseMerger.applyBPS(source,patch,0x400000);
    if(await rawHash(output)!==spec.sha)throw failure('verifyFail');
    return output;
}
async function readSayansSources(source,preset,file,saved){
    const specs=sayansSourceSpecs(source,preset);
    if(!specs.length)return {};
    const contents=file?await unzip(new Uint8Array(await file.arrayBuffer()),specs):{};
    for(const spec of specs){
        if(!file&&saved?.[spec.name])contents[spec.name]=from64(saved[spec.name]);
        if(!contents[spec.name]||await rawHash(contents[spec.name])!==spec.sha)throw failure('sayansNeedZip');
    }
    return contents;
}
async function buildSayans(source,preset,assets){
    const {edition,kind}=source;
    if(!isSayansEdition(edition)||!sayansPresets.includes(preset))throw failure('verifyFail');
    let bytes=source.bytes;
    let revision=source.revision;
    if(kind==='retail'||kind==='regular'){
        const entry=sayansData.editions[edition];
        const inputs=await unzip(from64(entry.archive),[entry.ips]);
        const ips=inputs[entry.ips.name];
        if(!ips||await rawHash(ips)!==entry.ips.sha)throw failure('verifyFail');
        if(kind==='regular')bytes=await sayansStep(sayansJoined(bytes,ips),edition,'regular');
        else{
            const padded=new Uint8Array(0x400200);padded.set(bytes,512);
            applyIPS(padded,ips);bytes=padded.subarray(512);
        }
    }
    if(kind==='donor'||kind==='retail')bytes=await sayansStep(bytes,edition,revision===1?'advance-r1':'advance');
    let level=kind==='output'?sayansPresets.indexOf(source.preset):0;
    const target=sayansPresets.indexOf(preset);
    if(level===2&&target<2){bytes=await sayansStep(bytes,edition,'removeMusic');level=1;}
    if(level===1&&target===0)bytes=await sayansStep(bytes,edition,'removeTwue');
    if(level===0&&target>=1)bytes=await sayansStep(sayansJoined(bytes,assets[sayansData.twue.name]),edition,'twue');
    if(level<2&&target===2)bytes=await sayansStep(sayansJoined(bytes,assets[sayansData.music.name]),edition,'music');
    const id=await rawHash(bytes);
    if(id!==sayansData.patches[edition+'-'+preset].sha)throw failure('verifyFail');
    return {bytes,id,profile:sayansProfile(edition,preset)};
}
