from pathlib import Path
import gzip,json,re,zipfile,sys
root=Path('.')
inputs=root/'inputs'
V0=(inputs/'retail0.sfc').read_bytes()
V1=(inputs/'retail1.sfc').read_bytes()
O,N=[json.load(gzip.open(root/(n+'.json.gz'),'rt')) for n in ('old','new')]
def at16(r,a):return int.from_bytes(r[a:a+2],'little')
def records(patch):
 i=5;out=[];assert patch[:i]==b'PATCH'
 while patch[i:i+3]!=b'EOF':
  a=int.from_bytes(patch[i:i+3],'big');n=int.from_bytes(patch[i+3:i+5],'big');i+=5
  if n:b=patch[i:i+n];i+=n
  else:n=int.from_bytes(patch[i:i+2],'big');b=patch[i+2:i+3]*n;i+=3
  out.append((a,b))
 return out
def full(p,ret=V0):
 r=bytearray(512)+bytearray(ret)+bytearray(0x400000-len(ret))
 for a,b in records((root/'inputs'/p).read_bytes()):r[a:a+len(b)]=b
 return bytes(r[512:])
