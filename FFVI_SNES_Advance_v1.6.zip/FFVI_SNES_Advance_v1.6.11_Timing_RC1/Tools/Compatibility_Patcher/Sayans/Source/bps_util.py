import struct,zlib
crc = lambda b: zlib.crc32(b) & 0xffffffff
def parse_bps(patch):
    assert patch[:4] == b'BPS1'
    assert crc(patch[:-4]) == struct.unpack('<I',patch[-4:])[0]
    pos = 4
    def number():
        nonlocal pos
        n,shift = 0,1
        while True:
            v=patch[pos]; pos+=1; n+=(v&127)*shift
            if v&128: return n
            shift*=128; n+=shift
    size, target_size, meta_size = number(),number(),number()
    metadata = patch[pos:pos+meta_size];pos+=meta_size
    actions=[]; written=0; cursors=[0,0]
    while pos < len(patch)-12:
        op = number(); mode=op&3; count=(op>>2)+1
        payload = None
        if mode==1:
            payload=patch[pos:pos+count];pos+=count
        elif mode>=2:
            value=number();delta=(value>>1)*(-1 if value&1 else 1)
            cursors[mode-2]+=delta;payload=cursors[mode-2];cursors[mode-2]+=count
        actions.append((written,mode,count,payload)); written+=count
    assert written==target_size and pos==len(patch)-12
    return size,target_size,metadata,actions,struct.unpack('<III',patch[-12:])

def apply_bps(source,patch):
    size,length,meta,actions,checks=parse_bps(patch)
    assert len(source)==size and crc(source)==checks[0]
    result=bytearray(length)
    for at,mode,count,payload in actions:
        if mode==0:result[at:at+count]=source[at:at+count]
        elif mode==1:result[at:at+count]=payload
        elif mode==2:result[at:at+count]=source[payload:payload+count]
        else:
            assert 0 <= payload < at
            for i in range(count): result[at+i]=result[payload+i]
    assert crc(result)==checks[1]
    return bytes(result)