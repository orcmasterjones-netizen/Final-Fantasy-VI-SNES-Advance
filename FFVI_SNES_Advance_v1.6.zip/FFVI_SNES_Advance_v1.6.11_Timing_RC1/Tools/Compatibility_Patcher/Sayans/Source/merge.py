from maptools import *
from bisect import bisect_right
import hashlib
SP=Path('inputs/spanish-native.sfc').read_bytes()
REG=Path('inputs/regular-native.sfc').read_bytes()
PROFILES={'advance':'inputs/spanish-native.sfc','twue':'inputs/twue-native.sfc','music':'inputs/config2.sfc'}
ED={'esp':'ff3esp.ips','sur':'ff3v2.ips'}
def near(p):return p.to_bytes(2,'little')
def far(p):return (p|0xc00000).to_bytes(3,'little')
def fieldstr(r,p):
 start=p
 while r[p]:
  op=r[p];p+=1+(op in (0x11,0x14,0x16))
 return r[start:p+1]
def menu_str(r,p):return r[p:r.index(0,p)+1]
def merge(ed,profile):
 base=Path(PROFILES[profile]).read_bytes();out=bytearray(base);d=full(ED[ed])
 def put(a,b):out[a:a+len(b)]=b
 def free(a,b):assert base[a:a+len(b)]==b'\xff'*len(b),(hex(a),len(b));put(a,b)
 def field_add(a,b): assert len(b) and ((a^(a+len(b)-1))&0xff0000)==0;free(a,b)
 # All original dialog IDs use their original offsets in their own three text banks.
 # The third conflicts with Advance, so give it a new home at FA:6000.
 put(0xd0000,d[0xd0000:0xef100]);field_add(0x3a6000,d[0x300000:0x307600]);put(O['DTETbl'],d[O['DTETbl']:O['DTETbl']+256])
 ptrs=[0x39a000]*4096;lo1=at16(d,0xdf80);lo2=at16(d,0xdf83)
 for i in range(3084):
  off=at16(d,0xce602+i*2);ptrs[i]=(0xd0000 if i<lo1 else 0xe0000 if i<lo2 else 0x3a6000)+off
  source=(0xd0000 if i<lo1 else 0xe0000 if i<lo2 else 0x300000)+off
  s=fieldstr(d,source);assert out[ptrs[i]:ptrs[i]+len(s)]==s,(ed,i)
 # The Advance-only messages were authored in Spanish with another accent/font map.
 # Convert them separately. They use explicit letters rather than dictionary pairs.
 punct={'esp':{0x63:0x69,0x68:0x6f,0x69:0x6d,0x6a:0x6e,0x6e:0x63,0x6f:0x70,0x70:0x72,0x71:0x60},'sur':{0x63:0x70,0x68:None,0x69:None,0x6a:0x6a,0x6e:0x69,0x6f:0x64,0x70:0x6d,0x71:0x6f}}[ed]
 # South American Sayans lacks inverted punctuation; both glyphs can occupy formerly
 # unused symbols in its field font, once their absence from its own script is checked.
 used=set()
 for i in range(3084):
  off=at16(d,0xce602+i*2);a=(0xd0000 if i<lo1 else 0xe0000 if i<lo2 else 0x300000)+off
  used.update(fieldstr(d,a))
 # Fill native font data with the chosen edition; battle icons and item symbols
 # elsewhere in the game are left in place.
 put(0x47fc0,d[0x47fc0:0x490c0]);put(0x490c0,d[0x490c0:0x49900])
 if ed=='sur':
  for key,new in zip((0x68,0x69),[k for k in range(0x73,0x7f) if k not in used][:2]):
   punct[key]=new;put(0x490c0+(new-32)*22,SP[0x490c0+(key-32)*22:][:22]);out[0x48fc0+new]=SP[0x48fc0+key]
  assert all(punct[k] for k in (0x68,0x69))
 bonus=bytearray(b'\0')
 for i in range(0xf20,0xfd0):
  tab=(0x3c0000+(i-0xf20)*2) if i<0xf4c else (0x3c0100+(i-0xf4c)*2)
  a=at16(SP,tab)
  if a==0xffff:continue
  assert 0x300<=a<0x1d00,(i,a)
  raw=fieldstr(SP,0x3c0000+a);buff=bytearray();pos=0
  while pos<len(raw):
   c=raw[pos];pos+=1
   assert c<128,(i,c)
   buff.append(punct.get(c,c))
   if c in (0x11,0x14,0x16):buff.append(raw[pos]);pos+=1
  ptrs[i]=0x39a000+len(bonus);bonus.extend(buff)
 field_add(0x39a000,bonus);free(0x396000,b''.join(far(a) for a in ptrs))
 # Keep the stock near-call ABI and its normal dialogue-enable/return sequence.
 stub=bytes.fromhex('c2 20 a5 d0 0a 18 65 d0 aa bf 00 60 f9 85 c9 7b e2 20 bf 02 60 f9 85 cb 5c df 7f c0')
 free(0x399000,stub);put(0x7fbf,b'\x5c'+far(0x399000))
 # Menu static labels use the same linked entries with preserved tile positions.
 # Restrict each write to its record, including the original terminating zero.
 addrs=sorted(set(O.values()));newadd=sorted(set(N.values()));labels=0
 for k,a in O.items():
  if not (0x30000<=a<0x40000 and 'Text' in k and k in N):continue
  n=N[k];end=addrs[bisect_right(addrs,a)];ne=newadd[bisect_right(newadd,n)]
  if end-a<3 or end-a>130 or V0[end-1]!=0 or d[end-1]!=0 or ne-n!=end-a or base[n+2:n+3]==b'\x22':continue
  if not (0x4000<=at16(V0,a)<=0x9fff):continue
  if b'\0' not in V0[a+2:end]:continue
  put(n+2,d[a+2:end]);labels+=1
 # Menu and battle fonts assign their own tile codes. Localized Advance-only
 # names and descriptions need those mappings too.
 accent=({0xc3:0xc9,0xc8:0xbe,0xc9:0xbf,0xca:0xce,0xce:0xc3,0xcf:0xd0,0xd0:0xd2,0xd1:0xc0,0xd2:0xc0} if ed=='esp' else {0xc3:0xcf,0xc8:0xbe,0xc9:0xbf,0xca:0xca,0xce:0xc9,0xcf:0xc4,0xd0:0xc8,0xd1:0xae,0xd2:0xae})
 def localized(x):return bytes(accent.get(c,c) for c in x)
 put(0x360080,localized(SP[0x360080:0x360143]))
 olddesc=SP.index(bytes.fromhex('c9 fe d0 06 a2'),0x3d000,0x40000)
 newdesc=base.index(bytes.fromhex('c9 fe d0 06 a2'),0x3d000,0x40000)
 for j in range(15):
  oldptr=0x30000+at16(SP,olddesc+10*j+5); newptr=0x30000+at16(base,newdesc+10*j+5)
  val=menu_str(SP,oldptr);avail=(0x30000+at16(base,newdesc+10*(j+1)+5)-newptr) if j<14 else len(menu_str(REG,oldptr))
  assert len(val)<=avail,(j,len(val),avail)
  put(newptr,localized(val))
 if profile!='advance':
  # TWUE 3.07 base retains vanilla charge. Reproduce the official Add-Ons
  # gauge mask at its relocated C1 address; keep the other Add-Ons separate.
  roles=['Hechicera','Aventurero','Samurái','Asesino','Maquinista','Monje','Dama rúnica','Mago azul','Pictomante','Tahúr','Moguri','Moguri','Niño salvaje','Mimo','Yeti','Sacerdote','General','Fantasma','Fantasma']+['Moguri']*11+['Esper','Moguri','Soldado imp.','Soldado imp.','Shogun','Moguri']
  chars={**{chr(65+i):128+i for i in range(26)},**{chr(97+i):154+i for i in range(26)},' ':254,'.':197,'á':accent[0xce],'ú':accent[0xd1],'ñ':accent[0xca]}
  for i,role in enumerate(roles):
   a=0x326100+13*i;assert base[a+12]==0
   put(a,bytes(chars[c] for c in role).ljust(12,b'\xff'))
  gauge=base.index(bytes.fromhex('a5 0e 29 03 d0 03 ee 82 7b'));out[gauge+3]=0
 # Replace purely textual legacy data. The variable-width fields in the menu
 # (including TWUE's extended item descriptions) have explicit redirects below.
 for a,b in [(0x478c0,0x47a40),(0x18cea0,0x18cf80),(0x11f000,0x11f9a0),(0x126f00,0x126f80),(0xf3c40,0xf3d00),(0xffc00,0xffe00),(0xffeae,0xfffbe),(0x2dfe00,0x300000-0x20000),(0x2d6400,0x2d7ca0),(0x26f567,0x270000)]:
  put(a,d[a:b])
 for k,w,count in [('StatusName',10,32),('MonsterName',10,384),('MonsterSpecialName',10,384)]:
  for i in range(count):
   a=O[k]+i*w;b=N[k]+i*w
   extra=('Den'+k) in N
   val=SP[N['Den'+k]+i*w:N['Den'+k]+(i+1)*w] if extra and i in (367,372,380) else d[a:a+w]
   put(b,localized(val) if extra and i in (367,372,380) else val)
   if extra:put(N['Den'+k]+i*w,localized(val) if i in (367,372,380) else val)
  if 'Den'+k in N:put(N['Den'+k]+384*w,localized(SP[N['Den'+k]+384*w:N['Den'+k]+452*w]))
 for i in range(256):
  a=0x12b300+i*13
  # Advance replaced just these old records. The standalone Spanish build
  # already contains their corresponding Advance names.
  val=localized(SP[a:a+13]) if REG[a:a+13]!=V1[a:a+13] else d[a:a+13]
  put(a,val)
 # Use the short Sayans labels in all menu paths plus the separate battle copies.
 for k,sym,w,count,bonuscount in [('MagicName','GetMagicNamePtr',7,54,85),('GenjuName','GetGenjuNamePtr',8,27,31)]:
  routine=N[sym];spaddr=((SP[routine+11]&63)<<16)+at16(SP,routine+6)
  rel=0x3000 if profile!='advance' else 0
  native=spaddr+rel
  put(native,d[O[k]:O[k]+w*count])
  put(native+w*count,localized(SP[spaddr+w*count:spaddr+w*bonuscount]))
  put(routine+1,near(w));put(routine+6,near(native&65535));out[routine+11]=(native>>16)|0xc0
 gaddr=0x305d08+(0x3000 if profile!='advance' else 0);assert gaddr==N['GenjuAttackName']-(0x3000 if profile=='advance' else 0)
 put(gaddr,d[O['GenjuAttackName']:O['GenjuAttackName']+270]);put(gaddr+270,localized(SP[0x305d08+270:0x305d08+310]))
 for k in ['GetLoreNamePtr','GetDanceNamePtr','GetItemDescPtr']:
  a=N[k];put(a,SP[a:a+(18 if k=='GetItemDescPtr' else 15)])
 # Repack the four menus which append new IDs, retaining the bonus records.
 def repack(data,table,num,total,room,extra=None):
  old,a=O[data],N[data];pt=N[table]
  if table=='MagicDescPtrs':pt=0x305913+(0x3000 if profile!='advance' else 0)
  ps=0x305913 if table=='MagicDescPtrs' else N[table]
  buff=bytearray();seen={};vals=[]
  for i in range(total):
   val=menu_str(d,old+at16(d,O[table]+2*i)) if i<num else menu_str(SP,N[data]+at16(SP,ps+2*i))
   if i>=num and data!='MapTitle':val=localized(val)
   if val not in seen:seen[val]=len(buff);buff.extend(val)
   vals.append(near(seen[val]))
  if len(buff)>room and data=='MagicDesc':
   copy=0x39c000;free(copy,buff);routine=N['GetMagicDescPtr'];put(routine+6,near(copy&65535));out[routine+15]=0xf9
   # Keep original spell descriptions available to secondary stock callers.
   put(a,d[old:old+room])
  else:
   assert len(buff)<=room,(data,len(buff),room);put(a,buff)
  put(pt,b''.join(vals))
  if extra:put(extra,d[O[table]:O[table]+num*2] if len(buff)>room else b''.join(vals[:num]))
 repack('MagicDesc','MagicDescPtrs',54,85,0x500,0x18cf80)
 repack('GenjuAttackDesc','GenjuAttackDescPtrs',27,31,0x300)
 repack('RareItemDesc','RareItemDescPtrs',20,22,0x350)
 # Map names share the field font and DTE tables; recode any bonus accent.
 repack('MapTitle','MapTitlePtrs',73,75,0x500)
 for i in (73,74):
  start=N['MapTitle']+at16(out,N['MapTitlePtrs']+2*i);s=menu_str(out,start)
  put(start,bytes(punct.get(c,c) for c in s))
 put(0xefba0,d[0xefba0:0xefba0+20*13])
 # Battle-dialogue tables use absolute low words within a dedicated data bank.
 battle=0x376000;field_add(battle,d[0x10d200:0x110000]);p=N['GetBattleDlgPtr'];out[p+1]=0xf7
 for i in range(256):put(0x10d000+2*i,near((battle&65535)+at16(d,0x10d000+2*i)-0xd200))
 text=0x3b9000;field_add(text,d[0xfe1e0:0xffc00]);special={224,225,226,227,228,229,230,231,240,241,242,243,244,249,250,251,252,253,254}
 # The Spanish bonus string bank can be copied wholesale; battle controls have
 # argument bytes that can themselves contain zero.
 free(0x3bb000,localized(SP[0x3b6000:0x3b62b8]))
 for i in range(256):
  p=0x3b0000+2*i
  t=(0xb000+at16(SP,p)-0x6000) if i in special else 0x9000+at16(d,0xfdfe0+2*i)-0xe1e0
  if ed=='sur' and i in (41,42):
   # In the southern edition this stock message points into enemy properties.
   # Recover the intended on-disc text from the start following message 40.
   old=at16(d,0xfdfe0+2*(i-1));following=at16(d,0xfdfe0+2*(i+1))
   assert ed=='sur' and i in (41,42)
   # The original on-disc pointer is $05E0; use the surviving text at $E5E0.
   corrected={41:0xe5e0,42:0xe5f7}[i]
   assert d[0xf0000+corrected-1]==0 and d[0xf0000+corrected:0xf0000+corrected+8]==bytes.fromhex('80 9b a2 a5 a2 9d 9a 9d')
   t=0x9000+corrected-0xe1e0
  put(p,near(t))
 out[0xffdc:0xffe0]=b'\xff\xff\x00\x00';s=sum(out)&65535;put(0xffdc,near(s^65535)+near(s))
 assert len(out)==len(base);print(ed,profile,labels,'labels',len(bonus),'bonus bytes',hashlib.sha256(out).hexdigest()[:16])
 return out
if __name__=='__main__':
 for e in ED:
  for p in PROFILES:(root/'roms'/f'{e}-{p}.sfc').write_bytes(merge(e,p))
