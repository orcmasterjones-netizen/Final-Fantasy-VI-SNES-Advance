const portraitMachine=PORTRAIT_MACHINE_RECORDS;
const portraitBanks=[
        [0x330000,0x33e000],[0x375500,0x380000],[0x3a5f00,0x3b0000],
        [0x319b00,0x320000],[0x38b100,0x390000],[0x36c400,0x370000],
        [0x30cc00,0x310000],[0x399700,0x39b000],[0x39db00,0x3a0000]
    ];
const fixedDialoguePortraits={"18":{"tiles":"////////4ODg4ODg4ODg4P///////+D/4P/g//D/+P////////+AwFBwEB8gIAAA////////QL+wz2/wP98B/////////wCCAAQABEDCEHL////////+TRzzDPvGPfKN////////AAABAQEBAUEDQ////////yP/Iv8i/kC+RL7///////8fH9/f//////////////////8nP8fH/////+jo4ODk5ODg4P/g8ODh4OTv9+D//Pv////g8O/h/uT7AAAAAAAAgIAgIAAAAEAAAID/IP8A/4B/4N8A/3y/A/8AMgISABAQEAAAAAAAAICAcs0S7RDvEO8A/wD/AP+Af09PHBw4OBASXV1PTw8vLz9QuCP1B+Mv0WKUcZUz0zPD///n5w/PHx8//////////+fnHxf3Jy/P3x8/P//////g4ODg4ODg4ODg4ODi4uDo4P/g/+D/4P/g/+D/4f/s9wAAAAAAPz19ecOXlzs/ZGcA/wP/P8BDvL9EH+gH+Fu8AADAwICAgIDA+Pj4BOyQTAD/wD+Af4B/+Af4B/wDbMsPHw8fDx83N2dXIREA8wBAF+cX5xfnK8NIlG6x32TON///////////h4eP3x8/P3////////8HB2efV6evz0ev4PDg4OPj4ODh4ebm4ODg4PDv4P/k/+j/4P/h/+///P8jZ9fXExOPjz8/BwceHT8/X7iveO3+9wjBPvj/Y/xA8HiEgPDAwMDA4OHg4PHysPG8f8A/wD/AP+Ee4B/wD3EO0FCE1AdXby8PLx//n1/f398n2ydYpnGB/w/nB2OLYY1/f3//////////////////h8e/P////////////////+Dg4ODg4ODg4OD////////4//j//P/u/+f/////////c39kfER8JDwkPP///////4/AnMM8w1zjHOP///////9i/lZ+Lz8+Phcf////////ngFpgDDHMccY4////////wAAAADIyAgICAj///////87z/gfNP+0/8T///////////9/f39/f3///////////39/v7+/v7+/f3////////8=","palette":"UVEpJVJSmXZTU+89VFRzTlVVtVZWVhljV1eec1hY/39ZWREAWlp4LVtbFm5cXB1/XV0cA15ef0tfX5l2"},"19":{"tiles":"/////////////////////////////////////////////////////////f37+/r6//////////////7////////////////8////////f3j////////4/33+/v///4D4////////vD8qPvD85Pvh/v///////yjXFv0v29/33/H///////+nHwd/H+cnH8ff////////B/8H/wf/x/8HP////////////////////////////////////////////P3/8fbi4crB1OvcclGJoPv/8vPt78Dfgf9Kt4rfVv+eAAB/c4xAP5gnYJ9IgBPs////zP///+E//h/zD/8f/+E9WpYf68gPHuIl241wBAUeMu389Dzw+Po5+PD6yPr8Bx9/b5/3Bz8//+en31+/v+cfjxcXD8cfJx+fPyd/R////////v7+/P34/fj+9fXm///+//3//P36+/j79fLv6e2pPzJsFekqdOsA/5hnGOc71oHzI/4X9yTbAP8A/4DvMMCgVgz1AvsM8pIsMEA5EC//iP+E+wb9AP9B//6vWOeXZy0GFmMXfTl2bynb1Hx/+Pz4/Pr44ZDQoBnxohAQiN/HHy/vF/9P////h7d/v4fnB88PFxdPT///h4cHB38H/OT///7///7+5P7i/v7y/OPn/f7+/v7+5eX44/zj/++gX1BvIJ8Af0A/DfGHeHt4AO8An0A/AP8A/wH+AP+I9x/oLcIZxjnGUY6AHyAfsA8M8wD/EP8g/yD/wP8A/wD/sTO+IvQstazVXacjmdr9XyzcHfwb+Nt5KthczGX1EOxHP59nR4cfB8e/h38H/5+H/z//Z/+H/wd/Z+ffx79/B+D/4f/n/O/4/vD////////x7uP87/D/4P7h////////McD8gI8BBzmDfP////////x//g/+A75ff4/////////QD7BP0C9IN8i3////////AP8A/wD/AP8A/////////xLmLslYhzmAnx////////8B+Bf3Pv1/4GDA////////5wcH/wf/h38nH/////////8Hn2cH//dv/x////////8=","palette":"UVEIIVJSLyFTU3YhVFS+IVVVPjpWVt9PV1fZSlhYO1tZWZ1rWlr/e1tbzhlcXFMeXV3YJl5efS9fX99P"},"21":{"tiles":"////////////////////////////////////////////////////8P/w9fjx+/P4////////9PD08Pbw9PD08P////////8AwD/CfLRfzzj///////8AAAAAPwA4ABAA////////3zfvJ8efZ7/HH////////wcHFwc3BxcHNwf///////////////////////////////////////////////////7//P75/fj/8v/////////+/vz9+Pv6+/T3+fL/8f/wffIYU2zhEx1kL/Tw9PD18BQQZOAWkIbgUNDdcxX++L3+Qv+BNMlTr9zDCABIAH4AwzyBfoMkQAA/AH/H/yePl751Zbtwj/Cf8283BxcHdASTAxYHFAcDB4QH////////P/+f/2//Dx8Xf/////9/f7+/X98P7y/vp/f0+vD75/X0/+X77Pri9+Xu9ff19+rr4ufk7+Xv6f/x/1H4+PXXbC1NY9sFr0N/jeyH5Avck7iy8KTw0PGg8FPw/9Av/CEYD9+4gB5O8chdR/8v/wP/ADAAfxC5kz8Qvxi83/hM2ItlR8JrpsbWmPhd4Afzh/VD+gP0CXkO50/jh4fvx/dH/yd/V38/Ly+vt1dX/y//p//X/6//1/9X/6//4/bp6PD64fPi8+Dm9fnk8On/9/3t+/z77ff7/+b/7/6N73ZVxHTt3YbvhKS4q3BRU/Cr8KvwIvhQ+RvxFPMv89dNLLtLBZPJTADIahj4Whi/EMcA/wA6f/z/lu8G/+f/l1ZSmrn9Nzoe+wgdiFo0XOmD5QvCD8UPhecn9+f34f8/zy+/Z7fvv4+fZ9dPZ1fft//X/9//V/93/7//P/+P/+Ly/fzj+fbz5v7////////t/uP95vvs/+H/////////aErozhr5HnsW2////////zfrM+9H98X3pe/////////2NWykFYiYTKps////////y//a////t/+X/////////1U8wLxA8mHCkEH////////h/2L/rPe9977z////////h0+vZzeXHz8HT///////////3/+v/yf/X/////////8=","palette":"UVGlEFJSCBlTU2wlVFTQLVVVMzZWVnZCV1fZTlhY/3tZWfYAWloSPltbdEpcXNdWXV05Y15enG9fX/97"},"22":{"tiles":"///////////////////////////////////////////////////op9iH4J/gn8Cf////////4J/Av8C/wL/Av////////x/iD/E/0jONXiH///////8C/AH+LvFzwMCA////////////f/8//19/n///////////f3+/P1+fH9/////////////////////////////////////////////////////////////+//7////////////////+/v7+8a7wjuGf8Y/IB5BnoB/IM6GfoZ+gn6CfQD9AP4B/gH+/wOUf0j/JP6Z/3rEw/48/AICAAIAAhgCJBk+AMM8I8J9P3y9P50/3T7Pj2RHGy7CPbw9vB3cHd4N7Af0C/AB+/////////////////////////////////////////////v///////////////////v7//////////////////4EWo1/UL8EtpQvzH9Yf5i6Af0M8RDtBPoJ8lGkRaSFYvPxw6ODTwLCAZQ+Hf8CEiaNHX4i/E38w/2f4j7PDf8nm7TF/ErUcDw5H9ouLrvuRBZrDTOGu8RL4/UyNdK1v+P9//3//P/8/f79/v/8//39/f39/vz+/P78/vz+/P39//////v/8/v3//f79//7//////v79/P38/fz9/P7+//+2K+Ne945BKtpm4H0IRZolJVnFOYV5B/1DvWOeA/4BfhhZAIIGaIchmVZUjQSIQITn+f6D/uv46e7Q/cL/3//kQ0NCZsey4774NU7xygEAaj3CPuX+Nf4NfAf8B/z//G//f/9//39/v/+/P1//37/ff39/f39/vz+/P1+f3x/fH//+/v39+Pny8uj//////////v/8/Pvw9+jn////////zAJCibVBqhBKm////////0E/iDdlmgL9G+T///////8wy4CwFvC/23hA/////////3v/cG+flWpAv////////8UODhX0kfogDBn////////4z/gfbJs8xxnm/////////7//v7/fP6d/H////////78/vz/fH4dnF+////////8=","palette":"UVELEVJSimBTUxgQVFT/b1VV0x1WVjsiV1ebJlhY/C5ZWV03WlrfP1tblzJcXNlCXV07U15enV9fX/9v"}};
function installDialoguePortraitArtwork(rom){
    const unpack=value=>Uint8Array.from(atob(value),c=>c.charCodeAt(0));
    for(const [id,asset] of Object.entries(fixedDialoguePortraits)){
        rom.set(unpack(asset.tiles),0x3f3400+Number(id)*800);
        rom.set(unpack(asset.palette),0x3fde00+Number(id)*60);
    }
}

function addFieldPortraits(original, cart) {
    const out = original.slice();
    const widths = original.subarray(0x48fc0, 0x490c0);
    const wideName = 6 * widths[gbaFormat.fieldGlyphs.W];
    const parameter = new Set([17,20,22]);
    const readRecord = address => {
        const pages = [[]];
        while (address < original.length) {
            const c = original[address++];
            if (c === 0) return pages;
            if (c === 19) { pages.push([]); continue; }
            const token = [c];
            if (parameter.has(c)) token.push(original[address++]);
            if(c>=128){const k=0xdfa0+2*(c-128);pages.at(-1).push([original[k]],[original[k+1]]);}else pages.at(-1).push(token);
        }
        throw Error("Unterminated field dialogue.");
    };
    function annotation(tokens) {
        const faces = [];
        let current = 0, first = null;
        const finish = () => { faces.push(first ?? current); first = null; };
        for (const t of tokens) {
            if (t === "\\page" || t === "\\wait_page") { finish(); continue; }
            if (t.startsWith("\\portrait")) { current = 1 + Number(t.slice(9)); continue; }
            if (t === "\\clear_portrait") { current = 0; continue; }
            if (!t.startsWith("\\") || t.startsWith("\\char") || t === "\\choice") {
                if (first === null) first = current;
                else if (first !== current) throw Error("Mid-line portrait change.");
            }
        }
        finish(); return faces;
    }
    function advance(token) {
        const [c,n] = token;
        if(c>=128) return advance([original[0xdfa0+2*(c-128)]])+advance([original[0xdfa1+2*(c-128)]]);
        if(c>=32) return widths[c];
        if(c>=2 && c<=15) return wideName;
        if(c===20) return n*widths[127];
        if(c===21) return 8;
        if(c===25) return 40;
        if(c===26 || c===27) return 56;
        return 0;
    }
    function fit(page,id) {
        const lines=[[]];
        for (const t of page) t[0]===1 ? lines.push([]) : lines.at(-1).push(t);
        const size = line => line.reduce((n,t)=>n+advance(t),0);
        if (lines.every(line=>size(line)<=171) && lines.length<=4) return page;
        // A choice begins on its own line, and a centered/tabbed or intentionally
        // empty line is meaningful. Preserve these boundaries when refitting prose.
        const blocks=[]; let block=[];
        function flush(){if(block.length)blocks.push(block);block=[];}
        for(const line of lines){
            if(!line.length){flush();blocks.push([]);continue;}
            if(line.some(t=>t[0]===21 || t[0]===20))flush();
            if(block.length)block.push([127]);
            block.push(...line);
        }
        flush();
        const fitted=[];
        for(let part of blocks){
            while(size(part)>171){
                let width=0,cut=-1;
                for(let i=0;i<part.length;i++){
                    if(part[i][0]===127 && i && width<=171)cut=i;
                    width+=advance(part[i]); if(width>171)break;
                }
                if(cut<1)throw Error("Unbreakable portrait line in "+id);
                fitted.push(part.slice(0,cut));part=part.slice(cut+1);
            }
            fitted.push(part);
        }
        if(fitted.length>4)throw Error("Portrait page exceeds four rows in "+id);
        return fitted.flatMap((line,i)=>i?[[1],...line]:line);
    }
    const stats={records:0,pages:0,refitted:0,faces:[],inherited:[]};
    const used=new Set();
    // Preserve the entire original script. Special-effect and borderless scenes
    // continue to use the native pointer table and its original line breaks.
    const banks=portraitBanks;
    const pointerTable=0x306000;
    for(const [lo,hi] of [[pointerTable,pointerTable+0xfd0*3],...banks]){
        if(!original.subarray(lo,hi).every(v=>v===255))throw Error("Portrait region is occupied.");
    }
    let bank=0,next=banks[0][0];
    function store(id,bytes){
        if(next+bytes.length>banks[bank][1]){bank++;if(bank===banks.length)throw Error("Portrait script capacity exceeded.");next=banks[bank][0];}
        out.set(bytes,next);out.set(gbaLong(next+0xc00000),pointerTable+3*id);next+=bytes.length;
    }
    const cases=[];
    for(let id=1;id<3084;id++)cases.push([id,id]);
    for(const [key,donor] of Object.entries(gbaFormat.bonus))cases.push([Number(key),donor]);
    for(const [id,donor] of cases){
        const p=0x3b2100+3*id;
        let addr=original[p]|original[p+1]<<8|original[p+2]<<16;
        const faces=annotation(gbaTokens(cart,"text2",donor));
        if(Object.hasOwn(gbaFormat.bonusPages,id))faces.splice(0,faces.length,faces[gbaFormat.bonusPages[id]]);
        if(!faces.some(Boolean))continue;
        if(addr===0xffffff){
            const boundary=gbaRead16(original,0xce600);
            addr=(id<boundary?0xcd0000:0xce0000)+gbaRead16(original,0xce602+2*id);
            stats.inherited.push(id);
        }
        const pages=readRecord(addr&0x3fffff);
        if(id===1318 && faces.every(f=>f===10))faces.length=pages.length;
        if(faces.some(Boolean)&&pages.length!==faces.length)throw Error("Page mismatch at "+id+": "+pages.length+" / "+faces.length);
        const bytes=[];
        for(let k=0;k<pages.length;k++){
            const f=faces[k]||0,pg=pages[k];
            if(k)bytes.push(19);
            if(f || (k && faces[k-1]))bytes.push(28,f);
            let content=pg;
            if(f){content=fit(pg,id);used.add(f-1);stats.pages++;if(pg!==content)stats.refitted++;}
            bytes.push(...content.flat());
        }
        if(faces.some(Boolean))stats.records++;
        bytes.push(0);store(id,bytes);
    }
    stats.faces=[...used].sort((a,b)=>a-b);
    for(const [addr,oldHex,newHex] of portraitMachine) {
        const decode=hex=>Uint8Array.from(hex.match(/../g),s=>parseInt(s,16));
        const before=decode(oldHex);
        if(!before.every((v,i)=>original[addr+i]===v))throw Error("Portrait renderer signature mismatch.");
        out.set(decode(newHex),addr);
    }
    const order=[0,1,2,3,8,16,17,18,19,9,4,5,6,7,10,20,21,22,23,11,13,14,15,24,12];
    for(let id=0;id<23;id++){
        if(Object.hasOwn(fixedDialoguePortraits,id))continue;
        const snesId=id<18?id:id===20?18:null;
        const native=snesId!==null, source=native?original:cart;
        const index=native?snesId:id;
        const pal=(native?0x2d5860:0x5fe55e)+32*index;
        // Reserve one ink for the current window color. When all 15 inks are
        // occupied, merge the least perceptible pair, weighted by pixel count.
        const tiles=[], counts=new Uint16Array(16);
        for (const k of order) {
            const offset=(native?0x2d1d00:0x5fe83e)+index*800+k*32;
            const pixels=[];
            for(let y=0;y<8;y++)for(let x=0;x<8;x++){
                let c=0;
                if(native){
                    for(let bit=0;bit<4;bit++)c|=((source[offset+(bit>>1)*16+y*2+(bit&1)]>>(7-x))&1)<<bit;
                }else c=source[offset+y*4+(x>>1)]>>(4*(x&1))&15;
                pixels.push(c); counts[c]++;
            }
            tiles.push(pixels);
        }
        const colors=Array.from({length:16},(_,i)=>gbaRead16(source,pal+2*i));
        let removed=15, neighbor=1, best=Infinity;
        for(let i=1;i<16;i++)for(let j=1;j<16;j++)if(i!==j){
            const error=[0,5,10].reduce((total,shift)=>total+(((colors[i]>>shift&31)-(colors[j]>>shift&31))**2),0)*counts[i];
            if(error<best){best=error;removed=i;neighbor=j;}
        }
        const remap=c=>c===15?removed:c;
        for(let c=1;c<16;c++){
            const color=c===removed?colors[15]:colors[c];
            out.set([0x50+c,0x50+c,color&255,color>>8],0x3fde00+60*id+4*(c-1));
        }
        for(let k=0;k<tiles.length;k++){
            const dest=0x3f3400+800*id+k*32;
            out.fill(0,dest,dest+32);
            tiles[k].forEach((c,p)=>{
                const ink=c===0?15:remap(c===removed?neighbor:c);
                for(let bit=0;bit<4;bit++)out[dest+(bit>>1)*16+(p>>3)*2+(bit&1)]|=(ink>>bit&1)<<(7-(p&7));
            });
        }
    }
    installDialoguePortraitArtwork(out);return {bytes:applyPortraitTiming(out),stats};
}

