// One native tile row beneath each character name is available on the main menu.
function installMainJobs(rom,cart){
    const store=gbaWriter(rom,0x3fa10,0x3fb40);
    gbaCheckFill(rom,0x3fa10,0x3fb40);
    const jobTable=0x3fa10;
    store(new Uint8Array(38));
    // BG1 tiles $220 onward are free in the field menu, above the description
    // buffers and below the first window tile at VRAM word $7800. Load them
    // only when entering the field menu. Other menu types own their own VRAM.
    const graphics=0x39c000,firstTile=0x20,tiles=new Map();
    function glyphColumns(c){
        const glyph=gbaGlyph(c,gbaFormat.battleGlyphs)[0];
        const at=0x47fc0+16*glyph;
        const columns=[];
        for(let x=7;x>=0;x--){
            let col=0;
            for(let y=0;y<16;y++)col|=((rom[at+y]>>x)&1)<<y;
            columns.push(col);
        }
        while(columns.length&&!columns[0])columns.shift();
        while(columns.length&&!columns.at(-1))columns.pop();
        return columns;
    }
    function tileNumber(cols){
        const key=cols.join(',');
        if(tiles.has(key))return tiles.get(key);
        const n=tiles.size,code=firstTile+n;
        gbaAssert(code<0x80,'Job tiles exceed the field-menu graphics space');
        const at=graphics+n*32;
        gbaCheckFill(rom,at,at+32);
        const tile=new Uint8Array(32);
        cols.forEach((column,x)=>{
            for(let y=0;y<16;y++)tile[y]|=((column>>y)&1)<<(7-x);
        });
        rom.set(tile,at);tiles.set(key,code);return code;
    }
    const titles=[];
    for(let id=0;id<18;id++){
        const name=gbaTokens(cart,'text1',0x289+id).join('');
        const columns=[];
        for(const word of name.split(' ')){
            if(columns.length)columns.push(0,0,0);
            Array.from(word).forEach((c,j)=>{
                if(j)columns.push(0);
                columns.push(...glyphColumns(c));
            });
        }
        const codes=[];
        while(columns.length%8)columns.push(0);
        for(let x=0;x<columns.length;x+=8)codes.push(tileNumber(columns.slice(x,x+8)));
        titles.push(codes);
    }
    const rowWidth=Math.max(...titles.map(t=>t.length)),blank=tileNumber(Array(8).fill(0));
    // Cover the entire previous title when the player cycles characters.
    titles.push([]);
    titles.forEach((codes,id)=>{
        const row=Array(rowWidth).fill(blank);
        row.splice(0,codes.length,...codes);
        rom.set(gbaWord(store([...row,0])),jobTable+2*id);
    });
    // Menu entry runs with rendering blanked. Use the same VRAM word transfer
    // mode as the native font loader. The original initializer follows.
    const fieldInit=0x36aef,nativeInit=gbaRead16(rom,fieldInit);
    gbaAssert(nativeInit===0x6b48,'Unexpected field-menu graphics initializer');
    const code=gbaWriter(rom,0x3fee4,0x3ff80);
    gbaCheckFill(rom,0x3fee4,0x3ff80);
    const load=code([0xa9,0x80,0x8d,0x15,0x21,
        0xa0,0x00,0x72,0x8c,0x16,0x21,
        0xa0,0x01,0x18,0x8c,0x00,0x43,
        0xa0,...gbaWord(graphics),0x8c,0x02,0x43,0xa9,0xf9,0x8d,0x04,0x43,
        0xa0,...gbaWord(32*tiles.size),0x8c,0x05,0x43,
        0xa9,0x01,0x8d,0x0b,0x42,0x4c,...gbaWord(nativeInit)]);
    rom.set(gbaWord(load),fieldInit);
    // Y is the name's tilemap location. The stock subroutine draws the name.
    // Put the job one row below it, keeping the status-icon and numeric rows intact.
    const at=code([
        0x5a,0x20,0xd0,0x34,0x7a,0xc2,0x20,0x98,0x18,0x69,0x40,0x00,0xa8,0xe2,0x20,
        0x20,0x1a,0x35,0xb9,0x00,0x00,0xc9,0x12,0x90,0x02,0xa9,0x12,0x0a,0xaa,0xc2,0x20,
        0xbf,...gbaLong(0xc00000+jobTable),0xaa,0xe2,0x20,0xbf,0,0,0xc3,0xf0,0x06,
        0x8d,0x80,0x21,0xe8,0x80,0xf4,0x9c,0x80,0x21,
        0xa5,0x29,0x48,0x09,0x02,0x85,0x29,0x20,0x35,0x80,0x68,0x85,0x29,0x60
    ]);
    gbaAssert(rom[0x360b1]===0x20 && gbaRead16(rom,0x360b2)===0x34e6,'Status job entry point');
    rom.set(gbaWord(0x39cf),0x360af);rom.set(gbaWord(at+15),0x360b2);
    for(const hook of [0x33322,0x3336e,0x333ba,0x33406]){
        gbaAssert(rom[hook]===0x20&&gbaRead16(rom,hook+1)===0x34d0,'Unexpected main-menu name call');
        rom.set(gbaWord(at),hook+1);
    }
}
const encounterDonors={224:0xef3,225:0xef4,226:0xef5,227:0xef6,228:0xef7,229:0xef8,230:0xef9,231:0xefa,240:0xefb,241:0xefc,242:0xefd,243:0xf00,244:0xf03,249:0xefe,250:0xeff,251:0xf01,252:0xf02,253:0xf04,254:0xef2};

function nativeCode(rom,at,build){
    const output=[],labels={},branches=[];
    const emit=(...bytes)=>output.push(...bytes);
    const mark=label=>{labels[label]=output.length;};
    const branch=(op,label)=>{emit(op,0);branches.push([output.length-1,label]);};
    build(emit,mark,branch);
    for(const [operand,label] of branches){
        const delta=labels[label]-operand-1;
        gbaAssert(Number.isInteger(delta)&&delta>=-128&&delta<=127,'Invalid menu branch '+label);
        output[operand]=delta&255;
    }
    gbaCheckFill(rom,at,at+output.length);rom.set(output,at);return at+0xc00000;
}
function gbaPositionedName(cart,key,id){
    if(key==='SHOP_OPTIONS_TEXT')return [0xe8,0xe9,0xea].map(i=>gbaTokens(cart,'text1',i).join('')).join('  ');
    const name=gbaTokens(cart,'text1',id).join('');
    if(key==='GAME_LOAD_MSG_1')return name.slice(0,name.lastIndexOf(' '));
    if(key==='GAME_LOAD_MSG_2')return name.slice(name.lastIndexOf(' ')+1);
    return name;
}
function fixGbaMenuLayout(rom){
    // Window positions use two bytes per tile. The right edges stay fixed.
    const setLayout=(at,expected,replacement)=>{
        gbaAssert(expected.every((v,i)=>rom[at+i]===v),'Unexpected menu geometry at '+at.toString(16));
        rom.set(replacement,at);
    };
    // Widen the inventory title by one cell and give Use and Sort room for their cursors.
    setLayout(0x37e74,[4,2,0x97,0x58,22],[5,2,0x99,0x58,21]);
    setLayout(0x37dfc,[64,22,104,22],[72,22,120,22]);
    setLayout(0x38d7b,[0x1d,0x79],[0x1f,0x79]);
    setLayout(0x38d81,[0x27,0x79],[0x2b,0x79]);
    // The second line of a description ends at y=42. Place the shared Skills
    // caption below the MP stat and above the list. Leave the scroll arrow at x=232 clear.
    setLayout(0x34db5,[0x75,0x61,7,1],[0x27,0x63,11,1]);
    const skillCaption=(x)=>gbaWord(0x81b7+(12-5)*64+(x-23)*2);
    for(const at of [0x35ce6,0x35cf0,0x35cf7,0x35cfe,0x35d06,0x35d0f,0x35d17]){
        setLayout(at,[0xb7,0x81],skillCaption(at===0x35ce6?16:17));
    }
    // The native two-digit writer has its own tilemap address. Reserve both cells.
    setLayout(0x3522b,[0xa9,0xbf,0x81],[0xa9,...skillCaption(24)]);
}
function installMenuLabels(rom,cart,lists){
    fixGbaMenuLayout(rom);
    const store=gbaWriter(rom,0x399400,0x39ae00);
    const redirects=[],applied=[],retained=[];
    for(const [label,source,original,id,cells] of gbaFormat.positionedLabels){
        if(label==='MAIN_MENU_ORDER')rom.set(gbaWord(gbaRead16(rom,source)-2),source);
        const name=label==='MAIN_MENU_SKILLS'?'Skills':gbaPositionedName(cart,label,id);
        const codes=lists.encode(name,cells);
        if(!codes){retained.push(label);continue;}
        if(codes.length<=original){
            rom.fill(0,source+2,source+3+original);rom.set(codes,source+2);
        }else{
            redirects.push([source,store([rom[source],rom[source+1],...codes,0])]);
        }
        applied.push(label);
    }
    const directory=0x399000,bins=Array.from({length:256},()=>[]);
    gbaCheckFill(rom,directory,directory+512);
    for(const [source,dest] of redirects)bins[source&255].push([source,dest]);
    for(let i=0;i<256;i++){
        const bin=bins[i];
        if(bin.length)rom.set(gbaWord(store([...bin.flatMap(([a,b])=>[...gbaWord(a),...gbaWord(b)]),0,0])),directory+i*2);
    }
    const code=nativeCode(rom,0x399200,(e,m,b)=>{
      e(0xa5,0xe9,0xc9,0xc3);b(0xd0,'resume');e(0xc2,0x20,0xa5,0xe7,0x29,0xff,0x00,0x0a,0xaa,0xbf,...gbaLong(directory+0xc00000),0xc9,0xff,0xff);b(0xf0,'native');
      e(0xaa);m('next');e(0xbf,0,0,0xf9);b(0xf0,'native');e(0xc5,0xe7);b(0xf0,'found');e(0xe8,0xe8,0xe8,0xe8);b(0x80,'next');
      m('found');e(0xbf,2,0,0xf9,0x85,0xe7,0xe2,0x20,0xa9,0xf9);b(0x80,'draw');
      m('native');e(0xe2,0x20,0xa9,0xc3);m('draw');e(0x85,0xe9);m('resume');e(0xa6,0x00,0x9b,0xc2,0x20,0x5c,0x05,0x03,0xc3);
    });
    gbaAssert(rom[0x302fa]===0x84&&rom[0x302fb]===0xe7,'Positioned label entry point');
    rom.set([0x5c,...gbaLong(code),0xea],0x30300);
    return {applied,retained};
}

// The original build packed pairs of letters into these two narrow stat captions.
// Change only their display records, retaining the font dictionary and all other names.
function shortenGbaMagicStats(rom){
    const defense='M. Def.', evasion='M. Eva.';
    const captions=[
        // Item and Equip captions occupy seven cells in the native menu text table.
        [0x38dfd,evasion,[0x67,0x69,0x68,0x66,0x25,0xa2,0x12]],
        [0x38e47,defense,[0x67,0x69,0x68,0x83,0x49,0x2b,0x32]],
        [0x3a429,evasion,[0x67,0x69,0x68,0x66,0x25,0xa2,0x12]],
        [0x3a473,defense,[0x67,0x69,0x68,0x83,0x49,0x2b,0x32]],
        // Status uses two nine-cell records relocated by installMenuLabels.
        [0x39949e,evasion,[0x8c,0x9a,0x69,0x68,0x84,0xaf,0x25,0xa2,0x12]],
        [0x3994aa,defense,[0x8c,0x9a,0x69,0x68,0x83,0x49,0x9e,0xa7,0x32]]
    ];
    for(const [offset,label,expected] of captions){
        gbaAssert(expected.every((v,i)=>rom[offset+i]===v)&&rom[offset+expected.length]===0,
            'Unexpected magic stat caption at '+offset.toString(16));
        const tiles=Array.from(label,c=>c===' '?0xfe:gbaGlyph(c,gbaFormat.battleGlyphs)[0]);
        // Blanks clear the full previous label when changing characters or equipment.
        rom.set(tiles,offset);rom.fill(0xfe,offset+tiles.length,offset+expected.length);
    }
}
