// TWUE's native fixed-width records and menu drawing code. The dialogue-width
// table and large glyphs begin at $C48FC0, immediately after the small font.
function twueMenus(rom,cart,ref){
    const fitRows=[],refs=[],fontStart=0x47fc0;
    rom.set(ref.subarray(fontStart,0x48fc0),fontStart);
    const copy=(start,end)=>rom.set(ref.subarray(start,end),start);
    // Keep SNES Advance's inventory, command dispatch and field engine. Only
    // transplant TWUE's list widths, menu tile positions and class display.
    for(const [a,b] of [
        [0x15fc7,0x16032],[0x164f6,0x16699],[0x16a3b,0x16a6e],[0x16a9b,0x16aaf],
        [0x18222,0x1822c],[0x2bb24,0x2bb40],[0x2bb70,0x2bb8c],
        [0x33308,0x33309],[0x33354,0x33355],[0x333a0,0x333a1],[0x333ec,0x333ed],
        [0x33498,0x3350b],[0x3371c,0x33723],[0x34e89,0x34e91],
        [0x34ef5,0x34ef7],[0x34fc9,0x34fd4],[0x3503b,0x3503c],
        [0x35066,0x35067],[0x35263,0x35265],[0x352c6,0x352d1],
        [0x352f5,0x352f6],[0x35320,0x35321],[0x35348,0x3534a],[0x35388,0x35393],
        [0x353fb,0x353fd],[0x354c0,0x354c2],[0x3555a,0x35565],[0x35599,0x355a0],
        [0x355bd,0x355be],[0x3563e,0x35640],[0x357de,0x357e0],[0x35821,0x3582c],
        [0x35850,0x35851],[0x358a4,0x358a5],[0x359f0,0x359f1],[0x35a14,0x35a27],
        [0x35b59,0x35b6b],[0x35d49,0x35d55],[0x35fb0,0x35fb2],[0x360b5,0x360b6],
        [0x3a33c,0x3a33d],[0x3a39c,0x3a3dc],[0x3fb00,0x3fb41],[0x3ff00,0x3ff0a],[0x3ff20,0x3ff32],[0x3ff90,0x3ffab]
    ])copy(a,b);
    // GBA descriptions draw two lines. TWUE's single-line banner would draw
    // its lower border through line two. Keep the two-line banner and put
    // the native caption below the portrait, as in GBA Presentation v1.6.8.
    rom.set([0x27,0x63,11,1],0x34db5);
    const caption=(x)=>0x81b7+7*64+(x-23)*2;
    // MP Cost spans columns 16–22. Column 23 separates it from the two digits.
    rom.set(gbaWord(caption(16)),0x35ce6);
    for(const at of [0x3fb00,0x3fb0c,0x3fb18,0x3fb22,0x3fb2d,0x3fb38])
        rom.set(gbaWord(caption(17)),at);
    rom.set(gbaWord(caption(24)),0x3522c);
    // A twelve-cell Esper name begins after the portrait. Align the three
    // stat labels just beyond its right edge on the two-line panel.
    gbaAssert(gbaRead16(rom,0x34f0e)===0x421d,'Skills Esper position');
    rom.set(gbaWord(0x4217),0x34f0e);
    for(const addr of [0x35d21,0x35d26,0x35d2b])rom.set(gbaWord(gbaRead16(rom,addr)+2),addr);
    const storage=gbaWriter(rom,0x395800,0x399000);
    gbaCheckFill(rom,0x395800,0x399000);
    function reserve(n){return storage(new Uint8Array(n).fill(255));}
    const ligatures=new Map([['lti',[0x78,0x79]],['ing',[0x7a,0x7b]],['igh',[0x7c,0x7d]],
        ['il',[0xd0]],['it',[0xd1]],['ll',[0xd2]],['li',[0xeb]],['ti',[0xec]]]);
    const singles=Object.fromEntries(Object.entries(gbaFormat.battleGlyphs).filter(([c])=>c.length===1));
    const inverse=Object.fromEntries(Object.entries(singles).map(([c,v])=>[v,c]));
    function decode(text){
        let s='';
        for(let i=0;i<text.length;i++){
            const v=text[i];if(!v)break;
            if(v===0xff||v===0xfe){s+=' ';continue;}
            const pair=[...ligatures].find(([,arr])=>arr.every((c,j)=>text[i+j]===c));
            if(pair){s+=pair[0];i+=pair[1].length-1;}
            else s+=inverse[v]??('['+v.toString(16)+']');
        }
        return s.trimEnd();
    }
    function encode(name,width){
        const spell=c=>c===' '?0xfe:singles[c==="'"?'’':c];
        const raw=Array.from(name,spell);
        if(raw.length<=width&&raw.every(x=>x!==undefined))return raw;
        // Only the letter combinations actually drawn by TWUE are available.
        // Use as few of them as necessary. Never squeeze an arbitrary pair.
        const options=Array.from({length:name.length+1},()=>new Map());options[0].set(0,[]);
        for(let i=0;i<name.length;i++)for(const [len,bytes] of options[i]){
            for(const [token,code] of [[name[i],[spell(name[i])]],...ligatures]){
                const n=len+code.length;
                if(n<=width&&code[0]!==undefined&&name.startsWith(token,i)&&!options[i+token.length].has(n))
                    options[i+token.length].set(n,bytes.concat(code));
            }
        }
        const final=options.at(-1);return final.size?final.get(Math.max(...final.keys())):null;
    }
    const col=(table,id)=>gbaTokens(cart,table,id).filter(t=>!t.startsWith('\\')).join('');
    const extra=[270,265,261,260,262,257,256,268,258,259,264,266,263,267,269];
    const enemies=[385,392,411,412,391,394,395,408,409,384,390,402,388,389,403,398,399,401,400,407,410,413,397,386,404,405,406,415,419,420,421,422,387,393,396,414];
    const enemyId=i=>i<382?0x40f+({367:416,372:417,380:418}[i]??i):i>=416?0x40f+enemies[i-416]:null;
    function group(key,source,count,width,icon,donor,table='text1',dest=reserve(count*width)){
        rom.set(ref.subarray(source,source+count*width),dest);refs.push({key,dest,count,width,icon});
        for(let i=0;i<count;i++){
            const id=donor(i);if(id==null)continue;
            let name=col(table,id);if(key==='Summon attacks'&&i>=27)name=name.split(':')[0];if(!name)continue;
            const at=dest+i*width+icon,cap=width-icon;
            const original=Array.from(rom.subarray(at,at+cap)),twue=decode(original);
            // The equipped Esper shares a row with LV. Use a TWUE letter pair
            // when a full-width name would leave no separating tile.
            const narrow=key==='Espers'&&name.length>=cap?encode(name,cap-1):null;
            const bytes=narrow||encode(name,cap),selected=bytes?name:twue;
            gbaAssert(selected&&!selected.includes('['),'Missing TWUE fallback for '+key+' '+i+' '+name+' '+twue);
            if(bytes){rom.fill(255,at,at+cap);rom.set(bytes,at);}
            else if(key==='Rare items'&&i===21){
                // This GBA-only key item has no original TWUE name. Keep
                // every letter of Crown by dropping the inter-word space.
                const compact=name.replace(' ','');const tiles=encode(compact,cap);
                gbaAssert(tiles,'Crown name capacity');rom.set(tiles,at);
                fitRows.push({group:key,id:i,gba:name,display:compact,twue:'',cells:cap,fit:'Bonus abbreviation'});continue;
            }
            fitRows.push({group:key,id:i,gba:name,display:selected,twue,cells:cap,fit:bytes?'GBA':'TWUE'});
        }
        return dest;
    }
    const items=group('Items',0x12b300,255,13,1,i=>0x17a+i,'text1',0x12b300);
    group('Bonus items',0x360080,15,13,1,i=>0x17a+extra[i],'text1',0x360080);
    const spells=group('Magic',0x3c8000,85,9,1,i=>i<54?0x29b+i:({82:0xa58,83:0xa5a,84:0xa59}[i]));
    const espers=group('Espers',0x3c8400,31,12,0,i=>i<27?0x2d1+i:0xa5b+i-27);
    const attacks=group('Battle abilities',0x32035e,175,16,0,i=>0x143e+i,'text2');
    const dances=group('Dance',0x320ffe,8,13,0,i=>0x3b6+i);
    const bushido=group('Bushido',0x321067,8,13,0,i=>0xa76+i);
    const summon=group('Summon attacks',0x3c8600,31,16,0,i=>i<27?0x39b+i:0xa62+i-27);
    const magitek=group('Magitek commands',0x26f9ad,8,13,0,i=>0x143e+50+i,'text2');
    group('Enemies',0x384bec,452,10,0,enemyId,'text1',0x384bec);
    group('Monster specials',0x385d94,452,10,0,i=>{const id=enemyId(i);return id==null?null:0xcbe+id-0x40f;},'text2',0x385d94);
    group('Condition names',0x2ade1,32,10,0,i=>0x784+i,'text1',0x2ade1);
    group('Rare items',0x34e13c,22,13,0,i=>i<2?0x5b6+i:i<=5?0x5b8:i===20?0x3c2:i===21?0x5c8:0x5b3+i,'text1',0x34e13c);
    group('Commands',0x18cea0,30,7,0,i=>0x15a+i,'text1',0x18cea0);
    // The game also reads shorter secondary copies for particular message types.
    // Preserve their native strides. The longer tables above are used by the lists.
    const selectRow=(key,id)=>fitRows.find(e=>e.group===key&&e.id===id);
    function mirror(key,count,base,width,icon,reference=base){
        for(let i=0;i<count;i++){
            const row=selectRow(key,i);if(!row)continue;
            const at=base+i*width+icon,cap=width-icon,bytes=encode(row.display,cap);
            if(bytes){rom.fill(255,at,at+cap);rom.set(bytes,at);}
            else if(key==='Rare items'&&i===21){
                // This GBA-only key item has no original TWUE name. Keep
                // every letter of Crown by dropping the inter-word space.
                const compact=name.replace(' ','');const tiles=encode(compact,cap);
                gbaAssert(tiles,'Crown name capacity');rom.set(tiles,at);
                fitRows.push({group:key,id:i,gba:name,display:compact,twue:'',cells:cap,fit:'Bonus abbreviation'});continue;
            }
            else if(reference!=null)rom.set(ref.subarray(reference+i*width+icon,reference+(i+1)*width),at);
        }
    }
    mirror('Monster specials',382,0xfd0d0,10,0,0x385d94);
    mirror('Enemies',382,0xfc050,10,0,0x384bec);
    mirror('Espers',31,0x305c10,8,0,0x26f6e1);mirror('Espers',27,0x26f6e1,8,0);
    mirror('Magic',54,0x26f567,7,1);mirror('Magic',54,0x3059bd,7,1,0x26f567);
    // The menu uses two different writers for Esper names in battle, including a
    // secondary message writer which originally kept the old eight-cell width.
    rom[0x16a7c]=12; // immediate LDA #record size at C1:6A7B
    for(const [at,dest] of [[0x15fdb,attacks],[0x16005,espers],[0x1602f,spells+1],[0x16508,magitek],
        [0x165bd,attacks],[0x165d9,espers],[0x165f1,spells],[0x16619,dances],[0x1666e,attacks+58*16],
        [0x16696,espers],[0x16a6b,attacks],[0x16a8d,espers],[0x16aac,spells],[0x334f9,espers],
        [0x35a24,espers],[0x2bb30,bushido],[0x2bb7b,summon]]){
        gbaAssert(rom[at-1]===0xbf,'Missing native name lookup at '+at.toString(16));
        rom.set(gbaLong(0xc00000+dest),at);
    }
    for(const [at,dest] of [[0x34fc8,spells],[0x352c5,attacks+58*16],[0x35387,bushido],[0x35559,espers],[0x35820,dances]]){
        gbaAssert(rom[at]===0xa0&&rom[at+5]===0xa0&&rom[at+10]===0xa9,'Missing fixed text table '+at.toString(16));
        rom.set(gbaWord(dest),at+6);rom[at+11]=0xf9;
    }
    // TWUE's class renderer already clears sixteen cells. Use the GBA titles
    // for its first 18 character records and TWUE's titles for later guests.
    const classPtr=reserve(512),blank=storage([0]);for(let i=0;i<256;i++)rom.set(gbaWord(blank),classPtr+2*i);
    for(let i=0;i<0x29;i++){
        const src=0x320000+gbaRead16(ref,0x326300+2*i);
        let bytes=Array.from(ref.subarray(src,src+16));const end=bytes.indexOf(0);if(end>=0)bytes=bytes.slice(0,end);
        if(i<18)bytes=encode(col('text1',0x289+i),16);
        const at=storage([...bytes,0]);rom.set(gbaWord(at),classPtr+2*i);
    }
    const jobCode=storage(ref.slice(0x323400,0x323436));
    rom.set(gbaLong(classPtr+0xc00000),jobCode+11);rom[jobCode+26]=0xf9;
    const posCode=storage(ref.slice(0x32c200,0x32c21f));
    rom.set(gbaLong(posCode+0xc00000),0x33499);
    rom.set(gbaLong(jobCode+0xc00000),0x3ff04);
    // Retain GBA wording that fits TWUE's existing positioned records. Use
    // TWUE's own labels for an entire prompt when it spans multiple records.
    for(let [label,addr,cap,id] of gbaFormat.positionedLabels){
        const wanted=gbaPositionedName(cart,label,id);
        if(label==='EQUIP_OPTION_EMPTY'){addr++;} // TWUE gives Remove its sixth cell.
        const end=ref.indexOf(0,addr+2),length=end-addr-2;
        if(length<0||length>cap+2)continue;
        const fallback=decode(ref.subarray(addr+2,end));
        const keepTWUE=label==='MAIN_MENU_RELIC'||/^GAME_(LOAD|SAVE)_MSG/.test(label);
        const bytes=keepTWUE?null:encode(wanted,Math.min(cap,length));
        const shown=bytes?wanted:fallback;
        if(bytes){rom.fill(0xff,addr+2,end);rom.set(bytes,addr+2);}
        else rom.set(ref.subarray(addr+2,end),addr+2);
        fitRows.push({group:'Menu labels',id:label,gba:wanted,display:shown,twue:fallback,cells:length,fit:bytes?'GBA':'TWUE'});
    }
    // Field text uses a different encoding from the fixed menu font. A hand-
    // drawn TWUE ligature must expand to its letters in a reward message.
    function insertTable(groupName,icon,width){
        const n=256,rows=fitRows.filter(r=>r.group===groupName),dest=0x39c000+(groupName==='Magic'?0x1800:0);
        gbaAssert(n*width<=0x1800,'Field insert table size');
        gbaCheckFill(rom,dest,dest+n*width); // $FF marks the end of a name.
        for(const row of rows){
            const bytes=Array.from(row.display).flatMap(c=>c===' '?[0xdf]:gbaGlyph(c,gbaFormat.fieldGlyphs).map(x=>x+0x60));
            gbaAssert(bytes.length<=width&&bytes.every(c=>c<255),'Unexpected field name '+row.display);
            rom.set(bytes,dest+row.id*width);
        }
        return dest;
    }
    const itemInsert=insertTable('Items',0,20),spellInsert=insertTable('Magic',0,9);
    function operand(at,old,value){gbaAssert(rom[at]===old,'Unexpected field insert operand '+at.toString(16));rom[at]=value;}
    for(const [p,old,value] of [[0x811f,13,20],[0x8128,12,20],[0x83de,13,20],[0x83ff,12,20],[0x841a,4,9],[0x843b,4,9]])operand(p,old,value);
    for(const [at,source] of [[0x8130,itemInsert],[0x83ef,itemInsert],[0x842b,spellInsert]])rom.set(gbaLong(source+0xc00000),at);
    return {fitRows,refs};
}
