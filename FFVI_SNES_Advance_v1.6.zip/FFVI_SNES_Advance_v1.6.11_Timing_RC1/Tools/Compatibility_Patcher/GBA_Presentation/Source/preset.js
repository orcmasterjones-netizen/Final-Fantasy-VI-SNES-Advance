// English handheld script conversion for the Regular ROM. All prose comes from the input cartridge.
const gbaFormat = GBA_FORMAT;
const gbaPreviewName = 'FFVI_SNES_Advance_v1.6.9_GBA_Presentation';
const gbaAssert = (test, message) => { if (!test) throw Error(message); };
const gbaRead16 = (data, i) => data[i] | data[i + 1] << 8;
const gbaWord = n => [n & 255, (n >>> 8) & 255];
const gbaLong = n => [...gbaWord(n), n >>> 16 & 255];
function gbaTokens(cart, table, id) {
    const base = table === 'text2' ? 0x174454 : 0x1654f8;
    const at = base + 16 + 4 * id;
    let pos = base + new DataView(cart.buffer,cart.byteOffset+at,4).getUint32(0,true);
    const words = gbaFormat.donor[table], out = [];
    for (let i = 0; i < 4096; i++) {
        let b = cart[pos++], v = words[b];
        if (b >= 128 && words[b*256+cart[pos]] !== undefined) v = words[b*256+cart[pos++]];
        gbaAssert(v !== undefined,'Unknown cartridge text symbol in '+table+' '+id);
        if (v === '\\0') return out;
        if (v.endsWith('[')) v = v.slice(0,-1)+':'+cart[pos++].toString(16).toUpperCase().padStart(2,'0');
        out.push(v);
    }
    throw Error('Unterminated cartridge record '+id);
}
function gbaGlyph(token, map) {
    const sub = {"'":'’','"':'”','—':'--','–':'--'};
    return Array.from(sub[token] || token, c => {
        const code = map[c];
        gbaAssert(code !== undefined,'Unmapped display glyph '+c);
        return code;
    });
}
function gbaField(tokens, timings, widths,adjustments,id) {
    const chars=gbaFormat.fieldGlyphs, at=new Map();
    for(const [index,bytes] of timings || []) at.set(index,[...(at.get(index)||[]),{bytes,width:0}]);
    const result=[]; let line=[], center=false, afterPage=false;
    function flush() {
        const lineWidth=parts=>parts.reduce((n,x)=>n+x.width,0);
        const emit=parts=>{
            const w=lineWidth(parts), spaces=center?Math.max(0,Math.floor((219-w)/(2*widths[127]))):0;
            if(spaces)result.push(20,spaces);
            for(const p of parts)result.push(...p.bytes);
        };
        while(lineWidth(line)>219) {
            let sum=0,cut=-1;
            for(let i=0;i<line.length;i++){sum+=line[i].width;if(sum>219)break;if(line[i].space&&i)cut=i;}
            gbaAssert(cut>0,'Field line cannot wrap safely at ID '+id);
            emit(line.slice(0,cut));result.push(1);line=line.slice(cut+1);adjustments.add(id);
        }
        emit(line);line=[];center=false;
    }
    function graphic(code) {line.push({bytes:[code],width:widths[code],space:code===127});}
    for(let i=0;i<=tokens.length;i++){
        if(at.has(i))line.push(...at.get(i));
        if(i===tokens.length)break;
        const t=tokens[i];
        if(t==='\\n'){
            // If an uncentered cartridge line overflows, carry the last words into the
            // following line instead of leaving those words stranded on their own.
            if(!afterPage&&!center&&line.reduce((sum,p)=>sum+p.width,0)>219){graphic(127);adjustments.add(id);}
            else if(!afterPage){flush();result.push(1);}
            afterPage=false;continue;
        }
        if(t==='\\page'||t==='\\wait_page'){flush();result.push(19);afterPage=true;continue;}
        if(t==='\\center'){center=true;continue;}
        if(t==='\\xC9:A0'){graphic(chars['♬']);afterPage=false;continue;}
        if(t.startsWith('\\char')){
            const who=Number(t.slice(5));
            line.push({bytes:[2+who],width:6*widths[chars.W]});afterPage=false;continue;
        }
        if(['\\choice','\\gil','\\item','\\spell'].includes(t)){
            const code={'\\choice':21,'\\gil':25,'\\item':26,'\\spell':27}[t];
            line.push({bytes:[code],width:code===21?8:code===25?40:56});afterPage=false;continue;
        }
        if(t.startsWith('\\')){
            gbaAssert(/^\\(?:portrait\d+|clear_portrait|4line|key|wait_key|wait_C[56]:[0-9A-F]{2}|xC4:B[567]|xC583|xC9:83)$/.test(t),'Unsupported field control '+t+' (ID '+id+')');
            continue;
        }
        if(t==='.' && tokens[i+1]==='.' && tokens[i+2]==='.' && !at.has(i+1) && !at.has(i+2)){graphic(chars['…']);i+=2;}
        else for(const code of gbaGlyph(t,chars))graphic(code);
        afterPage=false;
    }
    flush();result.push(0);return result;
}
function gbaBattle(tokens,kind,id) {
    const map=gbaFormat.battleGlyphs, out=[];
    const symbols={'*':0xcf,'♬':0xd1};
    for(let i=0;i<tokens.length;i++){
        const t=tokens[i];
        if(t.startsWith('\\char')){out.push(2,Number(t.slice(5)));continue;}
        if(t.startsWith('\\xC9:')){
            const arrows={'85':'','86':'up','87':'right','88':'down','89':'left'};
            const direction=arrows[t.slice(-2)];
            gbaAssert(direction!==undefined,'Unexpected battle button');
            for(const c of direction)out.push(map[c]);
            continue;
        }
        if(t==='\\key'||t==='\\wait_page')continue;
        if(t==='\\wait_key'){out.push(7);continue;}
        if(t==='\\n'){out.push(1);continue;}
        if(t==='\\xC4:B6'){out.push(5);continue;}
        if(kind==='attack'&&t.startsWith('\\wait_C5:')){
            const v=parseInt(t.slice(-2),16);
            if(v===0x96){const arg=tokens[++i];gbaAssert(/^\\wait_C5:8[456]$/.test(arg),'Unknown string substitution');out.push(18,parseInt(arg.slice(-2),16)-0x84);}
            else if(v===0x94||v===0x95)out.push(v-0x84);
            else if(v===0x8b)out.push(7);
            else throw Error('Unknown attack substitution '+v);
            continue;
        }
        if(t.startsWith('\\'))throw Error('Unmapped battle control '+t+' (ID '+id+')');
        if(t==='.'&&tokens[i+1]==='.'&&tokens[i+2]==='.'){out.push(map['…']);i+=2;continue;}
        if(symbols[t]!==undefined)out.push(symbols[t]);else out.push(...gbaGlyph(t,map));
    }
    out.push(0);return out;
}
function gbaWrapBattle(bytes,widths,kind,id,changes){
    const output=[],maxWidth=224;
    let row=[];
    function emit(){
        while(row.reduce((v,p)=>v+p.width,0)>maxWidth){
            let width=0,space=-1,end=0;
            for(let i=0;i<row.length;i++){width+=row[i].width;if(width>maxWidth)break;end=i+1;if(row[i].space&&i)space=i;}
            const cut=space>0?space:end;
            gbaAssert(cut>0,'Battle substitution exceeds width');
            output.push(...row.slice(0,cut).flatMap(p=>p.bytes),1);
            row=row.slice(cut+(space>0?1:0));(changes[kind]||=new Set()).add(id);
        }
        output.push(...row.flatMap(p=>p.bytes));row=[];
    }
    for(let i=0;i<bytes.length;i++){
        const c=bytes[i];
        if(c===0||c===1){emit();output.push(c);continue;}
        if(c===2||c===18){row.push({bytes:[c,bytes[++i]],width:c===2?6*widths[54]:72});continue;}
        const width=c>=128?widths[c-96]:c===16||c===17?36:0;
        row.push({bytes:[c],width,space:c===255});
    }
    return output;
}
function gbaWriter(rom,min,max) {
    let next=min;
    return bytes=>{
        if((next&65535)+bytes.length>65536)next=(next+65535)&~65535;
        gbaAssert(next+bytes.length<=max,'Text capacity exceeded');
        const offset=next;rom.set(bytes,offset);next+=bytes.length;return offset;
    };
}
function gbaCheckFill(b,lo,hi){
    gbaAssert(b.subarray(lo,hi).every(v=>v===255),'Occupied cartridge range '+lo.toString(16));
}
async function gbaPresentation(regular,cart,dash=true,advanceRules=true,menuReference=null){
    gbaAssert(await hash(regular)===gbaFormat.base,'Expected the verified plain SNES Advance Regular base');
    gbaAssert(await hash(cart)===gbaFormat.cart,'Choose Final Fantasy VI Advance (USA), unmodified English cartridge.');
    const font=from64(gbaFormat.advanceFont);
    gbaAssert(font.length===0x1d00 && await hash(font)===gbaFormat.advanceFontSHA,'Advance font validation failed.');
    const source=dash?(await combine(await identify(new File([regular],'regular.sfc')),new Set(['dash']),{},{})).bytes:regular;
    const rom=source.slice();
    if(!advanceRules)for(const [offset,value] of gbaFormat.snesBattleRules)rom[offset]=value;
    // Copy the verified Advance font into the native font slots. No font state in SRAM or Config.
    rom.set(font,0x487c0);
    const names=gbaMenuNames(rom,cart);
    const native=menuReference?twueMenus(rom,cart,menuReference):null;
    const terms=native?twueTerminology(native.fitRows):null;
    const fieldText=terms?terms.field:gbaField;
    const widths=rom.subarray(0x48fc0,0x490c0);
    const fieldPointers=0x3b2100, code=0x3b2000;
    for(const [a,b] of [[code,0x3f8000],[0x372400,0x37ffff],[0x36bc00,0x36ffff]])gbaCheckFill(rom,a,b);
    const writeMonster=gbaWriter(rom,0x3b5200,0x3b9900),writeField=gbaWriter(rom,0x3b9900,0x3f8000);
    const writeBattle=gbaWriter(rom,0x372400,0x380000),writeAttack=gbaWriter(rom,0x36bc00,0x370000);
    const adjusted=new Set(),fieldIds=[],skippedBattle=[],battleRows={},battleWraps={};
    // The original routine can also be called with a reserved ID. Chain those IDs back into it.
    const ptr=fieldPointers+0xc00000, stub=[
        0xc2,0x20,0xa5,0xd0,0xc9,0xd0,0x0f,0xb0,0x1c,0x0a,0x18,0x65,0xd0,0xaa,
        0xbf,...gbaLong(ptr+1),0xc9,0xff,0xff,0xf0,0x0e,0x85,0xca,0xbf,...gbaLong(ptr),
        0x85,0xc9,0x5c,0xd9,0xd6,0xc0,
        0x5c,0x6f,0xd6,0xc0];
    // Both branches target the fallback JML. Compute offsets from actual instruction positions.
    stub[8]=stub.length-4-9;stub[22]=stub.length-4-23;
    rom.set(stub,code);rom.set([0x5c,...gbaLong(code+0xc00000)],0x7fbf);
    function field(id,donor){
        let tokens=gbaTokens(cart,'text2',donor);
        if(Object.hasOwn(gbaFormat.bonusPages,id)){
            const split=tokens.indexOf('\\page');
            gbaAssert(split>0,'Expected two bonus dialogue pages.');
            tokens=gbaFormat.bonusPages[id]===0?tokens.slice(0,split):tokens.slice(split+1);
        }
        const bytes=fieldText(tokens,gbaFormat.timings[id],widths,adjusted,id);
        const loc=writeField(bytes);rom.set(gbaLong(loc+0xc00000),fieldPointers+id*3);
        fieldIds.push(id);
    }
    for(let id=1;id<3084;id++)if(id!==1655&&!gbaFormat.controls.includes(id))field(id,id);
    // Retain the cartridge lessons while naming the SNES buttons and menu entries.
    for(const id of [607,611,613,628]){
        const replacements={'\\xC9:89':'left','\\xC9:87':'right','\\xC9:86':'up'};
        let tokens=gbaTokens(cart,'text2',id);
        if(id===607||id===611||id===628){
            const [old,replacement]=({607:['Start','X'],611:['Select','X or Y'],628:['Abilities','Skills']})[id];
            const pos=tokens.findIndex((_,i)=>tokens.slice(i,i+old.length).join('')===old);
            gbaAssert(pos>=0,'Missing school button prompt');tokens.splice(pos,old.length,...replacement);
        }
        tokens=tokens.flatMap(t=>replacements[t]?Array.from(replacements[t]):[t]);
        const loc=writeField(fieldText(tokens,gbaFormat.timings[id],widths,new Set(),id));
        rom.set(gbaLong(loc+0xc00000),fieldPointers+id*3);
    }
    for(const [id,donor] of Object.entries(gbaFormat.bonus))field(Number(id),donor);
    // Both battle and monster text pointers are 16-bit. Map the 19 bonus encounter slots to their US cartridge counterparts.
    rom[0x197ee]=0xf7;rom[0x198d2]=0xf6;
    for(const [kind,offset,table,store] of [['battle',0xfae,0x10d000,writeBattle],['monster',0xe65,0x3b0000,writeMonster],['attack',0x10ae,0x11f7a0,writeAttack]]){
        let count=0;
        for(let id=0;id<256;id++){
            
            const tokens=gbaTokens(cart,'text2',kind==='monster'&&Object.hasOwn(encounterDonors,id)?encounterDonors[id]:offset+id);
            if(kind==='battle'&&tokens.some(t=>t.startsWith('\\xC9:')))skippedBattle.push(id);
            const converted=gbaBattle(terms?terms.text(tokens,kind,id):tokens,kind,id);
            const bytes=gbaWrapBattle(converted,widths,kind,id,battleWraps);
            count++;
            const loc=store(bytes);rom.set(gbaWord(loc),table+2*id);
        }
        battleRows[kind]=count;
    }
    const descriptions=gbaMenuDescriptions(rom,cart,terms);
    let menuStats;
    if(native){
        menuStats={...native,mentions:terms.mentions};
    }else{
        installMainJobs(rom,cart);
        const lists=installMenuLists(rom,cart);
        const menuLabels=installMenuLabels(rom,cart,lists);
        shortenGbaMagicStats(rom);
        menuStats={names,menuLabels,menuLists:{stats:lists.stats,groups:lists.groups,pairs:lists.pairs}};
    }
    writeChecksum(rom);
    const stats={...menuStats,descriptions,field:fieldIds.length,bonus:Object.keys(gbaFormat.bonus).length,rewrapped:[...adjusted],battleRows,adaptedBattle:skippedBattle,battleWraps:Object.fromEntries(Object.entries(battleWraps).map(([k,ids])=>[k,[...ids]]))};
    const edition=native?'gba-twue-menus':'gba-presentation';
    return {bytes:rom,profile:{edition,advanceRules,options:dash?['dash']:[]},id:await hash(rom),stats};
}
