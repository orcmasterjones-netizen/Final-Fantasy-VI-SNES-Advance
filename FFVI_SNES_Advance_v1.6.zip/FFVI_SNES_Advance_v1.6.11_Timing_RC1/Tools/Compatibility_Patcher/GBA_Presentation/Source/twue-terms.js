// Only named game objects and explicit menu references change in dialogue.
// Keep ordinary words (strength, soldier, frozen esper) in their story sense.
function twueTerminology(rows){
    const mentions=[];
    const normalize=x=>x.toLowerCase().replace(/[’‘]/g,"'").replace(/\s+/g,' ');
    const exact=new Set(rows.filter(r=>r.gba===r.display&&r.group!=='Enemies').map(r=>normalize(r.gba)));
    const names=new Map();
    for(const r of rows){
        const key=normalize(r.gba);
        if(r.fit==='GBA'||key===normalize(r.display)||['Menu labels','Monster specials','Condition names'].includes(r.group)||(r.group==='Enemies'&&exact.has(key)))continue;
        if(!names.has(key))names.set(key,[]);
        names.get(key).push(r);
    }
    const explicit={
        'abilities':{display:'Skills',field:[628]},
        'battle mode':{display:'Bat.Mode',field:[609]},
        'magic defense':{display:'Mag.Def',field:[634],description:[1837,1905],monster:[3758-0xe65]},
        'magic evasion':{display:'MBlock%',description:[1721]},
        'strength':{display:'Vigor',description:[1490,1491,1739,1965,1966]}
    };
    const words=[...new Set([...names.keys(),...Object.keys(explicit)])].sort((a,b)=>b.length-a.length);
    const esc=t=>t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    const regex=new RegExp('(?<![A-Za-z0-9])(?:'+words.map(w=>esc(w).replace(/ /g,'[ \\n]+').replace(/'/g,"['’]")).join('|')+')(?![A-Za-z0-9])','gi');
    function adapt(tokens,kind,id){
        // There is one input character per token here, including a sentinel
        // for every control. Matches can span a soft line break, never a page.
        const input=tokens.map(t=>t==='\\n'?'\n':t.length===1?t:'\u0001').join('');
        const out=[],offsets=new Map();let taken=0;
        const copyTo=n=>{while(taken<n){offsets.set(taken,out.length);out.push(tokens[taken++]);}};
        for(const hit of input.matchAll(regex)){
            const key=normalize(hit[0]);let use=null;
            if(explicit[key]){
                if(explicit[key][kind]?.includes(id))use=explicit[key].display;
            }else{
                const alternatives=names.get(key),known=alternatives.filter(r=>r.group!=='Enemies');
                if(known.length){
                    // Pickups and equipment instructions refer to an item even
                    // when an attack shares that item's GBA name.
                    const target=known.find(r=>r.group==='Items'||r.group==='Bonus items')||known[0];
                    if(!(kind==='description'&&id===1888&&key==='ordinary picture'))use=target.display;
                }
                else{
                    const titles=alternatives.filter(r=>r.gba===hit[0].replace(/\n/g,' '));
                    const isCombat=['monster','battle','attack'].includes(kind);
                    const actor=kind==='field'&&input[hit.index+hit[0].length]===':';
                    const dungeon=(kind==='field'&&id>=0xf20)||(kind==='monster'&&id>=224);
                    if(titles.length&&(isCombat||actor||dungeon)){
                        const candidates=dungeon?titles.filter(r=>r.id>=416):titles.filter(r=>r.id<416);
                        const values=new Set((candidates.length?candidates:titles).map(r=>r.display));
                        if(values.size===1)use=[...values][0];
                    }
                }
            }
            if(!use)continue;
            copyTo(hit.index);const start=out.length;
            for(let i=0;i<hit[0].length;i++)offsets.set(taken+i,start+Math.floor(i*use.length/hit[0].length));
            out.push(...Array.from(use));taken+=hit[0].length;mentions.push({kind,id,from:hit[0].replace(/\n/g,' '),to:use});
        }
        copyTo(tokens.length);offsets.set(tokens.length,out.length);
        return {out,offsets};
    }
    return {mentions,text:(tokens,k,i)=>adapt(tokens,k,i).out,
        field(tokens,timing,widths,changes,id){
            const {out,offsets}=adapt(tokens,'field',id);
            return gbaField(out,(timing||[]).map(([index,bytes,width])=>[offsets.get(index),bytes,width]),widths,changes,id);
        }};
}
