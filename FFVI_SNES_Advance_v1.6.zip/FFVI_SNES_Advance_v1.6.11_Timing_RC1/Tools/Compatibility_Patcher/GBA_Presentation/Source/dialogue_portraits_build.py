"""Install the optional field portrait renderer and its controls on the v1.6.10 patcher."""
from pathlib import Path

def add_dialogue_portraits(html):
    src = Path(__file__).resolve().parent
    def region(start, end, replacement):
        nonlocal html
        if html.count(start) != 1 or html.count(end) != 1:
            raise ValueError('Unexpected patcher source around ' + start)
        left = html.index(start)
        right = html.index(end, left)
        html = html[:left] + replacement + html[right:]

    region('<section id="gbaPanel"', '<section id="sayansPanel"', (src/'dialogue-portrait-panel.html').read_text(encoding='utf8'))
    marker = 'function gbaGlyph(token, map) {'
    if html.count(marker) != 1: raise ValueError('Missing GBA font code')
    renderer = (src/'dialogue-portraits.js').read_text(encoding='utf8')
    records = (src/'portrait-machine.json').read_text(encoding='utf8')
    timing = (src/'portrait-timing.js').read_text(encoding='utf8').replace('TIMING_MACHINE_RECORDS',(src/'portrait-timing-machine.json').read_text(encoding='utf8'))
    renderer += timing
    html = html.replace(marker, renderer.replace('PORTRAIT_MACHINE_RECORDS', records) + marker)
    region('const isGbaEdition=edition=>','function chooseEdition(edition){',(src/'dialogue-portrait-ui.js').read_text(encoding='utf8'))
    marker = 'function filename(p){\n'
    if html.count(marker) != 1: raise ValueError('Missing output filename handler')
    html = html.replace(marker,marker+"    if(p.portraits)return filename({...p,portraits:false}).replace(/\\.sfc$/i,'_Dialogue_Portraits.sfc');\n")
    return (html.replace('v1.6.10', 'v1.6.11')
            .replace('v1.6.11</title>', 'v1.6.11 · Portrait Timing RC1</title>')
            .replace('SNES Advance v1.6.11</p>', 'SNES Advance v1.6.11 · Portrait Timing RC1</p>'))
