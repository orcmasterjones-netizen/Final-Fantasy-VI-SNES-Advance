let gbaReopened=null;
const gbaLabels={
    en:{twueOption:'GBA presentation + TWUE menus · US English',twueTitle:'GBA presentation + TWUE menus',twueIntro:'Play the US GBA dialogue in MultiFont Advance with TWUE’s menu lettering, number spacing and longer names.',twueFile:'Ted Woolsey Uncensored Edition 3.07',twueHint:'Choose the entire TWUE 3.07 ZIP or the base IPS without add-ons.',twueNeed:'Select the US GBA game and the TWUE 3.07 ZIP or base IPS.',option:'GBA presentation · US English',title:'GBA presentation',intro:'Play SNES Advance Regular with the US cartridge dialogue and MultiFont Advance from the opening scene.',cart:'Final Fantasy VI Advance (USA) ROM',font:'Multi-Font Selection v1.4.1 patch (ZIP or headerless IPS)',get:'Get Multi-Font Selection',dash:'Hold B to dash',rules:'Use GBA physical Evade and Vanish / instant-death rules',fixes:'Uncheck the battle rules option to use the original US SNES behavior for those two fixes. Other patcher options are off. The US Rev 1 Sketch fix stays active with either input revision. Controls use SNES buttons. The opening Narshe streets are walk-only in Magitek armor, as on GBA.',need:'Select the USA GBA ROM to build. MultiFont Advance is included.',reopen:'Verified GBA presentation ROM. To change settings, select your original SNES ROM.',edition:'SNES Advance Regular',withFont:'MultiFont Advance from power-on',text:'English GBA field and battle text'},
    es:{twueOption:'Presentación GBA + menús de TWUE · inglés de EE. UU.',twueTitle:'Presentación GBA + menús de TWUE',twueIntro:'Juega con los diálogos de GBA en inglés, la fuente MultiFont Advance y los menús, números y nombres largos de TWUE.',twueFile:'Ted Woolsey Uncensored Edition 3.07',twueHint:'Elige el ZIP completo de TWUE 3.07 o el IPS base sin complementos.',twueNeed:'Selecciona la ROM de GBA de EE. UU. y el ZIP de TWUE 3.07 o su IPS base.',option:'Presentación GBA · inglés de EE. UU.',title:'Presentación GBA',intro:'Juega a SNES Advance Regular con los diálogos del cartucho estadounidense y MultiFont Advance desde la introducción.',cart:'ROM de Final Fantasy VI Advance (EE. UU.)',font:'Parche Multi-Font Selection v1.4.1 (ZIP o IPS sin cabecera)',get:'Obtener Multi-Font Selection',dash:'Mantener B para correr',rules:'Usar las reglas de GBA de evasión física e Invisibilidad / muerte instantánea',fixes:'Desactiva la opción de reglas de combate para recuperar el comportamiento de SNES en esos dos casos. Las demás opciones están desactivadas. La corrección de Sketch de EE. UU. Rev 1 se conserva con ambas revisiones. Las instrucciones usan los botones de SNES. Al principio, en las calles de Narshe, la armadura Magitek solo permite caminar, igual que en GBA.',need:'Selecciona la ROM GBA estadounidense. La fuente Advance está incluida.',reopen:'ROM de presentación GBA verificada. Para cambiar los ajustes, selecciona la ROM de SNES original.',edition:'SNES Advance Regular',withFont:'MultiFont Advance desde el inicio',text:'Texto de campo y batalla de GBA en inglés'}
};
const isGbaEdition=edition=>edition==='gba-presentation'||edition==='gba-twue-menus';
function renderGbaPresentation(){
    const l=gbaLabels[lang]||gbaLabels.en;
    document.querySelectorAll('[data-gba]').forEach(n=>n.textContent=l[n.dataset.gba]);
    const edition=gbaReopened?.profile.edition||retailEdition;
    const hybrid=edition==='gba-twue-menus';
    const active=isGbaEdition(edition);
    el('gbaPanel').hidden=!active;
    if(!active)return false;
    const opened=!!gbaReopened;
    el('gbaTwueInputs').hidden=!hybrid;
    for(const node of document.querySelectorAll('[data-gba="title"]'))node.textContent=hybrid?l.twueTitle:l.title;
    for(const node of document.querySelectorAll('[data-gba="intro"]'))node.textContent=hybrid?l.twueIntro:l.intro;
    el('retailPanel').hidden=opened;el('retailEdition').value=edition;
    for(const id of ['retailApply','retailMoleSource','molemanWarning','futureWarning','sayansPanel','battlePanel','optionsPanel','personalButton','personalHint'])el(id).hidden=true;
    el('gbaInputs').hidden=opened;el('retailStatus').textContent='';
    const dash=opened?gbaReopened.profile.options.includes('dash'):el('gbaDash').checked;
    const labels=[l.edition,...(hybrid?[l.twueTitle]:[]),l.withFont,l.text,...(dash?[l.dash]:[]),...((opened?gbaReopened.profile.advanceRules:el('gbaRules').checked)?[l.rules]:[])];
    el('selection').replaceChildren(...labels.map(s=>{const item=make('li');item.textContent=s;return item;}));
    el('romStatus').textContent=t('romVerified')+' · '+(opened?(hybrid?l.twueTitle:l.title):retailInput?t('retailDetected')+retailInput.revision:l.edition);
    el('romStatus').className='status ok';
    if(opened&&!result)publishOutput(gbaReopened);
    const missing=!el('gbaCart').files.length||(hybrid&&!el('gbaTwueFile').files.length);
    const reopenMessage=opened&&gbaReopened.profile.updatedMenu?(lang==='es'?'Menús actualizados. Descarga la ROM v1.6.9 con tus opciones actuales.':'Menus updated. Download the v1.6.9 ROM with your existing settings.'):l.reopen;
    el('build').hidden=!!result;el('build').disabled=building||missing||!!result;
    el('status').textContent=buildError||(building?t('working'):opened?(gbaReopened.profile.prior?(lang==='es'?'ROM '+gbaReopened.profile.prior+' verificada. Usa tu ROM original para crear v1.6.9.':'Verified '+gbaReopened.profile.prior+' ROM. Select your original SNES ROM to build v1.6.9.'):reopenMessage):result?t('done'):missing?(hybrid?l.twueNeed:l.need):t('ready'));
    el('status').className='status'+(buildError?' error':result?' ok':'');
    el('download').hidden=!result;el('outputName').hidden=!result;
    el('outputName').textContent=result?filename(result.profile)+' · CRC32 '+result.outputCRC32:'';
    return true;
}
for(const id of ['gbaCart','gbaTwueFile','gbaDash','gbaRules'])el(id).addEventListener('change',()=>{clearResult();render();});
async function buildGbaUI(){
    clearResult();const revision=buildRevision;
    const snes=el('rom').files[0],retail=retailInput,cart=el('gbaCart').files[0],dash=el('gbaDash').checked,rules=el('gbaRules').checked;
    const hybrid=retailEdition==='gba-twue-menus', donor=el('gbaTwueFile').files[0];
    building=true;render();
    try{
        gbaAssert(cart.size===0x800000,'Expected the 8 MiB US GBA cartridge.');
        let regular;
        if(retail)regular=(await buildRetailBase(retail,'regular',null)).bytes;
        else{regular=new Uint8Array(await snes.arrayBuffer());if(regular.length===0x400200)regular=regular.subarray(512);}
        if(revision!==buildRevision)return;
        const cartBytes=new Uint8Array(await cart.arrayBuffer());
        gbaAssert(await hash(cartBytes)===gbaFormat.cart,'Choose Final Fantasy VI Advance (USA), unmodified English cartridge.');
        let menuReference=null;
        if(hybrid){
            const selection={variant:'base',music:'none'};
            try{
                const patches=await readTWUEVariantSources([donor],{},selection);
                const base=await identify(new File([regular],'regular.sfc'));
                menuReference=(await combine(base,new Set(['twue']),{twue:patches},{...selection,variantSource:true})).bytes;
                gbaAssert(await hash(menuReference)==='0d9696ea9c1ea1a5138f7544505d13a5fd48313099dda449908c7df2d43ac100','TWUE menu source mismatch.');
            }catch{throw new Error((gbaLabels[lang]||gbaLabels.en).twueHint);}
        }
        if(revision!==buildRevision)return;
        const output=await gbaPresentation(regular,cartBytes,dash,rules,menuReference);
        const verified=(hybrid?gbaTwueHashes:gbaOutputs)[output.id];
        gbaAssert(verified && verified[0]===dash && verified[1]===rules,'Output checksum did not match the verified build.');
        if(revision===buildRevision)publishOutput(output);
    }catch(e){if(revision===buildRevision)buildError=e.message;}
    finally{if(revision===buildRevision){building=false;render();}}
}
async function reopenGba(file){
    if(![0x400000,0x400200].includes(file.size))return null;
    let bytes=new Uint8Array(await file.arrayBuffer());if(bytes.length===0x400200)bytes=bytes.subarray(512);
    if(bytes[0x3b2000]!==0xc2)return null;
    let id=await hash(bytes);
    const hybrid=gbaTwueHashes[id]||gbaTwuePreviews[id];
    if(hybrid){
        const [dash,advanceRules]=hybrid;
        const updatedMenu=!gbaTwueHashes[id];
        if(updatedMenu){
            // Published previews differ only in two positioned menu captions.
            // Authenticate the complete input above, then the entire new output.
            bytes=bytes.slice();
            bytes.set([0x69,0x83,0x8c,0x8f,0xfe,0x82,0xa8,0xac,0xad,0],0x35ce6);
            bytes.set([0x91,0x9e,0xa5,0xa2,0x9c,0],0x337e6);
            writeChecksum(bytes);id=await hash(bytes);
            const target=gbaTwueHashes[id];
            gbaAssert(target&&target[0]===dash&&target[1]===advanceRules,'Unexpected TWUE menu update checksum.');
        }
        return {bytes,id,profile:{edition:'gba-twue-menus',advanceRules,options:dash?['dash']:[],updatedMenu}};
    }
    const target=gbaOutputs[id]||gbaFormat.priorOutputs[id];
    if(!target)return null;
    const profile={edition:'gba-presentation',prior:target[2]||null,advanceRules:target[1],options:target[0]?['dash']:[]};
    if(profile.prior==='v1.6.6'||profile.prior==='v1.6.7'){
        if(profile.prior==='v1.6.6')fixGbaMenuLayout(bytes);
        shortenGbaMagicStats(bytes);
        writeChecksum(bytes);
        id=await hash(bytes);
        const expected=gbaOutputs[id];
        gbaAssert(expected&&expected[0]===target[0]&&expected[1]===target[1],'Unexpected menu update checksum.');
        profile.prior=null;
        profile.updatedMenu=true;
    }
    return {bytes,id,profile};
}
