// Lists retain fixed record widths on SNES. Use one 8x8 tile for a frequent pair
// of letters when a name needs an extra cell. Item IDs and battle text remain independent.
function installMenuLists(rom,cart){
    const groups=[],specs=[],stats={},packs=new Map(),space=0xfe;
    const store=gbaWriter(rom,0x395800,0x398f00);
    gbaCheckFill(rom,0x395800,0x398f00);
    const extra=[270,265,261,260,262,257,256,268,258,259,264,266,263,267,269];
    function list(key,base,count,width,skip,index,bank='text1'){
        const dest=store(rom.slice(base,base+count*width));
        groups.push({key,dest,base,count,width});
        for(let i=0;i<count;i++){
            const id=index(i);if(id==null)continue;
            const tokens=gbaTokens(cart,bank,id);
            if(key==='Enemies'&&i===333&&tokens.at(-1)==='\\x67')tokens.pop(); // Drop the trailing GBA control on Ipooh.
            if(skip&&tokens[0]?.startsWith('\\'))tokens.shift();
            if(!tokens.length)continue;
            gbaAssert(tokens.every(t=>!t.startsWith('\\')),'Unexpected list control in '+key+' '+i);
            const name=tokens.join('');
            specs.push({key,id:i,name,width:width-skip,dest:dest+i*width+skip});
        }
    }
    list('Items',0x12b300,255,13,1,i=>0x17a+i);
    list('Bonus items',0x360080,15,13,1,i=>0x17a+extra[i]);
    list('Magic',0x3059bd,85,7,1,i=>i<54?0x29b+i:({82:0xa58,83:0xa5a,84:0xa59}[i]));
    list('Espers',0x305c10,31,8,0,i=>i<27?0x2d1+i:0xa5b+i-27);
    list('Dance',0x26ff9d,8,12,0,i=>0x3b6+i);
    list('Lore',0x26f9fd,24,10,0,i=>0x1478+i,'text2');
    const extraMonsters=[385,392,411,412,391,394,395,408,409,384,390,402,388,389,403,398,399,401,400,407,410,413,397,386,404,405,406,415,419,420,421,422,387,393,396,414];
    const questMonsters={367:416,372:417,380:418};
    list('Enemies',0x384bec,452,10,0,i=>i<382?0x40f+(questMonsters[i]??i):i>=416?0x40f+extraMonsters[i-416]:null);
    list('Battle abilities',0x26f7b9,175,10,0,i=>0x143e+i,'text2');
    list('Rare items',0x34e13c,22,13,0,i=>i<2?0x5b6+i:i<=5?0x5b8:i===20?0x3c2:i===21?0x5c8:0x5b3+i);
    list('Commands',0x18cea0,30,7,0,i=>0x15a+i);
    const plain=t=>t==='ñ'?0x7f:t===' '?space:gbaGlyph(t,gbaFormat.battleGlyphs)[0];
    const layout=name=>{
        const best=[[]];
        for(let end=1;end<=name.length;end++){
            let seq=best[end-1].concat(name[end-1]);
            const p=name.slice(end-2,end);
            if(end>=2&&packs.has(p)&&best[end-2].length+1<seq.length)seq=best[end-2].concat(p);
            best.push(seq);
        }
        return best.at(-1);
    };
    const staticLabels=gbaFormat.positionedLabels.map(([key,addr,orig,id,width])=>({key,name:gbaPositionedName(cart,key,id),width}));
    const entries=[...specs,...staticLabels];
    const unitWidth=s=>{
        if(s===' ')return 2;
        const glyph=tiles(plain(s));
        return glyph.length;
    };
    function tiles(code){
        if(code===space)return [0,0];
        const source=code===0x7f?gbaFormat.battleGlyphs.n:code;
        const raw=rom.slice(0x47fc0+16*source,0x47fd0+16*source);
        if(code===0x7f){raw[0]=0x78;raw[1]=0x50;raw[2]=0x38;raw[3]=0x28;}
        const cols=Array.from({length:8},(_,x)=>raw.reduce((bits,v,y)=>bits|(((v>>(7-x))&1)<<y),0));
        while(cols.length>1&&!cols[0])cols.shift();
        while(cols.length>1&&!cols.at(-1))cols.pop();
        return cols;
    }
    // Prefer narrower letter pairs and try to leave ordinary words at full width.
    for(let pass=0;pass<111;pass++){
        const votes=new Map();
        for(const {name,width} of entries){
            const seq=layout(name);
            if(seq.length<=width)continue;
            for(let i=1;i<seq.length;i++){
                if(seq[i-1].length!==1||seq[i].length!==1)continue;
                const p=seq[i-1]+seq[i];
                votes.set(p,(votes.get(p)||0)+1/(unitWidth(p[0])+unitWidth(p[1])));
            }
        }
        if(!votes.size){
            // A different pairing can resolve an odd run of already-compressed letters.
            for(const {name,width} of entries){
                if(name.length>width*2||layout(name).length<=width)continue;
                for(let i=0;i+1<name.length;i+=2){
                    const p=name.slice(i,i+2);if(!packs.has(p))votes.set(p,(votes.get(p)||0)+1);
                }
            }
            if(!votes.size)break;
        }
        const pick=[...votes].sort((a,b)=>b[1]-a[1]||((a[0]<b[0])?-1:1))[0][0];
        packs.set(pick,0x10+packs.size);
    }
    // Use private fixed-text font transfers. Large-text dialogue fonts use separate tables.
    const font=0x39b000;
    gbaCheckFill(rom,font,font+0x1000);rom.set(rom.slice(0x47fc0,0x48fc0),font);
    rom.set(rom.slice(0x47fc0+16*plain('n'),0x47fd0+16*plain('n')),font+0x7f0);rom.set([0x78,0x50,0x38,0x28],font+0x7f0);
    for(const [pair,code] of packs){
        const cols=pair.split('').map(t=>tiles(plain(t)));
        const total=cols[0].length+cols[1].length;
        let split=Math.max(2,Math.min(5,Math.round(7*cols[0].length/total)));
        const thin=(src,n)=>Array.from({length:n},(_,x)=>src[Math.min(src.length-1,Math.floor((x+0.5)*src.length/n))]);
        const left=thin(cols[0],Math.min(split,cols[0].length));
        const right=thin(cols[1],Math.min(7-left.length,cols[1].length));
        const glyph=new Uint8Array(16);
        [...left,0,...right].forEach((c,x)=>{for(let y=0;y<16;y++)glyph[y]|=((c>>y)&1)<<(7-x);});
        rom.set(glyph,font+16*code);
    }
    // The 2bpp loader reads the whole font. The 4bpp loader starts eight tiles later.
    for(const [at,orig] of [[0x36b7d,0x47fc0],[0x36bbA,0x48040]]){
        // Match the complete LDA long,X within the appropriate font-load routine.
        let found=-1;
        for(let a=at-8;a<at+8;a++)if(rom[a]===0xbf&&rom[a+1]===(orig&255)&&rom[a+2]===((orig>>8)&255)&&rom[a+3]===0xc4){found=a+1;break;}
        gbaAssert(found>=0,'Menu font loader not found');rom.set(gbaLong(0xc00000+font+orig-0x47fc0),found);
    }
    function encode(name,width){
        let seq=Array.from(name);
        if(seq.length>width){
            seq=layout(name);
            // Give the widest pairs their normal two tiles whenever cells remain.
            const expand=seq.map((t,i)=>({t,i})).filter(({t})=>t.length===2)
                .sort((a,b)=>unitWidth(b.t[0])+unitWidth(b.t[1])-unitWidth(a.t[0])-unitWidth(a.t[1]));
            const separate=new Set(expand.slice(0,Math.max(0,width-seq.length)).map(({i})=>i));
            seq=seq.flatMap((t,i)=>separate.has(i)?Array.from(t):[t]);
        }
        return seq.length<=width?seq.map(t=>t.length===1?plain(t):packs.get(t)):null;
    }
    for(const {key,id,name,width,dest} of specs){
        const bytes=encode(name,width);gbaAssert(bytes,'Name exceeds the menu field: '+key+' '+id+' '+name);
        rom.fill(255,dest,dest+width);rom.set(bytes,dest);
        stats[key]=(stats[key]||0)+1;
    }
    for(const {key,base,dest} of groups){
        const immediates={'Magic':0x34fc8,'Lore':0x352c5,'Enemies':0x35468,'Espers':0x35559,'Dance':0x35820,'Rare items':0x38494};
        if(Object.hasOwn(immediates,key)){
            const h=immediates[key];gbaAssert(rom[h]===0xa0&&gbaRead16(rom,h+6)===(base&65535),'Array lookup '+key);
            rom.set(gbaWord(dest),h+6);rom[h+11]=(dest>>16)+0xc0;
        }
        const readers={'Items':[0x3813f,0x3907a,0x39dd1,0x3c122],'Bonus items':[0x3f744],'Espers':[0x334f9,0x35a24]};
        const battleReaders={'Items':[0x16576,0x16a20],'Bonus items':[0x16ad8],'Magic':[0x165f1,0x16aac],'Espers':[0x165d9,0x16696],'Dance':[0x16619],'Lore':[0x1666e],'Enemies':[0x16641,0x16947],'Commands':[0x1697c],'Battle abilities':[0x165bd,0x16a6b]};
        for(const h of [...(readers[key]||[]),...(battleReaders[key]||[])]){
            if(h<0x30000)gbaAssert(rom[h+3]===0x20&&[0x63fb,0x66f0].includes(gbaRead16(rom,h+4)),'Expected fixed tile writer');
            gbaAssert(rom[h-1]===0xbf&&gbaRead16(rom,h)===(base&65535),'Menu list reader '+key);
            rom.set(gbaLong(dest+0xc00000),h);
        }
        // In the native command lists the command table is addressed with a long load.
        if(key==='Commands'){
            const address=gbaLong(base+0xc00000);
            for(let h=0x30001;h<0x40000;h++)if(rom[h-1]===0xbf&&address.every((c,i)=>rom[h+i]===c))rom.set(gbaLong(dest+0xc00000),h);
        }
    }
    for(const a of [0x14060,0x143be]){
        gbaAssert(rom[a]===0xa2&&gbaRead16(rom,a+1)===0x7fc0&&rom[a+7]===0xc4,'Battle font transfer');
        rom.set(gbaWord(font),a+1);rom[a+7]=0xf9;
    }
    gbaAssert(rom[0x140d4]===0x69&&rom[0x140e1]===0xc4,'Battle single tile source');
    rom.set(gbaWord(font),0x140d5);rom[0x140e1]=0xf9;
    return {stats,encode,pairs:Object.fromEntries(packs),groups};
}
