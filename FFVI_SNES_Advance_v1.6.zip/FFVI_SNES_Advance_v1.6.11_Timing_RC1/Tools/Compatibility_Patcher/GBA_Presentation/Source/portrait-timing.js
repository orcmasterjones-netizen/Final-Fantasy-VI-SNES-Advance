// Update a verified v1.6.11 portrait layout. Fresh builds and upgrades use the same conversion.
const portraitTimingMachine = TIMING_MACHINE_RECORDS;
function applyPortraitTiming(input) {
    const out = input.slice();
    const count = 0xfd0, sparse = 0x306000, originalTable = 0x3b2100, merged = 0x36d000;
    const banks = portraitBanks.slice(0, 2);
    const readPointer = offset => input[offset] | input[offset + 1] << 8 | input[offset + 2] << 16;
    const decode = hex => Uint8Array.from(hex.match(/../g), byte => parseInt(byte, 16));
    const replacement = (records, reverse) => {
        for (const [address, original, patched] of records) {
            const before = decode(reverse ? patched : original);
            if (!before.every((v, i) => out[address + i] === v)) throw Error('Portrait timing signature mismatch.');
            out.set(decode(reverse ? original : patched), address);
        }
    };
    replacement(portraitMachine, true);
    replacement(portraitTimingMachine, false);
    if (!input.subarray(merged, merged + 3 * count).every(v => v === 255)) throw Error('Dialogue pointer table is occupied.');
    out.set(input.subarray(originalTable, originalTable + count * 3), merged);
    for (const [start, end] of banks) out.fill(255, start, end);
    // Four implicit breaks in the native airship lesson take one text-engine tick apiece.
    // Word positions were traced at the original automatic-wrap instruction on the SNES.
    const wraps = new Map([[1315, [[], [29, 58], []]], [1318, [[], [27], [32]]]]);
    let bank = 0, next = banks[0][0];
    for (let id = 0; id < count; id++) {
        const entry = 3 * id;
        const source = readPointer(sparse + entry);
        if (source === 0xffffff) continue;
        let base = readPointer(originalTable + entry);
        if (base === 0xffffff) {
            base = (id < gbaRead16(input, 0xce600) ? 0xcd0000 : 0xce0000) + gbaRead16(input, 0xce602 + 2 * id);
        }
        let at = source & 0x3fffff;
        const face = input[at] === 28 ? input[at + 1] : 0;
        if (input[at] === 28) at += 2;
        // Special effects and borderless events can switch straight to their original script.
        const record = [28, 128 | face, ...gbaLong(base)];
        let page = 0, glyph = 0, terminated = false;
        while (at < input.length) {
            const code = input[at++];
            if (code === 0) { record.push(0); terminated = true; break; }
            if (code === 19) { record.push(code); page++; glyph = 0; continue; }
            if (code !== 28 && code !== 1 && code !== 127) {
                if (wraps.get(id)?.[page]?.includes(glyph)) record.push(17, 0);
                glyph++;
            }
            record.push(code);
            if ([17, 20, 22, 28].includes(code)) record.push(input[at++]);
        }
        if (!terminated) throw Error('Unterminated portrait dialogue.');
        if (next + record.length > banks[bank][1]) {
            if (++bank === banks.length) throw Error('Portrait dialogue exceeds the renderer’s supported banks.');
            next = banks[bank][0];
        }
        const pointer = gbaLong(0xc00000 + next);
        for (const table of [sparse, merged]) out.set(pointer, table + entry);
        out.set(record, next);
        next += record.length;
    }
    writeChecksum(out);
    return out;
}
