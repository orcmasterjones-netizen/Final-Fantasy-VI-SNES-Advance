// Verified upstream IPS files are read from the player's copy. Both ExHiROM
// copies include the animation interpreter and the C2 battle routines.
const roseBattleOutputs = ROSE_ATB_OUTPUTS;
const roseBattleOriginals = Object.fromEntries(Object.entries(ROSE_ATB_ORIGINALS)
    .map(([mode, spans]) => [mode, spans.map(([at, data]) => [at, r16hex(data)])]));
const atbRevision10 = ROSE_ATB_DONORS;

async function readOriginalATBSource(mode, file) {
    const spec = catalog.sources[mode][0];
    if (file.size !== spec.size) return null;
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (await rawHash(bytes) !== atbRevision10[mode]) return null;
    // Normalize the official 1.0 IPS to its 1.1 counterpart for the existing
    // donor reader and personal-patcher format. Patch offsets here are IPS file offsets.
    bytes[7] = 0x38;
    if (mode === 'classic') bytes[17] = 0x66;
    if (await rawHash(bytes) !== spec.sha) throw failure('verifyFail');
    return {[spec.name]:bytes};
}
async function roseBattlePayload(mode, patch) {
    if (!patch || await rawHash(patch) !== catalog.sources[mode][0].sha) throw failure('badFiles');
    const {records} = decodeFutureIPS(patch,{maxAddress:0x50000,maxRecords:32});
    const writes = [];
    for (const {offset,length,data,rle} of records) {
        const bytes = rle ? new Uint8Array(length).fill(data[0]) : data;
        if (offset !== 0x19538) {
            writes.push([offset,bytes]);
            continue;
        }
        writes.push([0x1950e,bytes.subarray(0,4)]);
        // Classic wraps the interpreter call with start and end hooks. Preserve
        // SNES Advance's intervening BEQ and JSR $953C.
        if (mode === 'classic') writes.push([0x19517,bytes.subarray(9)]);
    }
    const originals = roseBattleOriginals[mode];
    if (writes.length !== originals.length || writes.some(([at, bytes], i) =>
        at !== originals[i][0] || bytes.length !== originals[i][1].length)) throw failure('verifyFail');
    return writes.map(([,bytes]) => bytes);
}
function setRoseBattle(source,mode,records,enable) {
    const out = source.slice();
    for (const [i,[offset,original]] of roseBattleOriginals[mode].entries()) {
        const before = enable ? original : records[i];
        const after = enable ? records[i] : original;
        for (const at of [offset,offset+0x400000]) {
            if (!r16match(source,at,before)) throw failure('verifyFail');
            out.set(after,at);
        }
    }
    writeROSEChecksum(out);
    return out;
}
async function identify(file) {
    if (file.size !== roseSize && file.size !== roseSize+512) return identifyBeforeRoseATB(file);
    const start = file.size-roseSize;
    const hook = new Uint8Array(await file.slice(start+0x1950e,start+0x19512).arrayBuffer());
    if (!r16match(hook,0,[0x22,0x1f,0xb5,0xc4])) return identifyBeforeRoseATB(file);
    const bytes = new Uint8Array(await file.slice(start).arrayBuffer());
    const checksums = [bytes.slice(0xffdc,0xffe0),bytes.slice(0x40ffdc,0x40ffe0)];
    writeROSEChecksum(bytes);
    const repaired = !r16match(bytes,0xffdc,checksums[0]) || !r16match(bytes,0x40ffdc,checksums[1]);
    const entry = roseBattleOutputs[await rawHash(bytes)];
    if (!entry) throw failure('verifyFail');
    const records = roseBattleOriginals[entry.kind].map(([offset,original]) => bytes.slice(offset,offset+original.length));
    const restored = setRoseBattle(bytes,entry.kind,records,false);
    if (await rawHash(restored) !== entry.base) throw failure('verifyFail');
    const input = await identifyBeforeRoseATB(new File([restored],file.name));
    return {...input,roseBattle:{kind:entry.kind,records},upgrade:input.upgrade||repaired,
        profile:{...input.profile,options:[...input.profile.options,entry.kind]}};
}
async function combine(input,selected,sources={},settings={}) {
    const rose = input.profile.edition === 'rose' || selected.has('rose');
    const mode = atbKinds.find(id => selected.has(id));
    if (!rose || (!mode && !input.roseBattle)) return combineBeforeRoseATB(input,selected,sources,settings);
    const options = new Set(selected);
    if (mode) options.delete(mode);
    if ((mode && options.has('vanilla')) || [...options].some(id => id === 'turn' || atbKinds.includes(id))) throw failure('battleConflict');
    const profile = {...input.profile,options:input.profile.options.filter(id => !atbKinds.includes(id))};
    const output = await combineBeforeRoseATB({...input,profile},options,sources,settings);
    if (!mode) return output;
    const base = await rawHash(output.bytes);
    if (output.profile.edition !== 'rose' || !Object.values(roseBattleOutputs).some(entry => entry.base === base))
        throw failure('roseATBVersion');
    const patch = sources[mode]?.[catalog.sources[mode][0].name];
    const records = patch ? await roseBattlePayload(mode,patch) : input.roseBattle?.kind === mode ? input.roseBattle.records : null;
    if (!records) throw failure('badFiles');
    const bytes = setRoseBattle(output.bytes,mode,records,true);
    const id = await rawHash(bytes);
    const entry = roseBattleOutputs[id];
    if (entry?.kind !== mode || entry.base !== base) throw failure('verifyFail');
    return {...output,bytes,id,profile:{...output.profile,options:[...output.profile.options,mode]}};
}
