"""Add the ROSE battle-system adapter to the v1.6.9 patcher source."""
import json
from pathlib import Path

def add_rose_atb(html):
    root = Path(__file__).resolve().parent
    js = (root / 'rose-atb.js').read_text(encoding='utf8')
    for key, filename in [('ROSE_ATB_OUTPUTS','outputs.json'),('ROSE_ATB_ORIGINALS','originals.json'),('ROSE_ATB_DONORS','rose-atb-ips10.json')]:
        js = js.replace(key,(root/filename).read_text(encoding='utf8'))
    changes = [
        ('async function identify(file){','async function identifyBeforeRoseATB(file){'),
        ('async function combine(input,selected,sources={},settings={}){','async function combineBeforeRoseATB(input,selected,sources={},settings={}){'),
        ('// Verified Sayans sources',js+'\n// Verified Sayans sources'),
        ('async function readSource(id,files,saved) {', '''async function readSource(id,files,saved) {
    if (atbKinds.includes(id) && files.length === 1) {
        const normalized = await readOriginalATBSource(id,files[0]);
        if (normalized) return normalized;
    }'''),
        ("else if(found.profile.edition==='rose')chosenBattle='vanilla';", "else if(found.profile.edition==='rose')chosenBattle=atbKinds.find(id=>personal.options?.includes(id))||'vanilla';"),
        ("if(roseMode)chosenBattle='vanilla';","if(roseMode && chosenBattle==='turn')chosenBattle='vanilla';"),
        ("else if(roseMode)supported=capabilities.has(id);","else if(roseMode)supported=capabilities.has(id)||atbKinds.includes(id);"),
        ("wanted.delete(other);chosenBattle='vanilla';","wanted.delete(other);if(chosenBattle==='turn')chosenBattle='vanilla';"),
        ('Uses the main patch with the native ROSE font, Original ATB, and built-in Cancel dash. Other font, battle-system and ROSE tweak patches are not supported.','ROSE includes its own font and Cancel dash. With ROSE 2.04, choose Original ATB, Modern ATB Enhanced, Classic ATB Enhanced, or CTB Wait.'),
        ('"roseUnsupported": "This ROSE build uses its native font, Original ATB, and built-in Cancel dash. This additional option is not supported.",','"roseUnsupported": "This option is unavailable with ROSE.",\n        "roseATBVersion": "RoSoDude’s battle modes require the original ROSE 2.04 main patch.",'),
        ('Usa el parche principal original ROSE v2.04 con su fuente propia, ATB original y carrera mediante Cancelar. No admite otras fuentes, sistemas de combate ni parches de ajustes de ROSE.','ROSE incluye su propia fuente y permite correr con Cancelar. Con ROSE 2.04, elige ATB original, Modern ATB Enhanced, Classic ATB Enhanced o CTB Wait.'),
        ('"roseUnsupported": "Esta versión de ROSE usa su fuente propia, ATB original y carrera mediante Cancelar. No admite esta opción adicional.",','"roseUnsupported": "Esta opción no está disponible con ROSE.",\n        "roseATBVersion": "Los modos de combate de RoSoDude requieren el parche principal original de ROSE 2.04.",')
    ]
    for old,new in changes:
        if html.count(old) != 1: raise ValueError('Unexpected patcher source at '+old[:70])
        html = html.replace(old,new)
    return html.replace('v1.6.9','v1.6.10').replace('1.1 US IPS','US v1.0 or v1.1 IPS').replace('para ROM estadounidense 1.1','para ROM estadounidense v1.0 o v1.1')
