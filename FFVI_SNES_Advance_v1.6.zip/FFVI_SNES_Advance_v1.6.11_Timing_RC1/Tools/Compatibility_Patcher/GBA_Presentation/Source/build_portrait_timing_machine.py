"""Emit a small native 65816 renderer. All 24-bit ROM addresses use HiROM."""
import struct,json
from pathlib import Path
import argparse
args = argparse.ArgumentParser(description='Emit the field-portrait 65816 hooks from a portrait-free GBA Presentation ROM.')
args.add_argument('rom', type=Path)
args.add_argument('output', type=Path)
options = args.parse_args()
rom = options.rom.read_bytes()
if len(rom) != 0x400000:
    args.error('Supply an unheadered 4 MiB GBA Presentation ROM.')
code=bytearray();labels={};refs=[];patches=[]
bank=0xff;origin=0xc000
def put(s):code.extend(bytes.fromhex(s))
def lab(n):
 assert n not in labels,n
 labels[n]=len(code)
def rel(op,n):put(op+' 00');refs.append((len(code)-1,n,'rel'))
def jmp(n):put('4c 00 00');refs.append((len(code)-2,n,'abs'))
def jsr(n):put('20 00 00');refs.append((len(code)-2,n,'abs'))
def wr(o,b):patches.append([o,rom[o:o+len(b)].hex(),b.hex()])
def hook(o,n,l,op=0x22):wr(o,bytes([op])+(0xff0000+origin+labels[n]).to_bytes(3,'little')+bytes([0xea])*(l-4))
def word(x):return struct.pack('<H',x)
def rx(op,x):put(op);code.extend(word(x))
def set8(v,a):put('a9 %02x 8d'%v);code.extend(word(a))
def set16(v,a):rx('a2',v);rx('8e',a)
def jml(a):put('5c');code.extend(a.to_bytes(3,'little'))
# $C6 requested portrait, $C7 hardware page counter is unused by field.
# $7e97f0 = installed face, $97f1 = position. The active VBlank handler owns these bytes.
# Keep the old entry-point offsets for this renderer revision.
lab('reset');put('a9 00 8f f0 97 7e 8f f1 97 7e 8f f2 97 7e a2 00 07 86 c6 6b')
# A marker is introduced only in the generated portrait streams. Original $1C symbols retain their native interpretation.
lab('marker');put('c9 1c');rel('d0','originalSymbol')
put('a5 cb c9 f3');rel('f0','portraitBank3');put('c9 f7');rel('d0','originalSymbol')
put('a5 ca c9 55');rel('90','originalSymbol');rel('80','inBank')
lab('portraitBank3');put('a5 ca c9 e0');rel('b0','originalSymbol')
lab('inBank');put('a5 be');rel('10','following')
put('ad 64 05');rel('d0','originalStream');put('ad 21 05 29 08');rel('d0','originalStream')
put('a2 05 00');rel('80','selectFace')
lab('originalStream');put('a0 02 00 c2 20 b7 c9 aa c8 c8 e2 20 b7 c9 85 cb 86 c9')
put('7b');jml(0xc0824d)
lab('following');put('a2 02 00 ad 64 05');rel('d0','setFull');put('ad 21 05 29 08');rel('d0','setFull')
lab('selectFace');put('a5 be 29 7f 85 c6');rel('f0','setFull')
put('a9 b0 85 c8');jsr('arm');rel('80','advanceMarker')
lab('setFull');put('64 c6 a9 e0 85 c8')
lab('advanceMarker');put('c2 21 8a 65 c9 85 c9 7b e2 20');jml(0xc0824d)
lab('originalSymbol');put('a5 bd 38 e9 1b 85 ce');jml(0xc08450)
lab('arm');put('c2 20 ad 00 15 c9 5c 82');rel('d0','armEnd')
put('ad 02 15 c9 01 c0');rel('d0','armEnd')
put('e2 20 a9 00 8f f0 97 7e 8f f2 97 7e a9 dc 8d 02 15 60')
lab('armEnd');put('e2 20 60')
# DMA uses the normal width except on a marked page. Native choice cursor uses same base.
lab('indent');put('a5 c6');rel('f0','wide');put('c2 21 a5 c3 69 60 38 6b')
lab('wide');put('c2 21 a5 c3 69 00 38 6b')
lab('choice');put('a5 c6');rel('f0','widechoice');put('c2 21 ad 80 05 69 60 38 6b')
lab('widechoice');put('c2 21 ad 80 05 69 00 38 6b')
# End-of-field VBlank. All palette edits use HDMA restricted to window scanlines.
lab('vblank');put('a5 c6');rel('f0','off');put('a5 ba c9 01');rel('d0','off')
put('a5 bb c9 05');rel('d0','off');put('ad 64 05');rel('d0','off')
put('ad 21 05 29 08');rel('d0','off')
put('a5 cc');rel('f0','on');put('c9 09');rel('f0','on');put('64 c6');rel('80','off')
lab('on');put('a5 c6 cf f0 97 7e');rel('d0','startinstall')
put('a5 bc cf f1 97 7e');rel('f0','enable')
lab('startinstall');jsr('install');lab('enable');jsr('palette');put('a9 ff 8d 0c 42 6b')
lab('off');put('af f0 97 7e');rel('f0','finishwipe');jsr('remove');rel('80','stock')
lab('finishwipe');put('af f2 97 7e');rel('f0','stock');put('a5 cc c9 02');rel('90','unmask');put('c9 09');rel('d0','stock')
lab('unmask');jsr('textoff');jsr('stockdma');put('a9 00 8f f2 97 7e')
lab('stock');put('af f0 97 7e 0f f2 97 7e');rel('d0','stockMask')
put('a5 c6');rel('f0','disarm');put('a5 ba');rel('d0','stockMask')
lab('disarm');put('64 c6 a9 e0 85 c8 a9 01 8d 02 15');lab('stockMask');put('ad 21 05 29 08 4a 4a 4a 09 fe 8d 0c 42 6b')
# A native frame always configures DMA0 as the field BG2 scroll channel before this hook.
# install/remove loans channel 0 for regular DMA then restores its native settings.
lab('stockdma');set16(0x0f43,0x4300);set16(0x7c51,0x4302);set8(0x7e,0x4304);put('8d 07 43 60')
# Fixed graphics below text inside each native row's left margin, one extra tile in its unused right gutter.
tileaddrs=[0x3800+0x200*(i//6)+16*(i%6) if i<24 else 0x39e0 for i in range(25)]
# Use column-major groups by position in ROM so four contiguous groups transfer directly.
lab('install');put('a5 c6 8f f0 97 7e a5 bc 8f f1 97 7e')
put('c2 20 a5 c6 29 ff 00 3a 0a aa bf 00 dc ff 8d 02 43 e2 20')
set16(0x1801,0x4300);set8(0xff,0x4304);set8(0x80,0x2115)
for i in (0,6,12,18,24):
 set16(tileaddrs[i],0x2116);set16(32*(6 if i<24 else 1),0x4305);set8(1,0x420b)
# map for both window placements; native field never displays this tilemap outside its own window.
jsr('mapon');jsr('stockdma');jsr('initpalette');put('60')
lab('remove');put('af f1 97 7e 8f f2 97 7e a9 00 8f f0 97 7e')
# The native eight-frame wipe clears the text margin; keep its tilemap masked until then.
jsr('mapoff');jsr('stockdma');put('60')
# Dialogue window uses BG1 map $4000. Upper window top tile row 1, lower row 18.
# The five art rows run from the third interior tile row; bottom/top show same tile pattern.
for name,table in [('mapon',0xdd00),('mapoff',0xdd40),('textoff',0)]:
 lab(name);set16(0x1801,0x4300);set8(0xff,0x4304);set8(0x80,0x2115)
 put('af f2 97 7e c9 01' if name=='textoff' else 'af f1 97 7e c9 01');rel('f0',name+'top');jmp(name+'bottom')
 for place,base in [('top',1),('bottom',18)]:
  lab(name+place)
  set16(table,0x4302)
  for y in range(0 if name=='textoff' else 5):
   set16(0x4000+32*(base+2+y)+2,0x2116);set16(10,0x4305);set8(1,0x420b)
  for row in range(0 if name=='mapoff' else 8):
   set16(0xd900 if name=='mapon' else 0xd920+row*12,0x4302)
   set16(0x4400+32*(base+row)+2,0x2116);set16(12,0x4305);set8(1,0x420b)
  put('60')
# Raster table uses mode 3: CGADD twice, then CGDATA twice. One color per HBlank.
# Nonrepeating HDMA records still transfer once on entry, so hold a harmless copy
# of color 1 for each intervening band. Direct table lives in the field text scratch.
lab('initpalette');put('8b a9 7e 48 ab')
# Only face changes require copying the palette and static raster records.
rx('a2',0xd990);rx('a0',0x96fb)
put('c2 20 a9 89 00 54 7e ff') # 138-byte HDMA template
put('a5 c6 29 ff 00 3a 0a aa bf 40 dc ff aa')
rx('a0',0x9706);put('a9 3b 00 54 7e ff e2 20')
put('a5 bc c9 01');rel('f0','istop');put('a9 7f');rel('80','first')
lab('istop');put('a9 08');lab('first');put('8d 00 97 ab 60')
lab('palette');put('8b a9 7e 48 ab c2 20')
# The map may animate its palette. Restore the current colors on every frame.
put('ad fe 74 8d 40 97 ad a2 74 8d 03 97 8d fe 96 ad 08 97 8d 45 97')
for i in range(15):
 rx('ad',0x74a2+2*i);rx('8d',0x974a+4*i)
put('e2 20 ab');set16(0x2103,0x4300)
put('a5 bc c9 01');rel('f0','hdtop');rx('a2',0x96fb);rel('80','hdstart')
lab('hdtop');rx('a2',0x9700);lab('hdstart');rx('8e',0x4302);set8(0x7e,0x4304);put('60')
for pos,n,k in refs:
 a=labels[n]
 if k=='rel':
  relv=a-pos-1;assert -128<=relv<=127,(n,relv);code[pos]=relv&255
 else:code[pos:pos+2]=word(origin+a)
for old,new in [('bf 01 21 fb','bf 01 d0 f6'),('bf 00 21 fb','bf 00 d0 f6')]:
 start=rom.index(bytes.fromhex(old),0x3b2000,0x3b2021)
 wr(start,bytes.fromhex(new))
wr(0x844b,bytes([0x5c])+(0xff0000+origin+labels['marker']).to_bytes(3,'little')+b'\xea')
# Keep the native vector and its DMA paths byte-identical on frames without a portrait.
nmi=bytearray(rom[0x0182:0x0238])
def patch_at(buf,offset,src,data):
 assert buf[offset:offset+len(src)]==src
 buf[offset:offset+len(src)]=data
patch_at(nmi,0x207-0x182,bytes.fromhex('20 3e 88'),bytes.fromhex('20 a2 dd'))
patch_at(nmi,0x20a-0x182,bytes.fromhex('20 03 86'),bytes.fromhex('20 62 dd'))
nmi+=b'\x22'+(0xff0000+origin+labels['vblank']).to_bytes(3,'little')+bytes.fromhex('4c 3d 02')
wr(0xdc82,nmi)
draw=bytearray(rom[0x8603:0x8642])
choice=bytearray(rom[0x883e:0x88aa])
# Preserve conditional indent during the portrait close animation.
def address(buf,offset,length,label):
 old=buf[offset:offset+length]
 assert old[:2]==bytes.fromhex('c2 21')
 buf[offset:offset+length]=b'\x22'+(0xff0000+origin+labels[label]).to_bytes(3,'little')+b'\xea'*(length-4)
address(draw,0x8611-0x8603,7,'indent')
address(choice,0x884e-0x883e,7,'indent');address(choice,0x8881-0x883e,8,'choice')
wr(0xdd62,draw);wr(0xdda2,choice)
# Field synchronous draw also uses the current portrait indent.
wr(0x8057,bytes.fromhex('20 68 dd'))
wr(0x3f0000+origin,bytes(code))
raster=bytearray(138)
def record(address,values):raster[address-0x96fb:address-0x96fb+len(values)]=bytes(values)
record(0x96fb,[17,0x51,0x51]);record(0x9700,[8,0x51,0x51]);record(0x9705,[0x8f])
record(0x9742,[41,0x51,0x51]);record(0x9747,[0x8f])
for i in range(15):record(0x9748+4*i,[0x51+i,0x51+i])
wr(0x3fd990,raster)
wr(0x3fd910,b'\x00');wr(0x3fd900,word(0x21ff)*6)
wr(0x3fd920,b''.join(word(0x2100+64*(y//2)+2*x+y%2) for y in range(8) for x in range(6)))
wr(0x3fdc00,b''.join(word(0x3400+800*i) for i in range(23)))
wr(0x3fdc40,b''.join(word(0xde00+60*i) for i in range(23)))
wr(0x3fdd00,b''.join(word(0x3400+(a//16)) for a in tileaddrs))
window=rom.index(bytes.fromhex('f0 f0 f1 f2 f1 f2 f1 f2'),0x3000,0x3800)
wr(0x3fdd40,b''.join(word(0x3e00+rom[window+32*(y+2)+2+x]) for y in range(5) for x in range(5)))
options.output.write_text(json.dumps(patches), encoding='utf8')
