// Keep the existing icons, object IDs and record widths at every call site.
function gbaMenuNames(rom,cart){
    const summary={};
    function group(label,count,offset,addresses,width,skip=0,bank='text1',remap=i=>i){
        let imported=0,retained=0;
        for(let i=0;i<count;i++){
            const targets=addresses(i);
            if(!targets.length)continue;
            let tokens=gbaTokens(cart,bank,offset+remap(i));
            if(skip && tokens[0]?.startsWith('\\'))tokens=tokens.slice(1);
            if(!tokens.length)continue;
            let bytes=[];
            try{for(const t of tokens){
                if(t.startsWith('\\'))throw Error('non-name');
                bytes.push(...(t===' '?[0xfe]:gbaGlyph(t,gbaFormat.battleGlyphs)));
            }}catch{retained++;continue;}
            if(bytes.length>width-skip){retained++;continue;}
            for(const a of targets){
                rom.fill(255,a+skip,a+width);rom.set(bytes,a+skip);
            }
            imported++;
        }
        summary[label]={imported,retained};
    }
    const plain=(base,width)=>i=>[base+i*width];
    group('characters',64,0x11a,plain(0x478c0,6),6);
    group('commands',30,0x15a,plain(0x18cea0,7),7);
    group('items',255,0x17a,plain(0x12b300,13),13,1);
    const extra=[270,265,261,260,262,257,256,268,258,259,264,266,263,267,269];
    group('bonus items',15,0x17a,plain(0x360080,13),13,1,'text1',i=>extra[i]);
    group('spells',54,0x29b,i=>[0x3059bd+i*7,0x26f567+i*7],7,1);
    group('espers',27,0x2d1,i=>[0x305c10+i*8,0x26f6e1+i*8],8);
    group('bonus espers',4,0xa5b,plain(0x305c10+27*8,8),8);
    group('summons',27,0x39b,i=>[0x305d08+i*10,0x26fe8f+i*10],10);
    group('monsters',382,0x40f,i=>[367,372,380].includes(i)?[]:[0x384bec+i*10,0xfc050+i*10],10);
    group('battle abilities',175,0x13ed+0x51,plain(0x26f7b9,10),10,0,'text2');
    group('monster specials',382,0xcbe,i=>[367,372,380].includes(i)?[]:[0x385d94+i*10,0xfd0d0+i*10],10,0,'text2');
    group('dance',8,0x3b6,plain(0x26ff9d,12),12);
    group('bushido',8,0xa76,plain(0xf3c40,12),12);
    group('status',32,0x784,plain(0x2ade1,10),10);
    return summary;
}
// The stock text buffer is also used by shops. Each imported description
// occupies just four bytes there. The renderer reads its words from ROM.
function gbaMenuDescriptions(rom,cart,terms=null){
    const summary={},tableStore=gbaWriter(rom,0x3a5400,0x3afc00);
    gbaCheckFill(rom,0x3a5400,0x3afc00);gbaCheckFill(rom,0x314200,0x320000);
    const widths=rom.subarray(0x48fc0,0x490c0), map=gbaFormat.battleGlyphs;
    const extra=[270,265,261,260,262,257,256,268,258,259,264,266,263,267,269];
    let nextText=0x314200;
    function storeText(bytes){
        if(!(nextText&255))nextText++;
        const at=nextText;nextText+=bytes.length;
        gbaAssert(nextText<=0x320000,'Description text bank is full');
        rom.set(bytes,at);return [4,...gbaWord(at),0];
    }
    function wrap(tokens){
        const text=tokens.map(t=>t==='\\n'?' ':t==='\\xC2:A1'?'“':t).join('').trim();
        gbaAssert(!text.includes('\\'),'Unknown menu description symbol');
        const words=text.split(/\s+/), lines=[];let chars=[],pixels=0;
        for(const word of words){
            const b=Array.from(word).flatMap(t=>gbaGlyph(t,map)),w=b.reduce((sum,c)=>sum+(widths[c-96]||8),0);
            gbaAssert(w<=204,'Menu description word exceeds the pane');
            if(chars.length&&pixels+(widths[159]||5)+w>204){lines.push(chars);chars=[];pixels=0;}
            if(chars.length){chars.push(255);pixels+=widths[159]||5;}
            chars.push(...b);pixels+=w;
        }
        if(chars.length)lines.push(chars);
        return lines;
    }
    function prepare(descId,nameId){
        const desc=gbaTokens(cart,'text1',descId);
        if(!desc.length)return null;
        let lines=wrap(terms?terms.text(desc,"description",descId):desc);
        if(nameId!=null){
            const name=gbaTokens(cart,'text1',nameId).filter(t=>!t.startsWith('\\'));
            if(name.length)lines=[...wrap(terms?terms.text(name,"description title",nameId):name),...lines];
        }
        const out=[];
        lines.forEach((row,i)=>{if(i)out.push(i%2?1:2);out.push(...row);});
        out.push(lines.length>2?3:0);return {stub:storeText(out),pages:Math.ceil(lines.length/2)};
    }
    function group(label,hook,count,donor,name=()=>null,shared=false){
        const oldTable=(rom[hook+11]&63)*65536+gbaRead16(rom,hook+1);
        const oldBase=(rom[hook+(shared?11:15)]&63)*65536+gbaRead16(rom,hook+6);
        const table=tableStore(new Uint8Array(count*2)),stats={imported:0,paged:0,retained:0};
        for(let i=0;i<count;i++){
            const id=donor(i),entry=id==null?null:prepare(id,name(i));
            let bytes;
            if(entry){bytes=entry.stub;stats.imported++;if(entry.pages>1)stats.paged++;}
            else{
                stats.retained++;bytes=[];
                if((label==='magic'&&i>=54&&i<=81)||(label==='items'&&i===255)||i>=20&&label==='rare items')bytes=[0];
                else{
                    const start=oldBase+gbaRead16(rom,oldTable+2*i);
                    for(let p=start;p<start+1024;p++){const c=rom[p];bytes.push(c);if(c===0&&![28,29,30,31].includes(bytes.at(-2)))break;}
                    gbaAssert(bytes.at(-1)===0,'Missing native description terminator');
                }
            }
            rom.set(gbaWord(tableStore(bytes)),table+2*i);
        }
        rom.set(gbaWord(table),hook+1);rom.set([0,0],hook+6);rom[hook+11]=0xfa;if(!shared)rom[hook+15]=0xfa;
        summary[label]=stats;
    }
    const textName=(id,width)=>{
        if(terms)return null;
        const t=gbaTokens(cart,'text1',id).filter(t=>!t.startsWith('\\'));return t.length>width?id:null;
    };
    group('items',0x38361,256,i=>i===255?null:0x5f9+i,i=>textName(0x17a+i,12));
    group('magic',0x35c42,85,i=>i<54?0x708+i:({82:0xa5f,83:0xa61,84:0xa60}[i]),i=>i<54?textName(0x29b+i,6):null);
    group('lore',0x3574a,24,i=>0x5e1+i);
    group('bushido',0x3575f,8,i=>0x73e+i);
    group('blitz',0x35774,8,i=>0x746+i);
    group('esper level bonuses',0x35c55,17,i=>0x5c9+i);
    group('summons',0x35c68,31,i=>i<27?0x764+i:0xa62+i-27);
    group('rare items',0x38392,22,i=>i<20?0x74e+i:i===21?0x763:0x707,i=>i<20?textName(i<2?0x5b6+i:i<=5?0x5b8:0x5b3+i,13):null,true);
    const bonus={imported:0,paged:0};
    extra.forEach((id,i)=>{
        const e=prepare(0x5f9+id,textName(0x17a+id,12));gbaAssert(e,'Bonus item has no description');
        const hook=0x3f753+i*10;
        gbaAssert(rom[hook]===0xc9&&rom[hook+1]===254-i&&rom[hook+4]===0xa2,'Bonus description reader');
        rom.set(e.stub,0x30000+gbaRead16(rom,hook+5));bonus.imported++;if(e.pages>1)bonus.paged++;
    });
    summary['bonus items']=bonus;
    gbaCheckFill(rom,0x3f9fa,0x3f9fe);rom.set([0x20,0x26,0xa8,0x6b],0x3f9fa);
    const routine=nativeCode(rom,0x399280,(e,m,b)=>{
        // X is the text position, Y is the native text task, $ED is its graphics cursor.
        e(0xaf,0xc9,0x9e,0x7e,0xc9,4);b(0xf0,'external');
        e(0xbf,0xc9,0x9e,0x7e);b(0x80,'character');
        m('external');e(0x5a,0x9b,0xc2,0x20,0xaf,0xca,0x9e,0x7e,0x85,0xe7,0xe2,0x20,0xa9,0xf1,0x85,0xe9,0xb7,0xe7,0x7a,0xc9,2);b(0xf0,'page');e(0xc9,3);b(0xf0,'page');
        m('character');e(0xc9,0);b(0xf0,'end');e(0xc9,1);b(0xf0,'line');e(0x5c,0x05,0xa9,0xc3);
        m('end');e(0x5c,0x2c,0xa9,0xc3);m('line');e(0x5c,0xf7,0xa8,0xc3);
        // The high bit of the task's graphics position is free while parked at a page marker.
        m('page');e(0x48,0xc2,0x20,0xb9,0x4a,0x34);b(0x30,'count');e(0xa9,0x97,0x80);
        m('count');e(0x3a,0x99,0x4a,0x34,0xc9,0,0x80);b(0xf0,'flip');e(0xe2,0x20,0x68,0x5c,0x1b,0xa9,0xc3);
        m('flip');e(0xa9,0,0,0x99,0x4a,0x34,0xe2,0x20,0x64,0x8d,0xda,0x5a,0x22,0xfa,0xf9,0xc3,0x7a,0xfa,0x68,0xc9,3);b(0xd0,'advance');e(0xa2,0xff,0xff);m('advance');e(0x5c,0x0d,0xa9,0xc3);
    });
    rom.set([0x5c,...gbaLong(routine)],0x3a8ed);
    return summary;
}
