gbaLabels.en.portraits='Show character portraits in framed field dialogue';
gbaLabels.es.portraits='Mostrar retratos de personajes en los cuadros de diálogo';
const previousPortraitHashes={"4b20473031bec41e906431f6e36c786feaf079cceaed1c12e52f82e691194121":["hybrid",true,true],"761716b432e32bb8faa538f1a4ee7fc6afbcd7e79c4fd9e586092bde867007c2":["hybrid",true,false],"6d79b553c43eaae0658122961c6a60ac9229615818d7bc9bc338f8685dbdf8d7":["hybrid",false,true],"a36268c1c2842581ab932e0dd73e2f1bdc11b52c0aa576c4d5ab92fe5c235f08":["hybrid",false,false],"6eac55385abf4133acb8a725766d28af8e5c7326eee96c6b79e58a749bb3eec9":["classic",true,true],"c5aa79cf76c90c7a3f68d7adc6846d3d1b484f26078b5c3143ea0a9487c5cf8f":["classic",true,false],"b39aecac54488054d3ebe07950b6b2c2c804f7dbf987e5883e08fc29d3bcb259":["classic",false,true],"19e625eced76009196323e3d03f80430ca0eb95949d354a113f76048bbeb3b2d":["classic",false,false],"cb102348a1194ce91d7c5456c0aec32e7265ae81776eae6b5331713e8f69fbff":["hybrid",true,true],"38b8506b4e0f14ff74a5a4459b928aafe38ce2f5a4a914c961264a05888a2e4e":["hybrid",true,false],"3b2cb6ddbb9ccdf7e69ef77b9eff7b0f020ee4d6a66edbf88a0f1510ce4a5832":["hybrid",false,true],"a910c48837d0180079c39247420827fffbd612b00b8c8ed183efc7f1060c3019":["hybrid",false,false],"f978cefef0f52c8e47ca131e7bbbacf8a5026e5ebf5b3503e107a2369a4ca5ca":["classic",true,true],"b749f23429314e656877d1674f5398da8bb17ed24d39ac7ebc06ce5eeb284474":["classic",true,false],"a862c4a90ce198e35f137082e188d94baa1234649a2f6c2cea14acd51a1f2c5e":["classic",false,true],"fcf8c5a64dd1b4dbce2e2c0e18576fd7ddf3e9a0a82062366b295a3d573780e1":["classic",false,false],"209f4d8068c186b7c0bb4ca154b9b2279aebe93a6c32f66d5b40298f9731fbe6":["hybrid",true,true],"de4acded312237f9e0449b480fe672c81f2dbbaa9402917c4399e001da45e211":["hybrid",true,false],"e7f486dd6b654dcbafdc0a4d4e09be4043053243c1ab715199bd89c8330c9962":["hybrid",false,true],"a6ab8e066795a27f504a3ad6baaf9d9123633c91143cf675510ae92dc27f0aa7":["hybrid",false,false],"ae7012319ad18b2880636076d1a031ad2c181c6fdce4dcca46c33c86b180e083":["classic",true,true],"19c45f682de0a6c00392440432c6f65941dfd41f7db4a4f76f4c61c45e40d44b":["classic",true,false],"37fd16dec07dfb5ebe90ef3f06cb63b00b72b5a4dae646e697077dcabf9ba4f7":["classic",false,true],"e1abec1fadaa7a1a663839435d61efc7d966ee8fa8058c9c767a456319f5d012":["classic",false,false],"73ab307ecf611082f20bb4fe8405a99d15a3182aeb09d693898dfaeb9586109e":["hybrid",true,true],"1282db41b682a93545c6326376d6fa164afaabb7a50913757356440028e00cb0":["hybrid",true,false],"235f809b905e4344d6c052fdd8438336e9e020d9428c46f2cbb8cf5281636546":["hybrid",false,true],"d374a09f646091c55ce9b6933b287b5b26da92270138ab84f451a9c5c7c03883":["hybrid",false,false],"0dfd9342d085f13a393f923ffef88ff4877d3dc0ef9061cb2625275843ca270d":["classic",true,true],"923e5acf47e18923f5c972a9e2d487dec479e3503af9c2a04ab71aabe6056f6d":["classic",true,false],"919327b9d99b2cbaef500b05d5ffe9fbaf8f7fe09f0378a6426659a9018c6a81":["classic",false,true],"0f35e3885ddae800d57eb0bf640764118377e962317079130850edabf4bb7b5a":["classic",false,false]};
const releasedPortraitHashes={"abbfc2a99c0a72a1a313c0f5910daa70de08c622986710d0567d8351719e7e63":["hybrid",true,true],"560df9e652623ad74ca20754ff419eec87bf10e4c0561638b4ba1ebd457167d5":["hybrid",true,false],"21c196f537ef0f24c7d7bf23e4ed9286852953a7f11399f466ae2a4b5e4f27b6":["hybrid",false,true],"6f88a2b169929a38e8e113892369fec6dbd8ee766520601c1e213e4557ba03ff":["hybrid",false,false],"44ef2cb2fa01272f78643395aaba7d58036a874ed12b00ad502ee835b2219deb":["classic",true,true],"a0f9e3c117f58a01ddea5671cb4829237ca88299a1766c4541aa554f78e986b8":["classic",true,false],"986091a20a7da0c75820ac0ff611cf35c64b9ba77721971f9047603b28ec7045":["classic",false,true],"9d1ccd1574cacc09f25560e079a5c1f331143669f2f7077557db538a2bb1a719":["classic",false,false]};
const portraitHashes={"3ee2adcc1ea3e0d432e21ce7e4885b9dc113e10a7051739eb469e6912dcfbc07":["hybrid",true,true],"d4b21de3b81dbac7182e1989ec8a6bf5fe84b3182682189ea250440843a136b1":["hybrid",true,false],"a29b019878ee1cec43139ff8adc71321a5af5f2b180cc3602ef58d244d2d1fd7":["hybrid",false,true],"85d7678abd9e6fe2fca656ef8d32e903343b421c7a13cd69662a6eed0d74c5ec":["hybrid",false,false],"57c6f3b53d8a344ffd2d3fcde703940427ff5dff4e8ecd79d5fbf35112eafbaa":["classic",true,true],"c44bb15f059fb3f8351c180959a1db98b7af7a137f03e37cf0fabf86aabc530d":["classic",true,false],"10d295bc3e27ccb5d3c4bc5539964d4cab991646512b62d3ea88ad1e31d53191":["classic",false,true],"552267466817383f4acbe51d6bad4caa7146f3f1fd4e2fe2adb419fc64db1b5d":["classic",false,false]};
const isGbaEdition=edition=>edition==='gba-presentation'||edition==='gba-twue-menus';
function renderGbaPresentation(){
    const l=gbaLabels[lang]||gbaLabels.en;
    document.querySelectorAll('[data-gba]').forEach(n=>n.textContent=l[n.dataset.gba]);
    const edition=gbaReopened?.profile.edition||retailEdition;
    const hybrid=edition==='gba-twue-menus';
    const active=isGbaEdition(edition);
    el('gbaPanel').hidden=!active;
    if(!active)return false;
    const opened=!!gbaReopened;
    const canChange=opened&&!gbaReopened.profile.prior;
    el('reopenPortraitControls').hidden=!canChange;
    if(canChange){
        const remove=!!gbaReopened.profile.portraits;
        el('portraitDonorLabel').hidden=remove;el('portraitDonor').hidden=remove;
        el('changePortraits').textContent=lang==='es'?(remove?'Quitar los retratos de esta ROM':'Añadir retratos a esta ROM'):(remove?'Remove portraits from this ROM':'Add portraits to this ROM');
        el('changePortraits').disabled=building||(!remove&&!el('portraitDonor').files.length);
    }
    el('gbaTwueInputs').hidden=!hybrid;
    for(const node of document.querySelectorAll('[data-gba="title"]'))node.textContent=hybrid?l.twueTitle:l.title;
    for(const node of document.querySelectorAll('[data-gba="intro"]'))node.textContent=hybrid?l.twueIntro:l.intro;
    el('retailPanel').hidden=opened;el('retailEdition').value=edition;
    for(const id of ['retailApply','retailMoleSource','molemanWarning','futureWarning','sayansPanel','battlePanel','optionsPanel','personalButton','personalHint'])el(id).hidden=true;
    el('gbaInputs').hidden=opened;el('retailStatus').textContent='';
    const dash=opened?gbaReopened.profile.options.includes('dash'):el('gbaDash').checked;
    const labels=[l.edition,...(hybrid?[l.twueTitle]:[]),l.withFont,l.text,...((opened?gbaReopened.profile.portraits:el('gbaPortraits').checked)?[l.portraits]:[]),...(dash?[l.dash]:[]),...((opened?gbaReopened.profile.advanceRules:el('gbaRules').checked)?[l.rules]:[])];
    el('selection').replaceChildren(...labels.map(s=>{const item=make('li');item.textContent=s;return item;}));
    el('romStatus').textContent=t('romVerified')+' · '+(opened?(hybrid?l.twueTitle:l.title):retailInput?t('retailDetected')+retailInput.revision:l.edition);
    el('romStatus').className='status ok';
    if(opened&&!result)publishOutput(gbaReopened);
    const missing=!el('gbaCart').files.length||(hybrid&&!el('gbaTwueFile').files.length);
    const reopenMessage=opened&&gbaReopened.profile.updatedPortraits?(lang==='es'?'Tiempos de diálogo con retratos actualizados. Descarga la ROM actualizada.':'Portrait dialogue timing updated. Download your updated ROM.') : opened&&gbaReopened.profile.updatedMenu?(lang==='es'?'Menús actualizados. Descarga la ROM v1.6.10 con tus opciones actuales.':'Menus updated. Download the v1.6.10 ROM with your existing settings.'):l.reopen;
    el('build').hidden=!!result;el('build').disabled=building||missing||!!result;
    el('status').textContent=buildError||(building?t('working'):opened?(gbaReopened.profile.prior?(lang==='es'?'ROM '+gbaReopened.profile.prior+' verificada. Usa tu ROM original para crear v1.6.10.':'Verified '+gbaReopened.profile.prior+' ROM. Select your original SNES ROM to build v1.6.10.'):reopenMessage):result?t('done'):missing?(hybrid?l.twueNeed:l.need):t('ready'));
    el('status').className='status'+(buildError?' error':result?' ok':'');
    el('download').hidden=!result;el('outputName').hidden=!result;
    el('outputName').textContent=result?filename(result.profile)+' · CRC32 '+result.outputCRC32:'';
    return true;
}
for(const id of ['gbaCart','gbaTwueFile','gbaDash','gbaRules','gbaPortraits'])el(id).addEventListener('change',()=>{clearResult();render();});
async function buildGbaUI(){
    clearResult();const revision=buildRevision;
    const snes=el('rom').files[0],retail=retailInput,cart=el('gbaCart').files[0],dash=el('gbaDash').checked,rules=el('gbaRules').checked;
    const portraits=el('gbaPortraits').checked;
    const hybrid=retailEdition==='gba-twue-menus', donor=el('gbaTwueFile').files[0];
    building=true;render();
    try{
        gbaAssert(cart.size===0x800000,'Expected the 8 MiB US GBA cartridge.');
        let regular;
        if(retail)regular=(await buildRetailBase(retail,'regular',null)).bytes;
        else{regular=new Uint8Array(await snes.arrayBuffer());if(regular.length===0x400200)regular=regular.subarray(512);}
        if(revision!==buildRevision)return;
        const cartBytes=new Uint8Array(await cart.arrayBuffer());
        gbaAssert(await hash(cartBytes)===gbaFormat.cart,'Choose Final Fantasy VI Advance (USA), unmodified English cartridge.');
        let menuReference=null;
        if(hybrid){
            const selection={variant:'base',music:'none'};
            try{
                const patches=await readTWUEVariantSources([donor],{},selection);
                const base=await identify(new File([regular],'regular.sfc'));
                menuReference=(await combine(base,new Set(['twue']),{twue:patches},{...selection,variantSource:true})).bytes;
                gbaAssert(await hash(menuReference)==='0d9696ea9c1ea1a5138f7544505d13a5fd48313099dda449908c7df2d43ac100','TWUE menu source mismatch.');
            }catch{throw new Error((gbaLabels[lang]||gbaLabels.en).twueHint);}
        }
        if(revision!==buildRevision)return;
        let output=await gbaPresentation(regular,cartBytes,dash,rules,menuReference);
        const verified=(hybrid?gbaTwueHashes:gbaOutputs)[output.id];
        gbaAssert(verified && verified[0]===dash && verified[1]===rules,'Output checksum did not match the verified build.');
        if(portraits){
            const {bytes}=addFieldPortraits(output.bytes,cartBytes);
            const id=await hash(bytes), expected=portraitHashes[id];
            gbaAssert(expected && expected[0]===(hybrid?'hybrid':'classic') && expected[1]===dash && expected[2]===rules,'Portrait output checksum mismatch.');
            output={bytes,id,profile:{...output.profile,portraits:true}};
        }
        if(revision===buildRevision)publishOutput(output);
    }catch(e){if(revision===buildRevision)buildError=e.message;}
    finally{if(revision===buildRevision){building=false;render();}}
}
async function reopenGba(file){
    if(![0x400000,0x400200].includes(file.size))return null;
    let bytes=new Uint8Array(await file.arrayBuffer());if(bytes.length===0x400200)bytes=bytes.subarray(512);
    if(![0xc2,0x5c].includes(bytes[0x3b2000]))return null;
    let id=await hash(bytes);
    const previousPortrait=previousPortraitHashes[id];
    if(previousPortrait){
        bytes=bytes.slice();
        installDialoguePortraitArtwork(bytes);writeChecksum(bytes);id=await hash(bytes);
        const expected=releasedPortraitHashes[id];
        gbaAssert(expected && expected.every((v,i)=>v===previousPortrait[i]),'Portrait artwork update checksum mismatch.');
    }
    const released=releasedPortraitHashes[id];
    if(released){
        bytes=applyPortraitTiming(bytes); id=await hash(bytes);
        const expected=portraitHashes[id];
        gbaAssert(expected && expected.every((v,i)=>v===released[i]),'Portrait timing update checksum mismatch.');
    }
    const portrait=portraitHashes[id];
    if(portrait){
        const [style,dash,advanceRules]=portrait;
        return {bytes,id,profile:{edition:style==='hybrid'?'gba-twue-menus':'gba-presentation',advanceRules,options:dash?['dash']:[],portraits:true,updatedPortraits:!!released}};
    }
    const hybrid=gbaTwueHashes[id]||gbaTwuePreviews[id];
    if(hybrid){
        const [dash,advanceRules]=hybrid;
        const updatedMenu=!gbaTwueHashes[id];
        if(updatedMenu){
            // Published previews differ only in two positioned menu captions.
            // Authenticate the complete input above, then the entire new output.
            bytes=bytes.slice();
            bytes.set([0x69,0x83,0x8c,0x8f,0xfe,0x82,0xa8,0xac,0xad,0],0x35ce6);
            bytes.set([0x91,0x9e,0xa5,0xa2,0x9c,0],0x337e6);
            writeChecksum(bytes);id=await hash(bytes);
            const target=gbaTwueHashes[id];
            gbaAssert(target&&target[0]===dash&&target[1]===advanceRules,'Unexpected TWUE menu update checksum.');
        }
        return {bytes,id,profile:{edition:'gba-twue-menus',advanceRules,options:dash?['dash']:[],updatedMenu}};
    }
    const target=gbaOutputs[id]||gbaFormat.priorOutputs[id];
    if(!target)return null;
    const profile={edition:'gba-presentation',prior:target[2]||null,advanceRules:target[1],options:target[0]?['dash']:[]};
    if(profile.prior==='v1.6.6'||profile.prior==='v1.6.7'){
        if(profile.prior==='v1.6.6')fixGbaMenuLayout(bytes);
        shortenGbaMagicStats(bytes);
        writeChecksum(bytes);
        id=await hash(bytes);
        const expected=gbaOutputs[id];
        gbaAssert(expected&&expected[0]===target[0]&&expected[1]===target[1],'Unexpected menu update checksum.');
        profile.prior=null;
        profile.updatedMenu=true;
    }
    return {bytes,id,profile};
}

function removeFieldPortraits(input){
    const out=input.slice();
    for(const [addr,original] of portraitTimingMachine){
        out.set(Uint8Array.from(original.match(/../g),v=>parseInt(v,16)),addr);
    }
    for(const [lo,hi] of [...portraitBanks,[0x306000,0x306000+3*0xfd0],
        [0x3f3400,0x3f3400+800*23],[0x3fde00,0x3fde00+60*23]])out.fill(255,lo,hi);
    writeChecksum(out);
    return out;
}
el('portraitDonor').addEventListener('change',()=>{clearResult();render();});
el('changePortraits').addEventListener('click',async()=>{
    const input=gbaReopened;
    if(!input || input.profile.prior || building)return;
    const donor=el('portraitDonor').files[0];
    clearResult();const revision=buildRevision;building=true;render();
    try{
        const turnOn=!input.profile.portraits;
        let bytes;
        if(turnOn){
            gbaAssert(donor?.size===0x800000,'Select the US GBA cartridge.');
            const gba=new Uint8Array(await donor.arrayBuffer());
            gbaAssert(await hash(gba)===gbaFormat.cart,'Choose the unmodified US GBA game.');
            bytes=addFieldPortraits(input.bytes,gba).bytes;
        }else bytes=removeFieldPortraits(input.bytes);
        const id=await hash(bytes),hybrid=input.profile.edition==='gba-twue-menus';
        const target=turnOn?portraitHashes[id]:(hybrid?gbaTwueHashes:gbaOutputs)[id];
        const dash=input.profile.options.includes('dash'), rules=input.profile.advanceRules;
        gbaAssert(target && (turnOn?target[0]===(hybrid?'hybrid':'classic') && target[1]===dash && target[2]===rules:
            target[0]===dash && target[1]===rules),'Unexpected output checksum.');
        if(revision!==buildRevision)return;
        gbaReopened={id,bytes,profile:{...input.profile,portraits:turnOn,updatedMenu:false,updatedPortraits:false}};
        publishOutput(gbaReopened);
    }catch(e){if(revision===buildRevision)buildError=e.message;}
    finally{if(revision===buildRevision){building=false;render();}}
});

