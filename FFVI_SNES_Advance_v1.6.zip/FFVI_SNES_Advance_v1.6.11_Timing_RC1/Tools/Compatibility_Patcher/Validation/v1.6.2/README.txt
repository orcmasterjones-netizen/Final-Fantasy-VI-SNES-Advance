Release checks for SNES Advance v1.6.2

82 existing ROM profiles passed install, recognition on reopen, and removal back to the exact input bytes. The set includes native audio and MSU-1, 4 MiB and 8 MiB ROMs, Regular, MoleMan, ROSE, TWUE, Spanish, fonts and battle modes. The executable HTML form was exercised in a Node DOM harness through its change, build and download handlers, including clean USA v1.0 and v1.1, a copier header, independent toggles, and rejection of a modified adapter.

Snes9x ran the actual ROM code. The Regular opening replay matched v1.6.1 with the option off at three input phases, through the return to the field. A CPU trace placed entry and exit from new-game initialization at the same scanline and master clock. The 264 frame-phase input checks for Fight, Magic, Item, Lore, Rage, and Dance matched for menu feedback, readiness and the measured execution milestones.

All 69 bonus formations registered the expected enemy IDs on Regular, MoleMan, ROSE and TWUE with MSU-1. These tests requested each formation from a controlled field state, then ran the native battle loader. A separate full-log fixture inspected all 399 displayed cards on five builds and compared their stats, affinity groups, and loot references with each ROM. Supplemental tests covered the final-battle formations and distinguished actual enemy 255 from empty slots. Screenshots in Bestiary/ use a seeded journal to display the requested entries.

Native save/load checks covered all three slots, saving across slots, old battery saves, invalid log signatures, New Game with stale working data, and cold-reloading a post-Kefka clear save on Regular, MoleMan and ROSE. The clear-save test also checked the existing added inventory quantities, spell data, Esper ownership and the return to the Falcon.

Results.json contains profile hashes and replay milestones. These are emulator tests with scripted inputs and controlled fixtures. Physical cartridges and a complete manual playthrough of every option combination were outside this test set.
