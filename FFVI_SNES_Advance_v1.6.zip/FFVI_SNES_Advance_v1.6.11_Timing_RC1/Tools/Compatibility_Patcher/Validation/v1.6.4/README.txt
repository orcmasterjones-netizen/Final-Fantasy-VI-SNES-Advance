SNES Advance v1.6.4 release checks

The US GBA ROM’s 384 numbered records were compared with the 400 unique enemy records in the release. The SNES table includes every GBA entry plus 16 additional records. All existing enemy IDs retain their relative order. The Phantom Train location is the only change to the 399 previous cards.

In Snes9x, the normal Phantom Train formation unlocked only the 100-HP Siegfried card. Wagering a Megalixir and selecting a fighter through the native Coliseum menu unlocked only the 32,760-HP Siegfried card. The tests used a controlled field state to enter each encounter. The Config route, page navigation, B return and Select shortcut were also exercised on Regular, MoleMan, TWUE and ROSE. We checked the locations and HP on screen and browsed both cards together on Regular, MoleMan, Spanish, ROSE and all four TWUE Music Player layouts.

We generated both encounter flags on each prior Bestiary release, used its native save menu to save the journal, then loaded the battery save on v1.6.4. Both cards appeared after Continue. Separate save tests exercised the three slots and New Game. Full-catalog tests opened all 400 cards on Regular, ROSE and MoleMan with long names and checked their monster data, loot and elemental affinities against the ROM.

All 82 reference profiles passed fresh installation, recognition and removal, plus direct upgrade from v1.6.2 and from v1.6.3. Upgrading produced the same bytes as a fresh installation. Removal restored the input bytes. Four additional TWUE Music Player layouts also passed direct upgrade from v1.6.3 and exact removal. The patcher form tests covered clean US v1.0/v1.1 input, headers, option selection and downloads.

Three opening battle replays and 264 battle input trials matched the previous no-Bestiary reference at the measured milestones. The distributed source reassembled to the installed ROM bytes after accounting for the header checksum. The standalone patcher matches the copy in the full release. Individual file hashes are in the full release manifest.
