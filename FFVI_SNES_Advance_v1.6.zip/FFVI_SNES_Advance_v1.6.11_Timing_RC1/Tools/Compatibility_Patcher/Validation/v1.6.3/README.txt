SNES Advance v1.6.3 release checks

The offline patcher built and recognized the Bestiary on 82 reference profiles. Removing it restored the input bytes on all 82. Reopening the corresponding v1.6.2 Bestiary builds and upgrading produced the same bytes as a fresh build. Four additional TWUE Music Player builds (Config 1, Config 2, Main Menu A and Main Menu B) passed install, recognition and exact removal. In each layout the player opened, allowed a track selection and returned to its parent menu. The player screens before and after track selection matched the corresponding build with Bestiary disabled, pixel for pixel.

In Snes9x, scripted controller input opened Config page two, selected the visible Bestiary row, browsed the entries, and returned to that row. Left and Right on Bestiary preserved the preference values. L switched back to the first Config page. The existing Select shortcut returned to the main menu. The test covered Regular, MoleMan, Multi-Font, Spanish, ROSE and all four TWUE Music Player layouts.

The screenshot fixture requested the four actual final-battle formations from a controlled field state. The tracker registered each encounter. The resulting flags supplied the ten-entry journal used for the screenshots. The Regular menu screenshots use the game's default blue palette. A separate full-journal fixture checked all 399 cards against the Regular edition’s name, stat, elemental-affinity and loot tables.

The opening battle matched the reference with the Bestiary disabled through return to the field at three input phases. The 264 Fight, Magic, Item, Lore, Rage and Dance input trials matched the reference for the measured milestones. Native battery-save tests covered loading three slots, saving across slots, and cold loading an existing v1.6.2 clear save containing a bestiary log.

The distributed assembly reproduced the installed adapter. Both release archives contain the same patcher files. Results.json contains individual hashes and milestones.
