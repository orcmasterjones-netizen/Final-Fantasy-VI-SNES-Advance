// v1.6.12. Keep the independently verified donor/canonical build available on
// reopen. All ROM edits have original-byte guards. No emulator or network needed.
const fieldActorRecipes=[{"checks":[[3749753,"eefffc050000f71dfb0200ff"],[3749886,"fc0d0003f80000f136f600e8e9fef003059bfdf0eeeeeffdf0ee1a19fffc120000f34b00fb0200fefc050000f0eefefef80081ff"]],"edits":[[195456,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff","08c96ff008c974f016284c712dc22048a97937995432a97b37996832682860c22048a9fe37995432a91b38996832682860"],[143422,"20712d","2080fb"]]},{"checks":[[3749754,"eefffc050000f71dfb0200ff"],[3749887,"fc0d0003f80000f136f600e8e9fef003059bfdf0eeeeeffdf0ee1a19fffc120000f34b00fb0200fefc050000f0eefefef80081ff"]],"edits":[[195456,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff","08c96ff008c974f016284c712dc22048a97a37995432a97c37996832682860c22048a9ff37995432a91c38996832682860"],[143422,"20712d","2080fb"]]},{"checks":[[3749748,"eefffc050000f71dfb0200ff"],[3749881,"fc0d0003f80000f136f600e8e9fef003059bfdf0eeeeeffdf0ee1a19fffc0a4036fb0c07f34b00fb0200fefc050000f0eefefef80081ff"]],"edits":[[195456,"ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff","08c96ff008c974f025284c4ff8c2204899a833a97437995432a9763799683268e220a920992d32a90099813c2860c2204899a833a9f937995432a9163899683268e220a920992d32a90099813c2860"],[143422,"204ff8","2080fb"]]}];
const fieldEditGroups={"doma":[[762092,"3d024602473e033e0545b2fea001fefefefe","3d023f02024602473e033e0545b2fea001fe"]],"shop":[[224795,"d4","d5"],[224803,"c0fe","0000"]],"book":[[261288,"ffffffffffffffffffffffffffffffffffffffffff","602960696079609960a960b908c9225458fd4c290e"],[261359,"ffffffffffffffffffffffffffffffffff","207e1ca901854a20eb39a906854e4c8838"],[211081,"4b29","a8fc"],[211267,"5929","b6fc"],[4020305,"7ca3","effc"],[207179,"602960696079609960a960b908c9225458fd4c290e","ffffffffffffffffffffffffffffffffffffffffff"],[238460,"207e1ca901854a20eb39a906854e4c8838","ffffffffffffffffffffffffffffffffff"]],"font":[[261499,"ffffffffffffffffffffffffffff","84e7a9c385e9a6009bc2204c0503"],[211904,"fa02","7bfd"],[211963,"fa02","7bfd"],[243596,"fa02","7bfd"],[243733,"fa02","7bfd"],[243823,"fa02","7bfd"],[244179,"fa02","7bfd"]]};
const fieldStampAt=0x2fbe0;
const fieldStamp=[0x53,0x4e,0x41,0x31,0x32,0x01];
function fieldHex(s){return Uint8Array.from(s.match(/../g)||[],c=>parseInt(c,16));}
function fieldIs(b,p,a){return a.every((v,i)=>b[p+i]===v);}
function fieldEdits(recipe,mask){
    const edits=fieldActorRecipes[recipe].edits.slice();
    for(const [i,name] of ['doma','shop','book','font'].entries())if(mask&(1<<i))edits.push(...fieldEditGroups[name]);
    return edits;
}
function fieldWrite(b,where,before,after){
    if(!fieldIs(b,where,before))throw failure('verifyFail');
    b.set(after,where);
}
function applyFieldFixes(source){
    if(fieldIs(source,fieldStampAt,fieldStamp))throw failure('verifyFail');
    const recipe=fieldActorRecipes.findIndex(r=>r.checks.every(([at,s])=>fieldIs(source,at,fieldHex(s)))&&fieldIs(source,0x2303e,fieldHex(r.edits[1][1])));
    if(recipe<0||!fieldIs(source,0x22fe8,[0xbf,0x5b,0xe2,0xf4]))throw failure('verifyFail');
    let mask=0;
    if(fieldIs(source,0xba0ec,fieldHex(fieldEditGroups.doma[0][1])))mask|=1;
    if(source[0x36e1b]===0xd4&&retailBaseMerger.crc32(source.subarray(0x150000,0x1503c0))===2619891484)mask|=2;
    if(fieldIs(source,0x3a37c,fieldHex('207e1ca901854a20eb39a906854e4c8838')))mask|=4;
    if(fieldIs(source,0x30300,fieldHex('5c00d9ffea')))mask|=8;
    const b=source.slice(),wide=b.length===0x800000;
    let mirrored=0;
    fieldEdits(recipe,mask).forEach(([at,oldHex,newHex],i)=>{
        const before=fieldHex(oldHex),after=fieldHex(newHex);
        fieldWrite(b,at,before,after);
        if(wide&&at<0x100000&&fieldIs(b,at+0x400000,before)){fieldWrite(b,at+0x400000,before,after);mirrored|=1<<i;}
    });
    const stamp=Uint8Array.from([...fieldStamp,recipe,mask,mirrored&255,(mirrored>>>8)&255,(mirrored>>>16)&255,(mirrored>>>24)&255,...source.slice(0xffdc,0xffe0),...(wide?source.slice(0x40ffdc,0x40ffe0):[])]);
    fieldWrite(b,fieldStampAt,new Uint8Array(stamp.length).fill(255),stamp);
    if(wide)writeROSEChecksum(b);else writeChecksum(b);
    return b;
}
async function restoreFieldFile(file){
    const size=file.size&~0x3ff;
    if(![0x400000,0x800000].includes(size))return file;
    const head=file.size-size,offset=head+fieldStampAt;
    if(!fieldIs(new Uint8Array(await file.slice(offset,offset+fieldStamp.length).arrayBuffer()),0,fieldStamp))return file;
    const src=new Uint8Array(await file.slice(head).arrayBuffer()),b=src.slice(),wide=b.length===0x800000;
    const stamp=b.slice(fieldStampAt,fieldStampAt+(wide?20:16)),recipe=stamp[6],mask=stamp[7];
    if(!fieldActorRecipes[recipe]||mask>15)throw failure('verifyFail');
    const mirrored=new DataView(stamp.buffer).getUint32(8,true);
    for(const [i,[at,oldHex,newHex]] of fieldEdits(recipe,mask).entries()){
        const before=fieldHex(oldHex),after=fieldHex(newHex);
        fieldWrite(b,at,after,before);
        if(mirrored&(1<<i))fieldWrite(b,at+0x400000,after,before);
    }
    b.fill(255,fieldStampAt,fieldStampAt+stamp.length);
    b.set(stamp.slice(12,16),0xffdc);if(wide)b.set(stamp.slice(16,20),0x40ffdc);
    // Also check the marker, inverse recipe, checksum and mirrored-ROM result.
    // Edition-specific verification of the recovered original follows as usual.
    const check=applyFieldFixes(b);if(!src.every((v,i)=>v===check[i]))throw failure('verifyFail');
    return new File([b],file.name);
}
