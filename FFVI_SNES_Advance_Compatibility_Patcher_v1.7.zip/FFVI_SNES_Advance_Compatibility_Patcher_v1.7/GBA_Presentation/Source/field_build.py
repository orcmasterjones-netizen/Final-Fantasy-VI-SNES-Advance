from pathlib import Path
def add_field_fixes(s):
    js=(Path(__file__).parent/'field_fixes.js').read_text(encoding='utf-8')
    # The verified profile, optional donor data and reversible profile logic use the
    # preceding release representation. Only files entering or leaving the UI are converted.
    s=s.replace('const controls=new Map()',js+'\nconst controls=new Map()',1)
    s=s.replace("const file=el('rom').files[0];reading=!!file;render();if(!file)return;\n    try{","let file=el('rom').files[0];reading=!!file;render();if(!file)return;\n    try{\n        file=await restoreFieldFile(file);",1)
    s=s.replace("                acceptCurrent(found);","                acceptCurrent(found);\n                if(!found.upgrade){const raw=new Uint8Array(await file.slice(-(file.size>=0x800000?0x800000:0x400000)).arrayBuffer());if(token!==romRevision)return;preparedBase={...found,bytes:raw};}",1)
    s=s.replace("    if(resultUrl)URL.revokeObjectURL(resultUrl);\n    resultUrl=URL.createObjectURL(new Blob([output.bytes]", "    const published=output.profile.prior?output.bytes:applyFieldFixes(output.bytes);\n    if(resultUrl)URL.revokeObjectURL(resultUrl);\n    resultUrl=URL.createObjectURL(new Blob([published]",1)
    s=s.replace('else{regular=new Uint8Array(await snes.arrayBuffer());','else{regular=new Uint8Array(await (await restoreFieldFile(snes)).arrayBuffer());',1)
    s=s.replace('retailBaseMerger.crc32(output.bytes).toString','retailBaseMerger.crc32(published).toString')
    s=s.replace('v1.6.11 · Portrait Timing RC1','v1.6.12').replace("const gbaPreviewName = 'FFVI_SNES_Advance_v1.6.11","const gbaPreviewName = 'FFVI_SNES_Advance_v1.6.12").replace("return 'FFVI_Advance_v1.6.11_","return 'FFVI_Advance_v1.6.12_")
    s=s.replace('Usa tu ROM original para crear v1.6.11','Usa tu ROM original para crear v1.6.12').replace('to build v1.6.11','to build v1.6.12')
    assert s.count('file=await restoreFieldFile(file)')==1 and 'Blob([published]' in s
    return s
