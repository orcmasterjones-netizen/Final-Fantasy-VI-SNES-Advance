Rebuilding the v1.6.12 compatibility patcher

Run python build_patcher.py original-v1.6.5.html output.html with the original SNES Advance v1.6.5 compatibility patcher as input. Use the scripts and JSON files in this folder together.

Verified_outputs.json identifies the four GBA Presentation outputs. TWUE_outputs.json identifies the four GBA Presentation + TWUE menus outputs. Each SHA-256 maps to a pair of switches in B-Dash, GBA battle rules order. TWUE_preview_hashes.json identifies supported preview upgrades.

twue-menus.js and twue-terms.js import the menu layout and adapt its terminology. The base TWUE 3.07 menu data comes from the player's copy of the TWUE distribution. The preset-specific JavaScript and builder are licensed under GPL-3.0. See ../MultiFont/LICENSE. The original patcher and credited projects retain their respective licenses.

The ROSE ATB adapter is in rose-atb.js. Its loader uses the original ROM bytes in originals.json and the verified output hashes in outputs.json. rose_atb_build.py integrates it into the patcher.

The optional field portrait renderer and UI are in dialogue-portraits.js, dialogue-portrait-ui.js and dialogue-portrait-panel.html. The build inserts the hooks from portrait-machine.json. To regenerate those hooks, run python build_portrait_machine.py GBA_PRESENTATION_TWUE_MENUS.sfc portrait-machine.json with an unheadered, portrait-free GBA Presentation + TWUE menus output. The release was rebuilt byte-for-byte from the original v1.6.5 patcher.

Portrait Timing RC1 adds portrait-timing.js, portrait-timing-machine.json and build_portrait_timing_machine.py. Regenerate the timing machine records with the same portrait-free TWUE-menus reference ROM and the new assembler script. build_patcher.py rebuilds the complete offline HTML, including upgrade from all eight original v1.6.11 portrait profiles.

Version 1.6.12 adds field_build.py and field_fixes.js. The latter checks original bytes, installs the targeted field and menu fixes, and reverses them when the verified ROM is reopened.
