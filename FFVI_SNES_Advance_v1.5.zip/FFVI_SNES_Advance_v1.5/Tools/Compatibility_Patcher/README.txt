FFVI SNES Advance Compatibility Patcher v1.5

MoleMan v1.8 supports both Standard and Minus Pop-Culture References.
Select MoleMan, open the original ZIP, then use “Edition to use from ZIP”
to choose the text. An extracted BPS selects its edition automatically.
The plain Minus output shows CRC32 91C14C2C. With options, the CRC changes.
Download filenames include MinusPopCulture when the alternate is active.

The patcher in this download is labeled “v1.5 · Shoreline.”
Choose a clean USA ROM, select Regular and click Apply base edition.
The plain Regular download shows CRC32 3B56ABF0. Optional patches
produce different checksums. Both retail revisions use the same BPS
files included in the full release, and the patcher verifies the finished
Regular ROM before enabling the download.

Strago's battle menu now checks the highlighted Lore when confirming a
selection and displaying the initial MP cost. Learned Lores such as
Condemned and Aqua Rake can be selected when Strago has enough MP.

The Dragon Temple water now reaches the stone lip at the north turtle
landing. This room uses color-math preset $07, which blends the water
with both stone layers and keeps the party and turtle in front.
The turtle holds each pose for eight frames while it waits and four while
swimming to a dock or carrying the party.

Existing SNES Advance .srm saves work directly. An emulator state made
inside the turtle room can retain the old display and idle animation.
Leave and re-enter the room, or cycle back to Mog with Y in a three-party
save. Normal Continue loads the new setting immediately.

To update an existing ROM, open the extracted HTML in a fresh tab, choose
the ROM, keep the detected options and select Build ROM. All earlier v1.5
builds and v1.4 are recognized. When updating several differently
configured ROMs, a fresh tab starts each one with its own detected options.
Both clean North American retail revisions are also supported.

Open FFVI_SNES_Advance_Compatibility_Patcher.html in a current browser.
Choose an original North American Final Fantasy III v1.0 or v1.1 ROM, a
supported SNES Advance ROM, or a recognized output from this patcher.
Files are processed locally; the tool works offline.

START FROM THE ORIGINAL GAME
Original ROMs are detected by their complete contents, with or without a
512-byte copier header. Choose Regular (original SNES text) or MoleMan GBA
Text, then select Apply base edition. Regular automatically uses the matching
v1.0/v1.1 base patch. MoleMan requires the original GBA Text BPS or ZIP;
the translation patch is not bundled. Both original-ROM revisions are
supported for either edition.

MoleMan v1.8 is the current tested source, and v1.6 remains supported. Newer
or unrecognized revisions display a warning and must pass compatibility
checks before building. Its supported future-data path is bounded main-field
dialogue with the known executable and other data protected.

The prepared base is ready to download immediately. You can also
choose optional patches and select Build ROM. Previously selected optional
choices in a personal copy remain available. A personal copy can retain the
verified MoleMan patch and chosen base edition for offline reuse; the original
game ROM is never included in that copy. Existing SNES Advance ROMs skip the
base-edition step and keep the same reopening behavior.

FUTURE PATCH VERSIONS
There is no numeric upper-version gate for MoleMan, ROSE, TWUE, Spanish,
clymax Turn-Based, Modern/Classic/CTB ATB, legacy fonts, Multi-Font Selection,
Music Player or its optional fixes. Newer advertised versions and unfamiliar
payloads warn; every source must still pass its compatibility checks.

Supported future changes are deliberately bounded:
- MoleMan and TWUE: main-field dialogue within their protected layouts.
- ROSE: main-field wording/pointers with the same adaptive control operations.
- Spanish: printable glyphs in the existing dialogue positions, preserving
  controls, pointers, patch write coverage and all other data.
- Battle-system, font, Music Player and fix patches: the same verified writes,
  including supported IPS record re-encodings. New functional changes need
  an updated adapter.

The listed versions remain tested baselines, not maximum accepted versions.
A newer filename alone never establishes compatibility. Incompatible code,
assets, controls or data/layout changes stop with an explanation. The original
U.S. FFVI Advance cartridge-font donor is a game image rather than a versioned
patch; its exact original-ROM checks remain required.

Personal copies retain source warnings alongside the selected patch files.
Known byte-identical outputs retain their existing game behavior. This update
adds no game routine, changes no Rage/Dance reader and introduces no new
battle/menu timing or RAM/save-layout change.

ROSE CLEAR-SAVE FIX (RETAINED)
The prior ROSE clear-save repair is included. Open a recognized older ROSE
output and build once to apply it; its original IPS is not required again.
See ROSE_CLEAR_SAVE_VALIDATION.txt for the original test scope.

STANDALONE v1.3 REFRESH (RETAINED)
The refreshed base release includes the Continue/save-restoration and skill-
heading fixes already present in compatibility-patcher outputs. Both refreshed
standalone editions are recognized for upgrading. Older v0.9.20/v0.9.21/v1.3
files remain supported; an update notice refers to the ROM's contents, not
its filename. Existing optional builds and their output hashes are unchanged.

SPELL NAMES AND CATEGORY ICONS
Regular and Spanish with native fonts use the name Gravja, with its black-
magic icon. The shorter name fits the original seven-cell spell record;
the native readers, buffers and memory layout are unchanged. The separate
casting announcement also uses Gravja.

MoleMan, every supported TWUE edition and ROSE retain Gravija in full.
Regular/Spanish with either optional GBA font also retain the full name using
the existing font-compatible eight-cell adapter. Returning to native fonts
restores Gravja and the original seven-cell readers automatically.

Valor uses the support/effect icon in every edition. The added battle spells
use their proper spell-name records, including the routing fixes for MoleMan,
TWUE and ROSE. The new standalone Regular and MoleMan downloads are accepted,
along with the previously supported inputs and older full-name native builds.

Reopen an older recognized ROM and select Build ROM once to apply the latest
corrections while retaining its selected options. Installed font and music
sources are reused; a corrected current ROM does not need another rebuild.

TWUE 3.07
Start from Regular and select one primary edition:
  Base; Base + Updated Opera;
  Bug Fixes; Bug Fixes + Updated Opera;
  Bug Fixes + Add-Ons; Bug Fixes + Add-Ons + Updated Opera.
Supply the original TWUE 3.07 ZIP, or that edition's original IPS. The primary
edition cannot be changed after installation; start from Regular to choose
another. Earlier base TWUE 3.06 IPS and 3.06a/3.07 BPS inputs remain supported.
TWUE is an alternative to MoleMan, Spanish and ROSE, and includes Cancel dash.
When adding TWUE to a Regular ROM with Modern/Classic/CTB already installed,
select that original ATB patch again to adapt its hooks to the new edition.

GBA FONT CHOICES
Multi-Font Selection 1.4.1 is now the default when enabling GBA font in a new
build. Supply the author's original ZIP or Multi_Fonts_1.4.1_nh.ips. Menus use
fixed-width cells; dialogue is proportional. In-game Config defaults to
Advance and offers Normal/Advance; Normal uses the chosen edition's native
font. The selected font survives normal saves.

Our cartridge font remains available. It imports original glyphs from an
unmodified U.S. FFVI Advance ROM (.gba or its ZIP), uses proportional menus,
and supports longer names. Selecting it displays an inline timing note:
some menus and battle item/spell lists may be slightly slower to open or
redraw. The note is hidden when another font is selected or GBA font is off.

Reopening a ROM preserves its installed font. Personal patchers preserve
explicit saved font preferences and their verified source files. The new
default does not silently replace an existing cartridge or legacy font.

Leave GBA font unchecked for native fonts. New builds can switch between the
two font implementations, or return to native fonts, by reopening the ROM.
Old seibaby-font builds did not retain native glyphs: use a native-font base to
choose Multi-Font or native fonts from those builds. Longer item/monster names
require our cartridge font. ROSE retains its separately supported native font.

MUSIC PLAYER
TWUE 3.07 offers Config 1 (Music replaces the Mono option beside Stereo),
Config 2 (a new Music row), or the compatible Main Menu version. Main Menu A
is for Bug Fixes editions; B is for Base editions. Both retain Config.
The player includes SNES Advance's bonus music track.

Optional sound-effect volume, Lete River and caves/cliffs fixes can be selected
independently. Supply the original TWUE ZIP or the chosen player/fix IPS files.
A TWUE ZIP selected in the edition row can also supply the Music Player files.

BUILDING AND REOPENING
Choose one battle system and any compatible extra options, then Build ROM and
Download ROM. Known supported builds are verified, including their reversible
spell-icon correction.
Installed Music/Multi-Font sources are retained for reopening without uploads.
Changing a player placement or adding a new fix requires its original source.
A personal HTML copy retains verified selected sources for private offline use.
Share the public patcher with other players, not a personal copy.

Existing battery saves can continue. Boot normally after changing ROMs; do not
load an emulator state containing code from another ROM. Keep a backup save.
Existing clymax Turn-Based builds retain that battle system; use a build without
clymax when switching away from it.

Read V1.5_SHORELINE_TESTS.txt for the current release checks.
FUTURE_SOURCE_VALIDATION.txt covers the earlier source compatibility tests. MOLEMAN_V18_VALIDATION.txt records the earlier MoleMan checks.
ORIGINAL_ROM_ENTRY_VALIDATION.txt records the earlier original-ROM entry.
STANDALONE_V13_REFRESH_VALIDATION.txt records the preceding base refresh.
GRAVJA_NATIVE_NAMES_VALIDATION.txt records the earlier spell-name update.
SPELL_ICON_AND_FONT_DEFAULTS_VALIDATION.txt records the preceding update.
EXPANDED_OPTIONS_VALIDATION.txt documents the earlier expanded-options release;
it and the other older reports are retained as historical evidence.
No game ROM or original third-party patch is included in this package.
Original author credits/readmes are in Credits/.
