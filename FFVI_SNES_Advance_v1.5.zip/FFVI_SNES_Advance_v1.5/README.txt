Final Fantasy VI • SNES Advance
v1.5 | Strago’s Lore, Dragon Temple water and turtle animation

The patcher in this download is labeled “v1.5 · Shoreline.”
Choose a clean USA ROM, select Regular and click Apply base edition.
The plain Regular download shows CRC32 3B56ABF0. Optional patches
produce different checksums. Both retail revisions use the same BPS
files included in the full release, and the patcher verifies the finished
Regular ROM before enabling the download.

Play the Advance bonus content in the Super NES game. Seek out four new
espers, explore the three-party Dragon’s Den, take on the Soul Shrine,
and save clear data after the ending.

Strago's battle menu now checks the highlighted Lore when confirming a
selection and displaying the initial MP cost. Learned Lores such as
Condemned and Aqua Rake can be selected when Strago has enough MP.

The Dragon Temple water now reaches the stone lip at the north turtle
landing. This room uses color-math preset $07, which blends the water
with both stone layers and keeps the party and turtle in front.
The turtle holds each pose for eight frames while it waits and four while
swimming to a dock or carrying the party.

Existing SNES Advance .srm saves work directly. An emulator state made
inside the turtle room can retain the old display and idle animation.
Leave and re-enter the room, or cycle back to Mog with Y in a three-party
save. Normal Continue loads the new setting immediately.

If you have an earlier v1.5 build, select your existing ROM in a freshly
opened copy of the compatibility patcher, keep the detected options, and
choose Build ROM. The patcher also accepts v1.4 and supported older builds.
For a plain Regular or MoleMan ROM you can instead apply the matching BPS
from Upgrade. Both clean North American retail revisions are supported.

START WITH THE INCLUDED ALL-IN-ONE PATCHER

1. Open Tools/Compatibility_Patcher/FFVI_SNES_Advance_Compatibility_Patcher.html
   in a current desktop browser and select your clean North American Final
   Fantasy III v1.0 or v1.1 (Rev 1) ROM. Copier headers are handled automatically.
2. Choose Regular or MoleMan GBA Text. For MoleMan, supply the original
   standard BPS or its ZIP, obtained separately from the project listed below.
   v1.8 is the current tested source; v1.6 remains supported.
3. Choose Apply base edition. The tool automatically selects the correct
   original-ROM revision. Download the verified base, or choose optional
   compatibility features and build them before downloading.

Both original revisions produce the same current base for the chosen edition
and MoleMan source. Existing SNES Advance ROMs can still be opened directly.
The standalone BPS and Merge.html routes below remain available.

PATCH THE GAME • REGULAR SNES TEXT

1. Extract this ZIP. Use a clean North American Final Fantasy III SNES ROM.
   The headerless file is 3,145,728 bytes. If yours is 3,146,240 bytes,
   remove the 512-byte copier header from a copy before patching.
2. Check the source CRC32 in your BPS patcher and apply the matching file.

   Original ROM       Source CRC32     File in Patches/
   USA v1.0           A27F1C7A         Regular_from_USA_v1.0.bps
   USA v1.1 (Rev 1)   C0FA0464         Regular_from_USA_v1.1.bps

3. Save the patched ROM as FFVI_Advance_v1.5.sfc and open it in your
   SNES emulator. Either patch produces the same Regular edition.

   BPS patchers
   Floating IPS      https://github.com/Alcaro/Flips
   Rom Patcher JS    https://www.marcrobledo.com/RomPatcher.js/

OPTIONAL GBA TEXT BY MOLEMAN

1. Obtain MoleMan’s Final Fantasy VI - GBA Text separately. Use its standard
   edition, which keeps the pop-culture references. v1.8 is the current tested
   source; v1.6 is still supported. The original patch is not included here.
   Project listing   https://www.romhacking.net/hacks/5864/

2. Open Tools/Merge.html in a desktop browser. Select your clean USA v1.0
   or v1.1 ROM and MoleMan’s BPS. You can also select the patched Regular
   ROM from the previous section. The merger works offline and
   accepts a ROM with a 512-byte copier header.
3. Choose “Build merged ROM”, then “Download verified ROM”. Open
   the downloaded MoleMan ROM in your emulator.

   Both finished ROMs are 4,194,304 bytes, headerless.
   Regular edition CRC32     3B56ABF0
   MoleMan v1.6 CRC32        E32CC561
   MoleMan v1.8 CRC32        FA35D88F
   MoleMan output checksums depend on the supplied translation revision.
   See V1.5_SHORELINE_TESTS.txt for current release checks and MOLEMAN_V18_VALIDATION.txt
   for the historical translation checks.

OPTIONAL PATCHES • INCLUDED COMPATIBILITY TOOL

Open this file in a current desktop browser:
   Tools/Compatibility_Patcher/FFVI_SNES_Advance_Compatibility_Patcher.html

Select your SNES Advance ROM, or prepare a clean original as described above,
choose compatible options, then Build ROM and Download ROM. The tool works offline and processes your files locally.
It offers the supported battle systems, GBA fonts, Spanish, TWUE editions,
ROSE and Music Player options. Its README and original author credits are
included in the same folder. Third-party patches and game ROMs are not bundled;
the tool requests the original source files when a newly selected option
requires them.

You do not need to know which spell-name revision you have. The same tool
automatically recognizes the original v0.9.20 Regular/MoleMan releases, this
updated release, and supported older outputs from the compatibility patcher,
including the earlier eight-cell full-name Gravija builds. A ROM's filename
does not determine its version. Headered copies are also recognized.

When reopening an existing patcher build, keep its detected choices and build
to apply the current corrections. Installed font/music sources are reused.
Native Regular/Spanish builds use Gravja; MoleMan, TWUE, ROSE and optional GBA
font builds retain Gravija. The separately downloaded compatibility tool is
the same file and accepts the same older ROMs; this ZIP is not needed to run it.

UPGRADE AN EXISTING ROM

The compatibility patcher accepts recognized builds with optional patches.
For standalone editions, apply the BPS matching your ROM and source version.

   Turtle-idle v1.5 Regular      Upgrade/Regular_from_idle_v1.5.bps
   Turtle-idle v1.5 MoleMan 1.6  Upgrade/MoleMan16_from_idle_v1.5.bps
   Turtle-idle v1.5 MoleMan 1.8  Upgrade/MoleMan18_from_idle_v1.5.bps
   Water-fix v1.5 Regular      Upgrade/Regular_from_water_v1.5.bps
   Water-fix v1.5 MoleMan 1.6  Upgrade/MoleMan16_from_water_v1.5.bps
   Water-fix v1.5 MoleMan 1.8  Upgrade/MoleMan18_from_water_v1.5.bps
   Initial v1.5 Regular      Upgrade/Regular_from_initial_v1.5.bps
   Initial v1.5 MoleMan 1.6  Upgrade/MoleMan16_from_initial_v1.5.bps
   Initial v1.5 MoleMan 1.8  Upgrade/MoleMan18_from_initial_v1.5.bps
   v1.4 Regular              Upgrade/Regular_from_v1.4.bps
   v1.4 MoleMan GBA Text 1.6  Upgrade/MoleMan16_from_v1.4.bps
   v1.4 MoleMan GBA Text 1.8  Upgrade/MoleMan18_from_v1.4.bps

The v0.9.19, v0.9.20, and v0.9.21 upgrade patches in the same folder now
produce v1.5 in a single step. The v0.9.21 label also covers the first public
v1.3 upload. BPS checks the source ROM's contents. To change MoleMan text
versions, use the merger with the translation version you want.

Keep your original SRAM filename paired with the updated ROM. Boot the game
and load the battery save from the title screen. The save importer is for
original-game SRAM. See V1.5_SKILL_TESTS.txt for coverage and test conditions.

SPELL-NAME AND ICON CORRECTION (RETAINED)

Regular uses the black-magic icon followed by "Gravja" in the original
seven-cell spell record. The separate cast-announcement name also reads
"Gravja". Valor uses the support/effect-magic icon. Those earlier spelling
and icon edits only changed name data, with no extra name-reading CPU work.
The separate Continue instruction repair in this refresh is described above.

MoleMan retains the full "Gravija" spelling in its existing nine-cell records,
with the black-magic icon, and uses the correct Valor icon. Its two battle
Magic columns now call the existing expanded spell-name reader, correcting
the routing for the added spells. No new name table or reader is allocated.

The included compatibility patcher retains the full "Gravija" spelling in
its full-name-capable editions and optional GBA-font builds. Use the included
tool when adding those options to either the older or corrected base ROM.

CHOOSE HOW TO PLAY

New game
   Choose New Game on the title screen.

Try the bonus content right away
   Open “Practice Saves/Start here.txt”. Three optional battery saves give
   you nine starting points, including the Soul Shrine ghost, the Dragon’s
   Den entrance, and the esper encounters. The same saves work with either
   edition. The guide explains how to try them alongside your own game.

Continue an original North American SNES save
   Back up your original battery save. Open Tools/FFVI_SNES_Save_Importer.html
   in a desktop browser and select the 8,192-byte .srm or .sav written by
   the original SNES game. Select only the original-game slots you want to
   import, then choose “Download compatible save”. The selected slots
   start the bonus content fresh. The tool copies the other slots as-is.

   Close the emulator and back up any same-named save before placing the
   downloaded file in its battery-save folder. Match the ROM’s basename
   (for example, FFVI_Advance_v1.5.srm for FFVI_Advance_v1.5.sfc).
   Open the ROM and load the slot at the title screen. The practice saves
   are already in SNES Advance format and can be loaded directly.


CREDITS

Final Fantasy VI, Final Fantasy VI Advance, and the original game assets
and music are by Square / Square Enix. The FFVI disassembly and FF6Tools
are by everything8215 and contributors. The project uses Terii Senshi’s
Vanish/Doom fix and the disassembly’s Evade fix.
https://github.com/everything8215/ff6
https://github.com/everything8215/ff6tools
https://www.rpglegion.com/ff6/hack/vanish.htm
https://www.rpglegion.com/ff6/hack/evade.htm

MoleMan created the optional GBA Text hack. His original release lists
its additional contributors. Floating IPS is by Alcaro and contributors.
The FantasyAnime FF6 save collection was used in earlier compatibility tests.
